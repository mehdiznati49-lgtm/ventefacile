import frData from './locales/fr.json';
import arData from './locales/ar.json';
import enData from './locales/en.json';
import esData from './locales/es.json';

/**
 * Creates a resilient Proxy around a language dictionary.
 * Rules:
 * 1. If key exists and is non-empty in target language, returns it.
 * 2. If key is missing, undefined, null, or empty string "", gracefully falls back to French ('fr').
 * 3. Never returns `undefined` (returns '' or fallback), eliminating accidental empty parentheses `( )` in UI.
 */
export function createSafeTranslationProxy(langData, fallbackData = frData) {
  return new Proxy(langData || {}, {
    get(target, prop) {
      if (typeof prop === 'symbol') return target[prop];
      if (prop in Object.prototype) return target[prop];

      const val = target[prop];
      if (val !== undefined && val !== null && String(val).trim() !== '') {
        return val;
      }

      const fallbackVal = fallbackData ? fallbackData[prop] : undefined;
      if (fallbackVal !== undefined && fallbackVal !== null && String(fallbackVal).trim() !== '') {
        return fallbackVal;
      }

      // Return empty string instead of undefined to prevent orphaned '( )' or 'undefined' in DOM
      return '';
    }
  });
}

// Proxied individual dictionaries
const safeFr = createSafeTranslationProxy(frData, frData);
const safeAr = createSafeTranslationProxy(arData, frData);
const safeEn = createSafeTranslationProxy(enData, frData);
const safeEs = createSafeTranslationProxy(esData, frData);

// Base translations map
const baseTranslations = {
  fr: safeFr,
  ar: safeAr,
  en: safeEn,
  es: safeEs
};

/**
 * Safe multi-lingual dictionary with automatic French fallback on unknown languages
 */
export const translations = new Proxy(baseTranslations, {
  get(target, prop) {
    if (typeof prop === 'symbol') return target[prop];
    if (prop in target) return target[prop];
    // Fallback to French if language unknown (e.g. invalid code)
    return target.fr;
  }
});

/**
 * Functional resolver for a given language code
 * @param {string} lang - 'fr' | 'ar' | 'en' | 'es'
 * @returns {Proxy} Safe dictionary
 */
export function getTranslation(lang = 'fr') {
  return translations[lang] || translations.fr;
}

/**
 * One-off translation helper with explicit fallback
 */
export function t(key, lang = 'fr', customFallback = '') {
  const dict = getTranslation(lang);
  const val = dict[key];
  if (val && String(val).trim() !== '') return val;
  if (customFallback && String(customFallback).trim() !== '') return customFallback;
  return frData[key] || '';
}

/**
 * Format helper that only wraps in parentheses if the content is non-empty.
 * Prevents rendering empty parentheses `( )` or `()` in the UI.
 * @param {*} val - Value to wrap
 * @returns {string} e.g. "(15)" or "" if empty/null
 */
export function formatWithParens(val) {
  if (val === undefined || val === null) return '';
  const str = String(val).trim();
  if (!str) return '';
  return `(${str})`;
}
