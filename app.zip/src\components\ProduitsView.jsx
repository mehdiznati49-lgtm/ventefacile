import React, { useState } from 'react';
import {
  Plus,
  Trash2,
  Edit3,
  FileSpreadsheet,
  Zap,
  Scale,
  Calendar,
  Tag,
  Search,
  Check,
  Download,
  Upload,
  Barcode,
  Printer,
  Layers,
  Percent,
  Sliders,
  CheckCircle2,
  Truck,
  PackageCheck,
  AlertCircle,
  AlertTriangle,
  Sparkles,
  Image as ImageIcon
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { translations } from '../translations';
import { db, initialProducts, recordSupplierInvoice, loadProductDemoData, clearProductData } from '../db';
import { parseSafeFloat, sanitizeDecimalInput } from '../utils/numberUtils';
import { getLocalDateString } from '../utils/dateUtils';
import { sanitizeProductsForRole } from '../authSecurity';
import { useToast } from '../context/ToastContext';
import { syncManager } from '../syncManager';
import { searchProducts } from '../utils/searchEngine';
import { exportProductsXLSX, downloadExcelTemplate, parseAndValidateExcel } from '../utils/excelEngine';

export default function ProduitsView({ 
  products, 
  settings, 
  currentLang, 
  onRefreshData,
  onOpenScanner,
  isAdmin = true,
  userRole = 'admin'
}) {
  const toast = useToast();
  const t = translations[currentLang] || translations.fr;
  // Par défaut en Dirhams marocains (DH / MAD) pour le commerce de détail
  const currency = settings.currency || 'DH';
  const isStoreConfigured = Boolean(settings?.isStoreConfigured);

  // Strict Data Sanitization: Purge supplier buy prices if current profile is Cashier
  const displayProducts = React.useMemo(() => {
    return sanitizeProductsForRole(products, isAdmin);
  }, [products, isAdmin]);

  const [activeSubTab, setActiveSubTab] = useState('liste'); // liste, ajouter, excel, etiquette, reassort
  const [searchFilter, setSearchFilter] = useState('');
  const [editingProduct, setEditingProduct] = useState(null);

  // Supplier Restocking / Réassort State (Connecté au crédit fournisseur)
  const [reassortItems, setReassortItems] = useState([]);
  const [reassortSearch, setReassortSearch] = useState('');
  const [supplierName, setSupplierName] = useState('Grossiste Parfums & Cosmétiques Luxe');
  const [selectedSupplierId, setSelectedSupplierId] = useState(null);
  const [availableSuppliers, setAvailableSuppliers] = useState([]);
  const [deliveryNoteRef, setDeliveryNoteRef] = useState('');
  const [reassortPaymentTerms, setReassortPaymentTerms] = useState('comptant'); // 'comptant', 'acompte', 'credit'
  const [reassortPaidAmount, setReassortPaidAmount] = useState('');
  const [reassortPaymentMethod, setReassortPaymentMethod] = useState('especes');
  const [reassortDeductCash, setReassortDeductCash] = useState(true);

  // Charger les fournisseurs disponibles
  React.useEffect(() => {
    if (activeSubTab === 'reassort') {
      db.suppliers.toArray().then(sups => {
        setAvailableSuppliers(sups || []);
        if (sups && sups.length > 0 && !selectedSupplierId) {
          setSelectedSupplierId(sups[0].id);
          setSupplierName(sups[0].name);
        }
      });
    }
  }, [activeSubTab]);


  // Smart Default Category based on Business Type
  const defaultCategory = React.useMemo(() => {
    switch (settings?.businessType) {
      case 'epicerie':
      case 'restauration':
        return 'Épicerie & Alimentation';
      case 'hightech':
        return 'High-Tech & Smartphones';
      case 'mode':
        return 'Mode & Chaussures';
      case 'quincaillerie':
      case 'cadeaux':
      case 'general':
        return 'Autre';
      case 'parfumerie':
      case 'pharmacie':
      default:
        return 'Parfumerie & Beauté';
    }
  }, [settings?.businessType]);

  // Form State for Adding / Editing Product
  const [formData, setFormData] = useState({
    barcode: '',
    name: '',
    brand: '',
    category: defaultCategory,
    buyPrice: '',
    sellPrice: '',
    vatRate: defaultCategory === 'Épicerie & Alimentation' ? 5.5 : 20,
    stock: '1',
    minStock: 3,
    isWeight: false,
    unit: 'unité',
    variantsText: '', // comma separated ex: 150 ml, 25 ml, 175 ml, Pointure 42
    expiryDate: '',
    image: ''
  });

  const [formErrors, setFormErrors] = useState({});

  // Auto-VAT Smart Detector based on category
  const handleCategoryChange = (cat) => {
    let autoVat = 20;
    if (cat.includes('Épicerie') || cat.includes('Alimentation')) {
      autoVat = 5.5;
    }
    setFormData({ ...formData, category: cat, vatRate: autoVat });
  };

  // Explicit Form Validation Function (Strict rules)
  const validateForm = () => {
    const errors = {};
    if (!formData.name || !formData.name.trim()) {
      errors.name = 'Le nom du produit est obligatoire.';
    }

    // Duplicate barcode validation against existing products (excluding self if editing)
    if (formData.barcode && formData.barcode.trim()) {
      const code = formData.barcode.trim();
      const duplicate = products.find(p => p.barcode === code && (!editingProduct || p.id !== editingProduct.id));
      if (duplicate) {
        errors.barcode = `Le code-barres "${code}" est déjà utilisé par "${duplicate.name}".`;
      }
    }

    // Prices and stock must be strictly positive or zero (>= 0)
    if (isAdmin) {
      const parsedBuy = parseSafeFloat(formData.buyPrice, NaN);
      if (formData.buyPrice === '' || isNaN(parsedBuy) || parsedBuy < 0) {
        errors.buyPrice = 'Le prix d\'achat est requis et doit être positif ou nul (>= 0).';
      }
    }
    const parsedSell = parseSafeFloat(formData.sellPrice, NaN);
    if (formData.sellPrice === '' || isNaN(parsedSell) || parsedSell < 0) {
      errors.sellPrice = 'Le prix de vente est requis et doit être un nombre positif (>= 0).';
    } else if (parsedSell <= 0) {
      errors.sellPrice = 'Le prix de vente doit être strictement supérieur à 0.';
    }
    const parsedStock = parseSafeFloat(formData.stock, NaN);
    if (formData.stock === '' || isNaN(parsedStock) || parsedStock < 0) {
      errors.stock = 'La quantité en stock doit être un nombre positif ou nul (>= 0).';
    }
    return errors;
  };

  // Submit Add / Edit Form
  const handleSubmitForm = async (e) => {
    e.preventDefault();
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
      setFormErrors(validationErrors);
      const firstError = Object.values(validationErrors)[0];
      toast.error(firstError, 'Validation Produit');
      return;
    }
    setFormErrors({});

    const variantsArray = formData.variantsText 
      ? formData.variantsText.split(',').map(v => v.trim()).filter(Boolean)
      : [];

    const computedBuyPrice = isAdmin 
      ? (parseSafeFloat(formData.buyPrice, 0))
      : (editingProduct ? (editingProduct.buyPrice || 0) : 0);

    const productPayload = {
      barcode: formData.barcode ? formData.barcode.trim() : Date.now().toString().slice(-12),
      name: formData.name.trim(),
      brand: formData.brand.trim() || 'Générique',
      category: formData.category,
      buyPrice: computedBuyPrice,
      sellPrice: parseSafeFloat(formData.sellPrice, 0),
      vatRate: parseSafeFloat(formData.vatRate, 20),
      stock: parseSafeFloat(formData.stock, 0),
      minStock: parseInt(parseSafeFloat(formData.minStock, 3)) || 3,
      isWeight: formData.isWeight,
      unit: formData.unit || 'unité',
      variants: variantsArray,
      expiryDate: formData.expiryDate,
      image: formData.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&q=80',
      synced: false,
      updatedAt: new Date().toISOString()
    };

    if (editingProduct) {
      await db.products.update(editingProduct.id, productPayload);
      toast.success(`Produit "${productPayload.name}" mis à jour avec succès.`, 'Catalogue');
    } else {
      await db.products.add(productPayload);
      toast.success(`Produit "${productPayload.name}" enregistré avec succès.`, 'Catalogue');
    }

    // Trigger cloud synchronization
    syncManager.syncNow().catch(() => {});

    // Try to sync with server if available
    try {
      fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(productPayload)
      }).catch(() => {});
    } catch (err) {}

    setEditingProduct(null);
    setFormData({
      barcode: '', name: '', brand: '', category: defaultCategory,
      buyPrice: '', sellPrice: '', vatRate: defaultCategory === 'Épicerie & Alimentation' ? 5.5 : 20, 
      stock: '1', minStock: 3,
      isWeight: false, 
      unit: 'unité', 
      variantsText: '', expiryDate: '', image: ''
    });
    setFormErrors({});
    setActiveSubTab('liste');
    if (onRefreshData) onRefreshData();
  };


  // Delete Product
  const handleDeleteProduct = async (id) => {
    const prod = products.find(p => p.id === id);
    const ok = await toast.confirm({
      title: "Supprimer le produit",
      message: prod ? `Voulez-vous supprimer "${prod.name}" du catalogue ?` : "Confirmer la suppression ?",
      confirmText: "Supprimer",
      variant: "danger"
    });
    if (!ok) return;

    await db.products.delete(id);
    if (onRefreshData) onRefreshData();
    toast.info(prod ? `"${prod.name}" a été supprimé du catalogue.` : 'Produit supprimé du catalogue.', 'Suppression');
  };

  // Export Products to Excel (.xlsx) with professional styling
  const handleExportExcel = () => {
    try {
      exportProductsXLSX(displayProducts, currency);
      toast.success("Catalogue exporté avec succès au format Excel (.xlsx) !", "Export Réussi");
    } catch (e) {
      toast.error("Erreur lors de l'export Excel : " + e.message);
    }
  };

  // Download blank sample Excel template
  const handleDownloadTemplate = () => {
    try {
      downloadExcelTemplate(currency);
      toast.info("Modèle Excel vierge téléchargé avec succès !", "Modèle Téléchargé");
    } catch (e) {
      toast.error("Erreur lors du téléchargement du modèle : " + e.message);
    }
  };

  // Import Products from Excel (.xlsx, .csv) with Smart Auto-Mapping & Validation
  const handleImportExcel = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      toast.info("Analyse du fichier Excel en cours...", "Importation");
      const result = await parseAndValidateExcel(file);

      if (!result.success) {
        toast.warning(result.message || "Le fichier Excel sélectionné est vide ou non reconnu.", "Fichier invalide");
        return;
      }

      const { validRows, errorRows } = result;

      if (validRows.length === 0) {
        toast.error(`Aucun produit valide trouvé dans le fichier. ${errorRows.length} lignes comportent des erreurs.`);
        return;
      }

      let importedCount = 0;
      let updatedCount = 0;

      for (const row of validRows) {
        const existing = products.find(p => p.barcode === row.barcode);
        if (existing) {
          await db.products.update(existing.id, {
            name: row.name,
            brand: row.brand || existing.brand,
            category: row.category || existing.category,
            buyPrice: row.buyPrice,
            sellPrice: row.sellPrice,
            vatRate: row.vatRate,
            stock: existing.stock + row.stock,
            unit: row.unit || existing.unit,
            expiryDate: row.expiryDate || existing.expiryDate,
            synced: false,
            updatedAt: new Date().toISOString()
          });
          updatedCount++;
        } else {
          await db.products.add({
            barcode: row.barcode,
            name: row.name,
            brand: row.brand,
            category: row.category,
            buyPrice: row.buyPrice,
            sellPrice: row.sellPrice,
            vatRate: row.vatRate,
            stock: row.stock,
            minStock: row.minStock || 3,
            unit: row.unit || 'unité',
            expiryDate: row.expiryDate,
            image: 'https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=400&q=80',
            synced: false,
            updatedAt: new Date().toISOString()
          });
          importedCount++;
        }
      }

      syncManager.syncNow().catch(() => {});
      if (onRefreshData) onRefreshData();

      let msg = `${importedCount} articles ajoutés, ${updatedCount} mis à jour.`;
      if (errorRows.length > 0) {
        msg += ` (${errorRows.length} lignes ignorées car incomplètes)`;
      }
      toast.success(msg, "Importation Excel réussie");
    } catch (err) {
      console.error("Erreur lecture Excel", err);
      toast.error(err.message, "Erreur de lecture Excel");
    } finally {
      e.target.value = '';
    }
  };

  const handleLoadDemoProducts = async () => {
    try {
      await loadProductDemoData();
      if (onRefreshData) await onRefreshData();
      toast.success("Articles de démonstration chargés avec succès !");
    } catch (err) {
      console.error(err);
      toast.error("Erreur lors du chargement des produits : " + err.message);
    }
  };

  const handleClearProducts = async () => {
    const ok = await toast.confirm({
      title: "Vider le catalogue d'exemples",
      message: "Voulez-vous supprimer les exemples de produits pour repartir sur un catalogue 100% vide ?",
      confirmText: "Vider les exemples",
      variant: "danger"
    });
    if (!ok) return;

    try {
      await clearProductData();
      if (onRefreshData) await onRefreshData();
      toast.info("Catalogue de produits vidé avec succès.");
    } catch (err) {
      console.error(err);
      toast.error("Erreur lors de la suppression : " + err.message);
    }
  };

  // High-Performance Fuzzy Search with Arabic & Accent Normalization
  const filteredList = React.useMemo(() => {
    return searchProducts(displayProducts, searchFilter, { enableFuzzy: true });
  }, [displayProducts, searchFilter]);

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 space-y-6 pb-36 sm:pb-16">
      
      {/* Sub Tabs Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full no-scrollbar">
          <button
            onClick={() => setActiveSubTab('liste')}
            className={`px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition ${
              activeSubTab === 'liste'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Tous les Produits ({displayProducts.length})</span>
          </button>

          <button
            onClick={() => {
              setEditingProduct(null);
              setFormData({
                barcode: '', name: '', brand: '', category: defaultCategory,
                buyPrice: '', sellPrice: '', vatRate: defaultCategory === 'Épicerie & Alimentation' ? 5.5 : 20, 
                stock: '', minStock: 3,
                isWeight: false, 
                unit: 'unité', 
                variantsText: '', expiryDate: '', image: ''
              });
              setActiveSubTab('ajouter');
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition ${
              activeSubTab === 'ajouter'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>{t.ajouterProduit}</span>
          </button>


          {isAdmin && (
            <button
              onClick={() => setActiveSubTab('reassort')}
              className={`px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition ${
                activeSubTab === 'reassort'
                  ? 'bg-teal-600 text-white shadow-sm'
                  : 'bg-teal-50 text-teal-700 dark:bg-teal-950/60 dark:text-teal-300'
              }`}
            >
              <Truck className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <span>📦 Réassort Fournisseur</span>
            </button>
          )}


          <label className="cursor-pointer px-3.5 py-2 rounded-xl text-xs font-extrabold bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 hover:bg-blue-100 transition flex items-center gap-1.5">
            <Upload className="w-4 h-4" />
            <span>Import Excel (.xlsx)</span>
            <input
              type="file"
              accept=".xlsx, .xls, .csv"
              onChange={handleImportExcel}
              className="hidden"
            />
          </label>

          <button
            onClick={handleExportExcel}
            className="px-3.5 py-2 rounded-xl text-xs font-extrabold bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 hover:bg-emerald-200 transition flex items-center gap-1.5"
            title="Exporter tout le catalogue avec prix, stocks et marges"
          >
            <Download className="w-4 h-4" />
            <span>Export Excel (.xlsx)</span>
          </button>

          <button
            onClick={handleDownloadTemplate}
            className="px-3 py-2 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300 transition flex items-center gap-1.5"
            title="Télécharger un modèle Excel pré-rempli pour importer facilement vos articles"
          >
            <FileSpreadsheet className="w-4 h-4 text-indigo-500" />
            <span>Modèle Vierge</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          {!isStoreConfigured && isAdmin && (
            displayProducts.length === 0 ? (
              <button
                onClick={handleLoadDemoProducts}
                className="px-3.5 py-2 rounded-xl text-xs font-extrabold bg-amber-50 hover:bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-300/50 flex items-center gap-1.5 transition active:scale-95 shadow-sm"
                title="Charger un catalogue de produits d'exemple"
              >
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>🌟 Charger Produits Exemple</span>
              </button>
            ) : (
              <button
                onClick={handleClearProducts}
                className="px-3 py-2 rounded-xl text-xs font-extrabold bg-slate-100 hover:bg-red-50 text-slate-600 hover:text-red-600 dark:bg-slate-800 dark:hover:bg-red-950/40 dark:text-slate-300 border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 transition active:scale-95"
                title="Supprimer les exemples pour vider le catalogue"
              >
                <Trash2 className="w-3.5 h-3.5 text-red-500" />
                <span>🧹 Supprimer les exemples</span>
              </button>
            )
          )}

          <button
            onClick={onOpenScanner}
            className="px-3.5 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl text-xs font-bold shadow-sm flex items-center gap-1.5"
          >
            <Zap className="w-4 h-4 text-yellow-300 animate-pulse" />
            <span>Scanner & Détecter 📷</span>
          </button>
        </div>
      </div>

      {/* Tab Content 1: Products List */}
      {activeSubTab === 'liste' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                type="text"
                placeholder="Filtrer la liste..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl"
              />
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-400 font-bold border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="p-3">Produit</th>
                    {isAdmin && <th className="p-3">Prix Achat</th>}
                    <th className="p-3">Prix Vente</th>
                    {isAdmin && <th className="p-3">Bénéfice</th>}
                    <th className="p-3">TVA</th>
                    <th className="p-3">Stock</th>
                    <th className="p-3">Péremption</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredList.map(p => {
                    const profit = isAdmin && p.buyPrice !== undefined ? (p.sellPrice - p.buyPrice) : null;
                    return (
                      <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                        <td className="p-3">
                          <div className="flex items-center gap-3">
                            {p.image ? (
                              <img 
                                src={p.image} 
                                alt="" 
                                onError={(e) => { e.currentTarget.style.display = 'none'; e.currentTarget.nextElementSibling?.classList.remove('hidden'); }}
                                className="w-8 h-8 rounded-lg object-cover bg-slate-100 dark:bg-slate-800" 
                              />
                            ) : null}
                            <div className={`${p.image ? 'hidden' : ''} w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-[10px]`}>
                              {p.name.slice(0, 2).toUpperCase()}
                            </div>
                            <div>
                              <span className="font-bold text-slate-900 dark:text-white block">{p.name}</span>
                              <span className="text-[10px] text-indigo-600 dark:text-indigo-400 font-semibold">{p.brand} • {p.category}</span>
                            </div>
                          </div>
                        </td>
                        {isAdmin && (
                          <td className="p-3 font-semibold text-slate-600 dark:text-slate-400">
                            {p.buyPrice !== undefined ? `${Number(p.buyPrice || 0).toFixed(2)} ${currency}` : '—'}
                          </td>
                        )}
                        <td className="p-3 font-extrabold text-slate-900 dark:text-white">{Number(p.sellPrice || 0).toFixed(2)} {currency}</td>
                        {isAdmin && (
                          <td className="p-3 font-extrabold text-emerald-600 dark:text-emerald-400">
                            {profit !== null ? `+${Number(profit || 0).toFixed(2)} ${currency}` : '—'}
                          </td>
                        )}
                        <td className="p-3 font-semibold text-slate-600 dark:text-slate-400">{p.vatRate}%</td>
                        <td className="p-3">
                          <span className={`font-bold px-2 py-0.5 rounded-md ${p.stock <= (p.minStock || 3) ? 'bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300' : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'}`}>
                            {p.stock} {p.unit || ''}
                          </span>
                        </td>
                        <td className="p-3 text-slate-500 font-medium">{p.expiryDate || 'N/A'}</td>
                        <td className="p-3 text-right space-x-1">
                          <button
                            onClick={() => {
                              setEditingProduct(p);
                              setFormData({
                                barcode: p.barcode,
                                name: p.name,
                                brand: p.brand,
                                category: p.category,
                                buyPrice: (isAdmin && p.buyPrice !== undefined) ? p.buyPrice.toString() : '',
                                sellPrice: p.sellPrice.toString(),
                                vatRate: p.vatRate || 20,
                                stock: p.stock.toString(),
                                minStock: p.minStock || 3,
                                isWeight: p.isWeight || false,
                                unit: p.unit || 'unité',
                                variantsText: (p.variants || []).join(', '),
                                expiryDate: p.expiryDate || '',
                                image: p.image || ''
                              });
                              setActiveSubTab('ajouter');
                            }}
                            className="p-1.5 text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950 rounded-lg"
                            title={t.modifier}
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteProduct(p.id)}
                            className="p-1.5 text-red-500 hover:bg-red-50 dark:hover:bg-red-950 rounded-lg"
                            title={t.supprimer}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {filteredList.length === 0 && (
                <div className="py-14 px-4 text-center space-y-4">
                  <div className="w-16 h-16 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 rounded-2xl flex items-center justify-center mx-auto text-2xl">
                    <PackageCheck className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-base text-slate-800 dark:text-slate-200">
                      {searchFilter ? 'Aucun produit ne correspond à votre recherche' : 'Votre catalogue de produits est actuellement vide'}
                    </h4>
                    <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                      {searchFilter 
                        ? 'Essayez avec un autre terme ou code-barres.'
                        : !isStoreConfigured 
                          ? 'Vous pouvez charger des articles de démonstration (avec photos, stocks, marges et codes-barres) ou créer directement vos vrais articles.'
                          : 'Votre catalogue est 100% prêt pour vos marchandises. Cliquez ci-dessous pour ajouter votre premier produit.'}
                    </p>
                  </div>
                  {!searchFilter && (
                    <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                      {!isStoreConfigured && isAdmin && (
                        <button
                          onClick={handleLoadDemoProducts}
                          className="py-2.5 px-5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-95 text-white rounded-xl text-xs font-extrabold shadow-md shadow-indigo-500/20 transition active:scale-95 flex items-center gap-1.5"
                        >
                          <Sparkles className="w-4 h-4 text-amber-300" />
                          <span>🌟 Charger Produits Exemple</span>
                        </button>
                      )}
                      <button
                        onClick={() => {
                          setEditingProduct(null);
                          setActiveSubTab('ajouter');
                        }}
                        className="py-2.5 px-5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-extrabold shadow-sm transition active:scale-95 flex items-center gap-1.5"
                      >
                        <Plus className="w-4 h-4" />
                        <span>+ Nouveau Produit Réel</span>
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Tab Content 2: Add / Edit Form */}
      {activeSubTab === 'ajouter' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-4 border-b border-slate-200 dark:border-slate-800 pb-3">
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
              {editingProduct ? '✏️ Modifier Produit' : '➕ Nouveau Produit'}
            </h3>
            <button onClick={() => setActiveSubTab('liste')} className="text-xs text-slate-500 hover:underline">
              Annuler
            </button>
          </div>

          <form onSubmit={handleSubmitForm} noValidate className="space-y-4 text-xs">
            
            {/* Bannière récapitulative des erreurs de saisie */}
            {Object.keys(formErrors).length > 0 && (
              <div className="p-3.5 bg-rose-50 dark:bg-rose-950/60 border border-rose-300 dark:border-rose-800 rounded-2xl text-xs text-rose-700 dark:text-rose-300 font-bold flex items-start gap-2.5 animate-in fade-in">
                <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5 text-rose-600" />
                <div>
                  <p className="font-extrabold text-sm">Champs obligatoires manquants ou invalides :</p>
                  <ul className="list-disc list-inside mt-1 space-y-0.5 font-semibold text-rose-600 dark:text-rose-400">
                    {Object.values(formErrors).map((err, i) => (
                      <li key={i}>{err}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                  Nom du produit <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="Ex: Eau de Parfum Sauvage 100ml"
                  value={formData.name}
                  onChange={(e) => {
                    setFormData({ ...formData, name: e.target.value });
                    if (formErrors.name) setFormErrors({ ...formErrors, name: null });
                  }}
                  className={`w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl placeholder:text-slate-400/60 placeholder:italic transition-all ${
                    formErrors.name 
                      ? 'border-rose-500 ring-2 ring-rose-200 dark:ring-rose-950 bg-rose-50/20' 
                      : 'border-slate-200 dark:border-slate-700'
                  }`}
                />
                {formErrors.name && (
                  <p className="text-[11px] text-rose-500 font-bold mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{formErrors.name}</span>
                  </p>
                )}
              </div>

              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">Marque / Fabricant</label>
                <input
                  type="text"
                  placeholder="Ex: Dior, Chanel, Apple, Nike..."
                  value={formData.brand}
                  onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl placeholder:text-slate-400/60 placeholder:italic"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">Catégorie (Auto-TVA)</label>
                <select
                  value={formData.category}
                  onChange={(e) => handleCategoryChange(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
                >
                  <option value="Parfumerie & Beauté">🌸 Parfumerie & Beauté</option>
                  <option value="Épicerie & Alimentation">🛒 Épicerie & Alimentation</option>
                  <option value="High-Tech & Smartphones">📱 High-Tech & Smartphones</option>
                  <option value="Mode & Chaussures">👕 Mode & Chaussures</option>
                  <option value="Autre">📦 Autre</option>
                </select>
              </div>

              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">Code-Barres (EAN/UPC)</label>
                <div className="flex gap-1">
                  <input
                    type="text"
                    placeholder="Ex: 3360372058878"
                    value={formData.barcode}
                    onChange={(e) => {
                      setFormData({ ...formData, barcode: e.target.value });
                      if (formErrors.barcode) setFormErrors({ ...formErrors, barcode: null });
                    }}
                    className={`w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl placeholder:text-slate-400/60 placeholder:italic font-mono transition-all ${
                      formErrors.barcode 
                        ? 'border-rose-500 ring-2 ring-rose-200 dark:ring-rose-950 bg-rose-50/20' 
                        : 'border-slate-200 dark:border-slate-700'
                    }`}
                  />
                  <button 
                    type="button" 
                    onClick={onOpenScanner} 
                    className="px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl flex items-center justify-center shadow-sm"
                    title="Scanner via la caméra"
                  >
                    📷
                  </button>
                </div>
                {formErrors.barcode && (
                  <p className="text-[11px] text-rose-500 font-bold mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{formErrors.barcode}</span>
                  </p>
                )}
              </div>
            </div>

            {/* Prices & VAT */}
            <div className={`grid grid-cols-1 ${isAdmin ? 'sm:grid-cols-3' : 'sm:grid-cols-2'} gap-3 p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700`}>
              {isAdmin && (
                <div>
                  <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                    Prix d'Achat ({currency}) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    inputMode="decimal"
                    placeholder="Ex: 50.00"
                    value={formData.buyPrice}
                    onChange={(e) => {
                      const val = sanitizeDecimalInput(e.target.value);
                      setFormData({ ...formData, buyPrice: val });
                      if (formErrors.buyPrice) setFormErrors({ ...formErrors, buyPrice: null });
                    }}
                    className={`w-full p-2.5 bg-white dark:bg-slate-900 border rounded-xl font-bold placeholder:text-slate-400/60 placeholder:italic placeholder:font-normal transition-all ${
                      formErrors.buyPrice 
                        ? 'border-rose-500 ring-2 ring-rose-200 dark:ring-rose-950 bg-rose-50/20' 
                        : 'border-slate-200 dark:border-slate-700'
                    }`}
                  />
                  {formErrors.buyPrice && (
                    <p className="text-[11px] text-rose-500 font-bold mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{formErrors.buyPrice}</span>
                    </p>
                  )}
                </div>
              )}

              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                  Prix de Vente ({currency}) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  placeholder="Ex: 110.00"
                  value={formData.sellPrice}
                  onChange={(e) => {
                    const val = sanitizeDecimalInput(e.target.value);
                    setFormData({ ...formData, sellPrice: val });
                    if (formErrors.sellPrice) setFormErrors({ ...formErrors, sellPrice: null });
                  }}
                  className={`w-full p-2.5 bg-white dark:bg-slate-900 border rounded-xl font-extrabold text-indigo-600 dark:text-indigo-400 placeholder:text-slate-400/60 placeholder:italic placeholder:font-normal transition-all ${
                    formErrors.sellPrice 
                      ? 'border-rose-500 ring-2 ring-rose-200 dark:ring-rose-950 bg-rose-50/20' 
                      : 'border-slate-200 dark:border-slate-700'
                  }`}
                />
                {formErrors.sellPrice && (
                  <p className="text-[11px] text-rose-500 font-bold mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{formErrors.sellPrice}</span>
                  </p>
                )}
              </div>

              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">TVA (%)</label>
                <input
                  type="text"
                  inputMode="decimal"
                  placeholder="Ex: 20"
                  value={formData.vatRate}
                  onChange={(e) => setFormData({ ...formData, vatRate: sanitizeDecimalInput(e.target.value) })}
                  className="w-full p-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl font-bold placeholder:text-slate-400/60 placeholder:italic"
                />
              </div>
            </div>

            {/* Net profit preview - STRICTLY ADMIN ONLY */}
            {isAdmin && parseSafeFloat(formData.sellPrice, 0) > 0 && parseSafeFloat(formData.buyPrice, 0) >= 0 && (
              <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl text-xs font-bold text-emerald-700 dark:text-emerald-300 flex justify-between">
                <span>Marge Bénéficiaire Réelle :</span>
                <span>+{(parseSafeFloat(formData.sellPrice, 0) - parseSafeFloat(formData.buyPrice, 0)).toFixed(2)} {currency} par article</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                  Quantité en Stock Initial <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  placeholder="Ex: 10"
                  value={formData.stock}
                  onChange={(e) => {
                    const val = sanitizeDecimalInput(e.target.value);
                    setFormData({ ...formData, stock: val });
                    if (formErrors.stock) setFormErrors({ ...formErrors, stock: null });
                  }}
                  className={`w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold placeholder:text-slate-400/60 placeholder:italic placeholder:font-normal transition-all ${
                    formErrors.stock 
                      ? 'border-rose-500 ring-2 ring-rose-200 dark:ring-rose-950 bg-rose-50/20' 
                      : 'border-slate-200 dark:border-slate-700'
                  }`}
                />
                {formErrors.stock && (
                  <p className="text-[11px] text-rose-500 font-bold mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{formErrors.stock}</span>
                  </p>
                )}
              </div>

              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                  Seuil d'Alerte Stock Minimum
                </label>
                <input
                  type="number"
                  min="0"
                  placeholder="Ex: 3"
                  value={formData.minStock}
                  onChange={(e) => setFormData({ ...formData, minStock: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
                />
                <span className="text-[10px] text-slate-400">Alerte lorsque le stock passe sous ce seuil.</span>
              </div>
            </div>

            {/* Vente au Poids & Unité de Mesure */}
            <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className={`p-2 rounded-xl transition-colors ${formData.isWeight ? 'bg-amber-100 dark:bg-amber-900/50 text-amber-600 dark:text-amber-400' : 'bg-slate-200 dark:bg-slate-700 text-slate-500'}`}>
                    <Scale className="w-4 h-4" />
                  </div>
                  <div>
                    <label htmlFor="isWeightToggle" className="text-xs font-bold text-slate-800 dark:text-slate-200 cursor-pointer">
                      Article Vendu au Poids (Vrac / Balance)
                    </label>
                    <p className="text-[10px] text-slate-400">
                      {formData.isWeight 
                        ? 'La caisse ouvrira le clavier balance lors du scan pour saisir le poids (ex: 1.25 kg).'
                        : 'Article standard vendu à la pièce / unité (ajout direct au panier).'
                      }
                    </p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    id="isWeightToggle"
                    type="checkbox"
                    checked={formData.isWeight}
                    onChange={(e) => {
                      const checked = e.target.checked;
                      setFormData({
                        ...formData,
                        isWeight: checked,
                        unit: checked && formData.unit === 'unité' ? 'kg' : (!checked && formData.unit === 'kg' ? 'unité' : formData.unit)
                      });
                    }}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
                <div>
                  <label className="block text-[11px] font-bold mb-1 text-slate-700 dark:text-slate-300">
                    Unité de Mesure Affichée
                  </label>
                  <select
                    value={formData.unit}
                    onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                    className="w-full p-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold"
                  >
                    <option value="unité">Unité (pièce, article)</option>
                    <option value="kg">Kilogramme (kg)</option>
                    <option value="g">Gramme (g)</option>
                    <option value="L">Litre (L)</option>
                    <option value="cl">Centilitre (cl)</option>
                    <option value="m">Mètre (m)</option>
                    <option value="paquet">Paquet / Sachet</option>
                    <option value="boîte">Boîte / Carton</option>
                    <option value="portion">Portion</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold mb-1 text-slate-700 dark:text-slate-300">
                    Date de Péremption (Optionnel)
                  </label>
                  <input
                    type="date"
                    value={formData.expiryDate}
                    onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })}
                    className="w-full p-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium"
                  />
                </div>
              </div>
            </div>

            {/* Image du Produit avec Aperçu en Direct */}
            <div>
              <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                Image du Produit (URL Web)
              </label>
              <div className="flex items-center gap-3">
                <div className="relative w-14 h-14 rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0 shadow-inner">
                  {formData.image ? (
                    <img
                      src={formData.image}
                      alt="Aperçu"
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.target.onerror = null;
                        e.target.src = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&q=80';
                      }}
                    />
                  ) : (
                    <ImageIcon className="w-6 h-6 text-slate-400" />
                  )}
                </div>
                <div className="flex-1 space-y-1">
                  <div className="relative flex items-center">
                    <input
                      type="url"
                      placeholder="https://exemple.com/photo-article.jpg"
                      value={formData.image}
                      onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                      className="w-full p-2.5 pr-8 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs placeholder:text-slate-400/60 placeholder:italic"
                    />
                    {formData.image && (
                      <button
                        type="button"
                        onClick={() => setFormData({ ...formData, image: '' })}
                        className="absolute right-2.5 text-xs text-slate-400 hover:text-rose-500 font-bold"
                        title="Effacer l'URL"
                      >
                        ✕
                      </button>
                    )}
                  </div>
                  <span className="text-[10px] text-slate-400 block">
                    Collez l'adresse d'une image web. Laissez vide pour utiliser l'image générique par défaut.
                  </span>
                </div>
              </div>
            </div>

            {/* Variants Saisie Libre */}
            <div>
              <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                Variantes à Saisie Libre (Séparées par des virgules) :
              </label>
              <input
                type="text"
                placeholder="Ex: 50 ml, 100 ml, 150 ml, Pointure 42, Noir, Rose..."
                value={formData.variantsText}
                onChange={(e) => setFormData({ ...formData, variantsText: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl placeholder:text-slate-400/60 placeholder:italic"
              />
              <span className="text-[10px] text-slate-400">Tapez n'importe quelle contenance, taille ou couleur personnalisée.</span>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-extrabold rounded-xl shadow-md text-xs hover:opacity-95"
            >
              {editingProduct ? 'Enregistrer les Modifications ✅' : 'Ajouter le Produit au Catalogue ✅'}
            </button>
          </form>
        </div>
      )}

      {/* Tab Content: Supplier Restocking / Réassort & Arrivages en Lot */}
      {activeSubTab === 'reassort' && (
        !isAdmin ? (
          <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm max-w-md mx-auto my-8">
            <span className="text-3xl block mb-2">🔒</span>
            <h4 className="font-extrabold text-base mb-1">Accès Réservé au Gérant</h4>
            <p className="text-xs text-slate-500 mb-4">La réception de marchandise et les prix d'achat grossistes sont confidentiels.</p>
            <button onClick={() => setActiveSubTab('liste')} className="px-4 py-2 bg-indigo-600 text-white text-xs font-bold rounded-xl">
              Retour au Catalogue
            </button>
          </div>
        ) : (
        <div className="space-y-6">
          {/* Top Banner & Supplier Header */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-teal-100 text-teal-600 dark:bg-teal-950 dark:text-teal-300 rounded-2xl">
                  <Truck className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                    Réassort Fournisseur & Réception de Marchandises
                  </h3>
                  <p className="text-xs text-slate-500">
                    Ajoutez en lot les articles livrés pour incrémenter le stock et actualiser les prix d'achat
                  </p>
                </div>
              </div>

              {reassortItems.length > 0 && (
                <button
                  onClick={async () => {
                    if (reassortItems.length === 0) return;
                    for (const item of reassortItems) {
                      const prod = await db.products.get(item.productId);
                      if (prod) {
                        const newStock = Math.max(0, prod.stock + (parseSafeFloat(item.addedQty, 0)));
                        const newBuyPrice = parseSafeFloat(item.buyPrice, prod.buyPrice);
                        await db.products.update(item.productId, { 
                          stock: newStock, 
                          buyPrice: newBuyPrice,
                          synced: false,
                          updatedAt: new Date().toISOString()
                        });
                      }
                    }
                    syncManager.syncNow().catch(() => {});
                    toast.success(`Arrivage de ${reassortItems.length} article(s) validé avec succès.`, "Stock mis à jour");
                    setReassortItems([]);
                    if (onRefreshData) onRefreshData();
                  }}
                  className="py-2.5 px-5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:opacity-95 text-white font-extrabold rounded-2xl text-xs shadow-md shadow-teal-500/20 flex items-center gap-2"
                >
                  <PackageCheck className="w-4 h-4" />
                  <span>Valider l'Arrivage ({reassortItems.length} articles)</span>
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">Fournisseur / Grossiste :</label>
                <div className="space-y-1.5">
                  <select
                    value={selectedSupplierId || ''}
                    onChange={(e) => {
                      const id = parseInt(e.target.value);
                      setSelectedSupplierId(id || null);
                      const s = availableSuppliers.find(sup => sup.id === id);
                      if (s) setSupplierName(s.name);
                    }}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold"
                  >
                    {availableSuppliers.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.name} {parseSafeFloat(s.debt, 0) > 0 ? `(Dette : ${parseSafeFloat(s.debt, 0).toFixed(2)} ${currency})` : '(À jour)'}
                      </option>
                    ))}
                    <option value="">+ Nouveau Fournisseur (Saisir ci-dessous)</option>
                  </select>

                  {!selectedSupplierId && (
                    <input
                      type="text"
                      value={supplierName}
                      onChange={(e) => setSupplierName(e.target.value)}
                      placeholder="Nom du nouveau grossiste..."
                      className="w-full p-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-semibold text-xs"
                    />
                  )}
                </div>
              </div>

              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">N° Bon de Livraison / Facture :</label>
                <input
                  type="text"
                  value={deliveryNoteRef}
                  onChange={(e) => setDeliveryNoteRef(e.target.value)}
                  placeholder="ex: BL-2026-0894"
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono font-bold"
                />
              </div>
            </div>
          </div>

          {/* Search & Add Products to Restocking Queue */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
            <h4 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Search className="w-4 h-4 text-teal-600" />
              <span>Sélectionner ou Scanner les Articles Reçus</span>
            </h4>

            <div className="relative">
              <input
                type="text"
                placeholder="Scanner code-barres ou chercher un produit par nom ou marque..."
                value={reassortSearch}
                onChange={(e) => setReassortSearch(e.target.value)}
                className="w-full p-3 pl-10 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl font-bold text-xs"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            </div>

            {/* Quick Picker Suggestions */}
            {reassortSearch.trim() && (
              <div className="max-h-48 overflow-y-auto space-y-1.5 p-2 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700">
                {products
                  .filter(p => 
                    p.name.toLowerCase().includes(reassortSearch.toLowerCase()) || 
                    (p.brand && p.brand.toLowerCase().includes(reassortSearch.toLowerCase())) ||
                    p.barcode.includes(reassortSearch)
                  )
                  .slice(0, 8)
                  .map(p => (
                    <div
                      key={p.id}
                      onClick={() => {
                        const existingIdx = reassortItems.findIndex(i => i.productId === p.id);
                        if (existingIdx > -1) {
                          const updated = [...reassortItems];
                          updated[existingIdx].addedQty += 10;
                          setReassortItems(updated);
                        } else {
                          setReassortItems([
                            ...reassortItems,
                            {
                              productId: p.id,
                              barcode: p.barcode,
                              name: p.name,
                              currentStock: p.stock,
                              addedQty: 10,
                              buyPrice: p.buyPrice,
                              unit: p.unit || 'unité'
                            }
                          ]);
                        }
                        setReassortSearch('');
                      }}
                      className="p-2 rounded-xl bg-white dark:bg-slate-900 hover:bg-teal-50 dark:hover:bg-teal-950/40 cursor-pointer flex items-center justify-between text-xs border border-slate-100 dark:border-slate-800"
                    >
                      <div>
                        <span className="font-bold text-slate-900 dark:text-white">{p.name}</span>
                        <span className="text-[10px] text-slate-400 block">{p.brand} • Stock actuel : {p.stock}</span>
                      </div>
                      <span className="text-teal-600 font-extrabold text-[11px]">+ Ajouter au Réassort</span>
                    </div>
                  ))}
              </div>
            )}
          </div>

          {/* Staged Reassortment Table */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">
                Articles en Cours de Réception ({reassortItems.length})
              </h4>
              {reassortItems.length > 0 && (
                <button
                  onClick={() => setReassortItems([])}
                  className="text-xs text-rose-500 hover:text-rose-700 font-bold"
                >
                  Vider la liste
                </button>
              )}
            </div>

            {reassortItems.length === 0 ? (
              <div className="text-center py-10 text-slate-400 text-xs border border-dashed border-slate-200 dark:border-slate-700 rounded-2xl">
                <Truck className="w-8 h-8 mx-auto text-slate-300 dark:text-slate-600 mb-2" />
                <span>Aucun produit sélectionné pour ce réassort. Cherchez un produit ci-dessus ou scannez son code-barres.</span>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-700 text-slate-400 text-[11px] uppercase font-bold">
                      <th className="py-2.5">Produit</th>
                      <th className="py-2.5 text-center">Stock Actuel</th>
                      <th className="py-2.5 text-center">Quantité Reçue</th>
                      <th className="py-2.5 text-center">Nouveau Stock</th>
                      <th className="py-2.5 text-right">Prix Achat HT</th>
                      <th className="py-2.5 text-right">Total Ligne</th>
                      <th className="py-2.5 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {reassortItems.map((item, idx) => {
                      const totalLine = (parseFloat(item.addedQty) || 0) * (parseFloat(item.buyPrice) || 0);
                      const projectedStock = item.currentStock + (parseFloat(item.addedQty) || 0);
                      return (
                        <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                          <td className="py-2.5 font-bold text-slate-800 dark:text-slate-200">
                            <div>{item.name}</div>
                            <span className="font-mono text-[10px] text-slate-400">{item.barcode}</span>
                          </td>
                          <td className="py-2.5 text-center font-semibold text-slate-500">
                            {item.currentStock} {item.unit}
                          </td>
                          <td className="py-2.5 text-center">
                            <input
                              type="text"
                              inputMode="decimal"
                              value={item.addedQty}
                              onChange={(e) => {
                                const updated = [...reassortItems];
                                updated[idx].addedQty = sanitizeDecimalInput(e.target.value);
                                setReassortItems(updated);
                              }}
                              className="w-20 p-1 text-center font-extrabold bg-slate-100 dark:bg-slate-800 border rounded-lg text-xs text-teal-600 dark:text-teal-400"
                            />
                          </td>
                          <td className="py-2.5 text-center font-extrabold text-emerald-600">
                            {projectedStock} {item.unit}
                          </td>
                          <td className="py-2.5 text-right">
                            <input
                              type="text"
                              inputMode="decimal"
                              value={item.buyPrice}
                              onChange={(e) => {
                                const updated = [...reassortItems];
                                updated[idx].buyPrice = sanitizeDecimalInput(e.target.value);
                                setReassortItems(updated);
                              }}
                              className="w-20 p-1 text-right font-bold bg-slate-100 dark:bg-slate-800 border rounded-lg text-xs"
                            />
                          </td>
                          <td className="py-2.5 text-right font-extrabold text-slate-900 dark:text-white">
                            {totalLine.toFixed(2)} {currency}
                          </td>
                          <td className="py-2.5 text-right">
                            <button
                              onClick={() => setReassortItems(reassortItems.filter((_, i) => i !== idx))}
                              className="p-1 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950 rounded-lg"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {reassortItems.length > 0 && (() => {
              const totalRestockAmount = reassortItems.reduce((sum, item) => sum + ((parseSafeFloat(item.addedQty, 0)) * (parseSafeFloat(item.buyPrice, 0))), 0);
              let effectivePaid = 0;
              if (reassortPaymentTerms === 'comptant') effectivePaid = totalRestockAmount;
              else if (reassortPaymentTerms === 'credit') effectivePaid = 0;
              else effectivePaid = Math.min(totalRestockAmount, Math.max(0, parseSafeFloat(reassortPaidAmount, 0)));
              const remainingDebt = Math.max(0, totalRestockAmount - effectivePaid);

              const handleValidateArrivage = async () => {
                const finalSupplierName = supplierName.trim() || 'Grossiste Principal';
                const finalBL = deliveryNoteRef.trim() || `BL-${Date.now().toString().slice(-6)}`;

                for (const item of reassortItems) {
                  const prod = await db.products.get(item.productId);
                  if (prod) {
                    const newStock = Math.max(0, prod.stock + (parseSafeFloat(item.addedQty, 0)));
                    const newBuyPrice = parseSafeFloat(item.buyPrice, prod.buyPrice);
                    await db.products.update(item.productId, { 
                      stock: newStock, 
                      buyPrice: newBuyPrice,
                      synced: false,
                      updatedAt: new Date().toISOString()
                    });
                  }
                }
                syncManager.syncNow().catch(() => {});

                await recordSupplierInvoice({
                  supplierId: selectedSupplierId,
                  supplierName: finalSupplierName,
                  invoiceNumber: finalBL,
                  items: reassortItems,
                  totalAmount: totalRestockAmount,
                  paidAmount: effectivePaid,
                  paymentMethod: reassortPaymentMethod,
                  deductFromCashDrawer: reassortPaymentMethod === 'especes' && reassortDeductCash && effectivePaid > 0,
                  cashier: 'Gérant'
                });

                toast.success(`📦 Arrivage validé ! Stock et prix d'achat actualisés.`);
                if (remainingDebt > 0) {
                  toast.info(`⚠️ Dette fournisseur enregistrée : ${remainingDebt.toFixed(2)} ${currency} ajoutée sur la fiche de ${finalSupplierName}.`);
                }

                setReassortItems([]);
                setDeliveryNoteRef('');
                setReassortPaidAmount('');
                if (onRefreshData) onRefreshData();
              };

              return (
                <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-4 text-xs">
                  {/* Financial Settlement Terms Panel */}
                  <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="text-slate-700 dark:text-slate-300 font-bold">
                        Montant Total de l'Arrivage : <span className="text-base text-teal-600 font-black">{totalRestockAmount.toFixed(2)} {currency}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-extrabold text-[11px] text-slate-500 uppercase mr-1">Modalité de Paiement :</span>
                        <button
                          type="button"
                          onClick={() => setReassortPaymentTerms('comptant')}
                          className={`px-3 py-1.5 rounded-xl font-extrabold text-[11px] transition ${
                            reassortPaymentTerms === 'comptant'
                              ? 'bg-emerald-600 text-white shadow-sm'
                              : 'bg-white dark:bg-slate-900 border text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          🟢 100% Comptant
                        </button>
                        <button
                          type="button"
                          onClick={() => setReassortPaymentTerms('acompte')}
                          className={`px-3 py-1.5 rounded-xl font-extrabold text-[11px] transition ${
                            reassortPaymentTerms === 'acompte'
                              ? 'bg-amber-600 text-white shadow-sm'
                              : 'bg-white dark:bg-slate-900 border text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          🟡 Acompte Partiel
                        </button>
                        <button
                          type="button"
                          onClick={() => setReassortPaymentTerms('credit')}
                          className={`px-3 py-1.5 rounded-xl font-extrabold text-[11px] transition ${
                            reassortPaymentTerms === 'credit'
                              ? 'bg-red-600 text-white shadow-sm'
                              : 'bg-white dark:bg-slate-900 border text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          🔴 100% à Crédit
                        </button>
                      </div>
                    </div>

                    {/* Partial down payment inputs */}
                    {reassortPaymentTerms === 'acompte' && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-200 dark:border-slate-700">
                        <div>
                          <label className="block font-bold mb-1">Montant Acompte Versé Immédiatement ({currency}) :</label>
                          <input
                            type="number"
                            step="0.01"
                            value={reassortPaidAmount}
                            onChange={(e) => setReassortPaidAmount(e.target.value)}
                            placeholder={`ex: ${(totalRestockAmount / 2).toFixed(2)}`}
                            className="w-full p-2 bg-white dark:bg-slate-900 border rounded-xl font-mono font-bold text-teal-600"
                          />
                        </div>
                        <div className="p-2.5 bg-red-50 dark:bg-red-950/40 rounded-xl border border-red-200 dark:border-red-900 flex items-center justify-between">
                          <span className="font-bold text-red-800 dark:text-red-300">Reste Dû au Grossiste (Crédit) :</span>
                          <span className="font-black text-red-600 dark:text-red-400 text-sm">
                            {remainingDebt.toFixed(2)} {currency}
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Cash drawer deduction toggle if cash */}
                    {effectivePaid > 0 && (
                      <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-200 dark:border-slate-700">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-[11px] text-slate-500">Moyen de paiement de l'acompte :</span>
                          {['especes', 'virement', 'cheque'].map(m => (
                            <button
                              key={m}
                              type="button"
                              onClick={() => setReassortPaymentMethod(m)}
                              className={`px-2.5 py-1 rounded-lg font-bold text-[10px] capitalize transition ${
                                reassortPaymentMethod === m
                                  ? 'bg-teal-600 text-white'
                                  : 'bg-white dark:bg-slate-900 border text-slate-600 dark:text-slate-400'
                              }`}
                            >
                              {m}
                            </button>
                          ))}
                        </div>

                        {reassortPaymentMethod === 'especes' && (
                          <label className="flex items-center gap-2 cursor-pointer text-slate-700 dark:text-slate-300">
                            <input
                              type="checkbox"
                              checked={reassortDeductCash}
                              onChange={(e) => setReassortDeductCash(e.target.checked)}
                              className="w-4 h-4 text-teal-600 rounded"
                            />
                            <span className="font-bold">Déduire {effectivePaid.toFixed(2)} {currency} du tiroir-caisse</span>
                          </label>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="text-slate-500 font-semibold">
                      Dette finale générée : <strong className={remainingDebt > 0 ? 'text-red-600' : 'text-emerald-600'}>{remainingDebt.toFixed(2)} {currency}</strong>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => window.print()}
                        className="py-2.5 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold rounded-xl flex items-center gap-1.5"
                      >
                        <Printer className="w-4 h-4" />
                        <span>Imprimer Bon d'Entrée</span>
                      </button>

                      <button
                        onClick={handleValidateArrivage}
                        className="py-2.5 px-5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:opacity-95 text-white font-extrabold rounded-xl shadow-md shadow-teal-500/20 flex items-center gap-1.5"
                      >
                        <PackageCheck className="w-4 h-4" />
                        <span>Valider Arrivage & Enregistrer Crédit</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>

        </div>
        )
      )}

    </div>
  );
}
