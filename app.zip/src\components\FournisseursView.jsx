import React, { useState, useEffect } from 'react';
import { 
  Truck, 
  Plus, 
  Search, 
  Phone, 
  MapPin, 
  DollarSign, 
  CreditCard, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  MessageSquare, 
  Calendar, 
  ArrowUpRight, 
  ArrowDownRight, 
  Printer, 
  UserCheck, 
  Layers, 
  Trash2, 
  Edit3, 
  ExternalLink,
  ShieldCheck,
  Building,
  Check,
  Clock
} from 'lucide-react';
import { db, recordSupplierPayment, loadSupplierDemoData, clearSupplierData } from '../db';
import { parseSafeFloat, sanitizeDecimalInput } from '../utils/numberUtils';
import { translations } from '../translations';
import { useToast } from '../context/ToastContext';
import { printReceiptThermal } from '../thermalPrinter';

export default function FournisseursView({ 
  settings, 
  currentLang = 'fr', 
  onRefreshData,
  isAdmin = true 
}) {
  const toast = useToast();
  const t = translations[currentLang] || translations.fr;
  const currency = settings?.currency || 'DH';
  const isStoreConfigured = Boolean(settings?.isStoreConfigured);

  const [activeTab, setActiveTab] = useState('fournisseurs'); // 'fournisseurs' | 'factures' | 'reglements'
  const [searchFilter, setSearchFilter] = useState('');
  
  // Data states
  const [suppliers, setSuppliers] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [payments, setPayments] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Modal States
  const [showSupplierModal, setShowSupplierModal] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState(null);
  const [supplierFormData, setSupplierFormData] = useState({
    name: '',
    phone: '',
    contactPerson: '',
    address: '',
    category: 'Parfumerie & Beauté',
    debt: '0',
    notes: ''
  });

  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedSupplierForPayment, setSelectedSupplierForPayment] = useState(null);
  const [paymentFormData, setPaymentFormData] = useState({
    amount: '',
    paymentMethod: 'especes',
    checkNumber: '',
    dueDate: '',
    deductFromCashDrawer: true,
    notes: ''
  });
  const [printingPayment, setPrintingPayment] = useState(null);

  // Invoice Details Modal
  const [inspectedInvoice, setInspectedInvoice] = useState(null);

  // Load suppliers and related data
  const loadSuppliersData = async () => {
    setIsLoading(true);
    try {
      const sups = await db.suppliers.toArray();
      const invs = await db.supplierInvoices.orderBy('date').reverse().toArray();
      const pays = await db.supplierPayments.orderBy('date').reverse().toArray();
      setSuppliers(sups || []);
      setInvoices(invs || []);
      setPayments(pays || []);
    } catch (err) {
      console.error('[FournisseursView] Erreur chargement', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadSuppliersData();
  }, []);

  // Summary Metrics
  const totalSupplierDebt = suppliers.reduce((sum, s) => sum + (parseSafeFloat(s.debt, 0)), 0);
  const totalPaidToSuppliers = payments.reduce((sum, p) => sum + (parseSafeFloat(p.amount, 0)), 0);
  const suppliersWithDebtCount = suppliers.filter(s => (parseSafeFloat(s.debt, 0)) > 0).length;

  // Filtered suppliers
  const filteredSuppliers = suppliers.filter(s => 
    (s.name && s.name.toLowerCase().includes(searchFilter.toLowerCase())) ||
    (s.contactPerson && s.contactPerson.toLowerCase().includes(searchFilter.toLowerCase())) ||
    String(s.phone || '').includes(searchFilter) ||
    (s.category && s.category.toLowerCase().includes(searchFilter.toLowerCase()))
  );

  // Open Add/Edit Supplier Modal
  const handleOpenSupplierModal = (sup = null) => {
    if (sup) {
      setEditingSupplier(sup);
      setSupplierFormData({
        name: sup.name || '',
        phone: sup.phone || '',
        contactPerson: sup.contactPerson || '',
        address: sup.address || '',
        category: sup.category || 'Général',
        debt: sup.debt ? String(sup.debt) : '0',
        notes: sup.notes || ''
      });
    } else {
      setEditingSupplier(null);
      setSupplierFormData({
        name: '',
        phone: '',
        contactPerson: '',
        address: '',
        category: 'Parfumerie & Beauté',
        debt: '0',
        notes: ''
      });
    }
    setShowSupplierModal(true);
  };

  // Save Supplier
  const handleSaveSupplier = async (e) => {
    e.preventDefault();
    if (!supplierFormData.name.trim()) {
      toast.error('Le nom du fournisseur est obligatoire.');
      return;
    }

    try {
      const payload = {
        name: supplierFormData.name.trim(),
        phone: supplierFormData.phone.trim(),
        contactPerson: supplierFormData.contactPerson.trim(),
        address: supplierFormData.address.trim(),
        category: supplierFormData.category,
        debt: parseSafeFloat(supplierFormData.debt, 0),
        notes: supplierFormData.notes.trim()
      };

      if (editingSupplier) {
        await db.suppliers.update(editingSupplier.id, payload);
        toast.success(`Fournisseur "${payload.name}" mis à jour.`);
      } else {
        payload.createdAt = new Date().toISOString();
        await db.suppliers.add(payload);
        toast.success(`Fournisseur "${payload.name}" ajouté avec succès.`);
      }

      setShowSupplierModal(false);
      await loadSuppliersData();
      if (onRefreshData) onRefreshData();
    } catch (err) {
      console.error('[FournisseursView] Erreur sauvegarde', err);
      toast.error('Erreur lors de l\'enregistrement : ' + err.message);
    }
  };

  // Delete Supplier
  const handleDeleteSupplier = async (sup) => {
    const hasDebt = (parseSafeFloat(sup.debt, 0)) > 0;
    const ok = await toast.confirm({
      title: "Supprimer le fournisseur",
      message: hasDebt 
        ? `Attention : Ce fournisseur a une dette non réglée de ${sup.debt} ${currency}. Confirmer la suppression ?`
        : `Voulez-vous supprimer le fournisseur "${sup.name}" ?`,
      confirmText: "Supprimer",
      variant: "danger"
    });
    if (!ok) return;

    try {
      await db.suppliers.delete(sup.id);
      toast.success(`Fournisseur "${sup.name}" supprimé.`);
      await loadSuppliersData();
      if (onRefreshData) onRefreshData();
    } catch (err) {
      toast.error('Impossible de supprimer : ' + err.message);
    }
  };

  // Open Payment Modal
  const handleOpenPaymentModal = (sup) => {
    setSelectedSupplierForPayment(sup);
    setPaymentFormData({
      amount: sup ? String(sup.debt || '') : '',
      paymentMethod: 'especes',
      checkNumber: '',
      dueDate: '',
      deductFromCashDrawer: true,
      notes: `Règlement compte fournisseur ${sup?.name || ''}`
    });
    setShowPaymentModal(true);
  };

  // Submit Payment
  const handleSavePayment = async (e) => {
    e.preventDefault();
    const amt = parseSafeFloat(paymentFormData.amount, 0);
    if (!amt || amt <= 0) {
      toast.error('Veuillez saisir un montant de versement valide.');
      return;
    }

    if (!selectedSupplierForPayment) {
      toast.error('Veuillez sélectionner un fournisseur.');
      return;
    }

    try {
      await recordSupplierPayment({
        supplierId: selectedSupplierForPayment.id,
        supplierName: selectedSupplierForPayment.name,
        amount: amt,
        paymentMethod: paymentFormData.paymentMethod,
        checkNumber: paymentFormData.checkNumber,
        dueDate: paymentFormData.dueDate,
        deductFromCashDrawer: paymentFormData.deductFromCashDrawer,
        notes: paymentFormData.notes,
        cashier: 'Gérant'
      });

      toast.success(`Règlement de ${amt.toFixed(2)} ${currency} enregistré pour ${selectedSupplierForPayment.name} !`);
      setShowPaymentModal(false);
      await loadSuppliersData();
      if (onRefreshData) onRefreshData();
    } catch (err) {
      console.error('[FournisseursView] Erreur versement', err);
      toast.error('Erreur lors du versement : ' + err.message);
    }
  };

  // Charger un exemple complet de fournisseurs avec dettes et factures
  const handleLoadDemoSuppliers = async () => {
    try {
      await loadSupplierDemoData();
      await loadSuppliersData();
      if (onRefreshData) await onRefreshData();
      toast.success('Données d\'exemple Fournisseurs chargées avec succès !');
    } catch (err) {
      console.error(err);
      toast.error('Erreur chargement démo : ' + err.message);
    }
  };

  // Vider tous les fournisseurs pour laisser la table 100% vierge
  const handleClearSuppliers = async () => {
    const ok = await toast.confirm({
      title: "Effacer les fournisseurs",
      message: "Voulez-vous effacer tous les fournisseurs pour repartir sur une liste 100% vide ?",
      confirmText: "Effacer la liste",
      variant: "danger"
    });
    if (!ok) return;

    try {
      await clearSupplierData();
      await loadSuppliersData();
      if (onRefreshData) await onRefreshData();
      toast.success('Fournisseurs effacés avec succès. La liste est maintenant vide.');
    } catch (err) {
      console.error(err);
      toast.error('Erreur suppression : ' + err.message);
    }
  };

  // WhatsApp Message to Supplier
  const handleWhatsAppSupplier = (sup) => {
    if (!sup.phone) {
      toast.error('Ce fournisseur n\'a pas de numéro de téléphone renseigné.');
      return;
    }

    const cleanPhone = sup.phone.replace(/[^0-9+]/g, '');
    const debtMsg = (parseSafeFloat(sup.debt, 0)) > 0
      ? `Le solde restant de notre compte chez vous est actuellement de ${parseSafeFloat(sup.debt, 0).toFixed(2)} ${currency}.`
      : `Notre compte chez vous est à jour (0.00 ${currency}).`;

    const message = encodeURIComponent(
      `Bonjour ${sup.contactPerson || sup.name},\n\n` +
      `Ici ${settings?.shopName || 'la boutique'}.\n` +
      `${debtMsg}\n\n` +
      `Merci pour votre collaboration et à très bientôt !`
    );

    window.open(`https://wa.me/${cleanPhone}?text=${message}`, '_blank');
  };

  // Print Payment Receipt
  const handlePrintPaymentReceipt = (payment) => {
    setPrintingPayment(payment);
    const textReceipt = `
========================================
     BON DE RÈGLEMENT FOURNISSEUR
========================================
Boutique : ${settings?.shopName || 'VenteFacile Pro'}
Date : ${new Date(payment.date).toLocaleString()}
Réf : PAY-SUP-${payment.id}

FOURNISSEUR : ${payment.supplierName}
Mode : ${payment.paymentMethod?.toUpperCase()}
${payment.checkNumber ? `N° Chèque/Traite : ${payment.checkNumber}` : ''}
${payment.dueDate ? `Échéance : ${payment.dueDate}` : ''}
----------------------------------------
MONTANT VERSÉ : ${Number(payment.amount).toFixed(2)} ${currency}
${payment.deductedFromCashDrawer ? '(*) Déduit du tiroir-caisse de la boutique' : ''}
----------------------------------------
Notes : ${payment.notes || 'Règlement de dette grossiste'}

Signature Livreur / Fournisseur :



========================================
`.trim();

    printReceiptThermal(textReceipt, settings);
  };

  if (!isAdmin) {
    return (
      <div className="max-w-md mx-auto my-16 p-8 bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-slate-200 dark:border-slate-800 text-center animate-in fade-in">
        <div className="w-16 h-16 bg-amber-100 dark:bg-amber-950/50 text-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4 text-3xl">
          🔒
        </div>
        <h3 className="text-xl font-bold mb-2">Accès Réservé au Gérant</h3>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">
          La gestion des fournisseurs, des prix d'achats grossistes et des dettes d'approvisionnement est strictement réservée au profil Administrateur.
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 space-y-6 pb-36 sm:pb-16 animate-in fade-in duration-200">
      
      {/* Top Header & Quick Action Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white font-display flex items-center gap-2">
            <Truck className="w-6 h-6 text-teal-600 dark:text-teal-400" />
            <span>Gestion Fournisseurs & Crédits Grossistes</span>
            <span className="text-[11px] font-mono font-bold bg-teal-50 dark:bg-teal-950/80 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800 px-2.5 py-0.5 rounded-full">
              B2B
            </span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Suivi des dettes de la boutique, règlements d'acomptes, factures d'arrivage et historique d'approvisionnement
          </p>
        </div>

        <div className="flex items-center gap-2">
          {!isStoreConfigured && isAdmin && (
            suppliers.length === 0 ? (
              <button
                onClick={handleLoadDemoSuppliers}
                className="px-3 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-95 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-sm transition active:scale-95"
                title="Charger un exemple de démonstration (Grossistes, dettes et factures)"
              >
                <span>🌟 Charger un Exemple (Démo)</span>
              </button>
            ) : (
              <button
                onClick={handleClearSuppliers}
                className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-red-50 text-slate-600 hover:text-red-600 dark:bg-slate-800 dark:hover:bg-red-950/40 dark:text-slate-300 font-extrabold text-xs flex items-center gap-1.5 transition border border-slate-200 dark:border-slate-700"
                title="Supprimer les exemples de fournisseurs pour laisser la table 100% vierge"
              >
                <Trash2 className="w-3.5 h-3.5 text-red-500" />
                <span>🧹 Supprimer les exemples</span>
              </button>
            )
          )}

          <button
            onClick={() => handleOpenPaymentModal(null)}
            className="px-3 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:opacity-95 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-sm transition active:scale-95"
          >
            <DollarSign className="w-4 h-4" />
            <span className="hidden sm:inline">Régler</span>
          </button>

          <button
            onClick={() => handleOpenSupplierModal(null)}
            className="px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-sm transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Nouveau Fournisseur</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Grid (Financial Pulse of Supplier Debts) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Total Supplier Debt (Dettes fournisseurs totales) */}
        <div className={`rounded-3xl p-5 shadow-lg border relative overflow-hidden transition-all ${
          totalSupplierDebt > 0 
            ? 'bg-gradient-to-br from-red-600 to-rose-700 text-white border-red-500/30 shadow-red-500/20' 
            : 'bg-gradient-to-br from-emerald-600 to-teal-700 text-white border-emerald-500/30 shadow-emerald-500/20'
        }`}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider opacity-90">
              Total Dû aux Grossistes
            </span>
            <div className="p-2 bg-white/20 rounded-xl backdrop-blur-sm">
              <Truck className="w-5 h-5 text-white" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black mb-1">
            {totalSupplierDebt.toFixed(2)} <span className="text-base font-semibold">{currency}</span>
          </div>
          <div className="text-xs font-medium opacity-90 flex items-center gap-1">
            {totalSupplierDebt > 0 ? (
              <>
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{suppliersWithDebtCount} fournisseur(s) en attente de solde</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Toutes vos dettes fournisseurs sont à jour !</span>
              </>
            )}
          </div>
        </div>

        {/* Card 2: Total Suppliers Count */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Fournisseurs Référencés
            </span>
            <div className="p-2 bg-teal-50 text-teal-600 dark:bg-teal-950 dark:text-teal-400 rounded-xl">
              <Building className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mb-1">
            {suppliers.length}
          </div>
          <span className="text-xs text-slate-500 font-medium">Partenaires et grossistes actifs</span>
        </div>

        {/* Card 3: Total Invoices Count */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Factures d'Arrivage
            </span>
            <div className="p-2 bg-blue-50 text-blue-600 dark:bg-blue-950 dark:text-blue-400 rounded-xl">
              <FileText className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mb-1">
            {invoices.length}
          </div>
          <span className="text-xs text-slate-500 font-medium">Livraisons enregistrées en stock</span>
        </div>

        {/* Card 4: Total Payments Settled */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Règlements Effectués
            </span>
            <div className="p-2 bg-emerald-50 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400 rounded-xl">
              <CreditCard className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mb-1">
            {totalPaidToSuppliers.toFixed(2)} <span className="text-base font-semibold text-slate-500">{currency}</span>
          </div>
          <span className="text-xs text-slate-500 font-medium">Total des versements enregistrés</span>
        </div>

      </div>

      {/* Tabs Switcher Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 p-2.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full no-scrollbar">
          
          <button
            onClick={() => setActiveTab('fournisseurs')}
            className={`px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition ${
              activeTab === 'fournisseurs'
                ? 'bg-teal-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            <Building className="w-4 h-4" />
            <span>Répertoire Fournisseurs ({suppliers.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('factures')}
            className={`px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition ${
              activeTab === 'factures'
                ? 'bg-teal-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Bons de Livraison & Factures ({invoices.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('reglements')}
            className={`px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition ${
              activeTab === 'reglements'
                ? 'bg-teal-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            <DollarSign className="w-4 h-4" />
            <span>Historique des Règlements ({payments.length})</span>
          </button>

        </div>

        {/* Search Input Filter */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            placeholder="Rechercher fournisseur..."
            className="w-full pl-9 pr-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
        </div>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: SUPPLIERS DIRECTORY & DEBTS CARDS                                  */}
      {/* ========================================================================= */}
      {activeTab === 'fournisseurs' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredSuppliers.map((supplier) => {
            const debt = parseSafeFloat(supplier.debt, 0);
            const hasDebt = debt > 0;

            return (
              <div
                key={supplier.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm hover:shadow-md transition flex flex-col justify-between space-y-4 relative overflow-hidden"
              >
                {/* Header: Name & Status Badge */}
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-teal-600 dark:text-teal-400 block">
                        {supplier.category || 'Fournisseur Général'}
                      </span>
                      <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                        {supplier.name}
                      </h3>
                    </div>

                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold shrink-0 border flex items-center gap-1 ${
                      hasDebt
                        ? 'bg-red-50 text-red-700 border-red-200 dark:bg-red-950/60 dark:text-red-300 dark:border-red-800'
                        : 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800'
                    }`}>
                      {hasDebt ? (
                        <>
                          <AlertCircle className="w-3 h-3" />
                          <span>Dette : {debt.toFixed(2)} {currency}</span>
                        </>
                      ) : (
                        <>
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Compte à jour</span>
                        </>
                      )}
                    </span>
                  </div>

                  {/* Contact Info */}
                  <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
                    {supplier.contactPerson && (
                      <p className="flex items-center gap-2">
                        <UserCheck className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>Contact : <strong className="text-slate-800 dark:text-slate-200">{supplier.contactPerson}</strong></span>
                      </p>
                    )}
                    {supplier.phone && (
                      <p className="flex items-center gap-2 font-mono">
                        <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>{supplier.phone}</span>
                      </p>
                    )}
                    {supplier.address && (
                      <p className="flex items-center gap-2">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{supplier.address}</span>
                      </p>
                    )}
                    {supplier.notes && (
                      <p className="text-[11px] text-slate-500 italic mt-1 bg-slate-50 dark:bg-slate-800/60 p-2 rounded-xl">
                        « {supplier.notes} »
                      </p>
                    )}
                  </div>
                </div>

                {/* Bottom Action Buttons */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    {supplier.phone && (
                      <button
                        onClick={() => handleWhatsAppSupplier(supplier)}
                        className="p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 transition"
                        title="Envoyer un message WhatsApp au fournisseur"
                      >
                        <MessageSquare className="w-4 h-4" />
                      </button>
                    )}

                    <button
                      onClick={() => handleOpenSupplierModal(supplier)}
                      className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 transition"
                      title="Modifier les coordonnées"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => handleDeleteSupplier(supplier)}
                      className="p-2 rounded-xl bg-red-50 hover:bg-red-100 dark:bg-red-950/40 text-red-600 dark:text-red-400 transition"
                      title="Supprimer le fournisseur"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <button
                    onClick={() => handleOpenPaymentModal(supplier)}
                    className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-extrabold text-xs flex items-center gap-1 shadow-sm transition active:scale-95"
                  >
                    <DollarSign className="w-3.5 h-3.5" />
                    <span>Régler</span>
                  </button>
                </div>

              </div>
            );
          })}

          {filteredSuppliers.length === 0 && (
            <div className="col-span-full py-16 px-4 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-4">
              <div className="w-16 h-16 bg-teal-50 dark:bg-teal-950/60 text-teal-600 rounded-2xl flex items-center justify-center mx-auto text-2xl">
                <Truck className="w-8 h-8" />
              </div>
              <div>
                <h4 className="font-extrabold text-base text-slate-800 dark:text-slate-200">
                  {searchFilter ? 'Aucun fournisseur ne correspond à votre recherche' : 'Votre répertoire Fournisseurs est actuellement vide'}
                </h4>
                <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                  {searchFilter 
                    ? 'Essayez avec un autre mot-clé ou effacez la recherche.'
                    : !isStoreConfigured
                      ? 'Vous pouvez charger un exemple de démonstration (avec grossistes, dettes et bons de livraison) ou commencer à saisir vos vrais fournisseurs.'
                      : 'Votre répertoire de fournisseurs est 100% propre. Cliquez ci-dessous pour ajouter votre premier fournisseur.'}
                </p>
              </div>

              {!searchFilter && (
                <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                  {!isStoreConfigured && isAdmin && (
                    <button
                      onClick={handleLoadDemoSuppliers}
                      className="py-2.5 px-5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-95 text-white rounded-xl text-xs font-extrabold shadow-md shadow-indigo-500/20 transition active:scale-95 flex items-center gap-1.5"
                    >
                      <span>🌟 Charger un Exemple (Démo)</span>
                    </button>
                  )}

                  <button
                    onClick={() => handleOpenSupplierModal(null)}
                    className="py-2.5 px-5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-extrabold shadow-sm transition active:scale-95 flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" />
                    <span>+ Ajouter un Fournisseur Réel</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: INVOICES & RESTOCKING LIST                                         */}
      {/* ========================================================================= */}
      {activeTab === 'factures' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-sm">
          <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-teal-600" />
              <span>Historique des Bons de Livraison & Factures Fournisseurs</span>
            </h3>
            <span className="text-xs text-slate-400">{invoices.length} arrivage(s)</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400 uppercase text-[10px] font-bold border-b border-slate-100 dark:border-slate-800">
                <tr>
                  <th className="p-3">N° Facture / BL</th>
                  <th className="p-3">Date</th>
                  <th className="p-3">Fournisseur</th>
                  <th className="p-3 text-right">Total Facture</th>
                  <th className="p-3 text-right">Montant Réglé</th>
                  <th className="p-3 text-right">Reste Dû</th>
                  <th className="p-3 text-center">Statut</th>
                  <th className="p-3 text-center">Articles</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {invoices.map((inv) => {
                  const rem = parseSafeFloat(inv.remainingDebt, 0);
                  const tot = parseSafeFloat(inv.totalAmount, 0);
                  const paid = parseSafeFloat(inv.paidAmount, 0);

                  return (
                    <tr key={inv.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                      <td className="p-3 font-mono font-bold text-slate-900 dark:text-white">
                        {inv.invoiceNumber}
                      </td>
                      <td className="p-3 text-slate-500">
                        {new Date(inv.date).toLocaleDateString()} {new Date(inv.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </td>
                      <td className="p-3 font-extrabold text-teal-700 dark:text-teal-400">
                        {inv.supplierName}
                      </td>
                      <td className="p-3 text-right font-extrabold text-slate-900 dark:text-white">
                        {tot.toFixed(2)} {currency}
                      </td>
                      <td className="p-3 text-right font-bold text-emerald-600 dark:text-emerald-400">
                        {paid.toFixed(2)} {currency}
                      </td>
                      <td className="p-3 text-right font-extrabold text-red-600 dark:text-red-400">
                        {rem > 0 ? `${rem.toFixed(2)} ${currency}` : '0.00'}
                      </td>
                      <td className="p-3 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                          rem === 0
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : paid > 0
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                            : 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                        }`}>
                          {rem === 0 ? 'Soldé 🟢' : paid > 0 ? 'Partiel 🟡' : 'Impayé 🔴'}
                        </span>
                      </td>
                      <td className="p-3 text-center">
                        <button
                          onClick={() => setInspectedInvoice(inv)}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[11px] font-bold"
                        >
                          Détails ({(inv.items || []).length})
                        </button>
                      </td>
                    </tr>
                  );
                })}

                {invoices.length === 0 && (
                  <tr>
                    <td colSpan="8" className="p-8 text-center text-slate-400">
                      Aucune facture d'achat enregistrée pour l'instant. Effectuez un réassort dans l'onglet Produits pour générer un premier bon de livraison.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: PAYMENTS HISTORY                                                   */}
      {/* ========================================================================= */}
      {activeTab === 'reglements' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-sm">
          <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-600" />
              <span>Historique Comptable des Règlements Fournisseurs</span>
            </h3>
            <span className="text-xs text-slate-400">{payments.length} versement(s)</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400 uppercase text-[10px] font-bold border-b border-slate-100 dark:border-slate-800">
                <tr>
                  <th className="p-3">Réf</th>
                  <th className="p-3">Date</th>
                  <th className="p-3">Fournisseur</th>
                  <th className="p-3 text-right">Montant Versé</th>
                  <th className="p-3">Mode de Règlement</th>
                  <th className="p-3">Tiroir-Caisse</th>
                  <th className="p-3">Notes</th>
                  <th className="p-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {payments.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                    <td className="p-3 font-mono font-bold text-slate-500">
                      PAY-{p.id}
                    </td>
                    <td className="p-3 text-slate-500">
                      {new Date(p.date).toLocaleDateString()} {new Date(p.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                    <td className="p-3 font-extrabold text-slate-900 dark:text-white">
                      {p.supplierName}
                    </td>
                    <td className="p-3 text-right font-black text-emerald-600 dark:text-emerald-400 text-sm">
                      {p.amount.toFixed(2)} {currency}
                    </td>
                    <td className="p-3 font-bold uppercase text-[10px] text-indigo-600 dark:text-indigo-400">
                      {p.paymentMethod} {p.checkNumber ? `(${p.checkNumber})` : ''}
                    </td>
                    <td className="p-3">
                      {p.deductedFromCashDrawer ? (
                        <span className="text-emerald-600 text-[10px] font-bold flex items-center gap-1">
                          <Check className="w-3 h-3" /> Déduit caisse
                        </span>
                      ) : (
                        <span className="text-slate-400 text-[10px]">Autre compte</span>
                      )}
                    </td>
                    <td className="p-3 text-slate-500 truncate max-w-xs">
                      {p.notes || '—'}
                    </td>
                    <td className="p-3 text-center">
                      <button
                        onClick={() => handlePrintPaymentReceipt(p)}
                        className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                        title="Imprimer un bon de versement thermique"
                      >
                        <Printer className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}

                {payments.length === 0 && (
                  <tr>
                    <td colSpan="8" className="p-8 text-center text-slate-400">
                      Aucun versement enregistré. Cliquez sur « Régler un Fournisseur » pour enregistrer un premier acompte.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: ADD / EDIT SUPPLIER                                              */}
      {/* ========================================================================= */}
      {showSupplierModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Truck className="w-5 h-5 text-teal-600" />
                <span>{editingSupplier ? 'Modifier le Fournisseur' : 'Nouveau Fournisseur'}</span>
              </h3>
              <button
                onClick={() => setShowSupplierModal(false)}
                className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 flex items-center justify-center hover:bg-slate-200 transition"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveSupplier} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                  Nom de l'Entreprise / Grossiste * :
                </label>
                <input
                  type="text"
                  required
                  value={supplierFormData.name}
                  onChange={(e) => setSupplierFormData({ ...supplierFormData, name: e.target.value })}
                  placeholder="ex: Grossiste Beauté Prestige SARL"
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                    Nom du Commercial / Contact :
                  </label>
                  <input
                    type="text"
                    value={supplierFormData.contactPerson}
                    onChange={(e) => setSupplierFormData({ ...supplierFormData, contactPerson: e.target.value })}
                    placeholder="ex: Rachid Berrada"
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                    Téléphone (WhatsApp) :
                  </label>
                  <input
                    type="text"
                    value={supplierFormData.phone}
                    onChange={(e) => setSupplierFormData({ ...supplierFormData, phone: e.target.value })}
                    placeholder="ex: +212 6 61 00 00 00"
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                    Catégorie Principale :
                  </label>
                  <select
                    value={supplierFormData.category}
                    onChange={(e) => setSupplierFormData({ ...supplierFormData, category: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-semibold"
                  >
                    <option value="Parfumerie & Beauté">Parfumerie & Beauté</option>
                    <option value="High-Tech & Smartphones">High-Tech & Smartphones</option>
                    <option value="Épicerie & Alimentation">Épicerie & Alimentation</option>
                    <option value="Mode & Chaussures">Mode & Chaussures</option>
                    <option value="Fournitures & Emballages">Fournitures & Emballages</option>
                    <option value="Autre">Autre</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                    Dette Actuelle Initiale ({currency}) :
                  </label>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={supplierFormData.debt}
                    onChange={(e) => setSupplierFormData({ ...supplierFormData, debt: sanitizeDecimalInput(e.target.value) })}
                    placeholder="0.00"
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono font-bold text-red-600 dark:text-red-400"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                  Adresse / Dépôt :
                </label>
                <input
                  type="text"
                  value={supplierFormData.address}
                  onChange={(e) => setSupplierFormData({ ...supplierFormData, address: e.target.value })}
                  placeholder="ex: Derb Omar, Casablanca"
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                  Remarques & Notes Internes :
                </label>
                <textarea
                  rows="2"
                  value={supplierFormData.notes}
                  onChange={(e) => setSupplierFormData({ ...supplierFormData, notes: e.target.value })}
                  placeholder="ex: Conditions de livraison, Franco de port 3000 DH..."
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div className="flex gap-2 justify-end pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowSupplierModal(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-bold"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-bold shadow-md shadow-teal-500/20"
                >
                  {editingSupplier ? 'Enregistrer les Modifications' : 'Créer le Fournisseur'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: RECORD SUPPLIER PAYMENT                                          */}
      {/* ========================================================================= */}
      {showPaymentModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-emerald-600" />
                <span>Régler un Fournisseur (Versement)</span>
              </h3>
              <button
                onClick={() => setShowPaymentModal(false)}
                className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 flex items-center justify-center hover:bg-slate-200 transition"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSavePayment} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                  Fournisseur Bénéficiaire * :
                </label>
                <select
                  required
                  value={selectedSupplierForPayment?.id || ''}
                  onChange={(e) => {
                    const sup = suppliers.find(s => s.id === parseInt(e.target.value));
                    setSelectedSupplierForPayment(sup);
                    if (sup && (parseSafeFloat(sup.debt, 0)) > 0) {
                      setPaymentFormData(prev => ({ ...prev, amount: String(sup.debt) }));
                    }
                  }}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold"
                >
                  <option value="">-- Choisir un fournisseur --</option>
                  {suppliers.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.name} (Dette : {parseSafeFloat(s.debt, 0).toFixed(2)} {currency})
                    </option>
                  ))}
                </select>
              </div>

              {selectedSupplierForPayment && (
                <div className="p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-2xl flex items-center justify-between">
                  <span className="font-bold text-red-800 dark:text-red-300">Dette Actuelle Due :</span>
                  <span className="font-black text-red-600 dark:text-red-400 text-sm">
                    {parseSafeFloat(selectedSupplierForPayment.debt, 0).toFixed(2)} {currency}
                  </span>
                </div>
              )}

              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                  Montant du Versement ({currency}) * :
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  required
                  value={paymentFormData.amount}
                  onChange={(e) => setPaymentFormData({ ...paymentFormData, amount: sanitizeDecimalInput(e.target.value) })}
                  placeholder="ex: 1500.00"
                  className="w-full p-3 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono text-base font-extrabold text-emerald-600 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                  Moyen de Règlement :
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {['especes', 'cheque', 'virement'].map(mode => (
                    <button
                      key={mode}
                      type="button"
                      onClick={() => setPaymentFormData({ ...paymentFormData, paymentMethod: mode })}
                      className={`py-2 px-2 rounded-xl font-extrabold text-[11px] capitalize border transition ${
                        paymentFormData.paymentMethod === mode
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                          : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      {mode}
                    </button>
                  ))}
                </div>
              </div>

              {paymentFormData.paymentMethod === 'cheque' && (
                <div className="grid grid-cols-2 gap-2 p-3 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700">
                  <div>
                    <label className="block font-bold mb-1 text-[11px]">N° de Chèque :</label>
                    <input
                      type="text"
                      value={paymentFormData.checkNumber}
                      onChange={(e) => setPaymentFormData({ ...paymentFormData, checkNumber: e.target.value })}
                      placeholder="ex: CHQ-984321"
                      className="w-full p-2 bg-white dark:bg-slate-900 border rounded-lg font-mono text-xs"
                    />
                  </div>
                  <div>
                    <label className="block font-bold mb-1 text-[11px]">Date d'Échéance :</label>
                    <input
                      type="date"
                      value={paymentFormData.dueDate}
                      onChange={(e) => setPaymentFormData({ ...paymentFormData, dueDate: e.target.value })}
                      className="w-full p-2 bg-white dark:bg-slate-900 border rounded-lg text-xs"
                    />
                  </div>
                </div>
              )}

              {paymentFormData.paymentMethod === 'especes' && (
                <label className="flex items-center gap-2 p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={paymentFormData.deductFromCashDrawer}
                    onChange={(e) => setPaymentFormData({ ...paymentFormData, deductFromCashDrawer: e.target.checked })}
                    className="w-4 h-4 text-emerald-600 rounded"
                  />
                  <div className="text-xs">
                    <span className="font-extrabold text-amber-900 dark:text-amber-200 block">
                      Déduire immédiatement du tiroir-caisse
                    </span>
                    <span className="text-[10px] text-amber-700 dark:text-amber-300">
                      Enregistre une sortie de caisse officielle pour la clôture (Ticket Z).
                    </span>
                  </div>
                </label>
              )}

              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                  Notes / Motif :
                </label>
                <input
                  type="text"
                  value={paymentFormData.notes}
                  onChange={(e) => setPaymentFormData({ ...paymentFormData, notes: e.target.value })}
                  placeholder="ex: Acompte sur arrivage parfums"
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div className="flex gap-2 justify-end pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowPaymentModal(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-bold"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:opacity-95 text-white rounded-xl font-extrabold shadow-md shadow-emerald-500/20"
                >
                  Valider le Versement
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: INVOICE ITEMS INSPECTION                                         */}
      {/* ========================================================================= */}
      {inspectedInvoice && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                  <FileText className="w-5 h-5 text-teal-600" />
                  <span>Détail Bon d'Arrivage : {inspectedInvoice.invoiceNumber}</span>
                </h3>
                <span className="text-xs text-slate-500">Fournisseur : {inspectedInvoice.supplierName}</span>
              </div>
              <button
                onClick={() => setInspectedInvoice(null)}
                className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 flex items-center justify-center hover:bg-slate-200 transition"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs max-h-96 overflow-y-auto">
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {(inspectedInvoice.items || []).map((item, idx) => (
                  <div key={idx} className="py-2.5 flex items-center justify-between">
                    <div>
                      <span className="font-extrabold text-slate-900 dark:text-white block">{item.name}</span>
                      <span className="text-[10px] text-slate-500">Qté livrée : {item.addedQty} {item.unit || 'unités'}</span>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-slate-700 dark:text-slate-300 block">
                        {(parseSafeFloat(item.buyPrice, 0)).toFixed(2)} {currency} / u
                      </span>
                      <span className="font-extrabold text-teal-600 dark:text-teal-400">
                        Total : {((parseSafeFloat(item.addedQty, 0)) * (parseSafeFloat(item.buyPrice, 0))).toFixed(2)} {currency}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-2xl space-y-1 pt-3 border-t">
                <div className="flex justify-between font-bold">
                  <span>Total Facture :</span>
                  <span>{(parseSafeFloat(inspectedInvoice.totalAmount, 0)).toFixed(2)} {currency}</span>
                </div>
                <div className="flex justify-between font-bold text-emerald-600">
                  <span>Déjà Réglé :</span>
                  <span>{(parseSafeFloat(inspectedInvoice.paidAmount, 0)).toFixed(2)} {currency}</span>
                </div>
                <div className="flex justify-between font-black text-red-600 text-sm border-t pt-1">
                  <span>Reste Dû :</span>
                  <span>{(parseSafeFloat(inspectedInvoice.remainingDebt, 0)).toFixed(2)} {currency}</span>
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-100 dark:border-slate-800 flex justify-end">
              <button
                onClick={() => setInspectedInvoice(null)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-bold"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Printable Container for Supplier Payment Receipt */}
      {printingPayment && (
        <div id="supplier-receipt-print" className="p-4 bg-white text-black font-mono text-[11px] space-y-1.5 border border-slate-200">
          <div className="text-center font-bold text-sm">{settings?.shopName || 'VENTEFACILE PRO'}</div>
          <div className="text-center text-[10px] text-slate-500">BON DE RÈGLEMENT FOURNISSEUR</div>
          <div className="border-t border-dashed border-slate-300 my-1"></div>
          <div className="flex justify-between"><span>Réf :</span><b>PAY-SUP-{printingPayment.id}</b></div>
          <div className="flex justify-between"><span>Date :</span><span>{new Date(printingPayment.date).toLocaleString()}</span></div>
          <div className="flex justify-between"><span>Fournisseur :</span><b>{printingPayment.supplierName}</b></div>
          <div className="flex justify-between"><span>Mode :</span><span className="uppercase">{printingPayment.paymentMethod}</span></div>
          {printingPayment.checkNumber && <div className="flex justify-between"><span>N° Chèque/Traite :</span><span>{printingPayment.checkNumber}</span></div>}
          {printingPayment.dueDate && <div className="flex justify-between"><span>Échéance :</span><span>{printingPayment.dueDate}</span></div>}
          <div className="border-t border-dashed border-slate-300 my-1"></div>
          <div className="flex justify-between font-extrabold text-sm">
            <span>MONTANT VERSÉ :</span>
            <span>{Number(printingPayment.amount).toFixed(2)} {currency}</span>
          </div>
          {printingPayment.deductedFromCashDrawer && (
            <div className="text-[10px] italic text-slate-500">(*) Déduit du tiroir-caisse de la boutique</div>
          )}
          {printingPayment.notes && (
            <div className="text-[10px] text-slate-600 mt-1">Notes : {printingPayment.notes}</div>
          )}
          <div className="border-t border-dashed border-slate-300 my-2"></div>
          <div className="pt-2 text-[10px] text-center text-slate-400">
            <div>Signature Livreur / Fournisseur :</div>
            <div className="h-10 mt-1 border-b border-dashed border-slate-300"></div>
          </div>
        </div>
      )}

    </div>
  );
}
