import { db } from './db';
import { 
  pushSaleToSupabase, 
  pushProductToSupabase, 
  pullProductsFromSupabase,
  pullSalesFromSupabase,
  testSupabaseConnection,
  SUPABASE_DIRECT_CONFIG
} from './supabaseClient';

class SyncManager {
  constructor() {
    this.status = 'offline'; // 'connected' | 'syncing' | 'pending' | 'offline' | 'unconfigured'
    this.isSyncing = false;
    this.lastSyncTime = null;
    this.pendingCount = 0;
    this.listeners = new Set();
    this.intervalId = null;

    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => this.handleNetworkChange(true));
      window.addEventListener('offline', () => this.handleNetworkChange(false));
    }
  }

  subscribe(listener) {
    this.listeners.add(listener);
    listener({
      status: this.status,
      isSyncing: this.isSyncing,
      lastSyncTime: this.lastSyncTime,
      pendingCount: this.pendingCount
    });
    return () => this.listeners.delete(listener);
  }

  notify() {
    for (const listener of this.listeners) {
      try {
        listener({
          status: this.status,
          isSyncing: this.isSyncing,
          lastSyncTime: this.lastSyncTime,
          pendingCount: this.pendingCount
        });
      } catch (e) {
        console.error('[SyncManager] Erreur notification listener', e);
      }
    }
  }

  handleNetworkChange(isOnline) {
    if (!isOnline) {
      this.status = 'offline';
      this.notify();
    } else {
      // Quand le réseau revient, déclencher immédiatement la synchronisation
      this.syncNow();
    }
  }

  start(getSettings, onDataUpdated = null) {
    this.getSettings = getSettings;
    this.onDataUpdated = onDataUpdated;

    if (this.intervalId) clearInterval(this.intervalId);

    // Initial check
    this.syncNow();

    // Heartbeat sync every 30 seconds
    this.intervalId = setInterval(() => {
      this.syncNow();
    }, 30000);
  }

  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  async countPendingItems() {
    try {
      const allSales = await db.sales.toArray();
      const pendingSales = allSales.filter(s => s.synced !== true);
      const allProducts = await db.products.toArray();
      const pendingProducts = allProducts.filter(p => p.synced !== true);
      this.pendingCount = pendingSales.length + pendingProducts.length;
      return this.pendingCount;
    } catch (e) {
      return 0;
    }
  }

  async syncNow() {
    if (this.isSyncing) return;
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      this.status = 'offline';
      await this.countPendingItems();
      this.notify();
      return;
    }

    const settings = typeof this.getSettings === 'function' ? this.getSettings() : {};
    const config = {
      supabaseUrl: settings.supabaseUrl || SUPABASE_DIRECT_CONFIG.url,
      supabaseAnonKey: settings.supabaseAnonKey || SUPABASE_DIRECT_CONFIG.anonKey
    };

    if (!config.supabaseUrl || !config.supabaseAnonKey) {
      this.status = 'unconfigured';
      await this.countPendingItems();
      this.notify();
      return;
    }

    this.isSyncing = true;
    this.status = 'syncing';
    this.notify();

    try {
      // 1. Tester la connexion
      const conn = await testSupabaseConnection(config.supabaseUrl, config.supabaseAnonKey);
      if (!conn.success) {
        this.status = 'pending';
        this.isSyncing = false;
        await this.countPendingItems();
        this.notify();
        return;
      }

      // 2. Pousser les ventes locales non synchronisées
      const allSales = await db.sales.toArray();
      const unsyncedSales = allSales.filter(s => s.synced !== true);
      for (const sale of unsyncedSales) {
        const ok = await pushSaleToSupabase(sale, config);
        if (ok) {
          await db.sales.update(sale.id, { synced: true });
        }
      }

      // 3. Pousser les produits locaux vers Supabase
      const allProducts = await db.products.toArray();
      const unsyncedProducts = allProducts.filter(p => p.synced !== true);
      for (const prod of unsyncedProducts) {
        const ok = await pushProductToSupabase(prod, config);
        if (ok) {
          await db.products.update(prod.id, { synced: true });
        }
      }

      // 4. Récupérer les nouveaux produits depuis Supabase pour synchronisation multi-appareils
      const remoteProducts = await pullProductsFromSupabase(config);
      let pulledCount = 0;
      if (remoteProducts && remoteProducts.length > 0) {
        for (const rp of remoteProducts) {
          const localMatch = allProducts.find(p => (rp.barcode && p.barcode === rp.barcode) || p.id === rp.id);
          if (!localMatch) {
            await db.products.add({ ...rp, synced: true });
            pulledCount++;
          } else if (localMatch.synced === true) {
            const remoteUpdated = new Date(rp.updated_at || 0).getTime();
            const localUpdated = new Date(localMatch.updatedAt || 0).getTime();
            if (remoteUpdated > localUpdated) {
              await db.products.update(localMatch.id, {
                stock: rp.stock,
                sellPrice: rp.sell_price,
                buyPrice: rp.buy_price,
                updatedAt: rp.updated_at,
                synced: true
              });
              pulledCount++;
            }
          }
        }
      }

      // 5. Récupérer les ventes distantes créées sur d'autres appareils
      const remoteSales = await pullSalesFromSupabase(config);
      if (remoteSales && remoteSales.length > 0) {
        for (const rs of remoteSales) {
          const localSale = allSales.find(s => s.receiptNo === rs.receiptNo);
          if (!localSale) {
            await db.sales.add({ ...rs, synced: true });
            pulledCount++;
          }
        }
      }

      if (pulledCount > 0 && typeof this.onDataUpdated === 'function') {
        this.onDataUpdated();
      }

      this.lastSyncTime = new Date();
      this.status = 'connected';
      await this.countPendingItems();
    } catch (err) {
      console.warn('[SyncManager] Erreur synchronisation', err);
      this.status = 'pending';
    } finally {
      this.isSyncing = false;
      this.notify();
    }
  }
}

export const syncManager = new SyncManager();
