import React from 'react';
import { 
  BarChart3, 
  ShoppingCart, 
  Package, 
  Users, 
  Truck,
  MessageSquare, 
  Globe, 
  Settings 
} from 'lucide-react';
import { translations } from '../translations';

export default function Navigation({ activeTab, onTabChange, currentLang, isAdmin = true, userRole = 'admin', onRequestAdmin }) {
  const t = translations[currentLang] || translations.fr;

  const navItems = [
    { id: 'dashboard', label: t.dashboard, icon: BarChart3, adminOnly: true },
    { id: 'caisse', label: t.caisse, icon: ShoppingCart, badge: 'POS' },
    { id: 'produits', label: t.produits, icon: Package },
    { id: 'clients', label: t.clients, icon: Users },
    { id: 'fournisseurs', label: 'Fournisseurs & Dettes', icon: Truck, adminOnly: true },
    { id: 'whatsapp', label: t.whatsapp, icon: MessageSquare, badge: 'Meta' },
    { id: 'website', label: t.website, icon: Globe, adminOnly: true },
    { id: 'parametres', label: t.parametres, icon: Settings, adminOnly: true }
  ];

  const handleTabClick = (item) => {
    if (item.adminOnly && !isAdmin) {
      if (onRequestAdmin) {
        onRequestAdmin(item.id);
      }
      return;
    }
    onTabChange(item.id);
  };

  return (
    <>
      {/* Desktop / Tablet Top Navigation Bar */}
      <nav className="hidden sm:block bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-sm transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-3 sm:px-4">
          <div className="flex items-center gap-1 sm:gap-2 overflow-x-auto no-scrollbar py-0.5">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              const isLockedForCashier = item.adminOnly && !isAdmin;

              return (
                <button
                  key={item.id}
                  onClick={() => handleTabClick(item)}
                  title={isLockedForCashier ? 'Réservé au Gérant / Admin (Code PIN requis)' : item.label}
                  className={`flex items-center gap-2 px-3 sm:px-4 py-3 text-xs sm:text-sm font-bold border-b-2 whitespace-nowrap shrink-0 transition-all duration-150 ${
                    isActive
                      ? 'border-indigo-600 text-indigo-600 dark:border-indigo-400 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/30'
                      : isLockedForCashier
                      ? 'border-transparent text-slate-400 dark:text-slate-600 hover:text-amber-600 dark:hover:text-amber-400 hover:bg-amber-50/50 dark:hover:bg-amber-950/20'
                      : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'scale-110 text-indigo-600 dark:text-indigo-400' : ''}`} />
                  <span className="inline-block">{item.label}</span>
                  {item.badge && (
                    <span className="text-[9px] font-extrabold px-1.5 py-0.5 rounded-full bg-indigo-100 text-indigo-700 dark:bg-indigo-900/60 dark:text-indigo-300 shrink-0">
                      {item.badge}
                    </span>
                  )}
                  {isLockedForCashier && (
                    <span className="text-[10px] text-amber-500 font-normal ml-0.5" title="Accès Admin">
                      🔒
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 shadow-lg px-1 py-1.5 transition-colors duration-200">
        <div className="flex items-center justify-around">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            const isLockedForCashier = item.adminOnly && !isAdmin;

            return (
              <button
                key={item.id}
                onClick={() => handleTabClick(item)}
                className={`relative flex flex-col items-center justify-center w-full py-1 rounded-xl transition-all ${
                  isActive
                    ? 'text-indigo-600 dark:text-indigo-400 font-bold bg-indigo-50 dark:bg-indigo-950/50 scale-105'
                    : isLockedForCashier
                    ? 'text-slate-400 dark:text-slate-600 opacity-60'
                    : 'text-slate-500 dark:text-slate-400 font-medium hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                <div className="relative">
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
                  {isLockedForCashier && (
                    <span className="absolute -top-1 -right-2 text-[8px]">🔒</span>
                  )}
                </div>
                <span className="text-[9px] mt-0.5 tracking-tight truncate max-w-[60px] text-center">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
}
