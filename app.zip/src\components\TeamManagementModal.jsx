import React, { useState } from 'react';
import {
  Users,
  X,
  Plus,
  Shield,
  ShieldCheck,
  UserCheck,
  Trash2,
  Award,
  ArrowDownCircle,
  Share2,
  Lock,
  Phone,
  AlertCircle,
  CheckCircle2,
  RefreshCw,
  KeyRound
} from 'lucide-react';
import { translations } from '../translations';
import { useToast } from '../context/ToastContext';
import { generateSalt, hashPinWithSalt } from '../authSecurity';

export default function TeamManagementModal({
  isOpen,
  onClose,
  team = [],
  currentCashier,
  onUpdateTeam,
  onOpenSwitchCashier,
  storeName = 'Mon Commerce',
  currentLang = 'fr'
}) {
  if (!isOpen) return null;

  const t = translations[currentLang] || translations.fr;
  const toast = useToast();

  // Role checks
  const isPatron = currentCashier?.role === 'patron';
  const isGerant = currentCashier?.role === 'gerant';
  const canManageCashiers = isPatron || (isGerant && Boolean(currentCashier?.permissions?.canManageCashiers));

  // Form states
  const [showAddForm, setShowAddForm] = useState(false);
  const [name, setName] = useState('');
  const [role, setRole] = useState('caissier');
  const [phone, setPhone] = useState('');
  const [pin, setPin] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);

  const roleMeta = {
    patron: {
      label: '👑 Patron (Propriétaire)',
      badge: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 border-indigo-300',
      desc: 'Contrôle total : finances, équipe, paramètres, marges, inventaire.'
    },
    gerant: {
      label: '🎖️ Gérant',
      badge: 'bg-teal-100 text-teal-700 dark:bg-teal-950 dark:text-teal-300 border-teal-300',
      desc: 'Gestion des produits, stocks, fournisseurs et clôtures journalières.'
    },
    caissier: {
      label: '💼 Caissier',
      badge: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border-emerald-300',
      desc: 'Encaissements, vente POS, scan code-barres et impression tickets.'
    }
  };

  const notify = (text, type = 'success') => {
    if (type === 'error') toast.error(text);
    else if (type === 'warning') toast.warning(text);
    else toast.success(text);
  };

  // 1. Ajouter un nouveau membre avec PIN haché SHA-256 + Sel
  const handleAddMember = async (e) => {
    e.preventDefault();
    if (!name.trim()) {
      notify('Veuillez saisir le nom du membre', 'error');
      return;
    }

    if (!canManageCashiers) {
      notify("Action refusée : Seul le Patron ou un Gérant autorisé peut ajouter un membre.", 'error');
      return;
    }

    // Gerant cannot add another Gerant or Patron
    const assignedRole = (isGerant && role !== 'caissier') ? 'caissier' : role;

    // Calcul du hash cryptographique salé
    const cleanPin = pin.trim() || (assignedRole === 'patron' ? '1234' : '0000');
    const salt = generateSalt(16);
    const pinHash = await hashPinWithSalt(cleanPin, salt);

    const newMember = {
      id: 'usr_' + Date.now(),
      name: name.trim(),
      role: assignedRole,
      pinHash,
      pinSalt: salt,
      phone: phone.trim(),
      avatarColor: ['#4f46e5', '#059669', '#0891b2', '#7c3aed', '#d97706', '#dc2626'][Math.floor(Math.random() * 6)],
      createdAt: new Date().toISOString(),
      permissions: {
        canSell: true,
        canManageProducts: assignedRole === 'patron' || assignedRole === 'gerant',
        canManageCashiers: assignedRole === 'patron' ? true : false,
        canViewMargins: assignedRole === 'patron'
      }
    };

    const updated = [...team, newMember];
    onUpdateTeam(updated);
    notify(`Membre ${newMember.name} ajouté avec succès !`);

    // Reset form
    setName('');
    setPhone('');
    setPin('');
    setRole('caissier');
    setShowAddForm(false);
  };

  // 2. Bouton "Promouvoir en Gérant" / "Rétrograder en Caissier"
  const handleToggleRole = (member) => {
    if (!isPatron) {
      notify("Action refusée : Seul le Patron a l'autorité de nommer ou révoquer un Gérant.", 'error');
      return;
    }

    if (member.role === 'patron') {
      notify("Impossible de modifier le rôle du Patron.", 'error');
      return;
    }

    const newRole = member.role === 'caissier' ? 'gerant' : 'caissier';
    const updated = team.map(m => {
      if (m.id === member.id) {
        return {
          ...m,
          role: newRole,
          permissions: {
            ...m.permissions,
            canManageProducts: newRole === 'gerant',
            canManageCashiers: newRole === 'gerant' ? (m.permissions?.canManageCashiers || false) : false
          }
        };
      }
      return m;
    });

    onUpdateTeam(updated);
    notify(
      newRole === 'gerant'
        ? `🎖️ Félicitations ! ${member.name} a été promu au rang de Gérant.`
        : `💼 ${member.name} a été rétrogradé au poste de Caissier.`
    );
  };

  // 3. Bouton "Supprimer le Caissier / Gérant"
  const handleDeleteMember = (member) => {
    if (member.role === 'patron') {
      notify("Impossible de supprimer le Patron de la boutique.", 'error');
      return;
    }

    if (member.role === 'gerant' && !isPatron) {
      notify("Action refusée : Seul le Patron peut révoquer un Gérant.", 'error');
      return;
    }

    if (member.role === 'caissier' && !canManageCashiers) {
      notify("Action refusée : Vous n'avez pas l'autorisation de supprimer des caissiers.", 'error');
      return;
    }

    const updated = team.filter(m => m.id !== member.id);
    onUpdateTeam(updated);
    setConfirmDeleteId(null);
    notify(`Membre ${member.name} supprimé de l'équipe.`);
  };

  // 4. Patron accorde ou retire l'autorisation au Gérant de gérer les caissiers
  const handleToggleGerantCashierPermission = (memberId, currentPerm) => {
    if (!isPatron) {
      notify("Seul le Patron peut modifier les permissions de l'équipe.", 'error');
      return;
    }

    const updated = team.map(m => {
      if (m.id === memberId) {
        return {
          ...m,
          permissions: {
            ...m.permissions,
            canManageCashiers: !currentPerm
          }
        };
      }
      return m;
    });

    onUpdateTeam(updated);
    notify("Permissions du gérant mises à jour avec succès.");
  };

  // 5. Inviter via WhatsApp
  const handleSendWhatsAppInvite = (member) => {
    const roleTxt = member.role === 'patron' ? 'Patron' : member.role === 'gerant' ? 'Gérant' : 'Caissier';
    const defaultPinHint = member.role === 'patron' ? '1234' : '0000';
    const text = encodeURIComponent(
      `👋 Bonjour ${member.name} !\n\n` +
      `Tu as été enregistré(e) dans l'équipe de *${storeName}* avec le rôle de *${roleTxt}*.\n\n` +
      `🔑 *Ton code PIN de caisse :* ${member.pin || defaultPinHint} (À personnaliser)\n` +
      `🌐 *Accéder à la boutique :* ${window.location.origin}\n\n` +
      `Bon travail et bienvenue dans l'équipe ! 🚀`
    );

    const cleanPhone = (member.phone || '').replace(/[^0-9]/g, '');
    const url = cleanPhone ? `https://wa.me/${cleanPhone}?text=${text}` : `https://wa.me/?text=${text}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-2xl w-full shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-indigo-700 via-indigo-800 to-slate-900 text-white relative flex-shrink-0">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center">
              <Users className="w-6 h-6 text-indigo-200" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-black tracking-tight">
                  Gestion de l'Équipe & Rôles
                </h3>
                <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  Apex Security
                </span>
              </div>
              <p className="text-xs text-indigo-200 mt-0.5">
                Patron, Gérants & Caissiers • Système hiérarchique ultra-sécurisé
              </p>
            </div>
          </div>

          {/* Quick active session indicator */}
          <div className="mt-3 flex items-center justify-between bg-black/20 backdrop-blur-sm rounded-xl px-3 py-2 border border-white/10 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-slate-300">Votre session active :</span>
              <span className="font-black text-white">{currentCashier?.name || 'Inconnu'}</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/20 font-bold">
                {currentCashier?.role === 'patron' ? '👑 Patron' : currentCashier?.role === 'gerant' ? '🎖️ Gérant' : '💼 Caissier'}
              </span>
            </div>
            {onOpenSwitchCashier && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenSwitchCashier();
                }}
                className="flex items-center gap-1.5 px-2.5 py-1 bg-white text-indigo-900 rounded-lg font-black text-[11px] hover:bg-indigo-50 transition shadow-sm"
              >
                <RefreshCw className="w-3 h-3" />
                Changer de Caissier
              </button>
            )}
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-5 overflow-y-auto space-y-5 flex-1">

          {/* Action Bar */}
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-extrabold text-sm text-slate-800 dark:text-slate-100">
                Membres actifs ({team.length})
              </h4>
              <p className="text-xs text-slate-500">
                {isPatron
                  ? 'Vous avez tous les droits de gestion et de promotion.'
                  : canManageCashiers
                  ? 'Vous êtes autorisé par le Patron à gérer les caissiers.'
                  : 'Mode consultation. Seul le Patron peut modifier les rôles et permissions.'}
              </p>
            </div>

            {canManageCashiers && (
              <button
                onClick={() => setShowAddForm(!showAddForm)}
                className="flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-sm"
              >
                <Plus className="w-4 h-4" />
                {showAddForm ? 'Fermer formulaire' : 'Ajouter un membre'}
              </button>
            )}
          </div>

          {/* Add Form */}
          {showAddForm && canManageCashiers && (
            <form onSubmit={handleAddMember} className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-indigo-200 dark:border-indigo-900/50 space-y-3 animate-in fade-in">
              <h5 className="font-extrabold text-xs text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
                Nouveau membre de l'équipe
              </h5>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                    Nom complet *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ex: Yassine Mansouri"
                    className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                    Rôle attribué
                  </label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    disabled={!isPatron}
                    className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none disabled:opacity-60"
                  >
                    <option value="caissier">💼 Caissier (Ventes POS uniquement)</option>
                    {isPatron && <option value="gerant">🎖️ Gérant (Produits & Stocks)</option>}
                  </select>
                  {!isPatron && (
                    <span className="text-[10px] text-slate-400 mt-0.5 block">
                      Seul le Patron peut créer un Gérant.
                    </span>
                  )}
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                    Numéro WhatsApp (pour invitation)
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="Ex: +212 600 000 000"
                    className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                    Code PIN de caisse (4 chiffres)
                  </label>
                  <input
                    type="password"
                    maxLength={6}
                    value={pin}
                    onChange={(e) => setPin(e.target.value)}
                    placeholder="Ex: 1234"
                    className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-700 font-bold"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition"
                >
                  Enregistrer le membre
                </button>
              </div>
            </form>
          )}

          {/* Members List */}
          <div className="space-y-3">
            {team.map((member) => {
              const meta = roleMeta[member.role] || roleMeta.caissier;
              const isMemberPatron = member.role === 'patron';
              const isMemberGerant = member.role === 'gerant';
              const isMemberCaissier = member.role === 'caissier';
              const isCurrentSession = currentCashier?.id === member.id || currentCashier?.name === member.name;

              return (
                <div
                  key={member.id}
                  className={`p-4 rounded-2xl border transition-all ${
                    isCurrentSession
                      ? 'border-indigo-400 bg-indigo-50/40 dark:bg-indigo-950/20 shadow-sm'
                      : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    {/* User Info */}
                    <div className="flex items-center gap-3">
                      <div
                        className="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-black text-base shadow-sm flex-shrink-0"
                        style={{ backgroundColor: member.avatarColor || '#4f46e5' }}
                      >
                        {member.name?.slice(0, 2)?.toUpperCase() || 'US'}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-black text-sm text-slate-900 dark:text-white">
                            {member.name}
                          </span>
                          <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${meta.badge}`}>
                            {meta.label}
                          </span>
                          {isCurrentSession && (
                            <span className="text-[10px] font-bold text-emerald-600 bg-emerald-100 dark:bg-emerald-950/80 px-2 py-0.5 rounded-full">
                              🟢 Session active
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-3 mt-1 text-[11px] text-slate-500">
                          {member.phone && (
                            <span className="flex items-center gap-1">
                              <Phone className="w-3 h-3 text-slate-400" />
                              {member.phone}
                            </span>
                          )}
                          <span className="flex items-center gap-1 font-mono">
                            <KeyRound className="w-3 h-3 text-slate-400" />
                            PIN: {member.pinHash ? '•••• (Protégé SHA-256)' : '••••'}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Actions Group */}
                    <div className="flex items-center gap-1.5 flex-wrap sm:justify-end">
                      {/* WhatsApp invite button */}
                      <button
                        type="button"
                        onClick={() => handleSendWhatsAppInvite(member)}
                        title="Envoyer les accès via WhatsApp"
                        className="p-2 rounded-xl bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 hover:bg-emerald-100 border border-emerald-200 dark:border-emerald-800 transition text-xs flex items-center gap-1 font-bold"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Inviter</span>
                      </button>

                      {/* Promouvoir en Gérant / Rétrograder en Caissier (Patron Only) */}
                      {isPatron && !isMemberPatron && (
                        <button
                          type="button"
                          onClick={() => handleToggleRole(member)}
                          className={`px-2.5 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition ${
                            isMemberCaissier
                              ? 'bg-amber-50 text-amber-800 border-amber-300 hover:bg-amber-100 dark:bg-amber-950/40 dark:text-amber-200'
                              : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300'
                          }`}
                        >
                          {isMemberCaissier ? (
                            <>
                              <Award className="w-3.5 h-3.5 text-amber-600" />
                              Promouvoir en Gérant
                            </>
                          ) : (
                            <>
                              <ArrowDownCircle className="w-3.5 h-3.5 text-slate-500" />
                              Rétrograder en Caissier
                            </>
                          )}
                        </button>
                      )}

                      {/* Supprimer le membre */}
                      {!isMemberPatron && (
                        <>
                          {confirmDeleteId === member.id ? (
                            <div className="flex items-center gap-1 animate-in fade-in">
                              <button
                                type="button"
                                onClick={() => handleDeleteMember(member)}
                                className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold rounded-lg shadow-sm"
                              >
                                Confirmer
                              </button>
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteId(null)}
                                className="px-2 py-1 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-bold rounded-lg"
                              >
                                Non
                              </button>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => {
                                if (isMemberGerant && !isPatron) {
                                  notify("Seul le Patron peut supprimer un Gérant.", 'error');
                                  return;
                                }
                                if (isMemberCaissier && !canManageCashiers) {
                                  notify("Autorisation requise pour supprimer un caissier.", 'error');
                                  return;
                                }
                                setConfirmDeleteId(member.id);
                              }}
                              title={isMemberCaissier ? "Supprimer le caissier" : "Supprimer le gérant"}
                              className="p-2 rounded-xl text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-transparent hover:border-rose-200 transition"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </>
                      )}
                    </div>
                  </div>

                  {/* Gerant Specific Permissions Control by Patron */}
                  {isMemberGerant && (
                    <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                      <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-400">
                        <Shield className="w-3.5 h-3.5 text-teal-600" />
                        <span>Droits : Ajout & Modification Produits ✅</span>
                      </div>

                      {/* Patron can toggle canManageCashiers */}
                      <div className="flex items-center gap-2">
                        <label className={`flex items-center gap-2 cursor-pointer text-xs font-semibold ${!isPatron ? 'opacity-60 cursor-not-allowed' : ''}`}>
                          <input
                            type="checkbox"
                            disabled={!isPatron}
                            checked={Boolean(member.permissions?.canManageCashiers)}
                            onChange={() => handleToggleGerantCashierPermission(member.id, member.permissions?.canManageCashiers)}
                            className="rounded border-slate-300 text-teal-600 focus:ring-teal-500 w-4 h-4"
                          />
                          <span className="text-[11px] text-slate-700 dark:text-slate-300">
                            Autoriser à recruter & supprimer des caissiers
                          </span>
                        </label>
                        {!isPatron && (
                          <span className="text-[10px] text-slate-400 italic">
                            (Réglable par le Patron)
                          </span>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Patron Inviolability Notice */}
                  {isMemberPatron && (
                    <div className="mt-2 text-[10px] text-indigo-600 dark:text-indigo-400 font-semibold flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" />
                      Propriétaire Principal — Tous les privilèges d'administration accordés.
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Quick Guide Card */}
          <div className="p-4 bg-indigo-50/70 dark:bg-indigo-950/30 rounded-2xl border border-indigo-100 dark:border-indigo-900/40 text-xs space-y-1.5 text-slate-700 dark:text-slate-300">
            <h5 className="font-extrabold text-indigo-900 dark:text-indigo-300 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-indigo-600" />
              Règles de sécurité hiérarchique :
            </h5>
            <ul className="list-disc pl-5 space-y-1 text-[11px] text-slate-600 dark:text-slate-400">
              <li><strong>Le Patron :</strong> Autorité suprême. Seul habilité à nommer/révoquer un Gérant et accorder des droits spéciaux.</li>
              <li><strong>Le Gérant :</strong> Gère les produits et l'approvisionnement. Ne peut pas recruter ni supprimer de caissiers <em>sauf si le Patron l'a explicitement autorisé</em>.</li>
              <li><strong>Le Caissier :</strong> Restreint aux encaissements et tickets POS. Pas d'accès aux marges ni aux paramètres sensibles.</li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between flex-shrink-0">
          <span className="text-xs text-slate-500">
            {team.length} {team.length > 1 ? 'membres configurés' : 'membre configuré'}
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold text-xs rounded-xl hover:opacity-90 transition"
          >
            Fermer
          </button>
        </div>

      </div>
    </div>
  );
}
