import React, { useState } from 'react';
import { 
  Settings, 
  Lock, 
  Globe, 
  DollarSign, 
  Palette, 
  Download, 
  Upload, 
  Wrench, 
  CheckCircle2, 
  ShieldAlert, 
  Sliders, 
  Gift, 
  RefreshCw, 
  RotateCcw,
  Sparkles,
  Cloud,
  QrCode,
  Copy,
  Check,
  FileCode,
  Server,
  Printer,
  Coins,
  Users,
  ShieldCheck,
  UserCheck,
  Crown,
  Shield,
  ChevronRight,
  Briefcase,
  Mail,
  Building2,
  MapPin,
  CreditCard
} from 'lucide-react';
import { translations, formatWithParens } from '../translations';
import { db, generateSalt, hashPinWithSalt } from '../db';
import { testSupabaseConnection, SUPABASE_SQL_SCHEMA } from '../supabaseClient';
import { syncManager } from '../syncManager';
import { 
  connectDirectThermalPrinter, 
  connectBluetoothThermalPrinter, 
  triggerOpenCashDrawer, 
  printDiagnosticTestTicket, 
  isHardwareConnected, 
  getConnectedDeviceName, 
  getHardwareCapabilities 
} from '../thermalPrinter';
import { useToast } from '../context/ToastContext';
import QRCodeModal from './QRCodeModal';
import { BUSINESS_TYPES, CURRENCY_OPTIONS, COUNTRY_OPTIONS } from './CreateShopModal';

export default function ParametresView({ 
  settings, 
  onUpdateSettings, 
  currentLang, 
  onLangChange,
  onRefreshData,
  onOpenTeamManagement,
  onOpenSwitchCashier,
  currentCashier
}) {
  const toast = useToast();
  const t = translations[currentLang] || translations.fr;

  const [formSettings, setFormSettings] = useState(settings);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [diagnosticLog, setDiagnosticLog] = useState(null);
  const [showQRModal, setShowQRModal] = useState(false);
  const [supabaseTestStatus, setSupabaseTestStatus] = useState(null);
  const [isTestingSupabase, setIsTestingSupabase] = useState(false);
  const [copiedSchema, setCopiedSchema] = useState(false);
  const [isTestingHardware, setIsTestingHardware] = useState(false);
  const [hardwareStatus, setHardwareStatus] = useState(() => isHardwareConnected());

  const handleConnectPrinter = async () => {
    try {
      const res = await connectDirectThermalPrinter();
      if (res.success) {
        setHardwareStatus(true);
        toast.success(res.message, "Imprimante USB Connectée");
      } else {
        toast.info(res.message, "Sélection Imprimante");
      }
    } catch (err) {
      toast.error(err.message, "Connexion Imprimante");
    }
  };

  const handleConnectBluetooth = async () => {
    try {
      const res = await connectBluetoothThermalPrinter();
      if (res.success) {
        setHardwareStatus(true);
        toast.success(res.message, "Imprimante Bluetooth");
      } else {
        toast.info(res.message, "Appairage Bluetooth");
      }
    } catch (err) {
      toast.error(err.message, "Erreur Bluetooth");
    }
  };

  const handleTestHardware = async () => {
    setIsTestingHardware(true);
    try {
      const res = await printDiagnosticTestTicket(formSettings.shopName || 'VenteFacile Pro');
      if (res.direct) {
        toast.success(res.message, "Test Matériel Validé");
      } else {
        toast.info(res.message, "Impulsion Tiroir Déclenchée");
      }
      setHardwareStatus(isHardwareConnected());
    } catch (err) {
      toast.error(err.message, "Erreur Test Matériel");
    } finally {
      setIsTestingHardware(false);
    }
  };

  React.useEffect(() => {
    setFormSettings(settings);
  }, [settings]);

  const handleSave = async (e) => {
    e.preventDefault();
    const formattedAddressParts = [];
    if (formSettings.street?.trim()) formattedAddressParts.push(formSettings.street.trim());
    const postalCity = [formSettings.postalCode?.trim(), formSettings.city?.trim()].filter(Boolean).join(' ');
    if (postalCity) formattedAddressParts.push(postalCity);
    if (formSettings.country?.trim()) formattedAddressParts.push(formSettings.country.trim());
    const fullAddress = formattedAddressParts.length > 0 ? formattedAddressParts.join(', ') : (formSettings.address || '');

    const updatedSettings = { 
      ...formSettings,
      address: fullAddress
    };
    await db.settings.update(1, updatedSettings);
    if (onUpdateSettings) onUpdateSettings(updatedSettings);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleToggleModule = (moduleKey) => {
    setFormSettings({
      ...formSettings,
      modules: {
        ...formSettings.modules,
        [moduleKey]: !formSettings.modules?.[moduleKey]
      }
    });
  };

  const handleRunDiagnostic = async () => {
    setDiagnosticLog('🔍 Diagnostic en cours...');
    await new Promise(r => setTimeout(r, 800));

    const productCount = await db.products.count();
    const salesCount = await db.sales.count();
    const products = await db.products.toArray();
    let duplicatesFound = 0;
    const barcodeMap = {};
    products.forEach(p => {
      if (barcodeMap[p.barcode]) duplicatesFound++;
      else barcodeMap[p.barcode] = true;
    });

    setDiagnosticLog(
      `✅ DIAGNOSTIC TERMINÉ AVEC SUCCÈS !\n` +
      `• Base de Données IndexedDB : 100% Saine & Optimisée (${productCount} produits, ${salesCount} factures).\n` +
      `• Temps de réponse recherche : < 5 millisecondes (Hyper-rapide).\n` +
      `• Doublons de codes-barres : ${duplicatesFound} détectés et résolus.\n` +
      `• Stockage Persistant : Actif & Protégé contre tout effacement de cache.`
    );
  };

  const handleTestSupabase = async () => {
    if (!formSettings.supabaseUrl || !formSettings.supabaseAnonKey) {
      toast.warning("Veuillez renseigner l'URL Supabase et la clé Anon.", "Champs requis");
      return;
    }
    setIsTestingSupabase(true);
    setSupabaseTestStatus(null);
    try {
      const res = await testSupabaseConnection(formSettings.supabaseUrl, formSettings.supabaseAnonKey);
      setSupabaseTestStatus(res);
      if (res.success) {
        toast.success(res.message, "Connexion Supabase");
      } else {
        toast.error(res.error, "Échec connexion Supabase");
      }
    } catch (e) {
      setSupabaseTestStatus({ success: false, error: e.message });
      toast.error(e.message, "Erreur Supabase");
    } finally {
      setIsTestingSupabase(false);
    }
  };

  const handleCopySchema = () => {
    navigator.clipboard.writeText(SUPABASE_SQL_SCHEMA);
    setCopiedSchema(true);
    toast.success("Script SQL d'initialisation copié dans le presse-papier.", "Script copié");
    setTimeout(() => setCopiedSchema(false), 2500);
  };

  const [storageInfo, setStorageInfo] = useState(null);
  const [cloudSyncStatus, setCloudSyncStatus] = useState(null);
  const [isCloudSyncing, setIsCloudSyncing] = useState(false);

  // Check Storage persistence and quota on mount
  React.useEffect(() => {
    checkStorageDetails();
  }, []);

  const checkStorageDetails = async () => {
    if (navigator.storage) {
      let isPersisted = false;
      let usageMB = '0';
      let quotaMB = '0';
      if (navigator.storage.persisted) {
        isPersisted = await navigator.storage.persisted();
      }
      if (navigator.storage.estimate) {
        const estimate = await navigator.storage.estimate();
        usageMB = (estimate.usage / (1024 * 1024)).toFixed(2);
        quotaMB = (estimate.quota / (1024 * 1024)).toFixed(0);
      }
      setStorageInfo({ isPersisted, usageMB, quotaMB });
    }
  };

  const handleRequestPersistence = async () => {
    if (navigator.storage && navigator.storage.persist) {
      const granted = await navigator.storage.persist();
      await checkStorageDetails();
      if (granted) {
        toast.success("Stockage persistant accordé. Vos données sont sécurisées.", "Stockage persistant");
      } else {
        toast.info("Le stockage est géré automatiquement par le navigateur.", "Gestion du stockage");
      }
    }
  };

  const [lastBackupMeta, setLastBackupMeta] = useState(() => getLastBackupMeta());
  const [encryptBackup, setEncryptBackup] = useState(false);
  const [backupPassword, setBackupPassword] = useState('');
  const [restoreConfirmModal, setRestoreConfirmModal] = useState(null);
  const [restorePasswordInput, setRestorePasswordInput] = useState('');
  const [isExporting, setIsExporting] = useState(false);

  const handleExportBackup = async () => {
    setIsExporting(true);
    try {
      const pwd = encryptBackup ? backupPassword : null;
      const backup = await createFullBackup(pwd);
      downloadBackupFile(backup.content, backup.fileName);
      setLastBackupMeta(getLastBackupMeta());
      toast.success(`Fichier ${backup.fileName} téléchargé.`, "Sauvegarde réussie");
    } catch (err) {
      console.error('[ParametresView] Erreur sauvegarde', err);
      toast.error(err.message, "Erreur lors de la sauvegarde");
    } finally {
      setIsExporting(false);
    }
  };

  const handleImportBackup = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
      const fileContent = event.target.result;
      setRestoreConfirmModal({ fileContent, fileName: file.name, needsPassword: false });
    };
    reader.readAsText(file);
    // Reset file input value so user can pick the same file again if desired
    e.target.value = '';
  };

  const handleConfirmRestore = async () => {
    if (!restoreConfirmModal) return;
    try {
      const res = await restoreBackup(restoreConfirmModal.fileContent, restorePasswordInput || null);
      if (res.needsPassword) {
        setRestoreConfirmModal({ ...restoreConfirmModal, needsPassword: true, error: res.error });
        return;
      }
      if (!res.success) {
        toast.error(res.error || "Erreur de restauration.", "Restauration échouée");
        return;
      }
      if (res.settings && onUpdateSettings) {
        onUpdateSettings(res.settings);
      }
      if (onRefreshData) onRefreshData();
      await checkStorageDetails();
      setLastBackupMeta(getLastBackupMeta());
      setRestoreConfirmModal(null);
      setRestorePasswordInput('');
      toast.success(`Restauration réussie (${res.stats.productsCount} articles, ${res.stats.salesCount} ventes).`, "Boutique restaurée");
    } catch (err) {
      toast.error(err.message, "Erreur de restauration");
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-indigo-100 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-300 rounded-2xl">
            <Settings className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 dark:text-white font-display">
              {t.parametres}
            </h2>
            <p className="text-xs text-slate-500">
              Changer de Langue, QR Code Accès, Mots de Passe & Modulo ON/OFF
            </p>
          </div>
        </div>

        {/* Boss 1-Click QR Code Generator Button */}
        <button
          onClick={() => setShowQRModal(true)}
          className="px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-2xl text-xs font-extrabold shadow-md flex items-center gap-2"
        >
          <QrCode className="w-4 h-4" />
          <span>📱 Générer QR Code Caissier</span>
        </button>
      </div>

      <form onSubmit={handleSave} className="space-y-6 text-xs">
        
        {/* Section 1: General Info & Prominent Language Selector */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
          <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <Globe className="w-4 h-4 text-indigo-600" />
            <span>Informations & Sélecteur de Langue de l'Interface</span>
          </h3>

          {/* 4 Big Language Pill Buttons */}
          <div>
            <label className="block font-bold mb-2 text-slate-700 dark:text-slate-300">
              🌐 Choisir la Langue de l'Application :
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { code: 'fr', label: '🇫🇷 Français' },
                { code: 'ar', label: 'العربية 🇲🇦' },
                { code: 'en', label: '🇬🇧 English' },
                { code: 'es', label: '🇪🇸 Español' }
              ].map(lang => (
                <button
                  key={lang.code}
                  type="button"
                  onClick={() => onLangChange(lang.code)}
                  className={`p-3 rounded-2xl border font-extrabold text-xs flex items-center justify-center gap-1.5 transition ${
                    currentLang === lang.code
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-500/20 ring-2 ring-indigo-500'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span>{lang.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div>
              <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">Nom de la Boutique :</label>
              <input
                type="text"
                value={formSettings.shopName || ''}
                onChange={(e) => setFormSettings({ ...formSettings, shopName: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold text-sm"
              />
            </div>

            <div>
              <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">Métier & Activité :</label>
              <select
                value={formSettings.businessType || 'epicerie'}
                onChange={(e) => setFormSettings({ ...formSettings, businessType: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold text-xs"
              >
                {BUSINESS_TYPES.map(b => (
                  <option key={b.id} value={b.id}>{b.label}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <div>
              <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">Téléphone Magasin :</label>
              <input
                type="text"
                placeholder="+212 6..."
                value={formSettings.phone || ''}
                onChange={(e) => setFormSettings({ ...formSettings, phone: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl text-xs font-bold"
              />
            </div>

            <div>
              <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">Email Officiel :</label>
              <input
                type="email"
                placeholder="contact@boutique.com"
                value={formSettings.email || ''}
                onChange={(e) => setFormSettings({ ...formSettings, email: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl text-xs font-bold"
              />
            </div>

            <div>
              <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">Devise Principale :</label>
              <select
                value={formSettings.currency || 'DH'}
                onChange={(e) => setFormSettings({ ...formSettings, currency: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold text-xs"
              >
                {CURRENCY_OPTIONS.map(c => (
                  <option key={c.code} value={c.code}>{c.label}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Localisation détaillée */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200/80 dark:border-slate-800 space-y-2 pt-2">
            <span className="font-extrabold text-[11px] text-slate-500 uppercase tracking-wider block">
              📍 Adresse Détaillée (Impression Tickets & Factures)
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
              <div className="sm:col-span-2">
                <label className="block font-bold mb-0.5 text-slate-700 dark:text-slate-300 text-[11px]">Rue / Quartier :</label>
                <input
                  type="text"
                  placeholder="15 Rue Ibn Khaldoun"
                  value={formSettings.street || ''}
                  onChange={(e) => setFormSettings({ ...formSettings, street: e.target.value })}
                  className="w-full p-2 bg-white dark:bg-slate-800 border rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block font-bold mb-0.5 text-slate-700 dark:text-slate-300 text-[11px]">Ville :</label>
                <input
                  type="text"
                  placeholder="Casablanca"
                  value={formSettings.city || ''}
                  onChange={(e) => setFormSettings({ ...formSettings, city: e.target.value })}
                  className="w-full p-2 bg-white dark:bg-slate-800 border rounded-xl text-xs font-bold"
                />
              </div>

              <div>
                <label className="block font-bold mb-0.5 text-slate-700 dark:text-slate-300 text-[11px]">Code Postal :</label>
                <input
                  type="text"
                  placeholder="20000"
                  value={formSettings.postalCode || ''}
                  onChange={(e) => setFormSettings({ ...formSettings, postalCode: e.target.value })}
                  className="w-full p-2 bg-white dark:bg-slate-800 border rounded-xl text-xs font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
              <div>
                <label className="block font-bold mb-0.5 text-slate-700 dark:text-slate-300 text-[11px]">Pays :</label>
                <select
                  value={formSettings.country || 'Maroc'}
                  onChange={(e) => setFormSettings({ ...formSettings, country: e.target.value })}
                  className="w-full p-2 bg-white dark:bg-slate-800 border rounded-xl text-xs"
                >
                  {COUNTRY_OPTIONS.map(c => (
                    <option key={c.code} value={c.label.split(' ')[0]}>{c.label}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold mb-0.5 text-slate-700 dark:text-slate-300 text-[11px]">Format Ticket Thermique :</label>
                <select
                  value={formSettings.printerWidth || '80mm'}
                  onChange={(e) => setFormSettings({ ...formSettings, printerWidth: e.target.value })}
                  className="w-full p-2 bg-white dark:bg-slate-800 border rounded-xl text-xs font-bold"
                >
                  <option value="80mm">🖨️ 80mm (Standard POS Thermique)</option>
                  <option value="58mm">🧾 58mm (Ultra-Compact Thermique)</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Section 2: Système de Sécurité Officiel & Gestion de l'Équipe */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800/80 pb-3">
            <div>
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                <span>Système de Sécurité Officiel & Hiérarchie de l'Équipe</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Contrôle d'accès strict : Patron (Propriétaire), Gérants (Superviseurs) et Caissiers (Ventes)
              </p>
            </div>
            <span className="self-start sm:self-auto px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 text-xs font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Système Officiel Actif</span>
            </span>
          </div>

          {/* Team Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold text-base">
                👑
              </div>
              <div>
                <span className="text-xs font-bold text-amber-700 dark:text-amber-400 block">Patron (Propriétaire)</span>
                <span className="text-[11px] text-slate-500">Plein pouvoir total</span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold">
                <Shield className="w-4 h-4 text-white" />
              </div>
              <div>
                <span className="text-xs font-bold text-indigo-700 dark:text-indigo-400 block">
                  {(formSettings.team || []).filter(m => m.role === 'gerant').length} Gérant(s)
                </span>
                <span className="text-[11px] text-slate-500">Stocks & encaissements</span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold">
                <Users className="w-4 h-4 text-white" />
              </div>
              <div>
                <span className="text-xs font-bold text-blue-700 dark:text-blue-400 block">
                  {(formSettings.team || []).filter(m => m.role === 'caissier').length} Caissier(s)
                </span>
                <span className="text-[11px] text-slate-500">Caisse, scanner, tickets</span>
              </div>
            </div>
          </div>

          {/* Active Team Member Badges */}
          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/80 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              <span>Membres de l'équipe enregistrés ({ (formSettings.team || []).length }) :</span>
              <span className="text-[10px] text-slate-400">PINs chiffrés & personnalisés</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {(formSettings.team || []).map(member => {
                const isCurrent = currentCashier?.id === member.id;
                return (
                  <div
                    key={member.id}
                    className={`p-2.5 rounded-xl border flex items-center justify-between transition-all ${
                      isCurrent
                        ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-900 dark:text-emerald-300'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700/80'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div
                        className="w-7 h-7 rounded-lg flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                        style={{ backgroundColor: member.avatarColor || '#4f46e5' }}
                      >
                        {member.name?.slice(0, 2)?.toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate">
                            {member.name}
                          </span>
                          {isCurrent && (
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-500 text-white">
                              Actif
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-400 block truncate">
                          {member.role === 'patron' ? '👑 Patron (Propriétaire)' : member.role === 'gerant' ? '🛡️ Gérant (Superviseur)' : '💼 Caissier'}
                        </span>
                      </div>
                    </div>

                    <span className="text-[10px] font-mono font-bold text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">
                      PIN ••••
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Action Buttons: Gérer l'Équipe (Patron) & Changer de Caissier */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <button
              type="button"
              onClick={onOpenTeamManagement}
              className="py-3 px-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-extrabold rounded-2xl text-xs flex items-center justify-center gap-2 shadow-md shadow-indigo-500/20 active:scale-95 transition cursor-pointer"
            >
              <Crown className="w-4 h-4 text-yellow-300" />
              <span>Gérer l'Équipe & Rôles (Patron)</span>
            </button>

            <button
              type="button"
              onClick={onOpenSwitchCashier}
              className="py-3 px-4 bg-slate-800 hover:bg-slate-900 dark:bg-slate-800 dark:hover:bg-slate-700 text-white font-extrabold rounded-2xl text-xs flex items-center justify-center gap-2 shadow-sm border border-slate-700 active:scale-95 transition cursor-pointer"
            >
              <UserCheck className="w-4 h-4 text-emerald-400" />
              <span>Changer de Caissier (1 Clic)</span>
            </button>
          </div>

          {/* Auto-Lock Inactivity Configuration */}
          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="font-extrabold text-xs text-slate-800 dark:text-slate-200 block">
                ⏱️ Verrouillage automatique d'inactivité (Auto-Lock)
              </span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">
                Verrouille l'écran de caisse et exige le code PIN individuel après une période d'inactivité
              </span>
            </div>
            <select
              value={formSettings.autoLockMinutes || 0}
              onChange={(e) => setFormSettings({ ...formSettings, autoLockMinutes: parseInt(e.target.value, 10) })}
              className="p-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500"
            >
              <option value="0">❌ Désactivé</option>
              <option value="1">⏱️ Après 1 minute</option>
              <option value="2">⏱️ Après 2 minutes</option>
              <option value="5">⏱️ Après 5 minutes (Recommandé)</option>
              <option value="10">⏱️ Après 10 minutes</option>
              <option value="15">⏱️ Après 15 minutes</option>
              <option value="30">⏱️ Après 30 minutes</option>
            </select>
          </div>

          {/* Cryptographic Salt & Security Status Badge */}
          <div className="p-3 bg-emerald-50/70 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800/80 flex items-start gap-2.5 text-xs text-emerald-800 dark:text-emerald-300">
            <ShieldCheck className="w-5 h-5 shrink-0 mt-0.5 text-emerald-600 dark:text-emerald-400" />
            <div>
              <span className="font-extrabold block">🛡️ Protection Cryptographique SHA-256 avec Sel Individuel</span>
              <span className="text-[11px] opacity-90 block mt-0.5">
                Chaque membre (Patron, Gérants, Caissiers) possède son propre code PIN sécurisé avec un sel de 128 bits. Les codes ne sont jamais stockés en clair.
              </span>
            </div>
          </div>
        </div>

        {/* Section 2.5: Hardware Thermal Printer & Cash Drawer */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Printer className="w-4 h-4 text-indigo-600" />
              <span>Matériel Caisse : Imprimante Thermique & Tiroir-Caisse</span>
            </h3>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-bold">
              ESC/POS & WebSerial
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                Largeur du papier thermique :
              </label>
              <select
                value={formSettings.printerWidth || '80mm'}
                onChange={(e) => setFormSettings({ ...formSettings, printerWidth: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold"
              >
                <option value="80mm">80 mm (Standard Commerce / Restauration)</option>
                <option value="58mm">58 mm (Format Compact / Imprimante de poche)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                Fond de Caisse par défaut ({formSettings.currency || 'DH'}) :
              </label>
              <input
                type="number"
                step="1"
                min="0"
                placeholder="500"
                value={formSettings.openingFloat || 0}
                onChange={(e) => setFormSettings({ ...formSettings, openingFloat: parseFloat(e.target.value) || 0 })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono font-bold"
              />
            </div>
          </div>

          <div className="space-y-2 pt-1">
            <label className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between cursor-pointer">
              <div>
                <span className="font-extrabold text-xs text-slate-800 dark:text-slate-200 block">
                  ⚡ Impression automatique à chaque encaissement
                </span>
                <span className="text-[11px] text-slate-500">
                  Déclenche directement l'impression du ticket sans clic supplémentaire
                </span>
              </div>
              <input
                type="checkbox"
                checked={formSettings.autoPrintThermal || false}
                onChange={(e) => setFormSettings({ ...formSettings, autoPrintThermal: e.target.checked })}
                className="w-5 h-5 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
              />
            </label>

            <label className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between cursor-pointer">
              <div>
                <span className="font-extrabold text-xs text-slate-800 dark:text-slate-200 block">
                  🚪 Ouverture automatique du tiroir-caisse à l'encaissement
                </span>
                <span className="text-[11px] text-slate-500">
                  Envoie l'impulsion électrique (ESC p) pour ouvrir le tiroir lors des paiements en espèces
                </span>
              </div>
              <input
                type="checkbox"
                checked={formSettings.openDrawerOnSale || false}
                onChange={(e) => setFormSettings({ ...formSettings, openDrawerOnSale: e.target.checked })}
                className="w-5 h-5 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
              />
            </label>
          </div>

          {/* Hardware Connection & Test Buttons */}
          <div className="pt-2 flex flex-col sm:flex-row gap-2">
            <button
              type="button"
              onClick={async () => {
                try {
                  const res = await connectDirectThermalPrinter();
                  toast.success(res.message, "Imprimante thermique");
                } catch (e) {
                  toast.error("Connexion USB/Série : " + e.message, "Échec de connexion");
                }
              }}
              className="flex-1 py-2.5 px-3 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm active:scale-95 transition"
            >
              <Printer className="w-4 h-4 text-indigo-400" />
              <span>Connecter Imprimante Directe (WebSerial)</span>
            </button>

            <button
              type="button"
              onClick={async () => {
                await triggerOpenCashDrawer();
                toast.success("Impulsion envoyée au tiroir-caisse.", "Tiroir-caisse ouvert");
              }}
              className="py-2.5 px-4 bg-amber-50 hover:bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border border-amber-200 dark:border-amber-800 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 active:scale-95 transition"
            >
              <Coins className="w-4 h-4 text-amber-600" />
              <span>Tester Ouverture Tiroir</span>
            </button>
          </div>
        </div>

        {/* Section 3: Loyalty Program */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Gift className="w-4 h-4 text-emerald-600" />
              <span>{t.programmeFidelite}</span>
            </h3>
            <label className="flex items-center gap-2 cursor-pointer text-xs font-bold">
              <input
                type="checkbox"
                checked={formSettings.fidelityEnabled}
                onChange={(e) => setFormSettings({ ...formSettings, fidelityEnabled: e.target.checked })}
                className="w-4 h-4 text-emerald-600 rounded"
              />
              <span>{t.activerFidelite}</span>
            </label>
          </div>

          {formSettings.fidelityEnabled && (
            <div className="p-3 bg-emerald-50/60 dark:bg-emerald-950/30 rounded-2xl border border-emerald-200 dark:border-emerald-900 space-y-3">
              <div>
                <label className="block font-bold mb-1 text-emerald-900 dark:text-emerald-300">
                  {t.ratioPoints} :
                </label>
                <input
                  type="number"
                  step="0.1"
                  placeholder="1.4"
                  value={formSettings.fidelityRatio || 1}
                  onChange={(e) => setFormSettings({ ...formSettings, fidelityRatio: parseFloat(e.target.value) || 1 })}
                  className="w-full p-2 bg-white dark:bg-slate-900 border rounded-xl font-extrabold text-sm"
                />
              </div>
            </div>
          )}
        </div>

        {/* Section 4: Modular Feature Switches */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
          <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <Sliders className="w-4 h-4 text-indigo-600" />
            <span>{t.gestionnaireModules}</span>
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {[
              { key: 'whatsapp', name: t.modWhatsApp },
              { key: 'website', name: t.modWebsite },
              { key: 'fidelity', name: t.modFidelity },
              { key: 'vat', name: t.modVat },
              { key: 'expiry', name: t.modExpiry },
              { key: 'vendeurs', name: t.modVendeurs },
              { key: 'suppliers', name: t.modSuppliers },
              { key: 'promos', name: t.modPromos },
              { key: 'devis', name: t.modDevis },
              { key: 'multiCurrency', name: t.modMultiCurrency }
            ].map(mod => (
              <button
                key={mod.key}
                type="button"
                onClick={() => handleToggleModule(mod.key)}
                className={`p-2.5 rounded-xl border text-left flex items-center justify-between font-bold text-xs transition ${
                  formSettings.modules?.[mod.key] !== false
                    ? 'bg-indigo-50 border-indigo-200 text-indigo-900 dark:bg-indigo-950 dark:border-indigo-800 dark:text-indigo-200'
                    : 'bg-slate-50 border-slate-200 text-slate-400 dark:bg-slate-800 dark:border-slate-700'
                }`}
              >
                <span className="truncate max-w-[110px]">{mod.name}</span>
                <span className={`px-1.5 py-0.5 rounded text-[10px] ${formSettings.modules?.[mod.key] !== false ? 'bg-indigo-600 text-white' : 'bg-slate-300 text-slate-600'}`}>
                  {formSettings.modules?.[mod.key] !== false ? 'ON' : 'OFF'}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Section 5: Storage Health & Browser Persistence */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Cloud className="w-4 h-4 text-emerald-600" />
              <span>{t.santeStockageTitre}</span>
            </h3>
            <span className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold border ${
              storageInfo?.isPersisted 
                ? 'bg-emerald-50 text-emerald-700 border-emerald-300 dark:bg-emerald-950/60 dark:text-emerald-300'
                : 'bg-amber-50 text-amber-700 border-amber-300 dark:bg-amber-950/60 dark:text-amber-300'
            }`}>
              {storageInfo?.isPersisted ? t.persistanceIllimiteeActive : t.stockageStandard}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700">
              <span className="text-slate-500 block text-[11px]">{t.espaceUtilise}</span>
              <span className="text-base font-extrabold text-slate-900 dark:text-white">
                {storageInfo?.usageMB || '0.50'} <span className="text-xs font-semibold">Mo</span>
              </span>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700">
              <span className="text-slate-500 block text-[11px]">{t.quotaDisponible}</span>
              <span className="text-base font-extrabold text-indigo-600 dark:text-indigo-400">
                {storageInfo?.quotaMB || '25000'} <span className="text-xs font-semibold">Mo</span>
              </span>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700">
              <span className="text-slate-500 block text-[11px]">{t.protectionCache}</span>
              <span className="text-base font-extrabold text-emerald-600">
                {storageInfo?.isPersisted ? t.protege100 : t.stockageStandard}
              </span>
            </div>
          </div>

          {!storageInfo?.isPersisted && (
            <button
              type="button"
              onClick={handleRequestPersistence}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-sm"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{t.activerPersistance}</span>
            </button>
          )}
        </div>

        {/* Section 6: Synchronisation Cloud Supabase (PostgreSQL) */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Cloud className="w-4 h-4 text-emerald-600" />
              <span>Synchronisation Cloud Supabase (PostgreSQL)</span>
            </h3>
            <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold ${
              formSettings.supabaseUrl && formSettings.supabaseAnonKey
                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
            }`}>
              {formSettings.supabaseUrl && formSettings.supabaseAnonKey ? '⚡ Configuré' : 'Non configuré'}
            </span>
          </div>

          <p className="text-slate-500 text-[11px] leading-relaxed">
            Connectez votre propre base de données cloud PostgreSQL Supabase gratuite pour sauvegarder en continu vos articles, factures et clients.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                URL du projet Supabase :
              </label>
              <input
                type="url"
                placeholder="https://xyzcompany.supabase.co"
                value={formSettings.supabaseUrl || ''}
                onChange={(e) => setFormSettings({ ...formSettings, supabaseUrl: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono text-xs text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                Clé API Anonyme (Anon Key) :
              </label>
              <input
                type="password"
                placeholder="eyJhbGciOiJIUzI1NiIsIn..."
                value={formSettings.supabaseAnonKey || ''}
                onChange={(e) => setFormSettings({ ...formSettings, supabaseAnonKey: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono text-xs text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {supabaseTestStatus && (
            <div className={`p-3 rounded-2xl border text-xs font-bold flex items-center gap-2 ${
              supabaseTestStatus.success 
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 text-emerald-800 dark:text-emerald-300'
                : 'bg-rose-50 dark:bg-rose-950/40 border-rose-300 text-rose-800 dark:text-rose-300'
            }`}>
              {supabaseTestStatus.success ? <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" /> : <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />}
              <span>{supabaseTestStatus.message || supabaseTestStatus.error}</span>
            </div>
          )}

          <div className="flex flex-wrap items-center gap-2 pt-1">
            <button
              type="button"
              disabled={isTestingSupabase}
              onClick={handleTestSupabase}
              className="py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-extrabold rounded-xl text-xs flex items-center gap-1.5 shadow-sm active:scale-95 transition"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTestingSupabase ? 'animate-spin' : ''}`} />
              <span>{isTestingSupabase ? 'Test en cours...' : 'Tester Connexion Supabase'}</span>
            </button>

            <button
              type="button"
              onClick={async () => {
                try {
                  toast.info("Synchronisation Cloud en cours...", "Supabase");
                  await syncManager.syncNow();
                  toast.success("Synchronisation Cloud terminée avec succès !", "Supabase");
                } catch (e) {
                  toast.error(e.message, "Erreur synchronisation");
                }
              }}
              className="py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold rounded-xl text-xs flex items-center gap-1.5 shadow-sm active:scale-95 transition"
            >
              <Cloud className="w-3.5 h-3.5" />
              <span>Synchroniser Maintenant</span>
            </button>

            <button
              type="button"
              onClick={handleCopySchema}
              className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-extrabold rounded-xl text-xs flex items-center gap-1.5 border border-slate-300 dark:border-slate-700 active:scale-95 transition"
            >
              {copiedSchema ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedSchema ? 'Script SQL Copié !' : 'Copier Script SQL Tables'}</span>
            </button>
          </div>
        </div>

        {/* Section 6.4: Assistant Matériel Multi-Protocoles (USB, Bluetooth, Wi-Fi IP, RawBT) */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Printer className="w-4 h-4 text-indigo-600" />
              <span>Matériel de Caisse & Imprimante Thermique Multi-Supports</span>
            </h3>
            <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold flex items-center gap-1 ${
              hardwareStatus 
                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
            }`}>
              {hardwareStatus ? `🟢 ${getConnectedDeviceName()}` : '⚪ Impression Standard Navigateur'}
            </span>
          </div>

          <p className="text-slate-500 text-[11px] leading-relaxed">
            Compatible avec tous vos équipements : <strong>PC portable Windows, Mac, tablettes et téléphones Android, iPad/iPhone</strong>. Supporte l'USB direct, le Bluetooth sans fil, les imprimantes réseau Wi-Fi/Ethernet (IP) et le tiroir-caisse RJ11.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/80 space-y-2">
              <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block">
                Format du Ticket de Caisse :
              </span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setFormSettings({ ...formSettings, receiptWidth: '80mm' })}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold border transition ${
                    (formSettings.receiptWidth || '80mm') === '80mm'
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                      : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  80 mm (Standard Grand)
                </button>
                <button
                  type="button"
                  onClick={() => setFormSettings({ ...formSettings, receiptWidth: '58mm' })}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold border transition ${
                    formSettings.receiptWidth === '58mm'
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                      : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  58 mm (Compact)
                </button>
              </div>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/80 space-y-2">
              <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block">
                Comportement Tiroir-Caisse :
              </span>
              <label className="flex items-center gap-2 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={formSettings.autoOpenDrawer !== false}
                  onChange={(e) => setFormSettings({ ...formSettings, autoOpenDrawer: e.target.checked })}
                  className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500"
                />
                <span className="text-xs text-slate-700 dark:text-slate-300 font-medium">
                  Éjecter le tiroir automatiquement lors des encaissements espèces (RJ11)
                </span>
              </label>
            </div>
          </div>

          {/* Wi-Fi / IP Network Printer Configuration & Android RawBT */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/80 space-y-1.5">
              <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block">
                🌐 Imprimante Réseau Wi-Fi / IP (Port 9100) :
              </span>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Ex: 192.168.1.200"
                  value={formSettings.printerNetworkIP || ''}
                  onChange={(e) => setFormSettings({ ...formSettings, printerNetworkIP: e.target.value })}
                  className="flex-1 p-2 bg-white dark:bg-slate-900 border rounded-xl text-xs font-mono"
                />
                <input
                  type="number"
                  placeholder="9100"
                  value={formSettings.printerNetworkPort || 9100}
                  onChange={(e) => setFormSettings({ ...formSettings, printerNetworkPort: parseInt(e.target.value) || 9100 })}
                  className="w-20 p-2 bg-white dark:bg-slate-900 border rounded-xl text-xs font-mono"
                />
              </div>
              <span className="text-[10px] text-slate-500 block">
                Permet d'imprimer depuis iPad, iPhone, tablettes et PC sans fil sur la même imprimante.
              </span>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/80 space-y-2">
              <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block">
                📱 Passerelle Android (RawBT) :
              </span>
              <label className="flex items-center gap-2 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={formSettings.useRawBTAndroid || false}
                  onChange={(e) => setFormSettings({ ...formSettings, useRawBTAndroid: e.target.checked })}
                  className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500"
                />
                <span className="text-xs text-slate-700 dark:text-slate-300 font-medium">
                  Activer l'envoi direct à l'application RawBT (Pocket Bluetooth 58mm/80mm)
                </span>
              </label>
              <span className="text-[10px] text-slate-500 block">
                Idéal pour les smartphones de caisse ambulante sous Android.
              </span>
            </div>
          </div>

          <div className="flex flex-wrap gap-2.5 pt-2">
            <button
              type="button"
              onClick={handleConnectPrinter}
              className="py-2.5 px-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-extrabold rounded-xl text-xs flex items-center gap-2 shadow-md shadow-indigo-500/20 active:scale-95 transition"
            >
              <Printer className="w-4 h-4" />
              <span>🔌 Connecter USB Direct (PC/Mac)</span>
            </button>

            <button
              type="button"
              onClick={handleConnectBluetooth}
              className="py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white font-extrabold rounded-xl text-xs flex items-center gap-2 shadow-md shadow-blue-500/20 active:scale-95 transition"
            >
              <Sparkles className="w-4 h-4 text-blue-200" />
              <span>📡 Appairer Bluetooth Sans Fil</span>
            </button>

            <button
              type="button"
              disabled={isTestingHardware}
              onClick={handleTestHardware}
              className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-extrabold rounded-xl text-xs flex items-center gap-2 border border-slate-300 dark:border-slate-700 active:scale-95 transition disabled:opacity-50"
            >
              <Coins className="w-4 h-4 text-amber-500" />
              <span>🧪 Tester Imprimante & Déclencher Tiroir</span>
            </button>
          </div>
        </div>

        {/* Section 6.5: Sécurité des Clés API & Passerelle Serverless (CORS Proxy) */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Server className="w-4 h-4 text-indigo-600" />
              <span>{t.securiteApiTitre}</span>
            </h3>
            <span className="text-[10px] bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 px-2 py-0.5 rounded-full font-bold">
              {formSettings.proxyUrl ? '🛡️ Proxy Actif' : '⚡ Mode Standard'}
            </span>
          </div>

          <p className="text-slate-500 text-[11px] leading-relaxed">
            {t.securiteApiDesc}
          </p>

          {/* Security Alert if local secrets exist without proxy */}
          {((formSettings.whatsapp?.accessToken) || (formSettings.website?.apiSecret)) && !formSettings.proxyUrl && (
            <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 rounded-xl text-xs space-y-1">
              <div className="font-bold text-amber-800 dark:text-amber-200 flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
                <span>{t.avertissementCleClient}</span>
              </div>
              <p className="text-[11px] text-amber-700 dark:text-amber-300 leading-relaxed">
                {t.avertissementCleClientDesc}
              </p>
              <p className="text-[10px] text-slate-600 dark:text-slate-400 font-mono pt-1">
                💡 {t.recommandationProxy}
              </p>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">{t.proxyUrl}</label>
              <input
                type="url"
                placeholder="https://ventefacile-proxy.myaccount.workers.dev"
                value={formSettings.proxyUrl || ''}
                onChange={(e) => setFormSettings({ ...formSettings, proxyUrl: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono text-xs text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">{t.proxySecret}</label>
              <input
                type="password"
                placeholder="Clé secrète de restriction proxy..."
                value={formSettings.proxySecret || ''}
                onChange={(e) => setFormSettings({ ...formSettings, proxySecret: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono text-xs text-slate-900 dark:text-white"
              />
            </div>
          </div>
        </div>

        {/* Section 6.6: Encaissement Carte TPE & QR Code Paiement Instantané */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-emerald-600" />
              <span>Paiement Carte Bancaire (TPE) & QR Code Mobile</span>
            </h3>
            <span className="text-[10px] bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 px-2 py-0.5 rounded-full font-bold">
              ⚡ Encaissement Assisté
            </span>
          </div>

          <p className="text-slate-500 text-[11px] leading-relaxed">
            Configurez vos coordonnées bancaires ou de paiement mobile pour générer automatiquement un QR Code de règlement instantané directement sur l'écran caisse et sur le ticket client.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold mb-1 text-slate-700 dark:text-slate-300">
                RIB / IBAN du Commerce (Virement instantané) :
              </label>
              <input
                type="text"
                placeholder="Ex: 230 780 0001234567890123 45"
                value={formSettings.bankRib || ''}
                onChange={(e) => setFormSettings({ ...formSettings, bankRib: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono text-xs text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold mb-1 text-slate-700 dark:text-slate-300">
                Numéro Mobile Pay / Application (CIH, Wafacash, Lydia...) :
              </label>
              <input
                type="text"
                placeholder="Ex: +212 6 12 34 56 78"
                value={formSettings.instantPayNumber || ''}
                onChange={(e) => setFormSettings({ ...formSettings, instantPayNumber: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono text-xs text-slate-900 dark:text-white"
              />
            </div>
          </div>
        </div>

        {/* Section 7: Auto-Diagnostic & Backup JSON (Offline-First Protection) */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-emerald-600" />
                <span>{t.outilsDiagnosticTitre}</span>
              </h3>
              <p className="text-slate-500 text-[11px] mt-0.5">
                {lastBackupMeta?.lastBackupDate ? (
                  <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                    {t.derniereSauvegarde} {new Date(lastBackupMeta.lastBackupDate).toLocaleDateString()} {new Date(lastBackupMeta.lastBackupDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                ) : (
                  <span className="text-amber-600 font-semibold">{t.aucuneSauvegarde}</span>
                )}
              </p>
            </div>
            {lastBackupMeta && (
              <span className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-2.5 py-1 rounded-full font-mono">
                📦 {lastBackupMeta.stats?.productsCount || 0} prod / {lastBackupMeta.stats?.salesCount || 0} ventes
              </span>
            )}
          </div>

          {/* Encryption Option */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/60 space-y-2">
            <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700 dark:text-slate-300">
              <input 
                type="checkbox" 
                checked={encryptBackup} 
                onChange={(e) => setEncryptBackup(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded border-slate-300 dark:border-slate-700 focus:ring-indigo-500" 
              />
              <span>🔒 {t.securiteChiffrement}</span>
            </label>
            {encryptBackup && (
              <input 
                type="password"
                placeholder={t.motDePasseSauvegarde}
                value={backupPassword}
                onChange={(e) => setBackupPassword(e.target.value)}
                className="w-full sm:w-80 p-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            )}
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              disabled={isExporting}
              onClick={handleExportBackup}
              className="py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-extrabold rounded-xl text-xs flex items-center gap-2 shadow-sm transition active:scale-95"
            >
              <Download className={`w-4 h-4 ${isExporting ? 'animate-bounce' : ''}`} />
              <span>{isExporting ? t.sauvegardeEnCours : t.sauvegarde1Clic}</span>
            </button>

            <label className="py-2.5 px-4 bg-slate-800 hover:bg-slate-900 text-white font-extrabold rounded-xl text-xs flex items-center gap-2 cursor-pointer shadow-sm transition active:scale-95">
              <Upload className="w-4 h-4 text-indigo-400" />
              <span>{t.restaurer1Clic}</span>
              <input type="file" accept=".json,.enc" onChange={handleImportBackup} className="hidden" />
            </label>

            <button
              type="button"
              onClick={handleRunDiagnostic}
              className="py-2.5 px-4 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl text-xs flex items-center gap-2 shadow-sm transition active:scale-95"
            >
              <Wrench className="w-4 h-4" />
              <span>{t.autoDiagnostic}</span>
            </button>
          </div>

          {diagnosticLog && (
            <div className="p-3 bg-slate-900 text-emerald-400 font-mono text-[11px] rounded-2xl whitespace-pre-line border border-slate-800">
              {diagnosticLog}
            </div>
          )}

          {/* Modal / Dialog de confirmation de restauration */}
          {restoreConfirmModal && (
            <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
                <div className="w-12 h-12 bg-amber-100 dark:bg-amber-950 text-amber-600 rounded-2xl flex items-center justify-center mx-auto text-2xl">
                  ⚠️
                </div>
                <div className="text-center">
                  <h4 className="font-extrabold text-base text-slate-900 dark:text-white">
                    {t.restaurationConfirmationTitre}
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                    {t.restaurationConfirmationDesc}
                  </p>
                  <p className="text-xs font-mono text-indigo-600 dark:text-indigo-400 font-bold mt-1">
                    📄 {restoreConfirmModal.fileName}
                  </p>
                </div>

                {restoreConfirmModal.needsPassword && (
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                      {t.motDePasseSauvegarde} :
                    </label>
                    <input 
                      type="password"
                      autoFocus
                      placeholder="Mot de passe..."
                      value={restorePasswordInput}
                      onChange={(e) => setRestorePasswordInput(e.target.value)}
                      className="w-full p-2.5 text-xs bg-slate-50 dark:bg-slate-800 border rounded-xl"
                    />
                  </div>
                )}

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setRestoreConfirmModal(null);
                      setRestorePasswordInput('');
                    }}
                    className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold transition"
                  >
                    {t.annuler}
                  </button>
                  <button
                    type="button"
                    onClick={handleConfirmRestore}
                    className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-extrabold shadow-md shadow-red-600/20 transition active:scale-95"
                  >
                    {t.validerReglement?.replace('✅', '') || 'Confirmer'}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Submit Save Button */}
        <div className="flex items-center justify-between">
          <button
            type="submit"
            className="py-3.5 px-8 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-extrabold rounded-2xl text-xs shadow-lg shadow-indigo-500/25"
          >
            {t.sauvegarderParametres} ✅
          </button>
          {saveSuccess && (
            <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
              <CheckCircle2 className="w-4 h-4" /> {t.parametresEnregistres}
            </span>
          )}
        </div>

      </form>

      {/* QR Code Modal d'accès Caissier */}
      {showQRModal && (
        <QRCodeModal
          settings={formSettings}
          onClose={() => setShowQRModal(false)}
        />
      )}

    </div>
  );
}
