import React, { useState, useEffect } from 'react';
import { 
  ArrowRightLeft, 
  Search, 
  RotateCcw, 
  Check, 
  Printer, 
  Send, 
  X, 
  AlertCircle, 
  Receipt, 
  CheckCircle2, 
  ShieldCheck,
  CreditCard,
  Banknote,
  Coins,
  Shirt,
  Tag,
  Package,
  ArrowRight
} from 'lucide-react';
import { db } from '../db';
import { computeSaleSeal, GENESIS_HASH } from '../auditChain';
import ThermalReceipt from './ThermalReceipt';
import { translations } from '../translations';
import { useToast } from '../context/ToastContext';
import { parseSafeFloat, sanitizeDecimalInput } from '../utils/numberUtils';
import { getLocalDateCompact } from '../utils/dateUtils';
import { syncManager } from '../syncManager';

export default function RefundModal({
  isOpen,
  onClose,
  settings = {},
  currentLang = 'fr',
  onRefreshData,
  cashierName = 'Caisse',
  products = []
}) {
  const toast = useToast();
  const t = translations[currentLang] || translations.fr;
  const currency = settings.currency || 'DH';

  // Navigation tab: 'refund' (Avoir & Remboursement) or 'exchange' (Échange de taille / variante)
  const [activeTab, setActiveTab] = useState('exchange');

  const [searchQuery, setSearchQuery] = useState('');
  const [matchingSales, setMatchingSales] = useState([]);
  const [selectedSale, setSelectedSale] = useState(null);

  // Refund Tab State
  const [refundQuantities, setRefundQuantities] = useState({});
  const [refundMethod, setRefundMethod] = useState('especes'); // especes, carte, avoir, virement
  const [refundReason, setRefundReason] = useState('Retour Marchandise');
  const [completedRefundSale, setCompletedRefundSale] = useState(null);

  // Exchange Tab State
  const [exchangeItemKey, setExchangeItemKey] = useState(null);
  const [exchangeQty, setExchangeQty] = useState(1);
  const [exchangeType, setExchangeType] = useState('same_product'); // 'same_product' | 'different_product'
  const [newVariant, setNewVariant] = useState('');
  const [replacementProductId, setReplacementProductId] = useState('');
  const [replacementName, setReplacementName] = useState('');
  const [replacementPrice, setReplacementPrice] = useState(0);
  const [exchangePaymentMethod, setExchangePaymentMethod] = useState('especes'); // when delta > 0
  const [exchangeRefundMethod, setExchangeRefundMethod] = useState('especes'); // when delta < 0
  const [exchangeReason, setExchangeReason] = useState('Changement de taille / pointure');
  const [completedExchangeSale, setCompletedExchangeSale] = useState(null);

  const [isProcessing, setIsProcessing] = useState(false);

  // Reset & load recent sales on open
  useEffect(() => {
    if (isOpen) {
      loadRecentSales();
      setSelectedSale(null);
      setCompletedRefundSale(null);
      setCompletedExchangeSale(null);
      setRefundQuantities({});
      setSearchQuery('');
      setExchangeItemKey(null);
      setExchangeQty(1);
      setNewVariant('');
    }
  }, [isOpen]);

  const loadRecentSales = async () => {
    try {
      const allSales = await db.sales.orderBy('id').reverse().limit(12).toArray();
      // Sales with positive amount and not pure refund
      setMatchingSales(allSales.filter(s => (s.totalTTC > 0 || !s.type) && s.type !== 'refund'));
    } catch (e) {
      console.error('Erreur chargement ventes:', e);
    }
  };

  const handleSearch = async (query) => {
    setSearchQuery(query);
    const q = (query || '').trim().toLowerCase();
    if (!q) {
      loadRecentSales();
      return;
    }

    try {
      const allSales = await db.sales.toArray();
      const filtered = allSales.filter(s => {
        if (s.type === 'refund') return false;
        const receiptMatch = s.receiptNo && s.receiptNo.toLowerCase().includes(q);
        const idMatch = s.id && s.id.toString() === q;
        const clientMatch = s.clientName && s.clientName.toLowerCase().includes(q);
        return receiptMatch || idMatch || clientMatch;
      }).reverse();

      setMatchingSales(filtered);
    } catch (e) {
      console.error('Erreur recherche vente:', e);
    }
  };

  const handleSelectSale = (sale) => {
    setSelectedSale(sale);
    const initialQ = {};
    (sale.items || []).forEach(item => {
      const key = item.productId || item.id || item.cartKey || item.name;
      initialQ[key] = 0;
    });
    setRefundQuantities(initialQ);
    setRefundMethod(sale.paymentMethod || 'especes');

    // Auto-select first item for exchange tab
    if (sale.items && sale.items.length > 0) {
      const firstItem = sale.items[0];
      const key = firstItem.productId || firstItem.id || firstItem.cartKey || firstItem.name;
      initExchangeForItem(firstItem, key);
    }
  };

  const initExchangeForItem = (item, key) => {
    setExchangeItemKey(key);
    setExchangeQty(1);
    setExchangeType('same_product');
    setReplacementProductId(item.productId || item.id || '');
    setReplacementName(item.name || '');
    const unitPrice = Number(item.sellPrice || 0) * (1 - (Number(item.discountPercent) || 0) / 100);
    setReplacementPrice(unitPrice);
    setNewVariant('');
  };

  // Find currently selected item for exchange
  const currentExchangeItem = selectedSale?.items?.find(item => {
    const key = item.productId || item.id || item.cartKey || item.name;
    return key === exchangeItemKey;
  }) || (selectedSale?.items && selectedSale.items.length > 0 ? selectedSale.items[0] : null);

  // Find product from prop or state to discover available variants
  const originalCatalogProduct = (products || []).find(p => p.id === currentExchangeItem?.productId) || null;
  const availableVariants = originalCatalogProduct?.variants || [];

  // Compute exchange delta
  const computeExchangeDelta = () => {
    if (!currentExchangeItem) {
      return { oldTotal: 0, newTotal: 0, delta: 0, oldUnitPrice: 0, newUnitPrice: 0, q: 0 };
    }
    const oldUnitPrice = Number(currentExchangeItem.sellPrice || 0) * (1 - (Number(currentExchangeItem.discountPercent) || 0) / 100);
    const newUnitPrice = parseSafeFloat(replacementPrice, oldUnitPrice);
    const maxAllowed = currentExchangeItem.quantity || 1;
    const q = Math.max(1, Math.min(parseSafeFloat(exchangeQty, 1), maxAllowed));
    const oldTotal = Math.round(oldUnitPrice * q * 100) / 100;
    const newTotal = Math.round(newUnitPrice * q * 100) / 100;
    const delta = Math.round((newTotal - oldTotal) * 100) / 100;

    return { oldTotal, newTotal, delta, oldUnitPrice, newUnitPrice, q };
  };

  const { oldTotal, newTotal, delta: exchangeDelta, oldUnitPrice, newUnitPrice, q: effectiveExchangeQty } = computeExchangeDelta();

  // Compute refund totals in real time (for Refund Tab)
  const computeRefundTotals = () => {
    if (!selectedSale) return { totalTTC: 0, subtotalHT: 0, totalVAT: 0, count: 0 };
    let totalTTC = 0;
    let subtotalHT = 0;
    let totalVAT = 0;
    let count = 0;

    (selectedSale.items || []).forEach(item => {
      const key = item.productId || item.id || item.cartKey || item.name;
      const q = parseSafeFloat(refundQuantities[key], 0);
      if (q > 0) {
        count += q;
        const unitPrice = Number(item.sellPrice || 0) * (1 - (Number(item.discountPercent) || 0) / 100);
        const lineTotal = unitPrice * q;
        const vatRate = Number(item.vatRate) || 20;
        const vatFactor = 1 + (vatRate / 100);
        const lineHT = lineTotal / vatFactor;
        const lineVAT = lineTotal - lineHT;

        totalTTC += lineTotal;
        subtotalHT += lineHT;
        totalVAT += lineVAT;
      }
    });

    return {
      totalTTC: Math.round(totalTTC * 100) / 100,
      subtotalHT: Math.round(subtotalHT * 100) / 100,
      totalVAT: Math.round(totalVAT * 100) / 100,
      count
    };
  };

  const { totalTTC: refundTotal, subtotalHT: refundHT, totalVAT: refundVAT, count: totalReturnedItemsCount } = computeRefundTotals();

  // ==========================================
  // CONFIRM RETURN / REFUND (TAB 1)
  // ==========================================
  const handleConfirmRefund = async () => {
    if (!selectedSale || refundTotal <= 0) return;
    setIsProcessing(true);

    try {
      const returnedItems = [];

      for (const item of (selectedSale.items || [])) {
        const key = item.productId || item.id || item.cartKey || item.name;
        const q = parseSafeFloat(refundQuantities[key], 0);
        if (q > 0) {
          const unitPrice = Number(item.sellPrice || 0) * (1 - (Number(item.discountPercent) || 0) / 100);
          returnedItems.push({
            ...item,
            quantity: q,
            refundedPrice: unitPrice
          });

          // 1. Re-integrate quantity into stock in db.products
          if (item.productId || item.id) {
            const targetId = item.productId || item.id;
            const prod = await db.products.get(targetId);
            if (prod) {
              const currentStock = Number(prod.stock || 0);
              await db.products.update(targetId, {
                stock: currentStock + q,
                synced: false,
                updatedAt: new Date().toISOString()
              });
            }
          }
        }
      }

      // 2. Adjust client debt if credit sale or avoir
      if (selectedSale.clientId && (selectedSale.isCredit || refundMethod === 'avoir')) {
        const client = await db.clients.get(selectedSale.clientId);
        if (client) {
          const newDebt = Math.max(0, (client.debt || 0) - refundTotal);
          await db.clients.update(client.id, { debt: Math.round(newDebt * 100) / 100 });
        }
      }

      // 3. Generate NF525 sequential number & hash chain seal
      const lastSale = await db.sales.orderBy('id').last();
      const count = await db.sales.count();
      const sequenceNumber = (lastSale && typeof lastSale.sequenceNumber === 'number') 
        ? lastSale.sequenceNumber + 1 
        : count + 1;

      const datePart = getLocalDateCompact();
      const refundReceiptNo = `AVOIR-${datePart}-${String(sequenceNumber).padStart(4, '0')}`;
      const previousHash = lastSale?.currentHash || GENESIS_HASH;

      const refundSaleData = {
        receiptNo: refundReceiptNo,
        originalReceiptNo: selectedSale.receiptNo,
        timestamp: new Date().toISOString(),
        items: returnedItems,
        subtotalHT: -refundHT,
        totalVAT: -refundVAT,
        totalTTC: -refundTotal,
        paymentMethod: refundMethod,
        clientName: selectedSale.clientName || 'Client Passant',
        clientId: selectedSale.clientId || null,
        type: 'refund',
        refundReason: refundReason,
        cashier: cashierName,
        synced: false
      };

      const seal = await computeSaleSeal(previousHash, refundSaleData, sequenceNumber);

      const savedRefundSale = {
        ...refundSaleData,
        sequenceNumber,
        previousHash: seal.previousHash,
        currentHash: seal.currentHash,
        sealShort: seal.sealShort,
        sealedAt: seal.sealedAt
      };

      const newId = await db.sales.add(savedRefundSale);
      savedRefundSale.id = newId;

      syncManager.syncNow().catch(() => {});
      setCompletedRefundSale(savedRefundSale);
      if (onRefreshData) onRefreshData();
      toast.success(`Avoir validé avec succès (${refundReceiptNo})`);
    } catch (err) {
      console.error('Erreur validation avoir:', err);
      toast.error('Erreur lors de la validation du retour : ' + err.message, "Erreur");
    } finally {
      setIsProcessing(false);
    }
  };

  // ==========================================
  // CONFIRM DIRECT EXCHANGE (TAB 2)
  // ==========================================
  const handleConfirmExchange = async () => {
    if (!selectedSale || !currentExchangeItem) return;
    setIsProcessing(true);

    try {
      const q = effectiveExchangeQty;
      const targetNewProdId = replacementProductId || currentExchangeItem.productId;

      // 1. Stock adjustments
      // Return old item to stock
      if (currentExchangeItem.productId) {
        const prod = await db.products.get(currentExchangeItem.productId);
        if (prod) {
          await db.products.update(prod.id, { 
            stock: Number(prod.stock || 0) + q,
            synced: false,
            updatedAt: new Date().toISOString()
          });
        }
      }

      // Deduct new item from stock
      if (targetNewProdId) {
        const prod = await db.products.get(targetNewProdId);
        if (prod) {
          await db.products.update(prod.id, { 
            stock: Math.max(0, Number(prod.stock || 0) - q),
            synced: false,
            updatedAt: new Date().toISOString()
          });
        }
      }

      // 2. Adjust client debt if delta !== 0 and payment method is debt / avoir
      if (selectedSale.clientId && exchangeDelta !== 0) {
        if (exchangePaymentMethod === 'avoir' || exchangeRefundMethod === 'avoir') {
          const client = await db.clients.get(selectedSale.clientId);
          if (client) {
            const newDebt = Math.max(0, (client.debt || 0) + exchangeDelta);
            await db.clients.update(client.id, { debt: Math.round(newDebt * 100) / 100 });
          }
        }
      }

      // 3. Generate NF525 sequential number & hash seal
      const lastSale = await db.sales.orderBy('id').last();
      const count = await db.sales.count();
      const sequenceNumber = (lastSale && typeof lastSale.sequenceNumber === 'number') 
        ? lastSale.sequenceNumber + 1 
        : count + 1;

      const datePart = getLocalDateCompact();
      const exchangeReceiptNo = `ECH-${datePart}-${String(sequenceNumber).padStart(4, '0')}`;
      const previousHash = lastSale?.currentHash || GENESIS_HASH;

      const effectiveOldVariant = currentExchangeItem.variant || 'Standard';
      const effectiveNewVariant = newVariant.trim() || 'Standard';

      const vatFactor = 1 + ((currentExchangeItem.vatRate || 20) / 100);
      const subtotalHT = Math.round((exchangeDelta / vatFactor) * 100) / 100;
      const totalVAT = Math.round((exchangeDelta - subtotalHT) * 100) / 100;

      const exchangeItems = [
        {
          productId: currentExchangeItem.productId,
          name: `[RETOUR] ${currentExchangeItem.name}`,
          variant: effectiveOldVariant,
          quantity: -q,
          sellPrice: oldUnitPrice,
          total: -oldTotal,
          vatRate: currentExchangeItem.vatRate || 20,
          isReturnLine: true
        },
        {
          productId: targetNewProdId,
          name: `[NOUVEAU] ${replacementName || currentExchangeItem.name}`,
          variant: effectiveNewVariant,
          quantity: q,
          sellPrice: newUnitPrice,
          total: newTotal,
          vatRate: currentExchangeItem.vatRate || 20,
          isExchangeLine: true
        }
      ];

      const resolvedPaymentMethod = exchangeDelta > 0 
        ? exchangePaymentMethod 
        : (exchangeDelta < 0 ? exchangeRefundMethod : 'echange_standard');

      const exchangeSaleData = {
        receiptNo: exchangeReceiptNo,
        originalReceiptNo: selectedSale.receiptNo,
        timestamp: new Date().toISOString(),
        items: exchangeItems,
        subtotalHT,
        totalVAT,
        totalTTC: exchangeDelta,
        paymentMethod: resolvedPaymentMethod,
        clientName: selectedSale.clientName || 'Client Passant',
        clientId: selectedSale.clientId || null,
        clientPhone: selectedSale.clientPhone || '',
        type: 'exchange',
        refundReason: exchangeReason,
        cashier: cashierName,
        synced: false,
        exchangeDetails: {
          originalItemName: currentExchangeItem.name,
          oldVariant: effectiveOldVariant,
          newItemName: replacementName || currentExchangeItem.name,
          newVariant: effectiveNewVariant,
          quantity: q,
          oldUnitPrice,
          newUnitPrice,
          delta: exchangeDelta
        }
      };

      const seal = await computeSaleSeal(previousHash, exchangeSaleData, sequenceNumber);

      const savedExchangeSale = {
        ...exchangeSaleData,
        sequenceNumber,
        previousHash: seal.previousHash,
        currentHash: seal.currentHash,
        sealShort: seal.sealShort,
        sealedAt: seal.sealedAt
      };

      const newId = await db.sales.add(savedExchangeSale);
      savedExchangeSale.id = newId;

      syncManager.syncNow().catch(() => {});
      setCompletedExchangeSale(savedExchangeSale);
      if (onRefreshData) onRefreshData();
      toast.success(`Échange validé avec succès (${exchangeReceiptNo})`);
    } catch (err) {
      console.error('Erreur validation échange:', err);
      toast.error("Erreur lors de la validation de l'échange : " + err.message, "Erreur");
    } finally {
      setIsProcessing(false);
    }
  };

  // ==========================================
  // WHATSAPP GENERATORS
  // ==========================================
  const handleSendWhatsAppAvoir = () => {
    if (!completedRefundSale) return;
    const phone = selectedSale?.clientPhone || '';
    const message = `*TICKET D'AVOIR / REMBOURSEMENT - ${settings.shopName || 'VenteFacile'}*\n` +
      `--------------------------------\n` +
      `*Avoir N°:* ${completedRefundSale.receiptNo}\n` +
      `*Ticket d'origine:* ${completedRefundSale.originalReceiptNo}\n` +
      `*Date:* ${new Date(completedRefundSale.timestamp).toLocaleString('fr-FR')}\n` +
      `*Motif:* ${completedRefundSale.refundReason}\n` +
      `--------------------------------\n` +
      (completedRefundSale.items || []).map(i => `• ${i.name} x${i.quantity} = -${(i.refundedPrice * i.quantity).toFixed(2)} ${currency}`).join('\n') +
      `\n--------------------------------\n` +
      `*TOTAL REMBOURSÉ:* -${Math.abs(completedRefundSale.totalTTC).toFixed(2)} ${currency}\n` +
      `*Mode de restitution:* ${completedRefundSale.paymentMethod.toUpperCase()}\n` +
      `*Statut Stock:* Marchandise réintégrée en inventaire ✅\n` +
      `*Sceau Fiscal:* ${completedRefundSale.sealShort} 🔐\n\n` +
      `Merci pour votre confiance !`;

    const url = phone ? `https://wa.me/${phone}?text=${encodeURIComponent(message)}` : `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const handleSendWhatsAppExchange = () => {
    if (!completedExchangeSale) return;
    const phone = selectedSale?.clientPhone || completedExchangeSale.clientPhone || '';
    const details = completedExchangeSale.exchangeDetails || {};
    const delta = completedExchangeSale.totalTTC || 0;
    const deltaText = delta > 0 
      ? `Complément payé : +${delta.toFixed(2)} ${currency} (${completedExchangeSale.paymentMethod.toUpperCase()})` 
      : delta < 0 
        ? `Différence restituée : -${Math.abs(delta).toFixed(2)} ${currency} (${completedExchangeSale.paymentMethod.toUpperCase()})` 
        : `Échange direct équivalent : 0.00 ${currency}`;

    const message = `*TICKET D'ÉCHANGE DE TAILLE / ARTICLE - ${settings.shopName || 'VenteFacile'}*\n` +
      `--------------------------------\n` +
      `*Ticket Échange N°:* ${completedExchangeSale.receiptNo}\n` +
      `*Ticket d'origine:* ${completedExchangeSale.originalReceiptNo}\n` +
      `*Date:* ${new Date(completedExchangeSale.timestamp).toLocaleString('fr-FR')}\n` +
      `*Motif:* ${completedExchangeSale.refundReason}\n` +
      `--------------------------------\n` +
      `🔄 *Article retourné:* ${details.originalItemName} (${details.oldVariant}) x${details.quantity}\n` +
      `✨ *Nouvel article:* ${details.newItemName} (${details.newVariant}) x${details.quantity}\n` +
      `--------------------------------\n` +
      `*RÈGLEMENT DIFFÉRENCE :* ${deltaText}\n` +
      `*Statut Stock:* Inventaire réajusté avec succès ✅\n` +
      `*Sceau Fiscal:* ${completedExchangeSale.sealShort} 🔐\n\n` +
      `Merci pour votre confiance !`;

    const url = phone ? `https://wa.me/${phone}?text=${encodeURIComponent(message)}` : `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="relative bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 max-w-2xl w-full border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto no-scrollbar">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className={`p-2.5 rounded-2xl ${activeTab === 'exchange' ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300' : 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'}`}>
              {activeTab === 'exchange' ? <Shirt className="w-5 h-5" /> : <RotateCcw className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <span>{activeTab === 'exchange' ? "Échange Taille & Variante" : "Gestion des Retours & Avoirs"}</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300 font-mono font-bold">
                  NF525
                </span>
              </h3>
              <p className="text-xs text-slate-500">
                {activeTab === 'exchange' 
                  ? "Échange direct de pointure/taille en 1 clic sans double manipulation de caisse" 
                  : "Restitution client, réintégration en stock et génération d'avoir certifié"}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector (Only show if not finished) */}
        {!completedRefundSale && !completedExchangeSale && (
          <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-2xl text-xs font-extrabold">
            <button
              type="button"
              onClick={() => setActiveTab('exchange')}
              className={`py-2 px-3 rounded-xl flex items-center justify-center gap-2 transition ${
                activeTab === 'exchange'
                  ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <Shirt className="w-4 h-4" />
              <span>Échange de Taille / Variante</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('refund')}
              className={`py-2 px-3 rounded-xl flex items-center justify-center gap-2 transition ${
                activeTab === 'refund'
                  ? 'bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <RotateCcw className="w-4 h-4" />
              <span>Avoir & Remboursement</span>
            </button>
          </div>
        )}

        {/* SUCCESS VIEW: COMPLETED REFUND */}
        {completedRefundSale && (
          <div className="space-y-4 text-center py-4">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-300 rounded-3xl flex items-center justify-center mx-auto text-3xl shadow-lg shadow-emerald-500/20">
              ✓
            </div>
            <div>
              <h4 className="font-extrabold text-lg text-slate-900 dark:text-white">
                Avoir Validé & Stock Réintégré !
              </h4>
              <p className="text-xs text-slate-500 mt-1">
                L'avoir <strong className="font-mono text-indigo-600 dark:text-indigo-400 font-extrabold">{completedRefundSale.receiptNo}</strong> a été scellé dans le journal d'audit fiscal.
              </p>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 text-left text-xs space-y-1.5 font-medium max-w-md mx-auto">
              <div className="flex justify-between">
                <span className="text-slate-500">Ticket d'origine :</span>
                <span className="font-bold text-slate-900 dark:text-white">{completedRefundSale.originalReceiptNo}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Articles retournés :</span>
                <span className="font-bold text-slate-900 dark:text-white">{completedRefundSale.items?.length} référence(s)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Mode de restitution :</span>
                <span className="font-bold uppercase text-emerald-600 dark:text-emerald-400">{completedRefundSale.paymentMethod}</span>
              </div>
              <div className="flex justify-between pt-1 border-t border-slate-200 dark:border-slate-700 font-extrabold text-sm">
                <span>Montant Remboursé :</span>
                <span className="text-rose-600 dark:text-rose-400">-{Math.abs(completedRefundSale.totalTTC).toFixed(2)} {currency}</span>
              </div>
            </div>

            {/* Hidden Thermal Receipt for Direct Printing */}
            <div className="hidden print:block">
              <ThermalReceipt sale={completedRefundSale} settings={settings} currentLang={currentLang} />
            </div>

            <div className="flex flex-wrap gap-2 justify-center pt-2">
              <button
                onClick={() => window.print()}
                className="px-4 py-2.5 bg-slate-900 hover:bg-black text-white dark:bg-slate-800 dark:hover:bg-slate-700 font-extrabold rounded-xl text-xs flex items-center gap-1.5 shadow-sm"
              >
                <Printer className="w-4 h-4" />
                <span>Imprimer Ticket d'Avoir</span>
              </button>
              <button
                onClick={handleSendWhatsAppAvoir}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl text-xs flex items-center gap-1.5 shadow-sm shadow-emerald-500/20"
              >
                <Send className="w-4 h-4" />
                <span>Envoyer sur WhatsApp</span>
              </button>
              <button
                onClick={onClose}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-200 font-bold rounded-xl text-xs"
              >
                Fermer
              </button>
            </div>
          </div>
        )}

        {/* SUCCESS VIEW: COMPLETED DIRECT EXCHANGE */}
        {completedExchangeSale && (
          <div className="space-y-4 text-center py-4">
            <div className="w-16 h-16 bg-indigo-100 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-300 rounded-3xl flex items-center justify-center mx-auto text-3xl shadow-lg shadow-indigo-500/20">
              ✓
            </div>
            <div>
              <h4 className="font-extrabold text-lg text-slate-900 dark:text-white">
                Échange Enregistré avec Succès !
              </h4>
              <p className="text-xs text-slate-500 mt-1">
                Le ticket d'échange <strong className="font-mono text-indigo-600 dark:text-indigo-400 font-extrabold">{completedExchangeSale.receiptNo}</strong> a été scellé et les stocks ont été mis à jour.
              </p>
            </div>

            {/* Visual Exchange Flow Card */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 text-left text-xs space-y-3 font-medium max-w-md mx-auto">
              <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-700">
                <span className="text-slate-500">Ticket d'origine :</span>
                <span className="font-mono font-bold text-slate-900 dark:text-white">#{completedExchangeSale.originalReceiptNo}</span>
              </div>

              <div className="grid grid-cols-2 gap-2 items-center text-center p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700">
                <div className="space-y-0.5">
                  <span className="text-[10px] text-rose-500 font-bold uppercase block">Retourné (+ stock)</span>
                  <p className="font-extrabold text-slate-900 dark:text-white text-xs truncate">
                    {completedExchangeSale.exchangeDetails?.originalItemName}
                  </p>
                  <span className="inline-block px-1.5 py-0.5 bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 rounded text-[10px] font-mono font-bold">
                    {completedExchangeSale.exchangeDetails?.oldVariant}
                  </span>
                </div>

                <div className="space-y-0.5">
                  <span className="text-[10px] text-emerald-500 font-bold uppercase block">Donné (- stock)</span>
                  <p className="font-extrabold text-slate-900 dark:text-white text-xs truncate">
                    {completedExchangeSale.exchangeDetails?.newItemName}
                  </p>
                  <span className="inline-block px-1.5 py-0.5 bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 rounded text-[10px] font-mono font-bold">
                    {completedExchangeSale.exchangeDetails?.newVariant}
                  </span>
                </div>
              </div>

              <div className="flex justify-between items-center pt-1 font-extrabold text-xs">
                <span>Règlement Différence :</span>
                {completedExchangeSale.totalTTC > 0 ? (
                  <span className="text-amber-600 dark:text-amber-400">
                    +{completedExchangeSale.totalTTC.toFixed(2)} {currency} (Encaissé en {completedExchangeSale.paymentMethod})
                  </span>
                ) : completedExchangeSale.totalTTC < 0 ? (
                  <span className="text-rose-600 dark:text-rose-400">
                    -{Math.abs(completedExchangeSale.totalTTC).toFixed(2)} {currency} (Restitué en {completedExchangeSale.paymentMethod})
                  </span>
                ) : (
                  <span className="text-emerald-600 dark:text-emerald-400">
                    0.00 {currency} (Échange direct)
                  </span>
                )}
              </div>
            </div>

            {/* Hidden Thermal Receipt for Direct Printing */}
            <div className="hidden print:block">
              <ThermalReceipt sale={completedExchangeSale} settings={settings} currentLang={currentLang} />
            </div>

            <div className="flex flex-wrap gap-2 justify-center pt-2">
              <button
                onClick={() => window.print()}
                className="px-4 py-2.5 bg-slate-900 hover:bg-black text-white dark:bg-slate-800 dark:hover:bg-slate-700 font-extrabold rounded-xl text-xs flex items-center gap-1.5 shadow-sm"
              >
                <Printer className="w-4 h-4" />
                <span>Imprimer Ticket d'Échange</span>
              </button>
              <button
                onClick={handleSendWhatsAppExchange}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl text-xs flex items-center gap-1.5 shadow-sm shadow-emerald-500/20"
              >
                <Send className="w-4 h-4" />
                <span>Envoyer sur WhatsApp</span>
              </button>
              <button
                onClick={onClose}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-200 font-bold rounded-xl text-xs"
              >
                Fermer
              </button>
            </div>
          </div>
        )}

        {/* STEP 1: SEARCH & PICK EXISTING SALE */}
        {!completedRefundSale && !completedExchangeSale && !selectedSale && (
          <div className="space-y-4">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
              <input
                type="text"
                autoFocus
                placeholder="Scanner ou saisir n° de ticket (ex: TICK-2026...), ID ou nom du client..."
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-bold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider px-1">
                <span>Ventes Récentes ({matchingSales.length})</span>
                <span>Cliquer pour sélectionner</span>
              </div>

              {matchingSales.length === 0 ? (
                <div className="p-8 text-center bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700 text-slate-400 text-xs">
                  Aucune vente trouvée correspondant à votre recherche.
                </div>
              ) : (
                <div className="max-h-80 overflow-y-auto space-y-2 pr-1">
                  {matchingSales.map((sale) => (
                    <div
                      key={sale.id}
                      onClick={() => handleSelectSale(sale)}
                      className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-500/50 hover:bg-indigo-50/20 dark:hover:bg-indigo-950/20 rounded-2xl cursor-pointer transition flex items-center justify-between gap-3 text-xs group"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold font-mono text-indigo-600 dark:text-indigo-400 group-hover:text-indigo-500 transition">
                            #{sale.receiptNo}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {new Date(sale.timestamp).toLocaleDateString('fr-FR')} {new Date(sale.timestamp).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-600 dark:text-slate-300 font-medium">
                          Client: <strong>{sale.clientName || 'Client Passant'}</strong> • {sale.items?.length || 0} article(s) • <span className="capitalize">{sale.paymentMethod || 'Espèces'}</span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="font-extrabold text-sm text-slate-900 dark:text-white block">
                          {Number(sale.totalTTC || 0).toFixed(2)} {currency}
                        </span>
                        <span className="text-[10px] text-indigo-600 font-bold group-hover:underline">
                          Sélectionner pour {activeTab === 'exchange' ? 'échange' : 'retour'} ➔
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* STEP 2A: DIRECT EXCHANGE VIEW (TAB 2) */}
        {!completedRefundSale && !completedExchangeSale && selectedSale && activeTab === 'exchange' && (
          <div className="space-y-4">
            {/* Sale Header Banner */}
            <div className="p-3 bg-indigo-50/60 dark:bg-indigo-950/40 rounded-2xl border border-indigo-200 dark:border-indigo-900/60 flex flex-wrap items-center justify-between gap-2 text-xs">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Ticket sélectionné :</span>
                <span className="font-mono font-extrabold text-sm text-slate-900 dark:text-white">
                  #{selectedSale.receiptNo}
                </span>
                <span className="text-slate-500 text-[11px] block">
                  {selectedSale.clientName || 'Client Passant'} • {new Date(selectedSale.timestamp).toLocaleDateString('fr-FR')} • {selectedSale.totalTTC?.toFixed(2)} {currency}
                </span>
              </div>

              <button
                type="button"
                onClick={() => setSelectedSale(null)}
                className="px-2.5 py-1.5 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-[11px] font-semibold border border-slate-200 dark:border-slate-700 hover:bg-slate-50"
              >
                Changer de vente
              </button>
            </div>

            {/* Step A: Select Item from Sale */}
            <div>
              <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                1. Choisir l'article à échanger :
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-44 overflow-y-auto pr-1">
                {(selectedSale.items || []).map((item, idx) => {
                  const key = item.productId || item.id || item.cartKey || item.name;
                  const isSelected = key === exchangeItemKey;
                  const itemUnitPrice = Number(item.sellPrice || 0) * (1 - (Number(item.discountPercent) || 0) / 100);

                  return (
                    <div
                      key={idx}
                      onClick={() => initExchangeForItem(item, key)}
                      className={`p-2.5 rounded-2xl border text-xs cursor-pointer transition flex items-center justify-between gap-2 ${
                        isSelected
                          ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/40 ring-2 ring-indigo-500/20'
                          : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                      }`}
                    >
                      <div className="truncate">
                        <span className="font-bold text-slate-900 dark:text-white block truncate">{item.name}</span>
                        <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                          {item.variant && (
                            <span className="px-1.5 py-0.2 bg-slate-100 dark:bg-slate-800 rounded font-mono font-bold text-indigo-600 dark:text-indigo-400">
                              {item.variant}
                            </span>
                          )}
                          <span>x{item.quantity || 1} • {itemUnitPrice.toFixed(2)} {currency}</span>
                        </div>
                      </div>
                      <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${isSelected ? 'border-indigo-600 bg-indigo-600 text-white' : 'border-slate-300'}`}>
                        {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Step B: Configure Replacement Size/Variant */}
            {currentExchangeItem && (
              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-700">
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <Shirt className="w-4 h-4 text-indigo-500" />
                    <span>Nouvelle Taille / Variante Souhaitée :</span>
                  </span>

                  <div className="flex items-center gap-2">
                    <label className="text-[11px] font-bold text-slate-500">Qté :</label>
                    <input
                      type="number"
                      min="1"
                      max={currentExchangeItem.quantity || 1}
                      value={exchangeQty}
                      onChange={(e) => setExchangeQty(Math.max(1, Math.min(currentExchangeItem.quantity || 1, parseInt(e.target.value) || 1)))}
                      className="w-14 p-1 text-center font-bold bg-white dark:bg-slate-900 border rounded-lg text-xs"
                    />
                  </div>
                </div>

                {/* Available Variants quick chips */}
                {availableVariants.length > 0 && (
                  <div className="space-y-1">
                    <span className="text-[10px] uppercase font-bold text-slate-400">
                      Tailles / Variantes disponibles au catalogue :
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {availableVariants.map((v, i) => (
                        <button
                          key={i}
                          type="button"
                          onClick={() => setNewVariant(v)}
                          className={`px-2.5 py-1 rounded-xl text-xs font-bold transition ${
                            newVariant === v
                              ? 'bg-indigo-600 text-white shadow-sm'
                              : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-indigo-400'
                          }`}
                        >
                          {v}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Free input for target variant */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                      Variante choisie (ex: Taille L, 43, Rouge...) :
                    </label>
                    <input
                      type="text"
                      placeholder="Ex: Taille L / Pointure 43 / Bleu"
                      value={newVariant}
                      onChange={(e) => setNewVariant(e.target.value)}
                      className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                      Nouveau Prix Unitaire ({currency}) :
                    </label>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={replacementPrice}
                      onChange={(e) => setReplacementPrice(sanitizeDecimalInput(e.target.value))}
                      className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-slate-900 dark:text-white"
                    />
                  </div>
                </div>

                {/* Option to exchange for another catalog article */}
                <div className="pt-2 border-t border-slate-200 dark:border-slate-700">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="text-[11px] font-bold text-slate-500">
                      Échanger contre un autre article du magasin ?
                    </span>
                    <button
                      type="button"
                      onClick={() => setExchangeType(exchangeType === 'same_product' ? 'different_product' : 'same_product')}
                      className="text-[11px] text-indigo-600 dark:text-indigo-400 font-bold hover:underline"
                    >
                      {exchangeType === 'same_product' ? "Changer d'article ➔" : "Revenir au même article"}
                    </button>
                  </div>

                  {exchangeType === 'different_product' && (
                    <select
                      value={replacementProductId}
                      onChange={(e) => {
                        const target = (products || []).find(p => p.id === parseInt(e.target.value));
                        if (target) {
                          setReplacementProductId(target.id);
                          setReplacementName(target.name);
                          setReplacementPrice(target.sellPrice || 0);
                          if (target.variants && target.variants.length > 0) {
                            setNewVariant(target.variants[0]);
                          }
                        }
                      }}
                      className="w-full p-2 bg-white dark:bg-slate-900 border rounded-xl text-xs font-bold"
                    >
                      <option value="">-- Sélectionner l'article de remplacement --</option>
                      {(products || []).map(p => (
                        <option key={p.id} value={p.id}>
                          {p.name} ({Number(p.sellPrice || 0).toFixed(2)} {currency})
                        </option>
                      ))}
                    </select>
                  )}
                </div>

                {/* Reason */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                    Motif de l'échange :
                  </label>
                  <select
                    value={exchangeReason}
                    onChange={(e) => setExchangeReason(e.target.value)}
                    className="w-full p-2 bg-white dark:bg-slate-900 border rounded-xl text-xs font-medium"
                  >
                    <option value="Changement de taille / pointure">Changement de taille / pointure</option>
                    <option value="Changement de couleur / modèle">Changement de couleur ou motif</option>
                    <option value="Défaut mineur / Retouche">Défaut mineur / Préférence coupe</option>
                    <option value="Cadeau à échanger">Cadeau à échanger</option>
                    <option value="Autre échange">Autre motif</option>
                  </select>
                </div>
              </div>
            )}

            {/* Financial Delta Settlement */}
            <div className="p-3.5 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-slate-500 block">Différence financière :</span>
                  {exchangeDelta > 0 ? (
                    <div className="flex items-center gap-1.5">
                      <span className="text-base font-black text-amber-600 dark:text-amber-400">
                        +{exchangeDelta.toFixed(2)} {currency}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold">
                        À encaisser auprès du client
                      </span>
                    </div>
                  ) : exchangeDelta < 0 ? (
                    <div className="flex items-center gap-1.5">
                      <span className="text-base font-black text-rose-600 dark:text-rose-400">
                        -{Math.abs(exchangeDelta).toFixed(2)} {currency}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 font-bold">
                        À restituer au client
                      </span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5">
                      <span className="text-base font-black text-emerald-600 dark:text-emerald-400">
                        0.00 {currency}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                        Échange standard sans frais
                      </span>
                    </div>
                  )}
                </div>

                {/* Method selector if delta !== 0 */}
                {exchangeDelta > 0 ? (
                  <div className="text-right">
                    <label className="block text-[10px] font-bold text-slate-500 uppercase">Mode de paiement du complément :</label>
                    <select
                      value={exchangePaymentMethod}
                      onChange={(e) => setExchangePaymentMethod(e.target.value)}
                      className="p-1.5 bg-white dark:bg-slate-900 border rounded-lg text-xs font-bold"
                    >
                      <option value="especes">💵 Espèces</option>
                      <option value="carte">💳 Carte Bancaire</option>
                      <option value="avoir">🏷️ Dette / Crédit Client</option>
                    </select>
                  </div>
                ) : exchangeDelta < 0 ? (
                  <div className="text-right">
                    <label className="block text-[10px] font-bold text-slate-500 uppercase">Mode de restitution :</label>
                    <select
                      value={exchangeRefundMethod}
                      onChange={(e) => setExchangeRefundMethod(e.target.value)}
                      className="p-1.5 bg-white dark:bg-slate-900 border rounded-lg text-xs font-bold"
                    >
                      <option value="especes">💵 Espèces</option>
                      <option value="avoir">🏷️ Bon d'Avoir</option>
                      <option value="carte">💳 Recrédit CB</option>
                    </select>
                  </div>
                ) : null}
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-700">
                <button
                  type="button"
                  onClick={() => setSelectedSale(null)}
                  className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300"
                >
                  Annuler
                </button>
                <button
                  type="button"
                  disabled={!currentExchangeItem || isProcessing}
                  onClick={handleConfirmExchange}
                  className={`px-4 py-2.5 text-xs font-extrabold rounded-xl text-white shadow-md flex items-center gap-1.5 transition ${
                    currentExchangeItem && !isProcessing
                      ? 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-500/20 active:scale-95'
                      : 'bg-slate-300 dark:bg-slate-700 cursor-not-allowed opacity-60'
                  }`}
                >
                  <ArrowRightLeft className={`w-4 h-4 ${isProcessing ? 'animate-spin' : ''}`} />
                  <span>{isProcessing ? 'Enregistrement...' : "Valider l'Échange Direct"}</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* STEP 2B: REFUND VIEW (TAB 1) */}
        {!completedRefundSale && !completedExchangeSale && selectedSale && activeTab === 'refund' && (
          <div className="space-y-4">
            {/* Sale Header Banner */}
            <div className="p-3.5 bg-amber-50/60 dark:bg-amber-950/40 rounded-2xl border border-amber-200 dark:border-amber-900/60 flex flex-wrap items-center justify-between gap-2 text-xs">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Ticket sélectionné :</span>
                <span className="font-mono font-extrabold text-sm text-slate-900 dark:text-white">
                  #{selectedSale.receiptNo}
                </span>
                <span className="text-slate-500 text-[11px] block">
                  {selectedSale.clientName || 'Client Passant'} • {new Date(selectedSale.timestamp).toLocaleDateString('fr-FR')} • {selectedSale.totalTTC?.toFixed(2)} {currency}
                </span>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const allQ = {};
                    (selectedSale.items || []).forEach(item => {
                      const key = item.productId || item.id || item.cartKey || item.name;
                      allQ[key] = item.quantity || 1;
                    });
                    setRefundQuantities(allQ);
                  }}
                  className="px-2.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-[11px] font-bold shadow-sm"
                >
                  Tout retourner
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedSale(null)}
                  className="px-2.5 py-1.5 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-[11px] font-semibold border border-slate-200 dark:border-slate-700"
                >
                  Changer de vente
                </button>
              </div>
            </div>

            {/* Items Table */}
            <div className="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden text-xs">
              <table className="w-full text-left">
                <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 font-bold border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="p-2.5">Article</th>
                    <th className="p-2.5 text-center">Qté Vendue</th>
                    <th className="p-2.5 text-right">Prix Unitaire</th>
                    <th className="p-2.5 text-center">Qté à Retourner</th>
                    <th className="p-2.5 text-right">Montant Avoir</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                  {(selectedSale.items || []).map((item, idx) => {
                    const key = item.productId || item.id || item.cartKey || item.name;
                    const maxQty = item.quantity || 1;
                    const currentQ = parseSafeFloat(refundQuantities[key], 0);
                    const unitPrice = Number(item.sellPrice || 0) * (1 - (Number(item.discountPercent) || 0) / 100);
                    const lineRefund = unitPrice * currentQ;

                    return (
                      <tr key={idx} className={currentQ > 0 ? 'bg-amber-50/40 dark:bg-amber-950/20' : ''}>
                        <td className="p-2.5">
                          <span className="font-bold text-slate-800 dark:text-slate-200 block">{item.name}</span>
                          {item.variant && <span className="text-[10px] text-slate-400">({item.variant})</span>}
                        </td>
                        <td className="p-2.5 text-center font-bold text-slate-600 dark:text-slate-400">
                          {maxQty}
                        </td>
                        <td className="p-2.5 text-right text-slate-700 dark:text-slate-300">
                          {unitPrice.toFixed(2)} {currency}
                        </td>
                        <td className="p-2.5 text-center">
                          <div className="inline-flex items-center gap-1.5">
                            <input
                              type="number"
                              min="0"
                              max={maxQty}
                              step="1"
                              value={currentQ}
                              onChange={(e) => {
                                const val = Math.min(maxQty, Math.max(0, parseSafeFloat(e.target.value, 0)));
                                setRefundQuantities(prev => ({ ...prev, [key]: val }));
                              }}
                              className="w-16 p-1 text-center font-extrabold bg-slate-50 dark:bg-slate-800 border rounded-lg text-xs"
                            />
                            <button
                              type="button"
                              onClick={() => setRefundQuantities(prev => ({ ...prev, [key]: maxQty }))}
                              className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-bold hover:bg-amber-100"
                              title="Retourner la quantité totale"
                            >
                              Max
                            </button>
                          </div>
                        </td>
                        <td className="p-2.5 text-right font-extrabold text-amber-600 dark:text-amber-400">
                          {lineRefund > 0 ? `-${lineRefund.toFixed(2)} ${currency}` : '—'}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Refund Options: Method & Reason */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                  Mode de Restitution / Remboursement :
                </label>
                <select
                  value={refundMethod}
                  onChange={(e) => setRefundMethod(e.target.value)}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold"
                >
                  <option value="especes">💵 Espèces (Sortie du tiroir-caisse)</option>
                  <option value="carte">💳 Carte Bancaire (Recrédit CB)</option>
                  <option value="avoir">🏷️ Bon d'Avoir / Déduction Dette</option>
                  <option value="virement">🏦 Virement Bancaire</option>
                </select>
              </div>

              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                  Motif du Retour :
                </label>
                <select
                  value={refundReason}
                  onChange={(e) => setRefundReason(e.target.value)}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-medium"
                >
                  <option value="Retour Marchandise">Défaut produit / Endommagé</option>
                  <option value="Erreur de Référence">Erreur de référence ou modèle</option>
                  <option value="Changement d'Avis">Changement d'avis du client</option>
                  <option value="Erreur Saisie Caisse">Erreur de saisie / doublon de caisse</option>
                  <option value="Autre Motif">Autre motif</option>
                </select>
              </div>
            </div>

            {/* Summary & Validation */}
            <div className="p-3.5 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
              <div>
                <span className="text-[11px] text-slate-500 block">Total Avoir à Générer :</span>
                <span className="text-lg font-black text-rose-600 dark:text-rose-400">
                  {refundTotal > 0 ? `-${refundTotal.toFixed(2)} ${currency}` : `0.00 ${currency}`}
                </span>
                <span className="text-[10px] text-slate-400 block">
                  {totalReturnedItemsCount} article(s) sélectionné(s) pour réintégration en stock
                </span>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedSale(null)}
                  className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300"
                >
                  Annuler
                </button>
                <button
                  type="button"
                  disabled={refundTotal <= 0 || isProcessing}
                  onClick={handleConfirmRefund}
                  className={`px-4 py-2.5 text-xs font-extrabold rounded-xl text-white shadow-md flex items-center gap-1.5 transition ${
                    refundTotal > 0 && !isProcessing
                      ? 'bg-amber-600 hover:bg-amber-700 shadow-amber-500/20 active:scale-95'
                      : 'bg-slate-300 dark:bg-slate-700 cursor-not-allowed opacity-60'
                  }`}
                >
                  <RotateCcw className={`w-4 h-4 ${isProcessing ? 'animate-spin' : ''}`} />
                  <span>{isProcessing ? 'Génération Avoir...' : 'Valider le Retour & Avoir'}</span>
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
