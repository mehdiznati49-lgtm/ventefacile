import http from 'http';
import fs from 'fs';
import path from 'path';
import https from 'https';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 5000;
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'ventefacile_db.json');
const BACKUP_FILE = path.join(DATA_DIR, 'ventefacile_backup.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initial Database Structure
const defaultDatabase = {
  version: 1,
  lastUpdated: new Date().toISOString(),
  products: [],
  sales: [],
  clients: [],
  payments: [],
  quotes: [],
  cashMovements: [],
  settings: {
    shopName: 'Boutique VenteFacile',
    phone: '',
    address: '',
    currency: '€',
    language: 'fr',
    theme: 'light',
    securityEnabled: false,
    whatsapp: {
      phoneId: '',
      accessToken: '',
      sellerNumber: '',
      autoReceipt: true,
      autoConfirm: true
    },
    website: {
      siteUrl: '',
      platform: 'WooCommerce',
      apiKey: '',
      apiSecret: '',
      autoSync: true
    }
  }
};

// Load or Initialize DB
function loadDatabase() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, 'utf8');
      return JSON.parse(raw);
    }
  } catch (err) {
    console.error('[Server DB] Erreur lecture base, tentative de restauration backup...', err);
    if (fs.existsSync(BACKUP_FILE)) {
      try {
        return JSON.parse(fs.readFileSync(BACKUP_FILE, 'utf8'));
      } catch (backupErr) {
        console.error('[Server DB] Échec restauration backup', backupErr);
      }
    }
  }
  // Initialize default
  saveDatabase(defaultDatabase);
  return defaultDatabase;
}

// Atomic Safe DB Write with Backup
function saveDatabase(data) {
  try {
    data.lastUpdated = new Date().toISOString();
    const jsonStr = JSON.stringify(data, null, 2);
    const tempFile = path.join(DATA_DIR, `temp_${Date.now()}.json`);
    
    fs.writeFileSync(tempFile, jsonStr, 'utf8');
    if (fs.existsSync(DB_FILE)) {
      fs.copyFileSync(DB_FILE, BACKUP_FILE);
    }
    fs.renameSync(tempFile, DB_FILE);
    return true;
  } catch (err) {
    console.error('[Server DB] Erreur écriture base :', err);
    return false;
  }
}

// Helper: Parse JSON Body
function parseJSONBody(req) {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', chunk => { body += chunk.toString(); });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (e) {
        resolve({});
      }
    });
  });
}

// Helper: Send JSON Response with CORS
function sendJSON(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With'
  });
  res.end(JSON.stringify(data));
}

// Helper: External HTTPS Request
function externalRequest(url, options = {}, postData = null) {
  return new Promise((resolve, reject) => {
    const parsedUrl = new URL(url);
    const client = parsedUrl.protocol === 'https:' ? https : http;
    
    const reqOptions = {
      method: options.method || 'GET',
      headers: options.headers || {},
      timeout: 10000
    };

    const req = client.request(parsedUrl, reqOptions, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk.toString(); });
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          data
        });
      });
    });

    req.on('error', reject);
    req.on('timeout', () => {
      req.destroy();
      reject(new Error('Délai d\'attente dépassé (Timeout)'));
    });

    if (postData) {
      req.write(typeof postData === 'string' ? postData : JSON.stringify(postData));
    }
    req.end();
  });
}

// HTTP Server
const server = http.createServer(async (req, res) => {
  // CORS Preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With'
    });
    return res.end();
  }

  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;

  // 1. Health check
  if (pathname === '/api/health' && req.method === 'GET') {
    return sendJSON(res, 200, {
      status: 'ok',
      service: 'VenteFacile Backend Server',
      uptime: process.uptime(),
      timestamp: new Date().toISOString()
    });
  }

  // 2. Full Database Sync Endpoint (Fetch all records)
  if (pathname === '/api/sync/all' && req.method === 'GET') {
    const db = loadDatabase();
    return sendJSON(res, 200, {
      success: true,
      lastUpdated: db.lastUpdated,
      products: db.products || [],
      sales: db.sales || [],
      clients: db.clients || [],
      payments: db.payments || [],
      quotes: db.quotes || [],
      cashMovements: db.cashMovements || [],
      settings: db.settings || {}
    });
  }

  // 3. Batch Push Sync Endpoint (Client updates Server)
  if (pathname === '/api/sync/push' && req.method === 'POST') {
    const payload = await parseJSONBody(req);
    const db = loadDatabase();

    if (payload.products && Array.isArray(payload.products)) {
      db.products = payload.products;
    }
    if (payload.sales && Array.isArray(payload.sales)) {
      db.sales = payload.sales;
    }
    if (payload.clients && Array.isArray(payload.clients)) {
      db.clients = payload.clients;
    }
    if (payload.payments && Array.isArray(payload.payments)) {
      db.payments = payload.payments;
    }
    if (payload.quotes && Array.isArray(payload.quotes)) {
      db.quotes = payload.quotes;
    }
    if (payload.cashMovements && Array.isArray(payload.cashMovements)) {
      db.cashMovements = payload.cashMovements;
    }
    if (payload.settings && typeof payload.settings === 'object') {
      db.settings = { ...db.settings, ...payload.settings };
    }

    saveDatabase(db);
    return sendJSON(res, 200, {
      success: true,
      message: 'Données synchronisées avec succès sur le serveur persistant.',
      lastUpdated: db.lastUpdated
    });
  }

  // 4. Products CRUD Endpoints
  if (pathname === '/api/products') {
    const db = loadDatabase();
    if (req.method === 'GET') {
      return sendJSON(res, 200, { success: true, products: db.products || [] });
    }
    if (req.method === 'POST') {
      const newProduct = await parseJSONBody(req);
      if (!newProduct.name) {
        return sendJSON(res, 400, { success: false, error: 'Le nom du produit est requis.' });
      }
      newProduct.id = newProduct.id || Date.now();
      db.products = db.products || [];
      db.products.push(newProduct);
      saveDatabase(db);
      return sendJSON(res, 201, { success: true, product: newProduct });
    }
  }

  // 5. Sales CRUD Endpoints
  if (pathname === '/api/sales') {
    const db = loadDatabase();
    if (req.method === 'GET') {
      return sendJSON(res, 200, { success: true, sales: db.sales || [] });
    }
    if (req.method === 'POST') {
      const newSale = await parseJSONBody(req);
      newSale.id = newSale.id || Date.now();
      db.sales = db.sales || [];
      db.sales.unshift(newSale);
      saveDatabase(db);
      return sendJSON(res, 201, { success: true, sale: newSale });
    }
  }

  // 6. WhatsApp Real API Gateway Endpoint
  if (pathname === '/api/whatsapp/send' && req.method === 'POST') {
    const { to, message, settings: reqSettings } = await parseJSONBody(req);
    const db = loadDatabase();
    const config = reqSettings?.whatsapp || db.settings?.whatsapp || {};

    if (!to || !message) {
      return sendJSON(res, 400, { success: false, error: 'Paramètres "to" (numéro) et "message" requis.' });
    }

    const cleanTo = to.replace(/[^0-9]/g, '');

    // Case A: Meta Cloud API configured
    if (config.phoneId && config.accessToken) {
      try {
        const metaUrl = `https://graph.facebook.com/v19.0/${config.phoneId}/messages`;
        const postData = JSON.stringify({
          messaging_product: 'whatsapp',
          recipient_type: 'individual',
          to: cleanTo,
          type: 'text',
          text: { preview_url: false, body: message }
        });

        const metaRes = await externalRequest(metaUrl, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${config.accessToken}`,
            'Content-Type': 'application/json'
          }
        }, postData);

        const responseData = JSON.parse(metaRes.data || '{}');
        if (metaRes.statusCode >= 200 && metaRes.statusCode < 300) {
          return sendJSON(res, 200, {
            success: true,
            provider: 'meta_cloud_api',
            result: responseData
          });
        } else {
          return sendJSON(res, metaRes.statusCode, {
            success: false,
            error: responseData.error?.message || 'Erreur API Meta WhatsApp',
            details: responseData
          });
        }
      } catch (err) {
        return sendJSON(res, 502, { success: false, error: `Échec de connexion Meta : ${err.message}` });
      }
    }

    // Case B: Fallback to WhatsApp Web Direct Link
    const waUrl = `https://wa.me/${cleanTo}?text=${encodeURIComponent(message)}`;
    return sendJSON(res, 200, {
      success: true,
      provider: 'direct_link',
      url: waUrl,
      message: 'Lien direct WhatsApp généré avec succès.'
    });
  }

  // 7. WhatsApp Test Connection
  if (pathname === '/api/whatsapp/test' && req.method === 'POST') {
    const { phoneId, accessToken } = await parseJSONBody(req);
    
    if (!phoneId || !accessToken) {
      return sendJSON(res, 400, {
        success: false,
        error: 'Veuillez saisir votre Phone Number ID et votre Access Token Meta.'
      });
    }

    try {
      const metaUrl = `https://graph.facebook.com/v19.0/${phoneId}?fields=display_phone_number,verified_name,quality_rating`;
      const metaRes = await externalRequest(metaUrl, {
        method: 'GET',
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });

      const data = JSON.parse(metaRes.data || '{}');
      if (metaRes.statusCode === 200) {
        return sendJSON(res, 200, {
          success: true,
          message: `Connexion Meta validée ! Numéro officiel : ${data.display_phone_number || phoneId} (${data.verified_name || 'Compte Entreprise'})`,
          data
        });
      } else {
        return sendJSON(res, 400, {
          success: false,
          error: data.error?.message || 'Identifiants Meta WhatsApp invalides.',
          details: data
        });
      }
    } catch (err) {
      return sendJSON(res, 502, {
        success: false,
        error: `Impossible de contacter l'API Meta : ${err.message}`
      });
    }
  }

  // 8. WooCommerce Real API Test Endpoint
  if (pathname === '/api/woocommerce/test' && req.method === 'POST') {
    const { siteUrl, apiKey, apiSecret } = await parseJSONBody(req);
    
    if (!siteUrl) {
      return sendJSON(res, 400, { success: false, error: 'L\'URL du site WooCommerce est obligatoire.' });
    }

    const cleanUrl = siteUrl.replace(/\/+$/, '');
    const authHeader = 'Basic ' + Buffer.from(`${apiKey || ''}:${apiSecret || ''}`).toString('base64');

    try {
      const testEndpoint = `${cleanUrl}/wp-json/wc/v3/products?per_page=5`;
      const response = await externalRequest(testEndpoint, {
        method: 'GET',
        headers: {
          'Authorization': authHeader,
          'User-Agent': 'VenteFacile-Pro/1.0'
        }
      });

      if (response.statusCode === 200) {
        let products = [];
        try { products = JSON.parse(response.data); } catch (e) {}
        const totalItems = response.headers['x-wp-total'] || products.length;

        return sendJSON(res, 200, {
          success: true,
          message: `Connexion réussie avec ${cleanUrl} ! ${totalItems} article(s) détecté(s) dans la boutique.`,
          totalProducts: parseInt(totalItems, 10) || products.length,
          sample: products.slice(0, 3).map(p => ({ id: p.id, name: p.name, price: p.price }))
        });
      } else if (response.statusCode === 401 || response.statusCode === 403) {
        return sendJSON(res, 401, {
          success: false,
          error: 'Échec d\'authentification : La clé API (Consumer Key) ou le secret (Consumer Secret) est invalide.'
        });
      } else {
        return sendJSON(res, response.statusCode, {
          success: false,
          error: `Le site a répondu avec le statut HTTP ${response.statusCode}. Vérifiez que WooCommerce REST API est activée.`
        });
      }
    } catch (err) {
      return sendJSON(res, 502, {
        success: false,
        error: `Impossible de joindre le site distant : ${err.message}`
      });
    }
  }

  // 9. WooCommerce Import/Sync Products into VenteFacile
  if (pathname === '/api/woocommerce/sync' && req.method === 'POST') {
    const { siteUrl, apiKey, apiSecret } = await parseJSONBody(req);
    if (!siteUrl) {
      return sendJSON(res, 400, { success: false, error: 'URL du site requise.' });
    }

    const cleanUrl = siteUrl.replace(/\/+$/, '');
    const authHeader = 'Basic ' + Buffer.from(`${apiKey || ''}:${apiSecret || ''}`).toString('base64');

    try {
      const endpoint = `${cleanUrl}/wp-json/wc/v3/products?per_page=50`;
      const response = await externalRequest(endpoint, {
        method: 'GET',
        headers: {
          'Authorization': authHeader,
          'User-Agent': 'VenteFacile-Pro/1.0'
        }
      });

      if (response.statusCode === 200) {
        const rawProducts = JSON.parse(response.data || '[]');
        const imported = rawProducts.map(wp => ({
          barcode: wp.sku || ('WC' + wp.id),
          name: wp.name,
          brand: wp.categories?.[0]?.name || 'WooCommerce',
          category: wp.categories?.[0]?.name || 'E-Commerce',
          buyPrice: parseFloat(wp.regular_price || wp.price || 0) * 0.5,
          sellPrice: parseFloat(wp.price || wp.regular_price || 0),
          vatRate: 20,
          stock: wp.stock_quantity !== null ? wp.stock_quantity : 10,
          image: wp.images?.[0]?.src || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&q=80'
        }));

        const db = loadDatabase();
        db.products = db.products || [];
        let added = 0;
        let updated = 0;

        for (const item of imported) {
          const idx = db.products.findIndex(p => p.name.toLowerCase() === item.name.toLowerCase() || p.barcode === item.barcode);
          if (idx >= 0) {
            db.products[idx].stock = item.stock;
            db.products[idx].sellPrice = item.sellPrice;
            updated++;
          } else {
            item.id = Date.now() + Math.floor(Math.random() * 1000);
            db.products.push(item);
            added++;
          }
        }

        saveDatabase(db);
        return sendJSON(res, 200, {
          success: true,
          message: `Synchronisation WooCommerce terminée : ${added} nouveaux produits ajoutés, ${updated} mis à jour.`,
          importedCount: imported.length
        });
      } else {
        return sendJSON(res, response.statusCode, { success: false, error: `Erreur HTTP ${response.statusCode} de WooCommerce.` });
      }
    } catch (err) {
      return sendJSON(res, 502, { success: false, error: err.message });
    }
  }


  // 404 for unknown endpoints
  sendJSON(res, 404, { error: 'Endpoint introuvable.' });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`[VenteFacile Backend] Serveur démarré avec succès sur le port ${PORT}`);
  console.log(`[VenteFacile Backend] Données persistantes stockées dans : ${DB_FILE}`);
});
