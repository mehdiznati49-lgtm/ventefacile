import React, { useState, useEffect } from 'react';
import { 
  ShoppingBag, 
  Search, 
  Sun, 
  Moon, 
  Globe, 
  Lock, 
  Zap, 
  ShieldCheck, 
  CheckCircle2,
  ChevronDown,
  Download,
  Cloud,
  RefreshCw,
  Crown,
  UserCheck,
  Smartphone,
  LogOut,
  Users
} from 'lucide-react';
import { translations } from '../translations';
import { db } from '../db';
import { createFullBackup, downloadBackupFile } from '../backupManager';
import { useToast } from '../context/ToastContext';

export default function Header({ 
  settings, 
  onUpdateSettings, 
  currentLang, 
  onLangChange,
  theme,
  onToggleTheme,
  searchQuery,
  onSearchChange,
  onOpenScanner,
  isAdmin,
  userRole,
  currentCashier,
  onOpenSwitchCashier,
  onOpenTeamManagement,
  onOpenLogin,
  onToggleAdmin,
  isServerOnline,
  cloudSyncStatus,
  onOpenCreateShop
}) {
  const toast = useToast();
  const t = translations[currentLang] || translations.fr;
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [isAppInstalled, setIsAppInstalled] = useState(() => {
    if (typeof window === 'undefined') return false;
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches || 
                         window.navigator.standalone === true ||
                         (document.referrer && document.referrer.startsWith('android-app://'));
    const localFlag = localStorage.getItem('pwa_installed') === 'true';
    return isStandalone || localFlag;
  });
  const [deferredPrompt, setDeferredPrompt] = useState(null);

  useEffect(() => {
    // Check standalone mode dynamically
    const checkStandalone = () => {
      const isStandalone = window.matchMedia('(display-mode: standalone)').matches || 
                           window.navigator.standalone === true ||
                           (document.referrer && document.referrer.startsWith('android-app://'));
      if (isStandalone) {
        setIsAppInstalled(true);
        localStorage.setItem('pwa_installed', 'true');
      }
    };
    checkStandalone();

    const mediaQuery = window.matchMedia('(display-mode: standalone)');
    if (mediaQuery.addEventListener) {
      mediaQuery.addEventListener('change', checkStandalone);
    }

    const handleBeforeInstall = (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
      // If browser can install and we are not in standalone window
      const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
      if (!isStandalone) {
        setIsAppInstalled(false);
        localStorage.removeItem('pwa_installed');
      }
    };

    const handleAppInstalled = () => {
      console.log('[VenteFacile PWA] Application installée avec succès.');
      setIsAppInstalled(true);
      setDeferredPrompt(null);
      localStorage.setItem('pwa_installed', 'true');
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      window.removeEventListener('appinstalled', handleAppInstalled);
      if (mediaQuery.removeEventListener) {
        mediaQuery.removeEventListener('change', checkStandalone);
      }
    };
  }, []);

  const handleInstallApp = async () => {
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
    if (isStandalone) {
      setIsAppInstalled(true);
      localStorage.setItem('pwa_installed', 'true');
      return;
    }

    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setIsAppInstalled(true);
        localStorage.setItem('pwa_installed', 'true');
      }
      setDeferredPrompt(null);
    } else {
      toast.info("Sur mobile : Menu ⋮ > Ajouter à l'écran d'accueil. Sur ordinateur : Icône Installer dans la barre d'adresse.", "Installation de l'application", 6000);
    }
  };

  const langNames = {
    fr: '🇫🇷 FR',
    ar: 'العربية 🇲🇦',
    en: '🇬🇧 EN',
    es: '🇪🇸 ES'
  };

  const handleQuickBackup = async () => {
    try {
      const backup = await createFullBackup();
      downloadBackupFile(backup.content, backup.fileName);
      toast.success(`Sauvegarde téléchargée (${backup.fileName}).`, "Sauvegarde réussie");
    } catch (err) {
      console.error('[Header] Erreur sauvegarde rapide', err);
      toast.error(err.message, "Erreur lors de la sauvegarde");
    }
  };



  return (
    <header className="sticky top-0 z-30 glass-panel border-b border-slate-200/80 dark:border-slate-800/80 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-2">
          
          {/* Logo & App Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-purple-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/20 transform transition hover:scale-105">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-lg sm:text-xl tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 dark:from-indigo-400 dark:to-pink-400 font-display">
                  {settings.shopName || t.appTitle}
                </h1>
                {!settings.isStoreConfigured && isAdmin && (
                  <button
                    onClick={onOpenCreateShop}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-black text-xs shadow-md shadow-amber-500/20 transition active:scale-95 animate-pulse cursor-pointer"
                    title="Configurer et activer votre vraie boutique"
                  >
                    <span>🚀 Créer ma Boutique</span>
                  </button>
                )}
                {settings.isStoreConfigured && (
                  <span className="hidden md:inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-800">
                    <CheckCircle2 className="w-3 h-3" /> Boutique Active
                  </span>
                )}
                {/* Supabase Cloud Status Indicator */}
                {cloudSyncStatus?.status === 'connected' ? (
                  <span className="hidden sm:inline-flex items-center gap-1.5 text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800" title="Connecté à PostgreSQL Supabase (Synchronisation active)">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    <span>Supabase Cloud 🟢</span>
                  </span>
                ) : cloudSyncStatus?.status === 'syncing' ? (
                  <span className="hidden sm:inline-flex items-center gap-1.5 text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 border border-indigo-300 dark:border-indigo-800">
                    <RefreshCw className="w-3 h-3 animate-spin text-indigo-600" />
                    <span>Sync Cloud...</span>
                  </span>
                ) : cloudSyncStatus?.status === 'pending' ? (
                  <span className="hidden sm:inline-flex items-center gap-1.5 text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-300 dark:border-amber-800" title="Données enregistrées localement en sécurité, en attente de synchronisation">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                    <span>{cloudSyncStatus.pendingCount || 1} en attente 🟡</span>
                  </span>
                ) : (
                  <span className="hidden sm:inline-flex items-center gap-1.5 text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border border-slate-300 dark:border-slate-700" title="Stockage local persistant actif (Offline-First)">
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
                    <span>Offline-First</span>
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 hidden sm:block">
                Caisse • Site Web • WhatsApp • Stock Illimité
              </p>
            </div>
          </div>

          {/* Quick Search & Instant Scanner Launch Button (RTL-ready) */}
          <div className="flex-1 max-w-md mx-2 sm:mx-4">
            <div className="relative flex items-center">
              <Search className="w-4 h-4 absolute start-3 text-slate-400 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder={t.rechercheProduit}
                className="w-full ps-9 pe-24 py-2 text-xs sm:text-sm bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white dark:focus:bg-slate-900 transition-all text-slate-800 dark:text-slate-100 text-start"
              />
              <button
                onClick={onOpenScanner}
                className="absolute end-1 px-2.5 py-1 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white flex items-center gap-1.5 shadow-sm transition active:scale-95"
                title={t.scanner}
              >
                <Zap className="w-3.5 h-3.5 text-yellow-300 animate-pulse" />
                <span className="hidden sm:inline">{t.scanner}</span>
              </button>
            </div>
          </div>

          {/* Right Action Controls */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            
            {/* 1-Tap Language Switcher Button & Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowLangMenu(!showLangMenu)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-extrabold rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 transition active:scale-95"
                title="Changer la langue (Français, Arabe, Anglais, Espagnol)"
              >
                <Globe className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <span>{langNames[currentLang]}</span>
                <ChevronDown className="w-3.5 h-3.5 opacity-60" />
              </button>

              {showLangMenu && (
                <div className="absolute ltr:right-0 rtl:left-0 top-full mt-1.5 w-44 bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                  <p className="text-[10px] font-bold text-slate-400 px-3 pb-1 uppercase tracking-wider">Changer la langue :</p>
                  <button 
                    onClick={() => { onLangChange('fr'); setShowLangMenu(false); }} 
                    className={`w-full text-start px-3 py-2 text-xs flex items-center justify-between hover:bg-indigo-50 dark:hover:bg-indigo-950/40 ${currentLang === 'fr' ? 'font-extrabold text-indigo-600 dark:text-indigo-400 bg-indigo-50/50' : 'text-slate-700 dark:text-slate-300'}`}
                  >
                    <span>🇫🇷 Français</span>
                    {currentLang === 'fr' && <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />}
                  </button>
                  <button 
                    onClick={() => { onLangChange('ar'); setShowLangMenu(false); }} 
                    className={`w-full text-start px-3 py-2 text-xs flex items-center justify-between hover:bg-indigo-50 dark:hover:bg-indigo-950/40 ${currentLang === 'ar' ? 'font-extrabold text-indigo-600 dark:text-indigo-400 bg-indigo-50/50' : 'text-slate-700 dark:text-slate-300'}`}
                  >
                    <span>العربية 🇲🇦</span>
                    {currentLang === 'ar' && <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />}
                  </button>
                  <button 
                    onClick={() => { onLangChange('en'); setShowLangMenu(false); }} 
                    className={`w-full text-start px-3 py-2 text-xs flex items-center justify-between hover:bg-indigo-50 dark:hover:bg-indigo-950/40 ${currentLang === 'en' ? 'font-extrabold text-indigo-600 dark:text-indigo-400 bg-indigo-50/50' : 'text-slate-700 dark:text-slate-300'}`}
                  >
                    <span>🇬🇧 English</span>
                    {currentLang === 'en' && <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />}
                  </button>
                  <button 
                    onClick={() => { onLangChange('es'); setShowLangMenu(false); }} 
                    className={`w-full text-start px-3 py-2 text-xs flex items-center justify-between hover:bg-indigo-50 dark:hover:bg-indigo-950/40 ${currentLang === 'es' ? 'font-extrabold text-indigo-600 dark:text-indigo-400 bg-indigo-50/50' : 'text-slate-700 dark:text-slate-300'}`}
                  >
                    <span>🇪🇸 Español</span>
                    {currentLang === 'es' && <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />}
                  </button>
                </div>
              )}
            </div>

            {/* PWA Install Button (Masqué automatiquement si l'application est déjà installée) */}
            {!isAppInstalled && (
              <button
                onClick={handleInstallApp}
                className="px-2.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-[11px] flex items-center gap-1.5 shadow-sm transition active:scale-95 animate-pulse"
                title="Installer VenteFacile Pro sur votre appareil (Tablette, PC, Mobile)"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span className="hidden md:inline">Installer l'App</span>
              </button>
            )}

            {/* 1-Click Quick Backup Download Button */}
            <button
              onClick={handleQuickBackup}
              className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-900 text-emerald-700 dark:text-emerald-300 transition"
              title="Sauvegarder ma boutique en 1 clic (Fichier JSON)"
            >
              <Download className="w-4 h-4" />
            </button>





            {/* Dark / Light Theme Toggle */}
            <button
              onClick={onToggleTheme}
              className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition"
              title="Changer de thème (Sombre / Clair)"
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 text-indigo-600" />
              )}
            </button>

            {/* Active Cashier Badge & 1-Click Switch Button */}
            {onOpenSwitchCashier ? (
              <button
                onClick={onOpenSwitchCashier}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-800/90 hover:border-indigo-300 dark:hover:border-indigo-700 transition active:scale-95 shadow-sm text-left"
                title="Changer de caissier actif pour ce poste de vente"
              >
                <div
                  className="w-6 h-6 rounded-lg flex items-center justify-center text-white text-[10px] font-black shadow-xs flex-shrink-0"
                  style={{ backgroundColor: currentCashier?.avatarColor || '#4f46e5' }}
                >
                  {(typeof currentCashier === 'object' ? currentCashier?.name : currentCashier)?.slice(0, 2)?.toUpperCase() || 'CA'}
                </div>
                <div className="flex flex-col leading-none">
                  <div className="flex items-center gap-1">
                    <span className="text-[11px] font-extrabold text-slate-800 dark:text-slate-200 max-w-[80px] sm:max-w-[110px] truncate">
                      {typeof currentCashier === 'object' ? currentCashier?.name : currentCashier || 'Patron'}
                    </span>
                    <ChevronDown className="w-3 h-3 text-slate-400" />
                  </div>
                  <span className="text-[9px] font-bold text-slate-400">
                    {typeof currentCashier === 'object' && currentCashier?.role === 'patron'
                      ? '👑 Patron'
                      : typeof currentCashier === 'object' && currentCashier?.role === 'gerant'
                      ? '🎖️ Gérant'
                      : '💼 Caissier'}
                  </span>
                </div>
              </button>
            ) : (
              <button
                onClick={onOpenLogin}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-black rounded-xl transition shadow-sm ${
                  isAdmin 
                    ? 'bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 border border-purple-200 dark:border-purple-800 hover:bg-purple-100' 
                    : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100'
                }`}
                title="Cliquer pour changer d'utilisateur ou verrouiller la session"
              >
                {isAdmin ? (
                  <>
                    <Crown className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
                    <span className="hidden sm:inline">Gérant</span>
                  </>
                ) : (
                  <>
                    <UserCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    <span className="hidden sm:inline">Caissier</span>
                  </>
                )}
                <LogOut className="w-3 h-3 opacity-60 ml-0.5" />
              </button>
            )}

            {/* Team & Roles Management Modal Trigger (Patron / Manager) */}
            {onOpenTeamManagement && (
              <button
                onClick={onOpenTeamManagement}
                className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-300 transition border border-indigo-200 dark:border-indigo-800/60"
                title="Gérer l'équipe, ajouter/supprimer des caissiers ou promouvoir en gérant"
              >
                <Users className="w-4 h-4" />
              </button>
            )}

          </div>

        </div>
      </div>
    </header>
  );
}
