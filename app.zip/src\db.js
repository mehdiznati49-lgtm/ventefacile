import Dexie from 'dexie';
import { parseSafeFloat, sanitizeDecimalInput } from './utils/numberUtils.js';

export { parseSafeFloat, sanitizeDecimalInput };

export const db = new Dexie('VenteFacileDB');

db.version(1).stores({
  products: '++id, barcode, name, category, brand, isWeight, expiryDate',
  sales: '++id, receiptNo, timestamp, paymentMethod, clientId, isCredit',
  clients: '++id, name, phone, debt',
  settings: 'id',
  templates: '++id, category, name'
});

db.version(2).stores({
  payments: '++id, receiptNo, timestamp, clientId, type, amount, paymentMethod'
});

db.version(3).stores({
  cashMovements: '++id, timestamp, amount, reason, cashier',
  quotes: '++id, quoteNo, timestamp, clientId, clientName, totalTTC, status'
});

db.version(4).stores({
  cashClosings: '++id, closingNo, date, timestamp, cashier'
});

db.version(5).stores({
  suppliers: '++id, name, phone, category, debt',
  supplierInvoices: '++id, supplierId, supplierName, invoiceNumber, date, status',
  supplierPayments: '++id, supplierId, supplierName, invoiceId, date, paymentMethod'
});

import { 
  generateSalt, 
  hashPinWithSalt, 
  verifyPin, 
  migrateSettingsToSaltedPins,
  hashMemberPin,
  verifyMemberPin,
  sanitizeProductsForRole,
  sanitizeStatsForRole
} from './authSecurity.js';

// Re-export Auth Security functions
export { 
  generateSalt, 
  hashPinWithSalt, 
  verifyPin, 
  migrateSettingsToSaltedPins,
  hashMemberPin,
  verifyMemberPin,
  sanitizeProductsForRole,
  sanitizeStatsForRole
};

// Secure cryptographic SHA-256 hashing (retained for backward compatibility)
export async function hashPassword(plainText) {
  if (!plainText) return '';
  try {
    const encoder = new TextEncoder();
    const data = encoder.encode(plainText);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  } catch (e) {
    console.error('[VenteFacile] Erreur hachage', e);
    return plainText;
  }
}

// Request browser persistent storage to prevent automatic cache deletion
export async function initStoragePersistence() {
  if (navigator.storage && navigator.storage.persist) {
    try {
      const isPersisted = await navigator.storage.persist();
      console.log(`[VenteFacile] Stockage persistant activé : ${isPersisted}`);
      return isPersisted;
    } catch (e) {
      console.warn('[VenteFacile] Impossible d\'activer le stockage persistant', e);
    }
  }
  return false;
}

// Initial seed catalog for immediate operational readiness
export const initialProducts = [
  {
    barcode: '3360372058878',
    name: 'Sauvage Eau de Parfum 100ml',
    brand: 'Dior',
    category: 'Parfumerie & Beauté',
    buyPrice: 55.00,
    sellPrice: 120.00,
    vatRate: 20,
    stock: 24,
    minStock: 5,
    unit: 'unité',
    variants: ['50 ml', '100 ml', '150 ml', '200 ml'],
    // Authentic dark flacon with midnight-blue glow
    image: 'https://images.unsplash.com/photo-1523293182086-7651a899d37f?auto=format&fit=crop&w=400&q=80',
    expiryDate: '2028-12-31'
  },
  {
    barcode: '3145891263007',
    name: 'Coco Mademoiselle 50ml',
    brand: 'Chanel',
    category: 'Parfumerie & Beauté',
    buyPrice: 48.00,
    sellPrice: 98.00,
    vatRate: 20,
    stock: 18,
    minStock: 4,
    unit: 'unité',
    variants: ['35 ml', '50 ml', '100 ml', '175 ml'],
    // Authentic soft pink faceted bottle with gold neck
    image: 'https://images.unsplash.com/photo-1588405748880-12d1d2a59f75?auto=format&fit=crop&w=400&q=80',
    expiryDate: '2028-06-30'
  },
  {
    barcode: '3145891136608',
    name: 'Chanel N°5 Eau de Parfum 100ml',
    brand: 'Chanel',
    category: 'Parfumerie & Beauté',
    buyPrice: 65.00,
    sellPrice: 135.00,
    vatRate: 20,
    stock: 12,
    minStock: 3,
    unit: 'unité',
    variants: ['50 ml', '100 ml'],
    // Iconic transparent flacon with amber juice
    image: 'https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=400&q=80',
    expiryDate: '2028-10-31'
  },
  {
    barcode: '3145891136301',
    name: 'Coco Noir Eau de Parfum 100ml',
    brand: 'Chanel',
    category: 'Parfumerie & Beauté',
    buyPrice: 68.00,
    sellPrice: 140.00,
    vatRate: 20,
    stock: 10,
    minStock: 3,
    unit: 'unité',
    variants: ['50 ml', '100 ml'],
    // Iconic pitch-black opaque bottle
    image: 'https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=400&q=80',
    expiryDate: '2028-08-31'
  },
  {
    barcode: '3614272648425',
    name: 'La Vie Est Belle 100ml',
    brand: 'Lancôme',
    category: 'Parfumerie & Beauté',
    buyPrice: 50.00,
    sellPrice: 115.00,
    vatRate: 20,
    stock: 15,
    minStock: 3,
    unit: 'unité',
    variants: ['30 ml', '50 ml', '100 ml'],
    image: 'https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=400&q=80',
    expiryDate: '2027-11-20'
  },
  {
    barcode: '8806094895027',
    name: 'Smartphone Galaxy S24 Ultra 256GB',
    brand: 'Samsung',
    category: 'High-Tech & Smartphones',
    buyPrice: 820.00,
    sellPrice: 1199.00,
    vatRate: 20,
    stock: 8,
    minStock: 2,
    unit: 'unité',
    variants: ['Noir Titane', 'Gris Titane', 'Violet Titane'],
    image: 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?auto=format&fit=crop&w=400&q=80',
    expiryDate: ''
  },
  {
    barcode: '194253001234',
    name: 'iPhone 15 Pro Max 256GB',
    brand: 'Apple',
    category: 'High-Tech & Smartphones',
    buyPrice: 950.00,
    sellPrice: 1350.00,
    vatRate: 20,
    stock: 6,
    minStock: 2,
    unit: 'unité',
    variants: ['Titane Naturel', 'Titane Bleu', 'Titane Noir'],
    image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=400&q=80',
    expiryDate: ''
  },
  {
    barcode: '1234567890123',
    name: 'Café Grains Pur Arabica Bio',
    brand: 'Selection Gourmet',
    category: 'Épicerie & Alimentation',
    buyPrice: 8.50,
    sellPrice: 18.00,
    vatRate: 5.5,
    stock: 45.5,
    minStock: 10,
    isWeight: true,
    unit: 'kg',
    variants: ['100 g', '250 g', '500 g', '1 kg'],
    image: 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?auto=format&fit=crop&w=400&q=80',
    expiryDate: '2027-04-15'
  },
  {
    barcode: '9876543210987',
    name: 'Amandes Grillées Salées (Vrac)',
    brand: 'BioNature',
    category: 'Épicerie & Alimentation',
    buyPrice: 9.00,
    sellPrice: 22.00,
    vatRate: 5.5,
    stock: 30.0,
    minStock: 5,
    isWeight: true,
    unit: 'kg',
    variants: ['100 g', '250 g', '500 g', '1 kg'],
    image: 'https://images.unsplash.com/photo-1508061252966-f728c7f3e8f9?auto=format&fit=crop&w=400&q=80',
    expiryDate: '2026-10-30'
  },
  {
    barcode: '4005808257001',
    name: 'Basket Running Air Sport 42',
    brand: 'Nike',
    category: 'Mode & Chaussures',
    buyPrice: 42.00,
    sellPrice: 89.90,
    vatRate: 20,
    stock: 12,
    minStock: 3,
    unit: 'unité',
    variants: ['Pointure 38', 'Pointure 39', 'Pointure 40', 'Pointure 41', 'Pointure 42', 'Pointure 43', 'Pointure 44', 'Pointure 45'],
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=400&q=80',
    expiryDate: ''
  }
];

export const initialClients = [
  {
    name: 'Karim Mansouri',
    phone: '+212 6 12 34 56 78',
    debt: 120.00,
    maxDebt: 300.00,
    email: 'karim@gmail.com',
    points: 45
  },
  {
    name: 'Sarah Bernard',
    phone: '+33 6 98 76 54 32',
    debt: 0.00,
    maxDebt: 500.00,
    email: 'sarah.b@gmail.com',
    points: 180
  },
  {
    name: 'Youssef El Amrani',
    phone: '+212 6 61 22 33 44',
    debt: 275.00,
    maxDebt: 500.00,
    email: 'youssef@hotmail.com',
    points: 12
  }
];

export const initialSuppliers = [
  {
    name: 'Grossiste Parfums & Cosmétiques Luxe',
    phone: '+212 6 61 88 99 00',
    contactPerson: 'Rachid Berrada',
    address: 'Derb Omar, Casablanca',
    category: 'Parfumerie & Beauté',
    debt: 4500.00,
    notes: 'Fournisseur officiel Dior, Chanel et parfums orientaux.'
  },
  {
    name: 'Tech & Accessoires Express',
    phone: '+212 6 63 44 55 66',
    contactPerson: 'Mehdi Alami',
    address: 'Boulevard Mohammed V, Rabat',
    category: 'High-Tech & Smartphones',
    debt: 1200.00,
    notes: 'Accessoires smartphones, chargeurs et protections.'
  },
  {
    name: 'Centrale d\'Alimentation & Épicerie Bio',
    phone: '+212 6 65 11 22 33',
    contactPerson: 'Fatima Zohra',
    address: 'Zone Industrielle, Tanger',
    category: 'Épicerie & Alimentation',
    debt: 0.00,
    notes: 'Cafés bio, amandes, fruits secs en vrac.'
  }
];

export async function clearAllDemoData() {
  await db.products.clear();
  await db.sales.clear();
  await db.payments.clear();
  await db.clients.clear();
  await db.suppliers.clear();
  await db.supplierInvoices.clear();
  await db.supplierPayments.clear();
  if (db.cashMovements) await db.cashMovements.clear();
  if (db.quotes) await db.quotes.clear();
  if (db.cashClosings) await db.cashClosings.clear();
  if (db.caisseJournals) await db.caisseJournals.clear();
  console.log('[VenteFacile] Toutes les données ont été remises à zéro.');
}

export async function loadProductDemoData() {
  await db.products.clear();
  // Strip any preexisting ids to allow clean auto-increment
  const cleanProducts = initialProducts.map(({ id, ...p }) => ({ ...p }));
  await db.products.bulkAdd(cleanProducts);
  console.log('[VenteFacile] Produits de démonstration chargés.');
}

export async function clearProductData() {
  await db.products.clear();
  console.log('[VenteFacile] Catalogue produits vidé.');
}

export async function loadClientDemoData() {
  await db.clients.clear();
  // Strip any preexisting ids to allow clean auto-increment
  const cleanClients = initialClients.map(({ id, ...c }) => ({ ...c }));
  await db.clients.bulkAdd(cleanClients);
  console.log('[VenteFacile] Clients de démonstration chargés.');
}

export async function clearClientData() {
  await db.clients.clear();
  console.log('[VenteFacile] Carnet clients vidé.');
}

export async function seedDatabaseIfEmpty() {
  // Initialise les paramètres par défaut au tout premier lancement
  const settingsCount = await db.settings.count();
  if (settingsCount === 0) {
    const defaultAdminSalt = generateSalt();
    const defaultAdminHash = await hashPinWithSalt('1234', defaultAdminSalt);
    const defaultCashierSalt = generateSalt();
    const defaultCashierHash = await hashPinWithSalt('0000', defaultCashierSalt);

    await db.settings.add({
      id: 1,
      shopName: 'Boutique VenteFacile',
      phone: '',
      address: '',
      currency: 'DH',
      language: 'fr',
      theme: 'light',
      primaryColor: '#4f46e5',
      adminPinHash: defaultAdminHash,
      adminPinSalt: defaultAdminSalt,
      cashierPinHash: defaultCashierHash,
      cashierPinSalt: defaultCashierSalt,
      securityEnabled: false,
      autoLockMinutes: 0, // 0 = désactivé
      fidelityEnabled: true,
      fidelityRatio: 1,
      fidelityRedeemValue: 0.05,
      modules: {
        whatsapp: true,
        website: true,
        fidelity: true,
        vat: true,
        expiry: true,
        vendeurs: true,
        suppliers: true,
        promos: true,
        devis: true,
        multiCurrency: true
      },
      // Store configured flag: false by default, set to true when merchant creates their store
      isStoreConfigured: false,
      // Team members hierarchy (Patron, Gérants, Caissiers) - Hachage avec sel SHA-256
      team: [
        {
          id: 'usr_patron_1',
          name: 'Patron',
          role: 'patron',
          pinHash: defaultAdminHash,
          pinSalt: defaultAdminSalt,
          phone: '',
          avatarColor: '#4f46e5',
          createdAt: new Date().toISOString(),
          permissions: {
            canManageCashiers: true,
            canManageProducts: true,
            canManageSuppliers: true,
            canViewProfits: true,
            canCloseCash: true
          }
        },
        {
          id: 'usr_caissier_1',
          name: 'Caissier 1',
          role: 'caissier',
          pinHash: defaultCashierHash,
          pinSalt: defaultCashierSalt,
          phone: '',
          avatarColor: '#059669',
          createdAt: new Date().toISOString(),
          permissions: {
            canManageCashiers: false,
            canManageProducts: false,
            canManageSuppliers: false,
            canViewProfits: false,
            canCloseCash: false
          }
        }
      ],
      // COMPLETELY EMPTY WHATSAPP SETTINGS (NO +33612345678 AT ALL)
      whatsapp: {
        phoneId: '',
        accessToken: '',
        sellerNumber: '',
        autoReceipt: true,
        autoConfirm: true
      },
      website: {
        siteUrl: '',
        platform: 'WooCommerce',
        apiKey: '',
        apiSecret: '',
        autoSync: true
      }
    });
  } else {
    // Migration: Purge cleartext passwords and generate salted hashes if not already present
    const existingSettings = await db.settings.get(1);
    if (existingSettings) {
      const { cleanedSettings, hasChanged } = await migrateSettingsToSaltedPins(existingSettings);
      
      // Force clean WhatsApp sellerNumber if demo number +33612345678 exists
      let whatsappCleaned = false;
      if (cleanedSettings.whatsapp?.sellerNumber?.includes('33612345678')) {
        cleanedSettings.whatsapp.sellerNumber = '';
        whatsappCleaned = true;
      }

      // Check isStoreConfigured migration
      let configFlagAdded = false;
      if (cleanedSettings.isStoreConfigured === undefined) {
        cleanedSettings.isStoreConfigured = Boolean(
          cleanedSettings.shopName && 
          cleanedSettings.shopName !== 'Boutique VenteFacile' && 
          cleanedSettings.shopName.trim() !== ''
        );
        configFlagAdded = true;
      }

      // Check team migration
      if (!cleanedSettings.team || !Array.isArray(cleanedSettings.team) || cleanedSettings.team.length === 0) {
        const pSalt = generateSalt();
        const pHash = await hashPinWithSalt('1234', pSalt);
        const cSalt = generateSalt();
        const cHash = await hashPinWithSalt('0000', cSalt);

        cleanedSettings.team = [
          {
            id: 'usr_patron_1',
            name: 'Patron',
            role: 'patron',
            pinHash: pHash,
            pinSalt: pSalt,
            phone: '',
            avatarColor: '#4f46e5',
            createdAt: new Date().toISOString(),
            permissions: {
              canManageCashiers: true,
              canManageProducts: true,
              canManageSuppliers: true,
              canViewProfits: true,
              canCloseCash: true
            }
          },
          {
            id: 'usr_caissier_1',
            name: 'Caissier 1',
            role: 'caissier',
            pinHash: cHash,
            pinSalt: cSalt,
            phone: '',
            avatarColor: '#059669',
            createdAt: new Date().toISOString(),
            permissions: {
              canManageCashiers: false,
              canManageProducts: false,
              canManageSuppliers: false,
              canViewProfits: false,
              canCloseCash: false
            }
          }
        ];
        configFlagAdded = true;
      }

      if (hasChanged || whatsappCleaned || configFlagAdded) {
        await db.settings.put(cleanedSettings, 1);
        console.log('[VenteFacile] Paramètres migrés vers hachage SHA-256 avec sel et statut boutique mis à jour.');
      }
    }
  }

  // Automatic Migration: Fix Perfume Product Images in existing IndexedDB
  await migrateAndFixProductImages();
}

/**
 * Migration automatique des images de parfums mal associées
 */
export async function migrateAndFixProductImages() {
  try {
    const products = await db.products.toArray();
    for (const p of products) {
      let newImage = null;
      const nameLower = (p.name || '').toLowerCase();
      
      // Fix Dior Sauvage (Remove black Coco Noir bottle, set dark Sauvage bottle)
      if (nameLower.includes('sauvage') && (p.image?.includes('1594035910387') || !p.image)) {
        newImage = 'https://images.unsplash.com/photo-1523293182086-7651a899d37f?auto=format&fit=crop&w=400&q=80';
      }
      // Fix Chanel Coco Mademoiselle (Remove Chanel N°5 rectangular flacon, set rose/peachy bottle)
      else if (nameLower.includes('mademoiselle') && (p.image?.includes('1541643600914') || !p.image)) {
        newImage = 'https://images.unsplash.com/photo-1588405748880-12d1d2a59f75?auto=format&fit=crop&w=400&q=80';
      }
      // Fix Chanel Coco Noir (Keep/set opaque black bottle)
      else if (nameLower.includes('coco noir') && !p.image?.includes('1594035910387')) {
        newImage = 'https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=400&q=80';
      }
      // Fix Chanel N°5 (Keep/set iconic square bottle)
      else if ((nameLower.includes('n°5') || nameLower.includes('no 5')) && !p.image?.includes('1541643600914')) {
        newImage = 'https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=400&q=80';
      }

      if (newImage && newImage !== p.image) {
        await db.products.update(p.id, { image: newImage });
        console.log(`[VenteFacile Migration] Image corrigée pour ${p.name}`);
      }
    }
  } catch (err) {
    console.warn('[VenteFacile Migration] Erreur lors de la mise à jour des images', err);
  }
}

/**
 * Synchronisation bi-directionnelle avec le serveur Backend Node.js
 */
export async function syncWithBackendServer() {
  try {
    const res = await fetch('/api/sync/all', { method: 'GET', headers: { 'Accept': 'application/json' } });
    if (!res.ok) {
      return { online: false, reason: `HTTP ${res.status}` };
    }

    const data = await res.json();
    if (!data.success) return { online: false };

    // Si le serveur a des données, on synchronise avec Dexie local
    if (data.products && data.products.length > 0) {
      // Merge products
      const localProducts = await db.products.toArray();
      if (localProducts.length === 0) {
        await db.products.bulkAdd(data.products);
      }
    } else {
      // Le serveur est vide (premier démarrage) : on pousse la base locale vers le serveur
      await pushLocalChangesToBackend();
    }

    return { online: true, lastUpdated: data.lastUpdated };
  } catch (err) {
    // Mode hors-ligne transparent
    return { online: false, error: err.message };
  }
}

/**
 * Envoi des modifications locales vers le serveur backend
 */
export async function pushLocalChangesToBackend() {
  try {
    const [
      products, 
      sales, 
      clients, 
      payments, 
      quotes, 
      cashMovements, 
      settings,
      suppliers,
      supplierInvoices,
      supplierPayments,
      cashClosings
    ] = await Promise.all([
      db.products.toArray(),
      db.sales.toArray(),
      db.clients.toArray(),
      db.payments.toArray(),
      db.quotes ? db.quotes.toArray() : [],
      db.cashMovements ? db.cashMovements.toArray() : [],
      db.settings.get(1),
      db.suppliers ? db.suppliers.toArray() : [],
      db.supplierInvoices ? db.supplierInvoices.toArray() : [],
      db.supplierPayments ? db.supplierPayments.toArray() : [],
      db.cashClosings ? db.cashClosings.toArray() : []
    ]);

    const payload = {
      products,
      sales,
      clients,
      payments,
      quotes,
      cashMovements,
      suppliers,
      supplierInvoices,
      supplierPayments,
      cashClosings,
      settings: settings || {}
    };

    const res = await fetch('/api/sync/push', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    return res.ok;
  } catch (err) {
    console.warn('[VenteFacile Sync] Impossible d\'envoyer vers le backend (mode hors-ligne actif)', err);
    return false;
  }
}

/**
 * Enregistrement d'un arrivage / facture fournisseur avec gestion du crédit
 */
export async function recordSupplierInvoice({
  supplierId,
  supplierName,
  invoiceNumber,
  items = [],
  totalAmount = 0,
  paidAmount = 0,
  paymentMethod = 'especes',
  deductFromCashDrawer = false,
  notes = '',
  cashier = 'Gérant'
}) {
  const tot = parseSafeFloat(totalAmount, 0);
  const paid = parseSafeFloat(paidAmount, 0);
  const remainingDebt = Math.max(0, tot - paid);
  const now = new Date().toISOString();

  // 1. Enregistrer ou mettre à jour le fournisseur
  let sId = supplierId;
  if (!sId && supplierName) {
    const existing = await db.suppliers.where('name').equalsIgnoreCase(supplierName.trim()).first();
    if (existing) {
      sId = existing.id;
    } else {
      sId = await db.suppliers.add({
        name: supplierName.trim(),
        phone: '',
        contactPerson: '',
        category: 'Général',
        debt: 0,
        createdAt: now
      });
    }
  }

  // 2. Mettre à jour la dette du fournisseur
  if (sId) {
    const s = await db.suppliers.get(sId);
    if (s) {
      const newDebt = (parseSafeFloat(s.debt, 0)) + remainingDebt;
      await db.suppliers.update(sId, { debt: newDebt });
    }
  }

  // 3. Créer la facture d'achat
  const invId = await db.supplierInvoices.add({
    supplierId: sId,
    supplierName: supplierName || 'Fournisseur',
    invoiceNumber: invoiceNumber || `BL-${Date.now().toString().slice(-6)}`,
    date: now,
    totalAmount: tot,
    paidAmount: paid,
    remainingDebt: remainingDebt,
    status: remainingDebt === 0 ? 'paid' : (paid > 0 ? 'partial' : 'unpaid'),
    items: items,
    notes: notes,
    createdAt: now
  });

  // 4. Si un acompte a été payé, enregistrer l'écriture de paiement
  if (paid > 0) {
    await db.supplierPayments.add({
      supplierId: sId,
      supplierName: supplierName,
      invoiceId: invId,
      invoiceNumber: invoiceNumber,
      amount: paid,
      paymentMethod: paymentMethod,
      date: now,
      deductedFromCashDrawer: deductFromCashDrawer,
      notes: notes || 'Acompte initial à la livraison',
      cashier: cashier,
      createdAt: now
    });

    // Déduction automatique de la caisse physique si demandé
    if (deductFromCashDrawer && paymentMethod === 'especes') {
      await db.cashMovements.add({
        timestamp: now,
        amount: paid,
        reason: `Règlement Fournisseur (${supplierName} - ${invoiceNumber || 'Arrivage'})`,
        cashier: cashier
      });
    }
  }

  return { invoiceId: invId, supplierId: sId, remainingDebt };
}

/**
 * Enregistrement d'un règlement d'une dette fournisseur ultérieure
 */
export async function recordSupplierPayment({
  supplierId,
  supplierName,
  invoiceId = null,
  amount,
  paymentMethod = 'especes',
  checkNumber = '',
  dueDate = '',
  deductFromCashDrawer = false,
  notes = '',
  cashier = 'Gérant'
}) {
  const pAmount = parseSafeFloat(amount, 0);
  if (pAmount <= 0) throw new Error('Le montant du versement doit être supérieur à zéro.');

  const now = new Date().toISOString();

  // 1. Mettre à jour la dette du fournisseur
  if (supplierId) {
    const s = await db.suppliers.get(supplierId);
    if (s) {
      const currentDebt = parseSafeFloat(s.debt, 0);
      const newDebt = Math.max(0, currentDebt - pAmount);
      await db.suppliers.update(supplierId, { debt: newDebt });
    }
  }

  // 2. Si lié à une facture spécifique, mettre à jour le reste dû
  if (invoiceId) {
    const inv = await db.supplierInvoices.get(invoiceId);
    if (inv) {
      const newPaid = (parseSafeFloat(inv.paidAmount, 0)) + pAmount;
      const newRemaining = Math.max(0, (parseSafeFloat(inv.totalAmount, 0)) - newPaid);
      await db.supplierInvoices.update(invoiceId, {
        paidAmount: newPaid,
        remainingDebt: newRemaining,
        status: newRemaining === 0 ? 'paid' : 'partial'
      });
    }
  }

  // 3. Enregistrer l'écriture de paiement
  const paymentId = await db.supplierPayments.add({
    supplierId,
    supplierName,
    invoiceId,
    amount: pAmount,
    paymentMethod,
    checkNumber,
    dueDate,
    deductedFromCashDrawer,
    date: now,
    notes,
    cashier,
    createdAt: now
  });

  // 4. Déduction automatique du tiroir-caisse si demandé
  if (deductFromCashDrawer && paymentMethod === 'especes') {
    await db.cashMovements.add({
      timestamp: now,
      amount: pAmount,
      reason: `Règlement Dette Fournisseur (${supplierName})`,
      cashier
    });
  }

  return paymentId;
}

/**
 * Supprimer toutes les données fournisseurs
 */
export async function clearSupplierData() {
  await db.suppliers.clear();
  await db.supplierInvoices.clear();
  await db.supplierPayments.clear();
}

/**
 * Charger un jeu complet de données de démonstration Fournisseurs & Dettes
 */
export async function loadSupplierDemoData() {
  await clearSupplierData();
  const now = new Date();
  const dateStr = (daysAgo = 0) => new Date(now.getTime() - daysAgo * 24 * 3600 * 1000).toISOString();

  const sup1Id = await db.suppliers.add({
    name: 'Grossiste Parfums & Cosmétiques Luxe',
    phone: '+212 6 61 88 99 00',
    contactPerson: 'Rachid Berrada',
    address: 'Derb Omar, Casablanca',
    category: 'Parfumerie & Beauté',
    debt: 4500.00,
    notes: 'Fournisseur officiel Dior, Chanel et parfums orientaux.',
    createdAt: dateStr(15)
  });

  const sup2Id = await db.suppliers.add({
    name: 'Tech & Accessoires Express',
    phone: '+212 6 63 44 55 66',
    contactPerson: 'Mehdi Alami',
    address: 'Boulevard Mohammed V, Rabat',
    category: 'High-Tech & Smartphones',
    debt: 1200.00,
    notes: 'Accessoires smartphones, chargeurs et protections.',
    createdAt: dateStr(10)
  });

  const sup3Id = await db.suppliers.add({
    name: 'Centrale d\'Alimentation & Épicerie Bio',
    phone: '+212 6 65 11 22 33',
    contactPerson: 'Fatima Zohra',
    address: 'Zone Industrielle, Tanger',
    category: 'Épicerie & Alimentation',
    debt: 0.00,
    notes: 'Cafés bio, amandes, fruits secs en vrac.',
    createdAt: dateStr(5)
  });

  // Facture 1 : Arrivage parfums
  await db.supplierInvoices.add({
    supplierId: sup1Id,
    supplierName: 'Grossiste Parfums & Cosmétiques Luxe',
    invoiceNumber: 'BL-2026-0842',
    date: dateStr(5),
    totalAmount: 10000.00,
    paidAmount: 5500.00,
    remainingDebt: 4500.00,
    status: 'partial',
    items: [
      { name: 'Sauvage Eau de Parfum 100ml', addedQty: 40, buyPrice: 55.00, unit: 'unité' },
      { name: 'Coco Mademoiselle 50ml', addedQty: 30, buyPrice: 48.00, unit: 'unité' },
      { name: 'Chanel N°5 100ml', addedQty: 50, buyPrice: 65.00, unit: 'unité' }
    ],
    notes: 'Arrivage direct Grasse - Acompte 5500 DH versé par virement.',
    createdAt: dateStr(5)
  });

  // Facture 2 : Arrivage accessoires
  await db.supplierInvoices.add({
    supplierId: sup2Id,
    supplierName: 'Tech & Accessoires Express',
    invoiceNumber: 'BL-2026-0914',
    date: dateStr(2),
    totalAmount: 3000.00,
    paidAmount: 1800.00,
    remainingDebt: 1200.00,
    status: 'partial',
    items: [
      { name: 'Coques et Chargeurs Rapides', addedQty: 100, buyPrice: 30.00, unit: 'unité' }
    ],
    notes: 'Livraison express - Acompte espèces 1800 DH.',
    createdAt: dateStr(2)
  });

  // Règlements
  await db.supplierPayments.add({
    supplierId: sup1Id,
    supplierName: 'Grossiste Parfums & Cosmétiques Luxe',
    amount: 5500.00,
    paymentMethod: 'virement',
    checkNumber: 'VIR-BK-8842',
    date: dateStr(5),
    deductedFromCashDrawer: false,
    notes: 'Acompte initial sur BL-2026-0842',
    cashier: 'Gérant',
    createdAt: dateStr(5)
  });

  await db.supplierPayments.add({
    supplierId: sup2Id,
    supplierName: 'Tech & Accessoires Express',
    amount: 1800.00,
    paymentMethod: 'especes',
    date: dateStr(2),
    deductedFromCashDrawer: true,
    notes: 'Acompte espèces livraison BL-2026-0914',
    cashier: 'Gérant',
    createdAt: dateStr(2)
  });
}

/**
 * Charger une simulation complète de boutique en activité
 */
export async function loadCompleteDemoDataset() {
  await clearAllDemoData();
  const cleanProducts = initialProducts.map(({ id, ...p }) => ({ ...p }));
  await db.products.bulkAdd(cleanProducts);
  const cleanClients = initialClients.map(({ id, ...c }) => ({ ...c }));
  await db.clients.bulkAdd(cleanClients);
  await loadSupplierDemoData();

  const now = new Date();
  const dateStr = (daysAgo = 0, hour = 14) => {
    const d = new Date(now.getTime() - daysAgo * 24 * 3600 * 1000);
    d.setHours(hour, Math.floor(Math.random() * 60), 0, 0);
    return d.toISOString();
  };

  const sampleSales = [
    {
      receiptNo: 'TICK-001',
      timestamp: dateStr(0, 11),
      clientName: 'Karim Mansouri',
      clientId: 1,
      paymentMethod: 'especes',
      totalTTC: 340.00,
      subtotalHT: 283.33,
      totalVAT: 56.67,
      cashier: 'Patron',
      items: [
        { name: 'Sauvage Eau de Parfum 100ml', quantity: 2, sellPrice: 120.00, buyPrice: 55.00, vatRate: 20 },
        { name: 'Coco Mademoiselle 50ml', quantity: 1, sellPrice: 98.00, buyPrice: 48.00, vatRate: 20 }
      ]
    },
    {
      receiptNo: 'TICK-002',
      timestamp: dateStr(1, 15),
      clientName: 'Sarah Bernard',
      clientId: 2,
      paymentMethod: 'carte',
      totalTTC: 1350.00,
      subtotalHT: 1125.00,
      totalVAT: 225.00,
      cashier: 'Caissier 1',
      items: [
        { name: 'iPhone 15 Pro Max 256GB', quantity: 1, sellPrice: 1350.00, buyPrice: 950.00, vatRate: 20 }
      ]
    },
    {
      receiptNo: 'TICK-003',
      timestamp: dateStr(2, 17),
      clientName: 'Youssef El Amrani',
      clientId: 3,
      paymentMethod: 'credit',
      isCredit: true,
      totalTTC: 275.00,
      subtotalHT: 229.17,
      totalVAT: 45.83,
      cashier: 'Patron',
      items: [
        { name: 'Chanel N°5 100ml', quantity: 1, sellPrice: 135.00, buyPrice: 65.00, vatRate: 20 },
        { name: 'Coco Noir 100ml', quantity: 1, sellPrice: 140.00, buyPrice: 68.00, vatRate: 20 }
      ]
    }
  ];

  await db.sales.bulkAdd(sampleSales);
  await db.clients.update(3, { debt: 275.00 });
}



