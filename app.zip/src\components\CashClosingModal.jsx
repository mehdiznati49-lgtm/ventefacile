import React, { useState, useEffect } from 'react';
import { 
  Calculator, 
  Receipt, 
  CheckCircle2, 
  AlertTriangle, 
  Printer, 
  X, 
  Coins, 
  DollarSign, 
  Clock, 
  ShieldCheck,
  RotateCcw
} from 'lucide-react';
import { db } from '../db';
import { triggerOpenCashDrawer, triggerPrintWithLayout } from '../thermalPrinter';
import { useToast } from '../context/ToastContext';
import { getLocalDateString, isSameLocalDay } from '../utils/dateUtils';

export default function CashClosingModal({
  isOpen,
  onClose,
  sales = [],
  settings = {},
  currentLang = 'fr',
  currentCashier = 'Caissier',
  onClosingCompleted
}) {
  const toast = useToast();
  const currency = settings.currency || 'DH';
  const [activeTab, setActiveTab] = useState('x'); // 'x' for X-Report (live preview), 'z' for Z-Report (official close)
  const [countedCash, setCountedCash] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [closedZRecord, setClosedZRecord] = useState(null);
  const [expenses, setExpenses] = useState([]);
  const [clientPayments, setClientPayments] = useState([]);

  // Fetch today's cash expenses and client debt repayments
  useEffect(() => {
    if (!isOpen) return;
    const fetchMovements = async () => {
      try {
        const all = await db.cashMovements?.toArray() || [];
        const todayExp = all.filter(m => isSameLocalDay(m.timestamp));
        setExpenses(todayExp);

        const allPayments = await db.payments?.toArray() || [];
        const todayPmts = allPayments.filter(p => isSameLocalDay(p.timestamp));
        setClientPayments(todayPmts);
      } catch (e) {
        console.warn('Error fetching cash movements or payments', e);
      }
    };
    fetchMovements();
  }, [isOpen]);

  if (!isOpen) return null;

  // Filter today's sales (strict local calendar day)
  const todayStr = getLocalDateString();
  const todaySales = sales.filter(s => isSameLocalDay(s.timestamp));

  // Sales totals
  const totalSalesCount = todaySales.length;
  const totalTTC = todaySales.reduce((acc, s) => acc + (s.totalTTC || 0), 0);
  const totalHT = todaySales.reduce((acc, s) => acc + (s.subtotalHT || (s.totalTTC / 1.2)), 0);
  const totalVAT = todaySales.reduce((acc, s) => acc + (s.totalVAT || (s.totalTTC - s.subtotalHT)), 0);

  // Breakdown by payment method
  const paymentsByMethod = todaySales.reduce((acc, s) => {
    const m = (s.paymentMethod || 'especes').toLowerCase();
    acc[m] = (acc[m] || 0) + (s.totalTTC || 0);
    return acc;
  }, { especes: 0, carte: 0, virement: 0, credit: 0 });

  // Client debt repayments collected today in cash
  const clientDebtCash = clientPayments
    .filter(p => (p.paymentMethod || 'especes').toLowerCase() === 'especes')
    .reduce((acc, p) => acc + (Number(p.amount) || 0), 0);

  // Cash calculation
  const openingFloat = Number(settings.openingFloat || 0);
  const totalCashExpenses = expenses.reduce((acc, e) => acc + (Number(e.amount) || 0), 0);
  const expectedCashInDrawer = Math.max(0, openingFloat + paymentsByMethod.especes + clientDebtCash - totalCashExpenses);

  // Cash variance
  const countedNum = countedCash !== '' ? parseFloat(countedCash) : null;
  const cashVariance = countedNum !== null ? (countedNum - expectedCashInDrawer) : 0;

  // Helper to open drawer for counting
  const handleOpenDrawerToCount = async () => {
    await triggerOpenCashDrawer();
    toast.info("Tiroir-caisse ouvert pour le comptage des espèces.", "Matériel Caisse");
  };

  // Perform Official Z-Closing
  const handleExecuteZClosing = async () => {
    if (countedCash === '' || isNaN(countedNum)) {
      toast.error("Veuillez saisir le montant réel des espèces comptées dans le tiroir.", "Comptage requis");
      return;
    }

    setIsSubmitting(true);
    try {
      const closingDate = new Date().toISOString();
      const zNumber = `Z-${closingDate.slice(0, 10).replace(/-/g, '')}-${Date.now().toString().slice(-4)}`;

      // Cryptographic seal payload (NF525)
      const payloadString = `Z_REPORT;;${zNumber};;${closingDate};;${totalSalesCount};;${totalTTC.toFixed(2)};;${expectedCashInDrawer.toFixed(2)};;${countedNum.toFixed(2)};;${cashVariance.toFixed(2)}`;
      const encoder = new TextEncoder();
      const digestBuffer = await crypto.subtle.digest('SHA-256', encoder.encode(payloadString));
      const hashArray = Array.from(new Uint8Array(digestBuffer));
      const zSignature = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

      const zRecord = {
        closingNo: zNumber,
        type: 'Z_CLOSING',
        date: closingDate.slice(0, 10),
        timestamp: closingDate,
        cashier: currentCashier,
        totalSalesCount,
        totalHT: Math.round(totalHT * 100) / 100,
        totalVAT: Math.round(totalVAT * 100) / 100,
        totalTTC: Math.round(totalTTC * 100) / 100,
        payments: paymentsByMethod,
        clientDebtCash: Math.round(clientDebtCash * 100) / 100,
        openingFloat,
        totalCashExpenses,
        expectedCash: expectedCashInDrawer,
        countedCash: countedNum,
        cashVariance: Math.round(cashVariance * 100) / 100,
        notes,
        sealedHash: zSignature,
        sealedHashShort: zSignature.slice(0, 16).toUpperCase()
      };

      // Save in Dexie if cashClosings table exists
      try {
        if (db.cashClosings) {
          await db.cashClosings.add(zRecord);
        }
      } catch (err) {
        console.warn('Could not save to db.cashClosings', err);
      }

      setClosedZRecord(zRecord);
      toast.success(`Clôture journalière ${zNumber} scellée et enregistrée avec succès !`, "Clôture Z Validée");
      if (onClosingCompleted) onClosingCompleted(zRecord);
    } catch (err) {
      toast.error(`Erreur lors de la clôture : ${err.message}`, "Erreur");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 max-w-lg w-full border border-slate-200 dark:border-slate-800 shadow-2xl my-6 animate-in zoom-in-95 duration-150">
        
        {/* Header with Mode Switcher */}
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                Gestion des Clôtures de Caisse
              </h3>
              <p className="text-[11px] text-slate-500">
                Caissier actif : <b>{currentCashier}</b> • {new Date().toLocaleDateString('fr-FR')}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher: Ticket X vs Ticket Z */}
        {!closedZRecord && (
          <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-2xl mb-4">
            <button
              type="button"
              onClick={() => setActiveTab('x')}
              className={`py-2 px-3 rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 ${
                activeTab === 'x'
                  ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <Clock className="w-4 h-4 text-amber-500" />
              <span>Ticket X (Consultation en direct)</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('z')}
              className={`py-2 px-3 rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 ${
                activeTab === 'z'
                  ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-indigo-600" />
              <span>Ticket Z (Clôture Officielle)</span>
            </button>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 1: TICKET X (SITUATION PROVISOIRE)                                  */}
        {/* ========================================================================= */}
        {activeTab === 'x' && !closedZRecord && (
          <div id="x-thermal-receipt" className="space-y-4 text-xs">
            <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 rounded-2xl text-amber-800 dark:text-amber-300 no-print">
              <span className="font-extrabold block mb-0.5">ℹ️ Situation Provisoire (Ticket X) :</span>
              Permet de faire le point à tout moment de la journée sans bloquer ni clôturer la caisse.
            </div>

            {/* Financial Highlights */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
                <span className="text-slate-400 block text-[11px] font-bold">Chiffre d'Affaires du Jour</span>
                <span className="text-lg font-black text-slate-900 dark:text-white">
                  {totalTTC.toFixed(2)} {currency}
                </span>
                <span className="text-[10px] text-slate-500 block">{totalSalesCount} ticket(s) encaissé(s)</span>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
                <span className="text-slate-400 block text-[11px] font-bold">Espèces Théoriques Tiroir</span>
                <span className="text-lg font-black text-emerald-600 dark:text-emerald-400">
                  {expectedCashInDrawer.toFixed(2)} {currency}
                </span>
                <span className="text-[10px] text-slate-500 block">Fond ({openingFloat} {currency}) inclus</span>
              </div>
            </div>

            {/* Payment Method Breakdown */}
            <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1.5 font-medium">
              <div className="font-extrabold text-slate-900 dark:text-white border-b border-slate-200 dark:border-slate-700 pb-1 flex justify-between">
                <span>Modes de Paiement</span>
                <span>Montant Total</span>
              </div>
              <div className="flex justify-between">
                <span>💵 Ventes Espèces</span>
                <span className="font-bold">{paymentsByMethod.especes.toFixed(2)} {currency}</span>
              </div>
              {clientDebtCash > 0 && (
                <div className="flex justify-between text-emerald-600 dark:text-emerald-400 font-bold">
                  <span>🤝 Versements Dettes Clients (Espèces)</span>
                  <span>+{clientDebtCash.toFixed(2)} {currency}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>💳 Carte Bancaire</span>
                <span className="font-bold">{paymentsByMethod.carte.toFixed(2)} {currency}</span>
              </div>
              <div className="flex justify-between">
                <span>🏦 Virement / Chèque</span>
                <span className="font-bold">{paymentsByMethod.virement.toFixed(2)} {currency}</span>
              </div>
              <div className="flex justify-between">
                <span>📝 Vente à Crédit Client</span>
                <span className="font-bold">{paymentsByMethod.credit.toFixed(2)} {currency}</span>
              </div>
              {totalCashExpenses > 0 && (
                <div className="flex justify-between text-rose-600 pt-1 border-t border-slate-200 dark:border-slate-700 font-bold">
                  <span>🔻 Dépenses / Sorties de caisse</span>
                  <span>-{totalCashExpenses.toFixed(2)} {currency}</span>
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="flex gap-2 pt-2 no-print">
              <button
                type="button"
                onClick={() => triggerPrintWithLayout('80mm')}
                className="flex-1 py-3 bg-slate-800 hover:bg-slate-900 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md"
              >
                <Printer className="w-4 h-4 text-indigo-400" />
                <span>Imprimer Ticket X (Aperçu)</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('z')}
                className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md shadow-indigo-500/20"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Passer à la Clôture Z ➔</span>
              </button>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 2: TICKET Z (CLÔTURE DÉFINITIVE & COMPTAGE TIROIR)                   */}
        {/* ========================================================================= */}
        {activeTab === 'z' && !closedZRecord && (
          <div className="space-y-4 text-xs">
            <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900/50 rounded-2xl text-indigo-800 dark:text-indigo-300">
              <span className="font-extrabold block mb-0.5">🔒 Clôture Officielle Journalière (Ticket Z) :</span>
              Comptez le tiroir-caisse ci-dessous. Le système scellera la journée avec signature cryptographique inaltérable (norme NF525).
            </div>

            {/* Cash Drawer Counting Input */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
              <div className="flex items-center justify-between">
                <label className="font-extrabold text-slate-800 dark:text-slate-200">
                  Comptage Physique des Espèces :
                </label>
                <button
                  type="button"
                  onClick={handleOpenDrawerToCount}
                  className="px-2.5 py-1 bg-amber-100 hover:bg-amber-200 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-bold rounded-lg text-[11px] flex items-center gap-1 transition"
                  title="Ouvrir le tiroir physique"
                >
                  <Coins className="w-3.5 h-3.5" />
                  <span>Ouvrir Tiroir</span>
                </button>
              </div>

              <div className="relative">
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="0.00"
                  value={countedCash}
                  onChange={(e) => setCountedCash(e.target.value)}
                  className="w-full text-lg font-black p-3 pr-12 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white"
                  autoFocus
                />
                <span className="absolute right-4 top-3.5 font-bold text-slate-400">
                  {currency}
                </span>
              </div>

              {/* Dynamic Variance Box */}
              <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex justify-between items-center text-xs">
                <div>
                  <span className="text-slate-500 block">Attendu en caisse :</span>
                  <span className="font-extrabold">{expectedCashInDrawer.toFixed(2)} {currency}</span>
                </div>

                {countedNum !== null && (
                  <div className="text-right">
                    <span className="text-slate-500 block">Écart de caisse :</span>
                    <span className={`font-black text-sm px-2 py-0.5 rounded-lg ${
                      Math.abs(cashVariance) < 0.01
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        : cashVariance > 0
                        ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                        : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                    }`}>
                      {Math.abs(cashVariance) < 0.01 
                        ? 'Exact ✅ (0.00)' 
                        : cashVariance > 0 
                        ? `+${cashVariance.toFixed(2)} ${currency} (Surplus)` 
                        : `${cashVariance.toFixed(2)} ${currency} (Manque)`}
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Note / Comment */}
            <div>
              <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                Remarques / Observations de clôture (Optionnel) :
              </label>
              <input
                type="text"
                placeholder="Ex: Fond de caisse 500 DH vérifié, aucun incident"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
              />
            </div>

            {/* Confirmation CTA */}
            <div className="pt-2 flex gap-2">
              <button
                type="button"
                onClick={() => setActiveTab('x')}
                className="px-4 py-3 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold"
              >
                Retour
              </button>
              <button
                type="button"
                disabled={isSubmitting || countedCash === ''}
                onClick={handleExecuteZClosing}
                className="flex-1 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 disabled:opacity-50 text-white font-extrabold rounded-xl shadow-lg flex items-center justify-center gap-2 active:scale-95 transition"
              >
                <ShieldCheck className="w-4 h-4 text-emerald-300" />
                <span>{isSubmitting ? 'Scellement en cours...' : 'Valider & Sceller Clôture Z ✅'}</span>
              </button>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 3: SEALED Z-RECEIPT (SUCCESS & PRINT VIEW)                          */}
        {/* ========================================================================= */}
        {closedZRecord && (
          <div className="space-y-4 text-xs animate-in zoom-in-95">
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 rounded-2xl text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600" />
              <div>
                <p className="font-extrabold text-sm">Clôture Z Enregistrée avec Succès !</p>
                <p className="text-[11px]">N° {closedZRecord.closingNo} • Sceau NF525 certifié</p>
              </div>
            </div>

            {/* Printable Thermal Container for Ticket Z */}
            <div id="z-thermal-receipt" className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 font-mono text-[11px] space-y-1.5">
              <div className="text-center font-bold text-sm">{settings.shopName || 'VENTEFACILE PRO'}</div>
              <div className="text-center text-[10px] text-slate-500">CLÔTURE JOURNALIÈRE OFFICIELLE (TICKET Z)</div>
              <div className="border-t border-dashed border-slate-300 dark:border-slate-600 my-1"></div>
              
              <div className="flex justify-between"><span>N° Clôture :</span><b>{closedZRecord.closingNo}</b></div>
              <div className="flex justify-between"><span>Date :</span><span>{new Date(closedZRecord.timestamp).toLocaleString()}</span></div>
              <div className="flex justify-between"><span>Caissier :</span><span>{closedZRecord.cashier}</span></div>
              <div className="flex justify-between"><span>Tickets encaissés :</span><b>{closedZRecord.totalSalesCount}</b></div>
              
              <div className="border-t border-dashed border-slate-300 dark:border-slate-600 my-1"></div>
              <div className="flex justify-between"><span>Ventes Espèces :</span><span>{closedZRecord.payments.especes.toFixed(2)} {currency}</span></div>
              {closedZRecord.clientDebtCash > 0 && (
                <div className="flex justify-between text-emerald-600 dark:text-emerald-400 font-bold">
                  <span>Dettes Clients (Espèces) :</span>
                  <span>+{closedZRecord.clientDebtCash.toFixed(2)} {currency}</span>
                </div>
              )}
              <div className="flex justify-between"><span>Carte :</span><span>{closedZRecord.payments.carte.toFixed(2)} {currency}</span></div>
              <div className="flex justify-between"><span>Virement :</span><span>{closedZRecord.payments.virement.toFixed(2)} {currency}</span></div>
              <div className="flex justify-between"><span>Crédit Client :</span><span>{closedZRecord.payments.credit.toFixed(2)} {currency}</span></div>

              <div className="border-t border-dashed border-slate-300 dark:border-slate-600 my-1"></div>
              <div className="flex justify-between"><span>Fond de caisse :</span><span>{closedZRecord.openingFloat.toFixed(2)} {currency}</span></div>
              {closedZRecord.totalCashExpenses > 0 && (
                <div className="flex justify-between text-rose-600">
                  <span>Sorties de caisse :</span>
                  <span>-{closedZRecord.totalCashExpenses.toFixed(2)} {currency}</span>
                </div>
              )}
              <div className="flex justify-between font-bold"><span>Espèces attendues :</span><span>{closedZRecord.expectedCash.toFixed(2)} {currency}</span></div>
              <div className="flex justify-between"><span>Espèces réelles :</span><b>{closedZRecord.countedCash.toFixed(2)} {currency}</b></div>
              <div className="flex justify-between font-bold">
                <span>Écart de caisse :</span>
                <span>{closedZRecord.cashVariance >= 0 ? `+${closedZRecord.cashVariance.toFixed(2)}` : closedZRecord.cashVariance.toFixed(2)} {currency}</span>
              </div>

              <div className="border-t border-dashed border-slate-300 dark:border-slate-600 my-1"></div>
              <div className="flex justify-between font-extrabold text-xs text-indigo-600 dark:text-indigo-400">
                <span>TOTAL JOURNÉE TTC :</span>
                <span>{closedZRecord.totalTTC.toFixed(2)} {currency}</span>
              </div>

              <div className="border-t border-dashed border-slate-300 dark:border-slate-600 my-1"></div>
              <div className="text-[10px] text-center text-slate-500 pt-1">
                <div>🔐 SIGNATURE INALTÉRABLE (NF525) :</div>
                <div className="font-bold select-all break-all">{closedZRecord.sealedHashShort}</div>
              </div>
            </div>

            {/* Print & Close */}
            <div className="flex gap-2 pt-2 no-print">
              <button
                type="button"
                onClick={() => triggerPrintWithLayout('80mm')}
                className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md shadow-indigo-500/20"
              >
                <Printer className="w-4 h-4" />
                <span>Imprimer Ticket Z Thermique</span>
              </button>
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-3 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-slate-800 dark:text-slate-200 font-bold rounded-xl text-xs"
              >
                Terminer
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
