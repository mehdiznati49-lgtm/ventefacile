import React, { useState } from 'react';
import { 
  Store, 
  Check, 
  X, 
  Sparkles, 
  Phone, 
  Mail, 
  MapPin, 
  Building2, 
  Navigation, 
  Globe2, 
  DollarSign, 
  ShieldCheck, 
  Briefcase,
  ShoppingBag,
  Lock,
  Key,
  Eye,
  EyeOff
} from 'lucide-react';
import { db, clearAllDemoData, generateSalt, hashPinWithSalt } from '../db';
import { translations } from '../translations';
import { useToast } from '../context/ToastContext';

export const BUSINESS_TYPES = [
  { id: 'epicerie', label: '🛒 Épicerie, Supérette & Alimentation', category: 'Épicerie & Alimentation', desc: 'Produits frais, épicerie sèche, ventes au poids (kg/g)' },
  { id: 'parfumerie', label: '🌸 Parfumerie, Beauté & Cosmétiques', category: 'Parfumerie & Beauté', desc: 'Parfums de luxe, soins, maquillage, dates de péremption' },
  { id: 'hightech', label: '📱 High-Tech, Smartphones & Informatique', category: 'High-Tech & Smartphones', desc: 'Smartphones, accessoires, pièces et réparations' },
  { id: 'mode', label: '👗 Mode, Prêt-à-porter & Chaussures', category: 'Mode & Chaussures', desc: 'Vêtements, tailles, pointures, arrivages textiles' },
  { id: 'pharmacie', label: '💊 Parapharmacie & Soins de Santé', category: 'Parfumerie & Beauté', desc: 'Compléments alimentaires, hygiène, soins dermato' },
  { id: 'quincaillerie', label: '🔧 Quincaillerie, Bricolage & Droguerie', category: 'Autre', desc: 'Outillage, fournitures, peinture, visserie' },
  { id: 'restauration', label: '☕ Café, Snack & Restauration rapide', category: 'Épicerie & Alimentation', desc: 'Boissons, snacking, encaissement ultra-rapide' },
  { id: 'cadeaux', label: '🎁 Cadeaux, Librairie & Papeterie', category: 'Autre', desc: 'Articles scolaires, carterie, jouets, souvenirs' },
  { id: 'general', label: '🏬 Autre commerce de détail', category: 'Autre', desc: 'Commerce polyvalent et multi-articles' }
];

export const COUNTRY_OPTIONS = [
  { code: 'MA', label: 'Maroc 🇲🇦', defaultCurrency: 'DH', defaultPhonePrefix: '+212' },
  { code: 'FR', label: 'France 🇫🇷', defaultCurrency: '€', defaultPhonePrefix: '+33' },
  { code: 'DZ', label: 'Algérie 🇩🇿', defaultCurrency: 'DZD', defaultPhonePrefix: '+213' },
  { code: 'TN', label: 'Tunisie 🇹🇳', defaultCurrency: 'TND', defaultPhonePrefix: '+216' },
  { code: 'SN', label: 'Sénégal 🇸🇳', defaultCurrency: 'FCFA', defaultPhonePrefix: '+221' },
  { code: 'CI', label: "Côte d'Ivoire 🇨🇮", defaultCurrency: 'FCFA', defaultPhonePrefix: '+225' },
  { code: 'BE', label: 'Belgique 🇧🇪', defaultCurrency: '€', defaultPhonePrefix: '+32' },
  { code: 'CA', label: 'Canada 🇨🇦', defaultCurrency: '$', defaultPhonePrefix: '+1' },
  { code: 'OTHER', label: 'Autre pays 🌍', defaultCurrency: '€', defaultPhonePrefix: '' }
];

export const CURRENCY_OPTIONS = [
  { code: 'DH', label: 'Dirham Marocain (DH / MAD)' },
  { code: '€', label: 'Euro (€)' },
  { code: '$', label: 'US Dollar ($)' },
  { code: 'FCFA', label: 'Franc CFA (FCFA)' },
  { code: 'DZD', label: 'Dinar Algérien (DZD)' },
  { code: 'TND', label: 'Dinar Tunisien (TND)' },
  { code: '£', label: 'Livre Sterling (£)' }
];

export default function CreateShopModal({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onRefreshData,
  currentLang = 'fr'
}) {
  if (!isOpen) return null;

  const toast = useToast();
  const t = translations[currentLang] || translations.fr;

  const [shopName, setShopName] = useState(
    settings?.shopName && settings.shopName !== 'Boutique VenteFacile' ? settings.shopName : ''
  );
  const [businessType, setBusinessType] = useState(settings?.businessType || 'epicerie');
  const [phone, setPhone] = useState(settings?.phone || '');
  const [email, setEmail] = useState(settings?.email || '');
  const [street, setStreet] = useState(settings?.street || '');
  const [city, setCity] = useState(settings?.city || '');
  const [postalCode, setPostalCode] = useState(settings?.postalCode || '');
  const [country, setCountry] = useState(settings?.country || 'Maroc');
  const [currency, setCurrency] = useState(settings?.currency || 'DH');
  const [adminPin, setAdminPin] = useState('');
  const [confirmAdminPin, setConfirmAdminPin] = useState('');
  const [showAdminPin, setShowAdminPin] = useState(false);
  const [startClean, setStartClean] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  // Handle Country Quick Preset Change
  const handleCountryChange = (selectedCountryCode) => {
    const selected = COUNTRY_OPTIONS.find(c => c.code === selectedCountryCode);
    if (selected) {
      setCountry(selected.label.split(' ')[0]);
      if (selected.defaultCurrency) setCurrency(selected.defaultCurrency);
      if (selected.defaultPhonePrefix && !phone) {
        setPhone(selected.defaultPhonePrefix + ' ');
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!shopName.trim()) {
      setError(currentLang === 'ar' ? 'يرجى إدخال اسم متجرك.' : 'Veuillez renseigner le nom de votre boutique.');
      return;
    }

    if (!city.trim()) {
      setError(currentLang === 'ar' ? 'يرجى إدخال اسم المدينة.' : 'Veuillez renseigner la ville où se situe votre boutique.');
      return;
    }

    // Validation du Code PIN Administrateur (Initial ou modification)
    const isFirstSetup = !settings?.isStoreConfigured;
    if (isFirstSetup || adminPin.trim().length > 0) {
      if (!adminPin.trim()) {
        setError(currentLang === 'ar' 
          ? 'يرجى تعيين رمز PIN للمسؤول لحماية إعدادات المتجر والأرباح.' 
          : 'Veuillez définir un code PIN administrateur (4 à 8 chiffres) pour sécuriser l\'accès.');
        return;
      }
      if (!/^\d{4,8}$/.test(adminPin.trim())) {
        setError(currentLang === 'ar'
          ? 'يجب أن يتكون رمز PIN من 4 إلى 8 أرقام فقط.'
          : 'Le code PIN administrateur doit comporter entre 4 et 8 chiffres numériques uniquement.');
        return;
      }
      if (adminPin.trim() === '1234') {
        setError(currentLang === 'ar'
          ? 'لأسباب أمنية، يرجى اختيار رمز PIN مختلف عن الرمز الافتراضي (1234).'
          : 'Pour des raisons de sécurité, veuillez choisir un code PIN différent du code d\'usine par défaut (1234).');
        return;
      }
      if (adminPin.trim() !== confirmAdminPin.trim()) {
        setError(currentLang === 'ar'
          ? 'رمزا PIN غير متطابقين.'
          : 'Les deux codes PIN saisis ne correspondent pas.');
        return;
      }
    }

    setIsSubmitting(true);
    setError('');

    try {
      if (startClean) {
        await clearAllDemoData();
      }

      // Hachage cryptographique sécurisé avec sel unique (SHA-256)
      let newAdminHash = settings?.adminPinHash;
      let newAdminSalt = settings?.adminPinSalt;
      let updatedTeam = Array.isArray(settings?.team) ? [...settings.team] : [];

      if (adminPin.trim()) {
        newAdminSalt = generateSalt();
        newAdminHash = await hashPinWithSalt(adminPin.trim(), newAdminSalt);

        // Mettre à jour le membre Patron dans l'équipe
        let patronUpdated = false;
        updatedTeam = updatedTeam.map(member => {
          if (member.role === 'patron' || member.id === 'usr_patron_1') {
            patronUpdated = true;
            return {
              ...member,
              pinHash: newAdminHash,
              pinSalt: newAdminSalt
            };
          }
          return member;
        });

        // Si le patron n'existe pas encore dans team, le créer proprement
        if (!patronUpdated) {
          updatedTeam.unshift({
            id: 'usr_patron_1',
            name: 'Patron',
            role: 'patron',
            pinHash: newAdminHash,
            pinSalt: newAdminSalt,
            phone: phone.trim(),
            avatarColor: '#4f46e5',
            createdAt: new Date().toISOString(),
            permissions: {
              canManageCashiers: true,
              canManageProducts: true,
              canManageSuppliers: true,
              canViewProfits: true,
              canCloseCash: true
            }
          });
        }
      }

      // Build structured and formatted address for receipts/invoices
      const formattedAddressParts = [];
      if (street.trim()) formattedAddressParts.push(street.trim());
      const postalCity = [postalCode.trim(), city.trim()].filter(Boolean).join(' ');
      if (postalCity) formattedAddressParts.push(postalCity);
      if (country.trim()) formattedAddressParts.push(country.trim());
      const fullAddress = formattedAddressParts.join(', ');

      const updatedSettings = {
        ...settings,
        shopName: shopName.trim(),
        businessType: businessType,
        phone: phone.trim(),
        email: email.trim(),
        street: street.trim(),
        city: city.trim(),
        postalCode: postalCode.trim(),
        country: country.trim(),
        address: fullAddress,
        currency: currency,
        isStoreConfigured: true,
        securityEnabled: true,
        adminPinHash: newAdminHash || settings?.adminPinHash,
        adminPinSalt: newAdminSalt || settings?.adminPinSalt,
        team: updatedTeam
      };

      sessionStorage.setItem('onboarding_wizard_dismissed', '1');
      await db.settings.update(1, updatedSettings);
      if (onUpdateSettings) await onUpdateSettings(updatedSettings);
      if (onRefreshData) await onRefreshData();

      toast.success(
        `Votre boutique "${shopName.trim()}" et votre code PIN administrateur sont configurés avec succès !`, 
        "Boutique Prête"
      );
      onClose();
    } catch (err) {
      console.error(err);
      setError('Erreur lors de la configuration de la boutique : ' + err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-md animate-in fade-in overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-xl w-full shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        
        {/* Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 text-white relative shrink-0">
          <button
            onClick={() => {
              sessionStorage.setItem('onboarding_wizard_dismissed', '1');
              onClose();
            }}
            className="absolute top-5 right-5 p-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white transition"
            title="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center text-white shrink-0 shadow-inner">
              <Store className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-0.5">
                <h2 className="text-lg sm:text-xl font-black">
                  {!settings?.isStoreConfigured 
                    ? (currentLang === 'ar' ? 'مساعد الإعداد الأولي للمتجر' : 'Assistant de Configuration Initiale')
                    : (currentLang === 'ar' ? 'تعديل بيانات المتجر' : 'Coordonnées de votre Boutique')}
                </h2>
                {!settings?.isStoreConfigured && (
                  <span className="text-[10px] uppercase font-black tracking-wide px-2 py-0.5 rounded-full bg-amber-400 text-slate-900 shadow">
                    Onboarding
                  </span>
                )}
              </div>
              <p className="text-xs text-indigo-100">
                {!settings?.isStoreConfigured
                  ? (currentLang === 'ar'
                      ? 'أدخل بيانات متجرك ورمز PIN السري لتأمين الحساب والبدء بالبيع الحقيقي.'
                      : 'Définissez votre identité commerciale et votre code PIN Administrateur pour démarrer en toute sécurité.')
                  : (currentLang === 'ar' 
                      ? 'تعديل الإعدادات والبيانات الرسمية لمتجرك.' 
                      : 'Configurez les coordonnées officielles de votre commerce (Tickets, Factures & Caisse).')}
              </p>
            </div>
          </div>
        </div>

        {/* Form Body - Scrollable */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4 overflow-y-auto custom-scrollbar flex-1">
          {error && (
            <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 text-xs font-bold border border-rose-200 dark:border-rose-900 animate-in fade-in">
              ⚠️ {error}
            </div>
          )}

          {/* Section 1: Identification & Métier */}
          <div className="space-y-3 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <Store className="w-3.5 h-3.5 text-indigo-500" />
              <span>1. Identité & Secteur d'activité</span>
            </h3>

            {/* Shop Name */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center justify-between">
                <span>{currentLang === 'ar' ? 'اسم المتجر / المحل' : 'Nom de votre Boutique'} <strong className="text-rose-500">*</strong></span>
                <span className="text-[10px] text-slate-400 font-normal">Affiché sur les tickets & factures</span>
              </label>
              <input
                type="text"
                required
                autoFocus
                placeholder="Ex: Supermarché Al Baraka, Parfumerie Royale, TechStore..."
                value={shopName}
                onChange={(e) => setShopName(e.target.value)}
                className="w-full p-2.5 text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 font-bold text-slate-900 dark:text-white"
              />
            </div>

            {/* Business Type / Métier */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Briefcase className="w-3.5 h-3.5 text-indigo-500" />
                  <span>{currentLang === 'ar' ? 'نوع النشاط / المهنة' : 'Métier & Secteur du Commerce'} <strong className="text-rose-500">*</strong></span>
                </span>
                <span className="text-[10px] text-indigo-600 dark:text-indigo-400 font-semibold">Adapte la caisse & catégories</span>
              </label>
              <select
                value={businessType}
                onChange={(e) => setBusinessType(e.target.value)}
                className="w-full p-2.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 font-bold text-slate-900 dark:text-white"
              >
                {BUSINESS_TYPES.map(b => (
                  <option key={b.id} value={b.id}>
                    {b.label}
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 italic">
                💡 {BUSINESS_TYPES.find(b => b.id === businessType)?.desc}
              </p>
            </div>
          </div>

          {/* Section 2: Contact & Communication */}
          <div className="space-y-3 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-indigo-500" />
              <span>2. Contact & Facturation</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Phone */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-indigo-500" />
                  <span>{currentLang === 'ar' ? 'رقم الهاتف / الواتساب' : 'Téléphone / WhatsApp'}</span>
                </label>
                <input
                  type="tel"
                  placeholder="Ex: +212 6 12 34 56 78"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full p-2.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 font-mono text-slate-900 dark:text-white"
                />
              </div>

              {/* Email */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-indigo-500" />
                  <span>{currentLang === 'ar' ? 'البريد الإلكتروني' : 'Adresse E-mail'}</span>
                </label>
                <input
                  type="email"
                  placeholder="Ex: contact@maboutique.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full p-2.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 font-sans text-slate-900 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Localisation Détaillée */}
          <div className="space-y-3 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-indigo-500" />
              <span>3. Adresse & Localisation</span>
            </h3>

            {/* Street / Rue */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Navigation className="w-3.5 h-3.5 text-indigo-500" />
                <span>{currentLang === 'ar' ? 'العنوان / الشارع والحي' : 'Adresse, Rue & Quartier'}</span>
              </label>
              <input
                type="text"
                placeholder="Ex: 15 Boulevard Mohammed V, Quartier Hassan"
                value={street}
                onChange={(e) => setStreet(e.target.value)}
                className="w-full p-2.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white"
              />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {/* Ville */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Building2 className="w-3 h-3 text-indigo-500" />
                  <span>{currentLang === 'ar' ? 'المدينة' : 'Ville'} <strong className="text-rose-500">*</strong></span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Casablanca, Paris..."
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full p-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 font-bold text-slate-900 dark:text-white"
                />
              </div>

              {/* Code Postal */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  <span>{currentLang === 'ar' ? 'الرمز البريدي' : 'Code Postal'}</span>
                </label>
                <input
                  type="text"
                  placeholder="Ex: 20000"
                  value={postalCode}
                  onChange={(e) => setPostalCode(e.target.value)}
                  className="w-full p-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 font-mono text-slate-900 dark:text-white"
                />
              </div>

              {/* Pays & Devise */}
              <div className="space-y-1 col-span-2 sm:col-span-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Globe2 className="w-3 h-3 text-indigo-500" />
                  <span>{currentLang === 'ar' ? 'البلد' : 'Pays'}</span>
                </label>
                <select
                  value={country}
                  onChange={(e) => {
                    setCountry(e.target.value);
                    const opt = COUNTRY_OPTIONS.find(c => c.label.startsWith(e.target.value));
                    if (opt) handleCountryChange(opt.code);
                  }}
                  className="w-full p-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white"
                >
                  <option value="Maroc">Maroc 🇲🇦</option>
                  <option value="France">France 🇫🇷</option>
                  <option value="Algérie">Algérie 🇩🇿</option>
                  <option value="Tunisie">Tunisie 🇹🇳</option>
                  <option value="Sénégal">Sénégal 🇸🇳</option>
                  <option value="Côte d'Ivoire">Côte d'Ivoire 🇨🇮</option>
                  <option value="Belgique">Belgique 🇧🇪</option>
                  <option value="Canada">Canada 🇨🇦</option>
                  <option value="Autre">Autre 🌍</option>
                </select>
              </div>
            </div>

            {/* Currency selector */}
            <div className="space-y-1 pt-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <DollarSign className="w-3.5 h-3.5 text-indigo-500" />
                  <span>{currentLang === 'ar' ? 'العملة الأساسية' : 'Devise Principale du Magasin'}</span>
                </span>
              </label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full p-2.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 font-bold text-slate-900 dark:text-white"
              >
                {CURRENCY_OPTIONS.map(c => (
                  <option key={c.code} value={c.code}>{c.label}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Section 4: Sécurité & Code PIN Administrateur */}
          <div className="space-y-3 bg-gradient-to-br from-amber-500/10 via-indigo-500/10 to-purple-500/10 dark:from-amber-950/30 dark:via-indigo-950/30 dark:to-purple-950/30 p-4 rounded-2xl border border-indigo-200/80 dark:border-indigo-800/80">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-indigo-700 dark:text-indigo-300 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                <span>4. Sécurité d'Accès & Code PIN Gérant / Patron</span>
              </h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-700">
                🔒 Requis
              </span>
            </div>

            <p className="text-[11px] text-slate-600 dark:text-slate-300">
              {currentLang === 'ar'
                ? 'استبدل رمز المصنع المؤقت (1234) برمز PIN السري الخاص بك (4 إلى 8 أرقام). يحمي هذا الرمز تقارير الإغلاق، الأرباح، والإعدادات.'
                : 'Remplacez le code d\'usine temporaire (1234) par votre code secret personnel (4 à 8 chiffres). Ce PIN protège les clôtures de caisse, les bénéfices et la configuration.'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              {/* Nouveau PIN */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <Key className="w-3 h-3 text-indigo-500" />
                    <span>Nouveau Code PIN Gérant <strong className="text-rose-500">*</strong></span>
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowAdminPin(!showAdminPin)}
                    className="text-[11px] text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    {showAdminPin ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    <span>{showAdminPin ? 'Masquer' : 'Afficher'}</span>
                  </button>
                </label>
                <input
                  type={showAdminPin ? "text" : "password"}
                  inputMode="numeric"
                  maxLength={8}
                  required={!settings?.isStoreConfigured}
                  placeholder="Ex: 5829 (4 à 8 chiffres)"
                  value={adminPin}
                  onChange={(e) => setAdminPin(e.target.value.replace(/\D/g, ''))}
                  className="w-full p-2.5 text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 font-mono tracking-widest text-slate-900 dark:text-white"
                />
              </div>

              {/* Confirmation PIN */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-500" />
                  <span>Confirmer le Code PIN <strong className="text-rose-500">*</strong></span>
                </label>
                <input
                  type={showAdminPin ? "text" : "password"}
                  inputMode="numeric"
                  maxLength={8}
                  required={!settings?.isStoreConfigured}
                  placeholder="Répétez le code PIN"
                  value={confirmAdminPin}
                  onChange={(e) => setConfirmAdminPin(e.target.value.replace(/\D/g, ''))}
                  className="w-full p-2.5 text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 font-mono tracking-widest text-slate-900 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* Clean start option */}
          <div className="p-3.5 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/60">
            <label className="flex items-start gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={startClean}
                onChange={(e) => setStartClean(e.target.checked)}
                className="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500"
              />
              <div className="text-xs">
                <span className="font-extrabold text-indigo-900 dark:text-indigo-200 block">
                  {currentLang === 'ar' ? 'بدء بمتجر نظيف 100% (تفريغ أي بيانات تجريبية)' : 'Démarrer avec une base 100% propre (Recommandé)'}
                </span>
                <span className="text-slate-500 dark:text-slate-400 text-[11px] block mt-0.5">
                  {currentLang === 'ar' 
                    ? 'يحذف الأمثلة التجريبية لتبدأ فوراً بإدخال بضائعك الحقيقية.' 
                    : 'Efface les articles et clients de test pour démarrer votre comptabilité à zéro avec vos vrais produits.'}
                </span>
              </div>
            </label>
          </div>

          {/* Security explanation */}
          <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 px-1">
            <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>
              {currentLang === 'ar'
                ? 'بعد التفعيل، سيتم إخفاء أزرار التجربة عن كل الهواتف ومستخدمي الكاشير للحفاظ على أمان متجرك.'
                : 'Une fois activée, les boutons de démo seront invisibles sur tous les téléphones et caissiers.'}
            </span>
          </div>

          {/* Buttons */}
          <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-100 dark:border-slate-800 shrink-0">
            <button
              type="button"
              onClick={() => {
                sessionStorage.setItem('onboarding_wizard_dismissed', '1');
                onClose();
              }}
              className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            >
              {!settings?.isStoreConfigured
                ? (currentLang === 'ar' ? 'استكشاف كعرض تجريبي أولاً' : 'Découvrir d\'abord en Démo')
                : t.annuler}
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-95 text-white font-extrabold text-xs shadow-md shadow-indigo-500/25 transition active:scale-95 disabled:opacity-50 flex items-center gap-2 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>
                {isSubmitting
                  ? 'Configuration en cours...'
                  : !settings?.isStoreConfigured
                    ? (currentLang === 'ar' ? 'تفعيل المتجر وحفظ PIN ✅' : 'Activer ma Boutique & Sécuriser le PIN 🚀')
                    : (currentLang === 'ar' ? 'حفظ التعديلات' : 'Enregistrer les modifications ✅')}
              </span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
}
