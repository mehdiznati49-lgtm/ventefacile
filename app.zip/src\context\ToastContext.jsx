import React, { createContext, useContext, useState, useCallback, useRef, useEffect } from 'react';
import { 
  CheckCircle2, 
  AlertCircle, 
  AlertTriangle, 
  Info, 
  X,
  HelpCircle,
  Trash2,
  Check
} from 'lucide-react';

const ToastContext = createContext(null);

// Global references for calls outside React tree
let globalToastHandler = null;
let globalConfirmHandler = null;

export const showGlobalToast = (options) => {
  if (globalToastHandler) {
    return globalToastHandler(options);
  } else {
    console.log('[Toast Global]', options);
  }
};

export const showGlobalConfirm = (options) => {
  if (globalConfirmHandler) {
    return globalConfirmHandler(options);
  }
  return Promise.resolve(window.confirm(options.message || options.title || 'Confirmer ?'));
};

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const [confirmDialog, setConfirmDialog] = useState(null);
  const timersRef = useRef(new Map());

  const removeToast = useCallback((id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
    if (timersRef.current.has(id)) {
      clearTimeout(timersRef.current.get(id));
      timersRef.current.delete(id);
    }
  }, []);

  const addToast = useCallback(({ 
    type = 'info', 
    title = '', 
    message = '', 
    duration = 4200 
  }) => {
    const id = Date.now().toString(36) + Math.random().toString(36).substr(2, 5);

    // Auto default clean titles if omitted
    const defaultTitles = {
      success: 'Opération réussie',
      error: 'Erreur',
      warning: 'Attention',
      info: 'Information'
    };
    const finalTitle = title || defaultTitles[type] || 'Notification';

    const newToast = {
      id,
      type, // 'success' | 'error' | 'warning' | 'info'
      title: finalTitle,
      message,
      duration,
      createdAt: Date.now()
    };

    setToasts((prev) => [newToast, ...prev.slice(0, 4)]); // Limit to 5 max

    if (duration > 0) {
      const timer = setTimeout(() => {
        removeToast(id);
      }, duration);
      timersRef.current.set(id, timer);
    }

    return id;
  }, [removeToast]);

  // Connect singleton
  globalToastHandler = addToast;

  // Specific helper methods
  const success = useCallback((message, title, duration) => 
    addToast({ type: 'success', message, title, duration }), [addToast]);

  const error = useCallback((message, title, duration) => 
    addToast({ type: 'error', message, title, duration }), [addToast]);

  const warning = useCallback((message, title, duration) => 
    addToast({ type: 'warning', message, title, duration }), [addToast]);

  const info = useCallback((message, title, duration) => 
    addToast({ type: 'info', message, title, duration }), [addToast]);

  const clear = useCallback(() => {
    timersRef.current.forEach((timer) => clearTimeout(timer));
    timersRef.current.clear();
    setToasts([]);
  }, []);

  // Promise-based modern confirmation modal
  const confirm = useCallback(({
    title = 'Confirmation',
    message = 'Êtes-vous sûr de vouloir effectuer cette action ?',
    confirmText = 'Confirmer',
    cancelText = 'Annuler',
    variant = 'danger' // 'danger' | 'primary'
  }) => {
    return new Promise((resolve) => {
      setConfirmDialog({
        title,
        message,
        confirmText,
        cancelText,
        variant,
        onConfirm: () => {
          setConfirmDialog(null);
          resolve(true);
        },
        onCancel: () => {
          setConfirmDialog(null);
          resolve(false);
        }
      });
    });
  }, []);

  globalConfirmHandler = confirm;

  // Intercept window.alert dynamically to kill old-style browser popups across the entire app
  useEffect(() => {
    const originalAlert = window.alert;

    window.alert = (rawMsg) => {
      if (!rawMsg) return;
      const str = String(rawMsg);

      let detectedType = 'info';
      let title = 'Information';

      if (str.includes('✅') || str.includes('🎉') || str.includes('✨') || str.toLowerCase().includes('succès') || str.toLowerCase().includes('réussi')) {
        detectedType = 'success';
        title = 'Succès';
      } else if (str.includes('❌') || str.toLowerCase().includes('erreur') || str.toLowerCase().includes('échec')) {
        detectedType = 'error';
        title = 'Erreur';
      } else if (str.includes('⚠️') || str.toLowerCase().includes('attention')) {
        detectedType = 'warning';
        title = 'Attention';
      }

      // Clean leading emojis and format cleanly
      const cleanMessage = str.replace(/^[✅🎉✨❌⚠️ℹ️📦💸🔒🧹]\s*/, '').trim();

      addToast({
        type: detectedType,
        title,
        message: cleanMessage,
        duration: 4500
      });
    };

    // Global helper access
    window.toast = {
      show: addToast,
      success,
      error,
      warning,
      info,
      clear
    };
    window.confirmModal = confirm;

    return () => {
      window.alert = originalAlert;
    };
  }, [addToast, success, error, warning, info, clear, confirm]);

  const toastMethods = {
    show: addToast,
    success,
    error,
    warning,
    info,
    confirm,
    remove: removeToast,
    clear
  };

  return (
    <ToastContext.Provider value={toastMethods}>
      {children}

      {/* Floating Island Notifications Container (Centered at top with subtle blur & spring motion) */}
      <div 
        aria-live="polite"
        className="fixed top-5 left-1/2 -translate-x-1/2 z-[9999] flex flex-col items-center gap-2.5 max-w-md w-full px-4 pointer-events-none"
      >
        {toasts.map((t) => (
          <ToastCard 
            key={t.id} 
            toast={t} 
            onClose={() => removeToast(t.id)} 
          />
        ))}
      </div>

      {/* Modern High-End Confirmation Modal (Stripe / Apple Glassmorphic Style) */}
      {confirmDialog && (
        <ConfirmModalDialog dialog={confirmDialog} />
      )}
    </ToastContext.Provider>
  );
}

// Ultra-Modern Glassmorphism Toast Card (Linear / Apple / Stripe style)
function ToastCard({ toast, onClose }) {
  const { type, title, message, duration } = toast;

  const config = {
    success: {
      border: 'border-emerald-500/30 dark:border-emerald-500/40',
      bg: 'bg-white/95 dark:bg-slate-900/95 shadow-2xl shadow-emerald-950/20',
      badge: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300',
      progressBg: 'bg-emerald-500',
      icon: <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
    },
    error: {
      border: 'border-rose-500/30 dark:border-rose-500/40',
      bg: 'bg-white/95 dark:bg-slate-900/95 shadow-2xl shadow-rose-950/20',
      badge: 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300',
      progressBg: 'bg-rose-500',
      icon: <AlertCircle className="w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0" />
    },
    warning: {
      border: 'border-amber-500/30 dark:border-amber-500/40',
      bg: 'bg-white/95 dark:bg-slate-900/95 shadow-2xl shadow-amber-950/20',
      badge: 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300',
      progressBg: 'bg-amber-500',
      icon: <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" />
    },
    info: {
      border: 'border-indigo-500/30 dark:border-indigo-500/40',
      bg: 'bg-white/95 dark:bg-slate-900/95 shadow-2xl shadow-indigo-950/20',
      badge: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300',
      progressBg: 'bg-indigo-500',
      icon: <Info className="w-5 h-5 text-indigo-600 dark:text-indigo-400 shrink-0" />
    }
  };

  const style = config[type] || config.info;

  return (
    <div 
      className={`pointer-events-auto w-full relative overflow-hidden flex items-start gap-3.5 p-4 rounded-2xl backdrop-blur-xl border ${style.border} ${style.bg} transition-all duration-200 transform translate-y-0 opacity-100 animate-in fade-in slide-in-from-top-4`}
      role="alert"
    >
      <div className="mt-0.5">
        {style.icon}
      </div>
      
      <div className="flex-1 min-w-0 pr-1">
        {title && (
          <h4 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white tracking-tight mb-0.5">
            {title}
          </h4>
        )}
        <p className="text-xs font-medium text-slate-600 dark:text-slate-300 leading-relaxed break-words whitespace-pre-line">
          {message}
        </p>
      </div>

      <button
        onClick={onClose}
        className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 p-1 rounded-xl transition-colors shrink-0"
        title="Fermer"
        aria-label="Fermer"
      >
        <X className="w-4 h-4" />
      </button>

      {/* Subtle Countdown Progress bar */}
      {duration > 0 && (
        <div 
          className={`absolute bottom-0 left-0 right-0 h-1 opacity-70 ${style.progressBg}`}
          style={{
            animation: `toastProgress ${duration}ms linear forwards`
          }}
        />
      )}
    </div>
  );
}

// Modern Confirmation Modal Dialog
function ConfirmModalDialog({ dialog }) {
  const { title, message, confirmText, cancelText, variant, onConfirm, onCancel } = dialog;
  const isDanger = variant === 'danger';

  return (
    <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-sm w-full p-6 shadow-2xl animate-in zoom-in-95 duration-150">
        
        <div className="flex items-center gap-3.5 mb-3">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 ${
            isDanger 
              ? 'bg-rose-100 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400' 
              : 'bg-indigo-100 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400'
          }`}>
            {isDanger ? <Trash2 className="w-6 h-6" /> : <HelpCircle className="w-6 h-6" />}
          </div>
          <div>
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white leading-tight">
              {title}
            </h3>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Confirmation requise
            </span>
          </div>
        </div>

        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-6 whitespace-pre-line">
          {message}
        </p>

        <div className="flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            {cancelText}
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className={`px-4 py-2 rounded-xl text-xs font-bold text-white shadow-sm transition active:scale-95 ${
              isDanger
                ? 'bg-rose-600 hover:bg-rose-700 shadow-rose-600/20'
                : 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-600/20'
            }`}
          >
            {confirmText}
          </button>
        </div>

      </div>
    </div>
  );
}

export function useToast() {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return context;
}
