import React, { useState } from 'react';
import { 
  Users, 
  UserPlus, 
  ShieldAlert, 
  Send, 
  Plus, 
  Edit3, 
  Trash2, 
  Gift, 
  CheckCircle2, 
  DollarSign,
  Search,
  UserCheck,
  Sparkles,
  Printer,
  History,
  Receipt,
  CreditCard,
  Banknote,
  Coins,
  X,
  ArrowDownRight,
  Check
} from 'lucide-react';
import { translations } from '../translations';
import { db, loadClientDemoData, clearClientData } from '../db';
import { parseSafeFloat, sanitizeDecimalInput } from '../utils/numberUtils';
import { getLocalDateCompact } from '../utils/dateUtils';
import { triggerOpenCashDrawer, triggerPrintWithLayout } from '../thermalPrinter';
import { useToast } from '../context/ToastContext';

export default function ClientsView({ 
  clients, 
  settings, 
  currentLang, 
  onRefreshData,
  isAdmin = true
}) {
  const toast = useToast();
  const t = translations[currentLang] || translations.fr;
  const currency = settings.currency || '€';
  const isStoreConfigured = Boolean(settings?.isStoreConfigured);

  const [searchFilter, setSearchFilter] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingClient, setEditingClient] = useState(null);
  
  // Partial Payment Modal State
  const [payDebtClient, setPayDebtClient] = useState(null);
  const [payAmount, setPayAmount] = useState('');
  const [payMethod, setPayMethod] = useState('especes'); // especes, carte, virement, cheque
  const [payNote, setPayNote] = useState('');

  // Payment Receipt Modal State
  const [completedPaymentReceipt, setCompletedPaymentReceipt] = useState(null);

  // Client Payment History Modal State
  const [historyClient, setHistoryClient] = useState(null);
  const [clientPayments, setClientPayments] = useState([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    maxDebt: 300,
    debt: 0,
    points: 0
  });

  const handleSaveClient = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.name.trim()) {
      toast.error('Le nom du client est obligatoire.', 'Fiche Client');
      return;
    }

    const parsedMaxDebt = parseSafeFloat(formData.maxDebt, 300);
    if (isNaN(parsedMaxDebt) || parsedMaxDebt < 0) {
      toast.error('Le plafond de crédit autorisé doit être supérieur ou égal à 0.', 'Validation');
      return;
    }

    const payload = {
      name: formData.name.trim(),
      phone: formData.phone.trim(),
      email: formData.email.trim(),
      maxDebt: parsedMaxDebt || 300,
      debt: parseSafeFloat(formData.debt, 0),
      points: parseInt(formData.points) || 0
    };

    if (editingClient) {
      await db.clients.update(editingClient.id, payload);
      toast.success(`Client "${payload.name}" mis à jour avec succès.`, 'Fiche Client');
    } else {
      await db.clients.add(payload);
      toast.success(`Client "${payload.name}" créé avec succès.`, 'Fiche Client');
    }

    setShowAddModal(false);
    setEditingClient(null);
    setFormData({ name: '', phone: '', email: '', maxDebt: 300, debt: 0, points: 0 });
    if (onRefreshData) onRefreshData();
  };

  const handleDeleteClient = async (id) => {
    const c = clients.find(cl => cl.id === id);
    if (!c) return;

    const currentDebt = parseSafeFloat(c.debt, 0);
    if (currentDebt > 0) {
      toast.error(
        `Action impossible : Le client "${c.name}" a une dette en cours de ${currentDebt.toFixed(2)} ${currency}. Vous devez obligatoirement régulariser son compte avant de pouvoir supprimer sa fiche.`,
        "Créance Impayée"
      );
      return;
    }

    const ok = await toast.confirm({
      title: "Supprimer le client",
      message: `Supprimer la fiche client de "${c.name}" ?`,
      confirmText: "Supprimer",
      variant: "danger"
    });
    if (!ok) return;

    await db.clients.delete(id);
    if (onRefreshData) onRefreshData();
    toast.info(`Client "${c.name}" supprimé.`, 'Clients');
  };

  const handleLoadDemoClients = async () => {
    try {
      await loadClientDemoData();
      if (onRefreshData) await onRefreshData();
      toast.success("Clients d'exemple chargés avec succès !");
    } catch (err) {
      console.error(err);
      toast.error("Erreur lors du chargement des clients : " + err.message);
    }
  };

  const handleClearDemoClients = async () => {
    const ok = await toast.confirm({
      title: "Vider le carnet clients d'exemples",
      message: "Voulez-vous supprimer les exemples de clients et vider le carnet ?",
      confirmText: "Vider les exemples",
      variant: "danger"
    });
    if (!ok) return;

    try {
      await clearClientData();
      if (onRefreshData) await onRefreshData();
      toast.info("Carnet clients vidé avec succès.");
    } catch (err) {
      console.error(err);
      toast.error("Erreur lors de la suppression : " + err.message);
    }
  };

  const handleConfirmPayDebt = async (e) => {
    e.preventDefault();
    const paidVal = parseSafeFloat(payAmount, 0);
    if (!paidVal || isNaN(paidVal) || paidVal <= 0 || !payDebtClient) {
      toast.error('Veuillez saisir un montant de versement valide supérieur à 0.', 'Règlement dette');
      return;
    }

    const previousDebt = Number(payDebtClient.debt || 0);
    const newDebt = Math.max(0, previousDebt - paidVal);
    const roundedNewDebt = Math.round(newDebt * 100) / 100;

    await db.clients.update(payDebtClient.id, { debt: roundedNewDebt });

    const datePart = getLocalDateCompact();
    const receiptNo = `REC-${datePart}-${Date.now().toString().slice(-4)}`;

    const paymentRecord = {
      receiptNo,
      timestamp: new Date().toISOString(),
      clientId: payDebtClient.id,
      clientName: payDebtClient.name,
      clientPhone: payDebtClient.phone || '',
      type: 'debt_settlement',
      amount: paidVal,
      previousDebt: previousDebt,
      remainingDebt: roundedNewDebt,
      paymentMethod: payMethod,
      note: payNote.trim()
    };

    const newId = await db.payments.add(paymentRecord);
    paymentRecord.id = newId;

    if (payMethod === 'especes') {
      try {
        await triggerOpenCashDrawer();
      } catch (err) {
        console.warn('Could not pulse cash drawer', err);
      }
    }

    toast.success(
      `Versement de ${paidVal.toFixed(2)} ${currency} encaissé dans le tiroir-caisse pour ${payDebtClient.name}. Nouveau solde : ${roundedNewDebt.toFixed(2)} ${currency}.`,
      'Règlement Encaissé'
    );

    setCompletedPaymentReceipt(paymentRecord);
    setPayDebtClient(null);
    setPayAmount('');
    setPayNote('');
    if (onRefreshData) onRefreshData();
  };

  const handleOpenHistory = async (client) => {
    setHistoryClient(client);
    setIsLoadingHistory(true);
    try {
      const allPayments = await db.payments.toArray();
      const clientRecords = allPayments
        .filter(p => p.clientId === client.id)
        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      setClientPayments(clientRecords);
    } catch (e) {
      console.error('Erreur chargement historique paiements:', e);
      setClientPayments([]);
    } finally {
      setIsLoadingHistory(false);
    }
  };

  const handleSendPaymentReceiptWhatsApp = (receipt) => {
    const phone = receipt.clientPhone ? receipt.clientPhone.replace(/\s+/g, '') : '';
    const message = `*REÇU DE RÈGLEMENT CLIENT - ${settings.shopName || 'VenteFacile'}*\n` +
      `--------------------------------\n` +
      `*Reçu N°:* ${receipt.receiptNo}\n` +
      `*Client:* ${receipt.clientName}\n` +
      `*Date:* ${new Date(receipt.timestamp).toLocaleString('fr-FR')}\n` +
      `--------------------------------\n` +
      `*Dette Initiale:* ${(receipt.previousDebt || 0).toFixed(2)} ${currency}\n` +
      `*Montant Versé:* ${receipt.amount.toFixed(2)} ${currency}\n` +
      `*Mode de Règlement:* ${receipt.paymentMethod.toUpperCase()}${receipt.note ? ` (${receipt.note})` : ''}\n` +
      `--------------------------------\n` +
      `*NOUVEAU RESTE DÛ:* ${Number(receipt.remainingDebt || 0).toFixed(2)} ${currency}\n` +
      `--------------------------------\n` +
      `Merci pour votre règlement ! 🌸`;

    const url = phone ? `https://wa.me/${phone}?text=${encodeURIComponent(message)}` : `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const handleSendWhatsAppReminder = (client) => {
    const phone = client.phone ? client.phone.replace(/\s+/g, '') : '';
    const message = `Bonjour ${client.name},\n` +
      `Nous vous contactons concernant votre solde débiteur de *${Number(client.debt || 0).toFixed(2)} ${currency}* chez ${settings.shopName || 'notre boutique'}.\n` +
      `Merci de passer à la caisse pour le règlement dès que possible. Merci ! 🌸`;

    const url = phone ? `https://wa.me/${phone}?text=${encodeURIComponent(message)}` : `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const filteredClients = clients.filter(c => 
    (c.name && c.name.toLowerCase().includes(searchFilter.toLowerCase())) ||
    String(c.phone || '').includes(searchFilter)
  );

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 space-y-6 pb-36 sm:pb-16">
      
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-indigo-100 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-300 rounded-2xl">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 dark:text-white font-display">
              {t.gestionClients}
            </h2>
            <p className="text-xs text-slate-500">
              {t.gestionClientsDesc}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {!isStoreConfigured && isAdmin && (
            clients.length === 0 ? (
              <button
                onClick={handleLoadDemoClients}
                className="px-3.5 py-2.5 bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 hover:bg-amber-100 rounded-2xl text-xs font-bold transition flex items-center gap-1.5 border border-amber-300/50"
                title="Charger des clients d'exemple"
              >
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>🌟 Charger Clients Exemple</span>
              </button>
            ) : (
              <button
                onClick={handleClearDemoClients}
                className="px-3.5 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/40 dark:hover:text-red-400 text-slate-600 dark:text-slate-300 rounded-2xl text-xs font-bold transition flex items-center gap-1.5 border border-slate-200 dark:border-slate-700"
                title="Supprimer les exemples de clients"
              >
                <Trash2 className="w-3.5 h-3.5 text-red-500" />
                <span>🧹 Supprimer les exemples</span>
              </button>
            )
          )}

          <button
            onClick={() => {
              setEditingClient(null);
              setFormData({ name: '', phone: '', email: '', maxDebt: 300, debt: 0, points: 0 });
              setShowAddModal(true);
            }}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl text-xs font-extrabold shadow-md flex items-center gap-2 transition"
          >
            <UserPlus className="w-4 h-4" />
            <span>{t.ajouterClient}</span>
          </button>
        </div>
      </div>

      {/* Search & Stats Bar */}
      <div className="flex items-center justify-between gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            placeholder={t.rechercherClient}
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl"
          />
        </div>
      </div>

      {/* Clients Cards Grid */}
      {filteredClients.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-dashed border-slate-300 dark:border-slate-800 text-slate-400 text-xs space-y-4">
          <div className="w-16 h-16 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 rounded-2xl flex items-center justify-center mx-auto text-2xl">
            <Users className="w-8 h-8" />
          </div>
          <div>
            <h4 className="font-extrabold text-base text-slate-800 dark:text-slate-200">
              {searchFilter ? t.aucunClientTrouve : 'Votre carnet de clients est actuellement vide'}
            </h4>
            <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
              {searchFilter 
                ? 'Essayez avec un autre nom ou numéro.'
                : !isStoreConfigured
                  ? 'Vous pouvez charger des clients d\'exemple (avec carnet d\'adresses, points fidélité et crédits) ou ajouter directement vos vrais clients.'
                  : 'Votre carnet de clients est 100% prêt. Cliquez ci-dessous pour ajouter votre premier client.'}
            </p>
          </div>
          {!searchFilter && (
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              {!isStoreConfigured && isAdmin && (
                <button
                  onClick={handleLoadDemoClients}
                  className="py-2.5 px-5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-95 text-white rounded-xl text-xs font-extrabold shadow-md shadow-indigo-500/20 transition active:scale-95 flex items-center gap-1.5"
                >
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>🌟 Charger Clients Exemple</span>
                </button>
              )}
              <button
                onClick={() => {
                  setEditingClient(null);
                  setFormData({ name: '', phone: '', email: '', maxDebt: 300, debt: 0, points: 0 });
                  setShowAddModal(true);
                }}
                className="py-2.5 px-5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-extrabold shadow-sm transition active:scale-95 flex items-center gap-1.5"
              >
                <UserPlus className="w-4 h-4" />
                <span>+ Ajouter un Client Réel</span>
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredClients.map(client => (
            <div 
              key={client.id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-3 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                      {client.name}
                    </h3>
                    <span className="text-xs text-slate-500 block">{client.phone || t.pasDeTelephone}</span>
                  </div>
                  {client.debt > 0 && (
                    <span className={`px-2.5 py-1 rounded-xl text-xs font-bold border ${
                      client.debt > (client.maxDebt || 300)
                        ? 'bg-red-100 text-red-700 border-red-300 dark:bg-red-950 dark:text-red-300'
                        : 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-950 dark:text-amber-300'
                    }`}>
                      {t.dette} : {client.debt.toFixed(2)} {currency}
                    </span>
                  )}
                </div>

                <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2 bg-slate-50 dark:bg-slate-800/60 rounded-xl">
                    <span className="text-[10px] text-slate-400 block font-semibold">{t.plafondCredit}</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{client.maxDebt || 300} {currency}</span>
                  </div>
                  <div className="p-2 bg-emerald-50/60 dark:bg-emerald-950/40 rounded-xl">
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400 block font-semibold">{t.pointsFidelite}</span>
                    <span className="font-extrabold text-emerald-700 dark:text-emerald-300 flex items-center gap-1">
                      <Gift className="w-3.5 h-3.5" /> {client.points || 0} pts
                    </span>
                  </div>
                </div>
              </div>

              {/* Actions Bar with Partial Payment & History */}
              <div className="pt-2 flex flex-col gap-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                {client.debt > 0 ? (
                  <div className="flex flex-col gap-1.5 w-full">
                    <div className="flex gap-1.5 w-full">
                      <button
                        onClick={() => {
                          setPayDebtClient(client);
                          setPayAmount(client.debt.toString());
                          setPayMethod('especes');
                          setPayNote('');
                        }}
                        className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl flex items-center justify-center gap-1.5 shadow-sm active:scale-95 transition"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>Versement / Régler</span>
                      </button>
                      <button
                        onClick={() => handleSendWhatsAppReminder(client)}
                        className="py-2 px-3 bg-green-500 hover:bg-green-600 text-white rounded-xl font-bold flex items-center gap-1 active:scale-95 transition"
                        title={t.relancer}
                      >
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex justify-between items-center pt-1 border-t border-slate-100 dark:border-slate-800">
                      <button
                        type="button"
                        onClick={() => handleOpenHistory(client)}
                        className="text-[11px] font-bold text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 flex items-center gap-1 transition"
                      >
                        <History className="w-3.5 h-3.5 text-indigo-500" />
                        <span>Historique Règlements</span>
                      </button>
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            setEditingClient(client);
                            setFormData({
                              name: client.name,
                              phone: client.phone || '',
                              email: client.email || '',
                              maxDebt: client.maxDebt || 300,
                              debt: client.debt || 0,
                              points: client.points || 0
                            });
                            setShowAddModal(true);
                          }}
                          className="text-[11px] text-indigo-600 hover:underline font-semibold"
                        >
                          Modifier
                        </button>
                        <button
                          onClick={() => handleDeleteClient(client.id)}
                          className="text-[11px] text-red-500 hover:underline font-semibold"
                        >
                          Supprimer
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-between w-full">
                    <button
                      type="button"
                      onClick={() => handleOpenHistory(client)}
                      className="text-[11px] font-bold text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 flex items-center gap-1 transition"
                    >
                      <History className="w-3.5 h-3.5 text-indigo-500" />
                      <span>Historique Règlements</span>
                    </button>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setEditingClient(client);
                          setFormData({
                            name: client.name,
                            phone: client.phone || '',
                            email: client.email || '',
                            maxDebt: client.maxDebt || 300,
                            debt: client.debt || 0,
                            points: client.points || 0
                          });
                          setShowAddModal(true);
                        }}
                        className="px-2.5 py-1 text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950 rounded-lg font-semibold flex items-center gap-1"
                      >
                        <Edit3 className="w-3.5 h-3.5" /> Modifier
                      </button>
                      <button
                        onClick={() => handleDeleteClient(client.id)}
                        className="p-1 text-red-500 hover:bg-red-50 dark:hover:bg-red-950 rounded-lg"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                )}
              </div>

            </div>
          ))}
        </div>
      )}

      {/* Add / Edit Client Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-md w-full border border-slate-200 dark:border-slate-800 shadow-2xl">
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white mb-4">
              {editingClient ? `✏️ ${t.modifierClient}` : `➕ ${t.nouveauClient}`}
            </h3>

            <form onSubmit={handleSaveClient} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">{t.nomClient} *</label>
                <input
                  type="text"
                  required
                  placeholder="ex: Karim Mansouri"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">{t.telephoneWhatsApp} *</label>
                <input
                  type="text"
                  required
                  placeholder="ex: +33 6 12 34 56 78"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">{t.plafondCredit} ({currency})</label>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={formData.maxDebt}
                    onChange={(e) => setFormData({ ...formData, maxDebt: sanitizeDecimalInput(e.target.value) })}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">{t.detteInitiale} ({currency})</label>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={formData.debt}
                    onChange={(e) => setFormData({ ...formData, debt: sanitizeDecimalInput(e.target.value) })}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold text-amber-600"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 text-xs font-semibold rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200"
                >
                  {t.annuler}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 text-xs font-extrabold rounded-xl bg-indigo-600 text-white shadow-md hover:bg-indigo-700"
                >
                  {t.enregistrer}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* STEP 1: MODAL VERSEMENT PARTIEL AVEC RECALCUL DU RESTE DÛ */}
      {payDebtClient && (() => {
        const currentDebt = Number(payDebtClient.debt || 0);
        const enteredVal = parseSafeFloat(payAmount, 0);
        const remainingVal = Math.max(0, currentDebt - enteredVal);

        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-3 sm:p-4 animate-in fade-in duration-150">
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 max-w-md w-full border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
              
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 rounded-2xl">
                    <Coins className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                      Règlement / Versement Client
                    </h3>
                    <p className="text-xs text-slate-500">{payDebtClient.name}</p>
                  </div>
                </div>
                <button
                  onClick={() => setPayDebtClient(null)}
                  className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Debt Summary Banner */}
              <div className="p-3.5 bg-amber-50/70 dark:bg-amber-950/40 rounded-2xl border border-amber-200/80 dark:border-amber-900/60 text-xs flex justify-between items-center">
                <span className="font-bold text-amber-900 dark:text-amber-200">Dette Actuelle du Client :</span>
                <span className="font-extrabold text-base text-amber-700 dark:text-amber-300">
                  {currentDebt.toFixed(2)} {currency}
                </span>
              </div>

              <form onSubmit={handleConfirmPayDebt} className="space-y-4 text-xs">
                
                {/* Amount Input with Live Remaining Balance */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="font-bold text-slate-700 dark:text-slate-300">
                      Montant du Versement ({currency}) :
                    </label>
                    <span className="text-[10px] text-slate-400 font-semibold">Saisie libre ou boutons rapides</span>
                  </div>
                  <input
                    type="text"
                    inputMode="decimal"
                    autoFocus
                    required
                    value={payAmount}
                    onChange={(e) => setPayAmount(sanitizeDecimalInput(e.target.value))}
                    placeholder="ex: 50.00"
                    className="w-full p-3 text-lg font-black bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-2xl text-emerald-600 dark:text-emerald-400 focus:ring-2 focus:ring-emerald-500"
                  />

                  {/* Quick Preset Buttons */}
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    <button
                      type="button"
                      onClick={() => setPayAmount(currentDebt.toString())}
                      className="px-2.5 py-1 bg-emerald-100 hover:bg-emerald-200 dark:bg-emerald-950 dark:hover:bg-emerald-900 text-emerald-800 dark:text-emerald-200 rounded-lg text-[11px] font-bold"
                    >
                      Totalité ({currentDebt.toFixed(2)} {currency})
                    </button>
                    <button
                      type="button"
                      onClick={() => setPayAmount((Math.round(currentDebt / 2 * 100) / 100).toString())}
                      className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg text-[11px] font-bold"
                    >
                      50% ({(currentDebt / 2).toFixed(2)})
                    </button>
                    {[20, 50, 100, 200].filter(v => v <= currentDebt).map(val => (
                      <button
                        key={val}
                        type="button"
                        onClick={() => setPayAmount(val.toString())}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg text-[11px] font-bold"
                      >
                        +{val} {currency}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Real-Time Recalculation Card */}
                {enteredVal > 0 && (
                  <div className={`p-3 rounded-2xl border text-xs space-y-1 ${
                    remainingVal === 0 
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-800 dark:bg-emerald-950/40 dark:border-emerald-800 dark:text-emerald-300'
                      : 'bg-indigo-50 border-indigo-200 text-indigo-900 dark:bg-indigo-950/40 dark:border-indigo-800 dark:text-indigo-200'
                  }`}>
                    <div className="flex justify-between">
                      <span>Dette antérieure :</span>
                      <span>{currentDebt.toFixed(2)} {currency}</span>
                    </div>
                    <div className="flex justify-between font-bold">
                      <span>Versement reçu :</span>
                      <span>-{enteredVal.toFixed(2)} {currency}</span>
                    </div>
                    <div className="flex justify-between font-extrabold text-sm pt-1 border-t border-current/20">
                      <span>Nouveau Reste Dû :</span>
                      <span>{remainingVal.toFixed(2)} {currency} {remainingVal === 0 ? '🎉 (Solde Soldé)' : ''}</span>
                    </div>
                  </div>
                )}

                {/* Payment Method Selector */}
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Mode de Règlement :
                  </label>
                  <select
                    value={payMethod}
                    onChange={(e) => setPayMethod(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-bold"
                  >
                    <option value="especes">💵 Espèces (Cash)</option>
                    <option value="carte">💳 Carte Bancaire (TPE)</option>
                    <option value="virement">🏦 Virement Bancaire</option>
                    <option value="cheque">📝 Chèque Bancaire</option>
                  </select>
                </div>

                {/* Reference Note */}
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Référence / Note (optionnel) :
                  </label>
                  <input
                    type="text"
                    value={payNote}
                    onChange={(e) => setPayNote(e.target.value)}
                    placeholder="ex: N° Virement, N° Chèque ou commentaire..."
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-medium"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setPayDebtClient(null)}
                    className="flex-1 py-2.5 font-semibold rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    disabled={enteredVal <= 0}
                    className={`flex-1 py-2.5 font-extrabold rounded-xl text-white shadow-md flex items-center justify-center gap-1.5 transition ${
                      enteredVal > 0 
                        ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-500/20 active:scale-95' 
                        : 'bg-slate-300 dark:bg-slate-700 cursor-not-allowed opacity-50'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Valider le Versement</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        );
      })()}

      {/* STEP 2: REÇU DE VERSEMENT PARTIEL VALIDE (POPUP + IMPRESSION + WHATSAPP) */}
      {completedPaymentReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-3 sm:p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 max-w-sm w-full border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 text-center">
            
            <div className="w-14 h-14 bg-emerald-100 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-300 rounded-2xl flex items-center justify-center mx-auto text-2xl shadow-md shadow-emerald-500/20">
              ✓
            </div>

            <div>
              <h4 className="font-extrabold text-base text-slate-900 dark:text-white">
                Versement Enregistré avec Succès !
              </h4>
              <p className="text-xs text-slate-500 mt-0.5 font-mono">
                Reçu #{completedPaymentReceipt.receiptNo}
              </p>
            </div>

            <div id="client-receipt-print" className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 text-left text-xs space-y-1.5 font-medium">
              <div className="flex justify-between">
                <span className="text-slate-500">Client :</span>
                <span className="font-bold text-slate-900 dark:text-white">{completedPaymentReceipt.clientName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Date :</span>
                <span>{new Date(completedPaymentReceipt.timestamp).toLocaleDateString('fr-FR')} {new Date(completedPaymentReceipt.timestamp).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Dette antérieure :</span>
                <span>{(completedPaymentReceipt.previousDebt || 0).toFixed(2)} {currency}</span>
              </div>
              <div className="flex justify-between font-bold text-emerald-600 dark:text-emerald-400">
                <span>Montant versé ({completedPaymentReceipt.paymentMethod?.toUpperCase()}) :</span>
                <span>+{completedPaymentReceipt.amount?.toFixed(2)} {currency}</span>
              </div>
              {completedPaymentReceipt.note && (
                <div className="flex justify-between text-slate-400 text-[10px]">
                  <span>Réf :</span>
                  <span>{completedPaymentReceipt.note}</span>
                </div>
              )}
              <div className="flex justify-between font-black text-sm pt-1.5 border-t border-slate-200 dark:border-slate-700 text-amber-600 dark:text-amber-400">
                <span>Reste Dû :</span>
                <span>{Number(completedPaymentReceipt.remainingDebt || 0).toFixed(2)} {currency}</span>
              </div>
            </div>

            <div className="flex flex-col gap-2 pt-1 no-print">
              <button
                type="button"
                onClick={() => triggerPrintWithLayout('80mm')}
                className="w-full py-2.5 bg-slate-900 hover:bg-black text-white dark:bg-slate-800 font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-sm"
              >
                <Printer className="w-4 h-4" />
                <span>Imprimer Reçu de Versement</span>
              </button>
              
              <button
                type="button"
                onClick={() => handleSendPaymentReceiptWhatsApp(completedPaymentReceipt)}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-sm shadow-emerald-500/20"
              >
                <Send className="w-4 h-4" />
                <span>Envoyer Reçu WhatsApp</span>
              </button>

              <button
                type="button"
                onClick={() => setCompletedPaymentReceipt(null)}
                className="w-full py-2 text-slate-500 hover:text-slate-800 text-xs font-bold"
              >
                Fermer
              </button>
            </div>

          </div>
        </div>
      )}

      {/* STEP 3: MODAL HISTORIQUE DES RÈGLEMENTS CLIENT */}
      {historyClient && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-3 sm:p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 max-w-xl w-full border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto no-scrollbar">
            
            <div id="client-history-print" className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 rounded-2xl">
                    <History className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                      Historique des Règlements
                    </h3>
                    <p className="text-xs text-slate-500">{historyClient.name} • Dette en cours : {historyClient.debt?.toFixed(2)} {currency}</p>
                  </div>
                </div>
                <button
                  onClick={() => setHistoryClient(null)}
                  className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 no-print"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {isLoadingHistory ? (
                <div className="py-10 text-center text-xs text-slate-400">
                  Chargement des versements...
                </div>
              ) : clientPayments.length === 0 ? (
                <div className="py-10 text-center bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700 text-xs text-slate-400 space-y-1">
                  <p className="font-bold">Aucun versement enregistré pour ce client.</p>
                  <p className="text-[11px]">Les versements partiels ou totaux apparaîtront automatiquement ici.</p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {clientPayments.map((pmt) => (
                    <div
                      key={pmt.id || pmt.receiptNo}
                      className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 text-xs flex flex-wrap items-center justify-between gap-3"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400">
                            #{pmt.receiptNo}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {new Date(pmt.timestamp).toLocaleDateString('fr-FR')} {new Date(pmt.timestamp).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5">
                          Mode: <strong className="uppercase">{pmt.paymentMethod || 'Espèces'}</strong>
                          {pmt.note && <span className="italic text-slate-400"> • Réf: {pmt.note}</span>}
                        </div>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          Dette avant: {(pmt.previousDebt || 0).toFixed(2)} {currency} ➔ Reste dû: {Number(pmt.remainingDebt || 0).toFixed(2)} {currency}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-sm text-emerald-600 dark:text-emerald-400">
                          +{Number(pmt.amount || 0).toFixed(2)} {currency}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleSendPaymentReceiptWhatsApp(pmt)}
                          className="p-1.5 bg-green-500 hover:bg-green-600 text-white rounded-lg no-print"
                          title="Renvoyer le reçu sur WhatsApp"
                        >
                          <Send className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center no-print">
              <button
                type="button"
                onClick={() => triggerPrintWithLayout('a4')}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm"
              >
                <Printer className="w-4 h-4" />
                <span>Imprimer Relevé A4</span>
              </button>
              <button
                type="button"
                onClick={() => setHistoryClient(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-xl text-xs font-bold"
              >
                Fermer
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
