import React from 'react';
import { Rocket, RefreshCw, X, Sparkles } from 'lucide-react';

export default function UpdateNotificationBanner({ currentLang = 'fr', onApplyUpdate, onDismiss }) {
  const isRTL = currentLang === 'ar';

  const texts = {
    fr: {
      title: "Mise à jour disponible !",
      desc: "Une nouvelle version améliorée de votre caisse est prête. Cliquez pour l'activer instantanément (vos données restent 100% protégées).",
      btn: "Actualiser Maintenant (1s)",
      badge: "Nouvelle Version"
    },
    ar: {
      title: "تحديث جديد متاح !",
      desc: "نسخة جديدة ومحسنة من برنامج الصندوق جاهزة. اضغط للتحديث فوراً (بياناتك ومبيعاتك محفوظة 100%).",
      btn: "تحديث الآن (ثانية واحدة)",
      badge: "إصدار جديد"
    },
    en: {
      title: "New Update Available!",
      desc: "An updated version of your POS software is ready. Click to apply instantly (your sales & data remain 100% safe).",
      btn: "Update Now (1s)",
      badge: "New Release"
    },
    es: {
      title: "¡Nueva actualización disponible!",
      desc: "Una versión mejorada de su TPV está lista. Haga clic para aplicarla al instante (sus datos quedan 100% protegidos).",
      btn: "Actualizar Ahora (1s)",
      badge: "Nueva Versión"
    }
  };

  const t = texts[currentLang] || texts.fr;

  return (
    <div 
      dir={isRTL ? 'rtl' : 'ltr'}
      className="bg-gradient-to-r from-indigo-700 via-purple-700 to-indigo-800 text-white shadow-xl border-b border-indigo-500/50 py-3 px-4 transition-all duration-300 relative z-50 animate-in slide-in-from-top-4"
    >
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-3 text-center sm:text-start">
          <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center shrink-0 shadow-inner">
            <Rocket className="w-5 h-5 text-amber-300 animate-bounce" />
          </div>
          <div>
            <div className="flex items-center gap-2 justify-center sm:justify-start">
              <span className="font-black text-sm tracking-wide text-white">{t.title}</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-400 text-slate-950 uppercase shadow-sm">
                {t.badge}
              </span>
            </div>
            <p className="text-xs text-indigo-100 font-medium line-clamp-1 sm:line-clamp-none mt-0.5">
              {t.desc}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onApplyUpdate}
            className="px-4 py-2 bg-white hover:bg-slate-100 text-indigo-950 font-black text-xs rounded-xl shadow-lg hover:shadow-white/20 transition-all flex items-center gap-2 active:scale-95 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5 text-indigo-600 animate-spin" style={{ animationDuration: '4s' }} />
            <span>{t.btn}</span>
          </button>
          {onDismiss && (
            <button
              type="button"
              onClick={onDismiss}
              className="p-2 rounded-xl text-indigo-200 hover:text-white hover:bg-white/10 transition"
              title="Fermer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
