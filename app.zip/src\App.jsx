import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Navigation from './components/Navigation';
import CaisseView from './components/CaisseView';
import ProduitsView from './components/ProduitsView';
import ClientsView from './components/ClientsView';
import DashboardView from './components/DashboardView';
import WhatsAppView from './components/WhatsAppView';
import WebsiteView from './components/WebsiteView';
import FournisseursView from './components/FournisseursView';
import ParametresView from './components/ParametresView';
import ScannerModal from './components/ScannerModal';
import LoginModal from './components/LoginModal';
import BackupAlertBanner from './components/BackupAlertBanner';
import CreateShopModal from './components/CreateShopModal';
import SwitchCashierModal from './components/SwitchCashierModal';
import TeamManagementModal from './components/TeamManagementModal';
import WelcomeOnboardingView from './components/WelcomeOnboardingView';
import UpdateNotificationBanner from './components/UpdateNotificationBanner';
import { shouldShowBackupAlert } from './backupManager';
import { 
  db, 
  seedDatabaseIfEmpty, 
  initStoragePersistence,
  syncWithBackendServer,
  migrateAndFixProductImages,
  pushLocalChangesToBackend
} from './db';
import { syncManager } from './syncManager';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [theme, setTheme] = useState('light');
  const [currentLang, setCurrentLang] = useState('fr');
  const [isAdmin, setIsAdmin] = useState(true);
  const [userRole, setUserRole] = useState('patron');
  const [currentCashier, setCurrentCashier] = useState({
    id: 'usr_patron_1',
    name: 'Patron',
    role: 'patron',
    pin: '1234',
    avatarColor: '#4f46e5',
    permissions: {
      canManageCashiers: true,
      canManageProducts: true,
      canManageSuppliers: true,
      canViewProfits: true,
      canCloseCash: true
    }
  });
  const [isSwitchCashierOpen, setIsSwitchCashierOpen] = useState(false);
  const [isTeamManagementOpen, setIsTeamManagementOpen] = useState(false);
  const [isLocked, setIsLocked] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [scannedProductForCart, setScannedProductForCart] = useState(null);
  const [isServerOnline, setIsServerOnline] = useState(false);
  const [cloudSyncStatus, setCloudSyncStatus] = useState({
    status: 'unconfigured',
    isSyncing: false,
    pendingCount: 0
  });
  const [showBackupAlert, setShowBackupAlert] = useState(false);
  const [isCreateShopOpen, setIsCreateShopOpen] = useState(false);
  const [isDemoExploring, setIsDemoExploring] = useState(() => sessionStorage.getItem('demo_exploring') === 'true');
  const [updateWaitingWorker, setUpdateWaitingWorker] = useState(null);

  useEffect(() => {
    const handleUpdateReady = (e) => {
      const reg = e.detail;
      if (reg && reg.waiting) {
        setUpdateWaitingWorker(reg.waiting);
      }
    };
    window.addEventListener('ventefacile:update-ready', handleUpdateReady);
    return () => window.removeEventListener('ventefacile:update-ready', handleUpdateReady);
  }, []);

  const handleApplyUpdate = () => {
    if (updateWaitingWorker) {
      updateWaitingWorker.postMessage({ type: 'SKIP_WAITING' });
    }
    setTimeout(() => {
      window.location.reload();
    }, 200);
  };

  // IndexedDB States
  const [settings, setSettings] = useState({
    shopName: 'Boutique VenteFacile',
    isStoreConfigured: false,
    currency: 'DH',
    language: 'fr',
    theme: 'light',
    adminPassword: '',
    cashierPassword: '',
    securityEnabled: false,
    supabaseUrl: '',
    supabaseAnonKey: '',
    modules: {
      whatsapp: true,
      website: true,
      fidelity: true,
      vat: true,
      expiry: true,
      vendeurs: true,
      suppliers: true,
      promos: true,
      devis: true,
      multiCurrency: true
    }
  });

  const [products, setProducts] = useState([]);
  const [sales, setSales] = useState([]);
  const [clients, setClients] = useState([]);

  // Load Database & Persistent Storage State
  const loadData = async () => {
    try {
      const loadedProducts = await db.products.toArray();
      const loadedSales = await db.sales.toArray();
      const loadedClients = await db.clients.toArray();
      const loadedSettings = await db.settings.get(1);

      setProducts(loadedProducts || []);
      setSales(loadedSales || []);
      setClients(loadedClients || []);

      if (loadedSettings) {
        setSettings(loadedSettings);
        if (loadedSettings.language) setCurrentLang(loadedSettings.language);
        if (loadedSettings.theme) setTheme(loadedSettings.theme);
        if (loadedSettings.securityEnabled) {
          setIsLocked(true);
        }
        if (loadedSettings.team && Array.isArray(loadedSettings.team) && loadedSettings.team.length > 0) {
          const savedId = localStorage.getItem('active_cashier_id');
          const activeM = loadedSettings.team.find(m => m.id === savedId) ||
                          loadedSettings.team.find(m => m.role === 'patron') ||
                          loadedSettings.team[0];
          if (activeM) {
            setCurrentCashier(activeM);
            setIsAdmin(activeM.role === 'patron' || activeM.role === 'gerant');
            setUserRole(activeM.role);
          }
        }

        // Déclenchement automatique de l'assistant d'onboarding au premier démarrage
        if (!loadedSettings.isStoreConfigured) {
          const dismissedInSession = sessionStorage.getItem('onboarding_wizard_dismissed');
          if (!dismissedInSession) {
            setIsCreateShopOpen(true);
          }
        }
      }

      const needsBackup = await shouldShowBackupAlert();
      setShowBackupAlert(needsBackup);
    } catch (err) {
      console.error('[VenteFacile] Erreur chargement local:', err);
    }
  };

  useEffect(() => {
    const initApp = async () => {
      await seedDatabaseIfEmpty();
      await initStoragePersistence();
      await migrateAndFixProductImages();
      await loadData();

      // Check backend server sync in background
      try {
        const syncRes = await syncWithBackendServer();
        setIsServerOnline(syncRes?.online || false);
      } catch (e) {
        setIsServerOnline(false);
      }
    };

    initApp();

    // Subscribe to background cloud sync manager
    const unsubSync = syncManager.subscribe((status) => {
      setCloudSyncStatus(status);
    });
    syncManager.start(() => settings, () => loadData());

    // Periodic Server Health & Sync Check every 30 seconds
    const interval = setInterval(async () => {
      try {
        const syncRes = await syncWithBackendServer();
        setIsServerOnline(syncRes?.online || false);
      } catch (e) {
        setIsServerOnline(false);
      }
    }, 30000);

    // Sécurisation stricte de l'URL : neutralisation et purge de tout paramètre ?access=
    try {
      const params = new URLSearchParams(window.location.search);
      if (params.has('access')) {
        params.delete('access');
        const cleanUrl = window.location.pathname + (params.toString() ? `?${params.toString()}` : '');
        window.history.replaceState({}, document.title, cleanUrl);
        console.warn('[Sécurité VenteFacile] Paramètre access ignoré et purgé pour empêcher toute élévation de privilèges non autorisée.');
      }
    } catch (e) {
      // Ignorer
    }

    return () => {
      clearInterval(interval);
      unsubSync();
      syncManager.stop();
    };
  }, []);

  // Update theme class on root html element
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  // Update RTL direction for Arabic language
  useEffect(() => {
    const root = document.documentElement;
    if (currentLang === 'ar') {
      root.setAttribute('dir', 'rtl');
    } else {
      root.setAttribute('dir', 'ltr');
    }
  }, [currentLang]);

  // Auto-Lock Inactivity Hook (Verrouillage automatique de session)
  useEffect(() => {
    const minutes = parseInt(settings.autoLockMinutes || 0, 10);
    if (!minutes || minutes <= 0 || isLocked) return;

    let timerId;
    const timeoutMs = minutes * 60 * 1000;

    const resetTimer = () => {
      clearTimeout(timerId);
      timerId = setTimeout(() => {
        console.log(`[VenteFacile] Auto-lock déclenché après ${minutes} min d'inactivité.`);
        setIsLocked(true);
        if (isAdmin) {
          setIsAdmin(false);
          setUserRole('caissier');
        }
      }, timeoutMs);
    };

    const userActivityEvents = ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll', 'click'];
    userActivityEvents.forEach(evt => window.addEventListener(evt, resetTimer, { passive: true }));
    resetTimer();

    return () => {
      clearTimeout(timerId);
      userActivityEvents.forEach(evt => window.removeEventListener(evt, resetTimer));
    };
  }, [settings.autoLockMinutes, isLocked, isAdmin]);

  const handleToggleTheme = () => {
    const nextTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(nextTheme);
    db.settings.update(1, { theme: nextTheme });
  };

  const handleLangChange = (newLang) => {
    setCurrentLang(newLang);
    db.settings.update(1, { language: newLang });
  };

  const handleScanSuccess = async (scannedProd) => {
    setIsScannerOpen(false);

    let targetProduct = products.find(p => p.barcode === scannedProd.barcode);

    if (!targetProduct) {
      const prodToSave = { ...scannedProd };
      if (typeof prodToSave.id === 'string') {
        delete prodToSave.id;
      }
      const newId = await db.products.add(prodToSave);
      targetProduct = { ...prodToSave, id: newId };
      await loadData();
    } else {
      targetProduct = { ...targetProduct, ...scannedProd, id: targetProduct.id };
    }

    // Transmettre le produit scanné pour ajout immédiat au panier actif
    setScannedProductForCart(targetProduct);
    // Switch to POS caisse to make sale immediately
    setActiveTab('caisse');
  };

  const handleLoginSuccess = ({ role }) => {
    setIsLocked(false);
    setUserRole(role);
    if (role === 'admin') {
      setIsAdmin(true);
    } else {
      setIsAdmin(false);
      setActiveTab('caisse'); // Caissiers directly land on POS Caisse
    }
  };

  const handleSelectCashier = (member) => {
    setCurrentCashier(member);
    localStorage.setItem('active_cashier_id', member.id);
    const isAdm = member.role === 'patron' || member.role === 'gerant';
    setIsAdmin(isAdm);
    setUserRole(member.role);
    const adminOnlyTabs = ['dashboard', 'fournisseurs', 'parametres', 'website'];
    if (!isAdm && adminOnlyTabs.includes(activeTab)) {
      setActiveTab('caisse');
    }
  };

  const handleUpdateTeam = async (newTeam) => {
    const updatedSettings = { ...settings, team: newTeam };
    setSettings(updatedSettings);
    await db.settings.update(1, { team: newTeam });
    const currentStillExists = newTeam.find(m => m.id === currentCashier?.id);
    if (currentStillExists) {
      handleSelectCashier(currentStillExists);
    } else {
      const fallbackPatron = newTeam.find(m => m.role === 'patron') || newTeam[0];
      if (fallbackPatron) handleSelectCashier(fallbackPatron);
    }
  };

  const handleUpdateSettings = async (newSettings) => {
    setSettings(newSettings);
    await db.settings.put(newSettings, 1);
    if (newSettings.team && Array.isArray(newSettings.team)) {
      const activePatron = newSettings.team.find(m => m.id === currentCashier?.id) ||
                           newSettings.team.find(m => m.role === 'patron') ||
                           newSettings.team[0];
      if (activePatron) {
        setCurrentCashier(activePatron);
        setIsAdmin(activePatron.role === 'patron' || activePatron.role === 'gerant');
        setUserRole(activePatron.role);
      }
    }
    // If Supabase config changed, trigger a sync test
    if (newSettings.supabaseUrl && newSettings.supabaseAnonKey) {
      syncManager.syncNow().catch(console.warn);
    }
  };

  const handleTabChange = (tabId) => {
    const adminOnlyTabs = ['dashboard', 'fournisseurs', 'parametres', 'website'];
    if (!isAdmin && adminOnlyTabs.includes(tabId)) {
      setIsLocked(true);
      return;
    }
    setActiveTab(tabId);
  };

  // ÉCRAN D'ACCUEIL & ONBOARDING PLEINE PAGE (PREMIER DÉMARRAGE NOUVEAU COMMERÇANT)
  if (!settings.isStoreConfigured && !isDemoExploring) {
    return (
      <WelcomeOnboardingView
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        onRefreshData={loadData}
        onStartDemo={() => {
          setIsDemoExploring(true);
          sessionStorage.setItem('demo_exploring', 'true');
        }}
        currentLang={currentLang}
        onLangChange={handleLangChange}
        theme={theme}
        onToggleTheme={handleToggleTheme}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200 selection:bg-indigo-500 selection:text-white">
      
      {/* BANDEAU PERSISTANT MODE ESSAI / DÉCOUVERTE POUR LE COMMERÇANT */}
      {!settings.isStoreConfigured && isDemoExploring && (
        <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-white px-4 py-2.5 text-xs font-bold shadow-lg flex flex-col sm:flex-row items-center justify-between gap-2.5 z-40 sticky top-0 border-b border-amber-600 animate-in slide-in-from-top duration-300">
          <div className="flex items-center gap-2">
            <span className="p-1 rounded-lg bg-black/20 text-sm">🧪</span>
            <span>
              {currentLang === 'ar'
                ? 'وضع تجريبي : أنت تتصفح الآن بضائع وأسعار وهمية للاختبار. لتفعيل متجرك الحقيقي وبدء حساباتك النظيفة :'
                : 'Mode Découverte : Vous testez actuellement avec des faux produits. Prêt à lancer votre vraie boutique ?'}
            </span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setIsCreateShopOpen(true)}
              className="px-3.5 py-1.5 rounded-xl bg-white text-amber-950 font-black hover:bg-amber-50 shadow transition active:scale-95 cursor-pointer flex items-center gap-1.5 text-xs"
            >
              <span>🚀 {currentLang === 'ar' ? 'تفعيل متجري الحقيقي الآن' : 'Activer ma Vraie Boutique'}</span>
            </button>
            <button
              onClick={() => {
                sessionStorage.removeItem('demo_exploring');
                setIsDemoExploring(false);
              }}
              className="px-2.5 py-1.5 rounded-xl bg-amber-800/80 hover:bg-amber-900 text-white font-bold transition active:scale-95 cursor-pointer text-[11px]"
              title="Retour à l'accueil"
            >
              {currentLang === 'ar' ? 'شاشة الترحيب' : 'Accueil Setup'}
            </button>
          </div>
        </div>
      )}

      {/* Login Lock Modal if Security Enabled or User Switch */}
      {isLocked && (
        <LoginModal
          settings={settings}
          onLoginSuccess={handleLoginSuccess}
          onOpenQRScanner={() => setIsScannerOpen(true)}
          onClose={() => setIsLocked(false)}
        />
      )}

      {/* Hot-Update Notification Banner for instant 0-cache reload */}
      {updateWaitingWorker && (
        <UpdateNotificationBanner
          currentLang={currentLang}
          onApplyUpdate={handleApplyUpdate}
          onDismiss={() => setUpdateWaitingWorker(null)}
        />
      )}

      {/* Sticky Header with Cloud & Role Indicators */}
      <Header
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        currentLang={currentLang}
        onLangChange={handleLangChange}
        theme={theme}
        onToggleTheme={handleToggleTheme}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onOpenScanner={() => setIsScannerOpen(true)}
        isAdmin={isAdmin}
        userRole={userRole}
        currentCashier={currentCashier}
        onOpenSwitchCashier={() => setIsSwitchCashierOpen(true)}
        onOpenTeamManagement={() => setIsTeamManagementOpen(true)}
        onOpenLogin={() => setIsLocked(true)}
        onToggleAdmin={() => {
          if (isAdmin) {
            setIsAdmin(false);
            setUserRole('caissier');
            setActiveTab('caisse');
          } else {
            setIsLocked(true);
          }
        }}
        isServerOnline={isServerOnline}
        cloudSyncStatus={cloudSyncStatus}
        onOpenCreateShop={() => setIsCreateShopOpen(true)}
      />

      {/* Preventive Backup Alert Banner if Data is at risk */}
      {showBackupAlert && (
        <BackupAlertBanner
          currentLang={currentLang}
          onBackupCompleted={() => setShowBackupAlert(false)}
        />
      )}

      {/* Main Tab Navigation - Role-Aware & Lock-Protected */}
      <Navigation
        activeTab={activeTab}
        onTabChange={handleTabChange}
        currentLang={currentLang}
        isAdmin={isAdmin}
        userRole={userRole}
        onRequestAdmin={() => setIsLocked(true)}
      />

      {/* View Content */}
      <main className="flex-1">
        {activeTab === 'dashboard' && (
          !isAdmin ? (
            <div className="max-w-md mx-auto my-16 p-8 bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-slate-200 dark:border-slate-800 text-center">
              <div className="w-16 h-16 bg-amber-100 dark:bg-amber-950/50 text-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4 text-3xl">
                🔒
              </div>
              <h3 className="text-xl font-bold mb-2">Accès Réservé au Gérant</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">
                Le Tableau de bord financier, le chiffre d'affaires et les marges nettes sont protégés par le profil Administrateur.
              </p>
              <div className="flex gap-3 justify-center">
                <button
                  onClick={() => setActiveTab('caisse')}
                  className="px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold transition-all"
                >
                  Retour Caisse
                </button>
                <button
                  onClick={() => setIsLocked(true)}
                  className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-600/20 transition-all"
                >
                  Déverrouiller Admin (PIN)
                </button>
              </div>
            </div>
          ) : (
            <DashboardView
              sales={sales}
              products={products}
              clients={clients}
              settings={settings}
              currentLang={currentLang}
              onRefreshData={loadData}
              isAdmin={isAdmin}
              userRole={userRole}
              onOpenCreateShop={() => setIsCreateShopOpen(true)}
              onOpenTeamManagement={() => setIsTeamManagementOpen(true)}
            />
          )
        )}

        {activeTab === 'caisse' && (
          <CaisseView
            products={products}
            sales={sales}
            clients={clients}
            settings={settings}
            currentLang={currentLang}
            searchQuery={searchQuery}
            scannedProductToAdd={scannedProductForCart}
            onScannedProductAdded={() => setScannedProductForCart(null)}
            onOpenScanner={() => setIsScannerOpen(true)}
            onRefreshData={loadData}
            currentCashier={currentCashier}
            onOpenSwitchCashier={() => setIsSwitchCashierOpen(true)}
            onOpenTeamManagement={() => setIsTeamManagementOpen(true)}
          />
        )}

        {activeTab === 'produits' && (
          <ProduitsView
            products={products}
            settings={settings}
            currentLang={currentLang}
            onRefreshData={loadData}
            onOpenScanner={() => setIsScannerOpen(true)}
            isAdmin={isAdmin}
            userRole={userRole}
          />
        )}

        {activeTab === 'clients' && (
          <ClientsView
            clients={clients}
            settings={settings}
            currentLang={currentLang}
            onRefreshData={loadData}
          />
        )}

        {activeTab === 'fournisseurs' && (
          !isAdmin ? (
            <div className="max-w-md mx-auto my-16 p-8 bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-slate-200 dark:border-slate-800 text-center animate-in fade-in">
              <div className="w-16 h-16 bg-amber-100 dark:bg-amber-950/50 text-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4 text-3xl">
                🔒
              </div>
              <h3 className="text-xl font-bold mb-2">Fournisseurs & Dettes Réservés</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">
                Le suivi des factures d'achat grossistes, des dettes et des règlements fournisseurs est protégé par le profil Administrateur.
              </p>
              <button
                onClick={() => setIsLocked(true)}
                className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all"
              >
                Déverrouiller Admin (PIN)
              </button>
            </div>
          ) : (
            <FournisseursView
              settings={settings}
              currentLang={currentLang}
              onRefreshData={loadData}
              isAdmin={isAdmin}
            />
          )
        )}

        {activeTab === 'whatsapp' && (
          <WhatsAppView
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
            currentLang={currentLang}
          />
        )}

        {activeTab === 'website' && (
          !isAdmin ? (
            <div className="max-w-md mx-auto my-16 p-8 bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-slate-200 dark:border-slate-800 text-center">
              <div className="w-16 h-16 bg-amber-100 dark:bg-amber-950/50 text-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4 text-3xl">
                🔒
              </div>
              <h3 className="text-xl font-bold mb-2">Gestion Vitrine Réservée</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">
                La configuration de la vitrine en ligne est réservée aux administrateurs.
              </p>
              <button
                onClick={() => setIsLocked(true)}
                className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all"
              >
                Déverrouiller Admin
              </button>
            </div>
          ) : (
            <WebsiteView
              settings={settings}
              onUpdateSettings={handleUpdateSettings}
              currentLang={currentLang}
              onRefreshData={loadData}
            />
          )
        )}

        {activeTab === 'parametres' && (
          !isAdmin ? (
            <div className="max-w-md mx-auto my-16 p-8 bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-slate-200 dark:border-slate-800 text-center">
              <div className="w-16 h-16 bg-amber-100 dark:bg-amber-950/50 text-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4 text-3xl">
                🔒
              </div>
              <h3 className="text-xl font-bold mb-2">Paramètres Protégés</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">
                La synchronisation Cloud Supabase, les mots de passe et la fiscalité sont réservés à l'administrateur.
              </p>
              <button
                onClick={() => setIsLocked(true)}
                className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all"
              >
                Déverrouiller Admin
              </button>
            </div>
          ) : (
            <ParametresView
              settings={settings}
              onUpdateSettings={handleUpdateSettings}
              currentLang={currentLang}
              onLangChange={handleLangChange}
              onRefreshData={loadData}
              onOpenTeamManagement={() => setIsTeamManagementOpen(true)}
              onOpenSwitchCashier={() => setIsSwitchCashierOpen(true)}
              currentCashier={currentCashier}
            />
          )
        )}
      </main>

      {/* Scanner Camera Modal */}
      {isScannerOpen && (
        <ScannerModal
          products={products}
          currency={settings?.currency || 'DH'}
          onClose={() => setIsScannerOpen(false)}
          onScanSuccess={handleScanSuccess}
        />
      )}

      {/* Store Creation & Activation Modal */}
      <CreateShopModal
        isOpen={isCreateShopOpen}
        onClose={() => setIsCreateShopOpen(false)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        onRefreshData={loadData}
        currentLang={currentLang}
      />

      {/* Switch Cashier Modal (Changer de Caissier en 1 clic) */}
      <SwitchCashierModal
        isOpen={isSwitchCashierOpen}
        onClose={() => setIsSwitchCashierOpen(false)}
        team={settings.team || []}
        currentCashier={currentCashier}
        onSelectCashier={handleSelectCashier}
        currentLang={currentLang}
      />

      {/* Team & Roles Management Modal (Apex Security) */}
      <TeamManagementModal
        isOpen={isTeamManagementOpen}
        onClose={() => setIsTeamManagementOpen(false)}
        team={settings.team || []}
        currentCashier={currentCashier}
        onUpdateTeam={handleUpdateTeam}
        onOpenSwitchCashier={() => {
          setIsTeamManagementOpen(false);
          setIsSwitchCashierOpen(true);
        }}
        storeName={settings.shopName}
        currentLang={currentLang}
      />

    </div>
  );
}
