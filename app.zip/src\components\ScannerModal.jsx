import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Zap, 
  Lightbulb, 
  Check, 
  Edit3, 
  Sparkles, 
  Volume2,
  Package,
  ShoppingBag,
  Camera,
  AlertCircle,
  Search,
  RefreshCw,
  ShieldCheck,
  Smartphone
} from 'lucide-react';
import { BrowserMultiFormatReader } from '@zxing/library';
import { parseSafeFloat, sanitizeDecimalInput } from '../utils/numberUtils';

export default function ScannerModal({ 
  onClose, 
  onScanSuccess, 
  products = [],
  currency = 'DH'
}) {
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const trackRef = useRef(null);
  const animationFrameRef = useRef(null);
  const codeReaderRef = useRef(null);

  const [torchOn, setTorchOn] = useState(false);
  const [torchSupported, setTorchSupported] = useState(false);
  const [scannedProduct, setScannedProduct] = useState(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState('');
  const [manualCode, setManualCode] = useState('');
  const [isScanningActive, setIsScanningActive] = useState(true);
  const [engineType, setEngineType] = useState('detecting'); // 'native' | 'zxing'

  // Editable Correction Form for Scanned Product
  const [correctionData, setCorrectionData] = useState({
    name: '',
    brand: '',
    category: 'Parfumerie & Beauté',
    vatRate: '20',
    buyPrice: '',
    sellPrice: '',
    stock: '1'
  });

  // Play audio Bip sound on scan
  const playBipSound = () => {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = 880; // A5 pitch
      gain.gain.value = 0.15;
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.12);
      if (navigator.vibrate) navigator.vibrate(100);
    } catch (e) {
      console.log('Bip sound play error', e);
    }
  };

  // Safe Camera Stop (Strict extinction of all media tracks to preserve battery and privacy)
  const stopCamera = () => {
    // 1. Cancel requestAnimationFrame loop
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }

    // 2. Reset ZXing decoder if active
    if (codeReaderRef.current) {
      try {
        codeReaderRef.current.reset();
      } catch (e) {
        console.warn('[ScannerModal] Erreur reset ZXing :', e);
      }
      codeReaderRef.current = null;
    }

    // 3. Stop every video track in the media stream
    if (streamRef.current) {
      try {
        streamRef.current.getTracks().forEach(track => {
          track.stop();
        });
      } catch (e) {
        console.warn('[ScannerModal] Erreur arrêt tracks :', e);
      }
      streamRef.current = null;
    }

    // 4. Detach video element stream
    if (videoRef.current) {
      try {
        videoRef.current.pause();
        videoRef.current.srcObject = null;
      } catch (e) {}
    }

    trackRef.current = null;
    setCameraActive(false);
    setTorchOn(false);
  };

  // Start Real Device Camera
  const startCamera = async () => {
    setCameraError('');
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('La caméra n\'est pas supportée par ce navigateur.');
      }

      // Stop existing stream if any before re-opening
      stopCamera();

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      });

      streamRef.current = stream;
      const videoTrack = stream.getVideoTracks()[0];
      trackRef.current = videoTrack;

      if (videoTrack) {
        const capabilities = videoTrack.getCapabilities ? videoTrack.getCapabilities() : {};
        setTorchSupported(!!capabilities.torch);
      }

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        videoRef.current.setAttribute('muted', 'true');
        await videoRef.current.play();
        setCameraActive(true);

        // Launch Barcode Engine (Native BarcodeDetector or ZXing fallback for iOS Safari)
        initScanningEngine();
      }
    } catch (err) {
      console.warn('[ScannerModal] Erreur démarrage caméra :', err);
      setCameraError(err.name === 'NotAllowedError' 
        ? 'Permission d\'accès à la caméra refusée. Veuillez autoriser la caméra dans les réglages du navigateur ou utiliser la recherche manuelle.'
        : `Impossible d'accéder à la caméra (${err.message}). Vous pouvez utiliser la saisie manuelle.`
      );
      setCameraActive(false);
    }
  };

  // Initialize Detection Engine: Native BarcodeDetector (Chrome/Android) or ZXing (Safari/iOS/Firefox)
  const initScanningEngine = () => {
    const hasNativeBarcodeDetector = typeof window !== 'undefined' && 'BarcodeDetector' in window;

    if (hasNativeBarcodeDetector) {
      setEngineType('native');
      let barcodeDetector = null;
      try {
        barcodeDetector = new window.BarcodeDetector({
          formats: ['ean_13', 'ean_8', 'code_128', 'qr_code', 'upc_a', 'upc_e', 'code_39']
        });
      } catch (e) {
        console.warn('[ScannerModal] BarcodeDetector formats error, falling back to ZXing', e);
      }

      if (barcodeDetector) {
        let isDetecting = true;
        const detectLoop = async () => {
          if (!isDetecting) return;

          if (videoRef.current && videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA && isScanningActive) {
            try {
              const barcodes = await barcodeDetector.detect(videoRef.current);
              if (barcodes && barcodes.length > 0) {
                const raw = barcodes[0].rawValue;
                if (raw) {
                  isDetecting = false;
                  handleBarcodeScanned(raw);
                  return;
                }
              }
            } catch (detectErr) {
              // Frame drop or non-fatal decode error
            }
          }

          animationFrameRef.current = requestAnimationFrame(detectLoop);
        };

        animationFrameRef.current = requestAnimationFrame(detectLoop);
        return;
      }
    }

    // Fallback: iOS Safari / iPadOS / Firefox - Pure JS Multi-Format Decoder (@zxing/library)
    setEngineType('zxing');
    try {
      const codeReader = new BrowserMultiFormatReader();
      codeReaderRef.current = codeReader;

      if (videoRef.current) {
        codeReader.decodeFromVideoElement(videoRef.current, (result, err) => {
          if (result && isScanningActive) {
            const raw = result.getText();
            if (raw) {
              handleBarcodeScanned(raw);
            }
          }
        });
      }
    } catch (zxingErr) {
      console.warn('[ScannerModal] Erreur initialisation ZXing fallback :', zxingErr);
    }
  };

  // Toggle Torch / Flashlight
  const handleToggleTorch = async () => {
    if (!trackRef.current) return;
    try {
      const nextTorch = !torchOn;
      await trackRef.current.applyConstraints({
        advanced: [{ torch: nextTorch }]
      });
      setTorchOn(nextTorch);
    } catch (e) {
      console.warn('Torch toggle error', e);
      setTorchOn(!torchOn);
    }
  };

  // Lifecycle: Start Camera on Mount, Stop on Unmount & Page Hide
  useEffect(() => {
    startCamera();

    // Prevent camera background battery leak when user switches apps or minimizes Safari
    const handleVisibilityChange = () => {
      if (document.hidden) {
        stopCamera();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      stopCamera();
    };
  }, []);

  // Process a Scanned Barcode (Camera or Manual)
  const handleBarcodeScanned = async (barcode) => {
    if (!barcode) return;
    setIsScanningActive(false);
    playBipSound();

    // Stop camera immediately to save battery while merchant validates item
    stopCamera();

    // 1. Check if product already exists in local catalog
    const existing = products.find(p => p.barcode === barcode);
    if (existing) {
      setScannedProduct(existing);
      setCorrectionData({
        name: existing.name,
        brand: existing.brand || '',
        category: existing.category || 'Général',
        vatRate: String(existing.vatRate || 20),
        buyPrice: String(existing.buyPrice || 0),
        sellPrice: String(existing.sellPrice || 0),
        stock: String(existing.stock || 1)
      });
      return;
    }

    // 2. Query Online Open Products API for auto prefill
    let autoName = `Article Scanné (${barcode})`;
    let autoBrand = 'Marque Inconnue';
    let autoImage = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&q=80';

    try {
      const resp = await fetch(`https://world.openfoodfacts.org/api/v0/product/${barcode}.json`);
      if (resp.ok) {
        const data = await resp.json();
        if (data.status === 1 && data.product) {
          autoName = data.product.product_name || autoName;
          autoBrand = data.product.brands ? data.product.brands.split(',')[0].trim() : autoBrand;
          autoImage = data.product.image_front_url || autoImage;
        }
      }
    } catch (e) {
      // Offline fallback
    }

    const newProd = {
      barcode,
      name: autoName,
      brand: autoBrand,
      category: 'Général',
      buyPrice: 20.00,
      sellPrice: 45.00,
      vatRate: 20,
      stock: 1,
      image: autoImage
    };

    setScannedProduct(newProd);
    setCorrectionData({
      name: autoName,
      brand: autoBrand,
      category: 'Général',
      vatRate: '20',
      buyPrice: '20.00',
      sellPrice: '45.00',
      stock: '1'
    });
  };

  const handleManualSubmit = (e) => {
    e.preventDefault();
    if (manualCode.trim()) {
      handleBarcodeScanned(manualCode.trim());
      setManualCode('');
    }
  };

  const handleConfirmAdd = () => {
    if (onScanSuccess && scannedProduct) {
      const finalProduct = {
        ...scannedProduct,
        name: correctionData.name.trim(),
        brand: correctionData.brand.trim(),
        category: correctionData.category,
        vatRate: parseSafeFloat(correctionData.vatRate, 20),
        buyPrice: parseSafeFloat(correctionData.buyPrice, 0),
        sellPrice: parseSafeFloat(correctionData.sellPrice, 0),
        stock: parseSafeFloat(correctionData.stock, 1)
      };

      // Supprimer tout ID temporaire sous forme de chaîne pour laisser Dexie auto-incrémenter l'ID numérique
      if (typeof finalProduct.id === 'string') {
        delete finalProduct.id;
      }

      stopCamera();
      if (onClose) onClose();
      onScanSuccess(finalProduct);
    }
  };

  const handleResumeScanning = () => {
    setScannedProduct(null);
    setIsScanningActive(true);
    startCamera();
  };

  const handleModalClose = () => {
    stopCamera();
    if (onClose) onClose();
  };

  // Search matches as user types manually
  const filteredQuickProducts = manualCode.trim().length >= 2
    ? products.filter(p => 
        (p.barcode && p.barcode.includes(manualCode.trim())) ||
        (p.name && p.name.toLowerCase().includes(manualCode.trim().toLowerCase()))
      ).slice(0, 4)
    : [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 text-white rounded-3xl p-5 max-w-md w-full border border-slate-800 shadow-2xl relative flex flex-col max-h-[90vh] overflow-y-auto">
        
        {/* Header Bar */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-600 flex items-center justify-center">
              <Camera className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-extrabold text-sm font-display">Scanner Code-Barres & Caméra</h3>
              </div>
              <p className="text-[10px] text-slate-400">Compatible tous smartphones Android, iPhone & iPad (Safari)</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Flash / Light Button */}
            {torchSupported && cameraActive && (
              <button
                type="button"
                onClick={handleToggleTorch}
                className={`p-2 rounded-xl transition flex items-center gap-1 text-xs font-bold ${
                  torchOn 
                    ? 'bg-amber-400 text-slate-950 shadow-lg shadow-amber-400/30' 
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
                title="Activer la lampe torche"
              >
                <Lightbulb className={`w-4 h-4 ${torchOn ? 'fill-current' : ''}`} />
              </button>
            )}

            <button 
              type="button"
              onClick={handleModalClose} 
              className="p-2 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Viewport: Real Camera Feed */}
        {!scannedProduct ? (
          <div className="space-y-4">
            
            {/* Engine Indicator Badge */}
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-400 font-semibold">Mode Détection :</span>
              {engineType === 'native' ? (
                <span className="px-2 py-0.5 bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 font-bold rounded-full flex items-center gap-1">
                  <Zap className="w-3 h-3 text-emerald-400" />
                  <span>Accélération Matérielle (Natif)</span>
                </span>
              ) : (
                <span className="px-2 py-0.5 bg-indigo-950/80 border border-indigo-500/40 text-indigo-300 font-bold rounded-full flex items-center gap-1">
                  <Smartphone className="w-3 h-3 text-indigo-400" />
                  <span>Moteur Universel Safari iOS (ZXing)</span>
                </span>
              )}
            </div>

            <div className="relative aspect-video w-full rounded-2xl overflow-hidden border-2 border-indigo-500/80 bg-slate-950 flex items-center justify-center shadow-inner">
              
              {/* Real Video Element */}
              <video
                ref={videoRef}
                playsInline
                muted
                className={`w-full h-full object-cover ${cameraActive ? 'block' : 'hidden'}`}
              />

              {/* Camera Target Overlay Guide */}
              {cameraActive && (
                <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center">
                  <div className="w-52 h-32 border-2 border-dashed border-indigo-400/80 rounded-xl relative shadow-lg">
                    {/* Laser Scan Line animation */}
                    <div className="w-full h-0.5 bg-red-500 shadow-lg shadow-red-500 absolute top-1/2 left-0 right-0 animate-pulse" />
                    <div className="absolute top-1 left-1 w-3 h-3 border-t-2 border-l-2 border-indigo-400" />
                    <div className="absolute top-1 right-1 w-3 h-3 border-t-2 border-r-2 border-indigo-400" />
                    <div className="absolute bottom-1 left-1 w-3 h-3 border-b-2 border-l-2 border-indigo-400" />
                    <div className="absolute bottom-1 right-1 w-3 h-3 border-b-2 border-r-2 border-indigo-400" />
                  </div>
                  <span className="text-[11px] font-bold text-white bg-slate-900/80 px-2.5 py-0.5 rounded-full mt-2 backdrop-blur-sm">
                    Cadrez le code-barres dans la zone
                  </span>
                </div>
              )}

              {/* Camera Permission / Error Fallback */}
              {!cameraActive && (
                <div className="p-4 text-center space-y-2">
                  <AlertCircle className="w-8 h-8 text-amber-400 mx-auto" />
                  <p className="text-xs text-slate-300 max-w-xs mx-auto">
                    {cameraError || 'Démarrage de la caméra...'}
                  </p>
                  <button
                    type="button"
                    onClick={startCamera}
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 mx-auto transition"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Réessayer la Caméra</span>
                  </button>
                </div>
              )}
            </div>

            {/* Manual Barcode Input Fallback (Always available) */}
            <form onSubmit={handleManualSubmit} className="space-y-1.5">
              <label className="block text-[11px] font-bold text-slate-400">
                ⌨️ Saisie ou Scan Manuel (Clavier, Douchette USB ou Recherche) :
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Tapez le code-barres ou le nom..."
                  value={manualCode}
                  onChange={(e) => setManualCode(e.target.value)}
                  className="flex-1 p-2.5 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition"
                >
                  Valider
                </button>
              </div>

              {/* Live search suggestions matching input */}
              {filteredQuickProducts.length > 0 && (
                <div className="p-2 bg-slate-800/80 rounded-xl border border-slate-700 space-y-1 mt-1">
                  <p className="text-[10px] text-slate-400 font-bold">Produits trouvés dans le catalogue :</p>
                  <div className="space-y-1">
                    {filteredQuickProducts.map(p => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => handleBarcodeScanned(p.barcode)}
                        className="w-full text-left p-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-xs flex justify-between items-center transition"
                      >
                        <span className="font-bold text-slate-200 truncate">{p.name}</span>
                        <span className="text-[10px] text-indigo-300 font-mono">{p.barcode}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </form>

            {/* Quick Catalog Shortcuts for testing */}
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <p className="text-[11px] font-bold text-slate-400">⚡ Codes-barres rapides de test :</p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => handleBarcodeScanned('3360372058878')}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-left text-xs border border-slate-700 transition"
                >
                  <span className="font-bold text-indigo-400 block truncate">Sauvage Dior 100ml</span>
                  <span className="text-[10px] text-slate-400 font-mono">3360372058878</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleBarcodeScanned('3145891263007')}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-left text-xs border border-slate-700 transition"
                >
                  <span className="font-bold text-pink-400 block truncate">Coco Mademoiselle</span>
                  <span className="text-[10px] text-slate-400 font-mono">3145891263007</span>
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* Scanned Result Confirmation & Edit */
          <div className="space-y-4 animate-in zoom-in-95 duration-150">
            <div className="p-3 bg-emerald-950/40 border border-emerald-800 rounded-2xl flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-emerald-400 font-bold">
                <Check className="w-4 h-4" />
                <span>Code Détecté : {scannedProduct.barcode}</span>
              </div>
              <span className="text-[10px] bg-emerald-900 px-2 py-0.5 rounded text-emerald-200 font-bold">Vérifié ✅</span>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-400 mb-1">Nom du Produit :</label>
                <input
                  type="text"
                  value={correctionData.name}
                  onChange={(e) => setCorrectionData({ ...correctionData, name: e.target.value })}
                  className="w-full p-2.5 bg-slate-800 border border-slate-700 rounded-xl font-bold text-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-400 mb-1">Marque :</label>
                  <input
                    type="text"
                    value={correctionData.brand}
                    onChange={(e) => setCorrectionData({ ...correctionData, brand: e.target.value })}
                    className="w-full p-2 bg-slate-800 border border-slate-700 rounded-xl text-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-400 mb-1">Catégorie :</label>
                  <input
                    type="text"
                    value={correctionData.category}
                    onChange={(e) => setCorrectionData({ ...correctionData, category: e.target.value })}
                    className="w-full p-2 bg-slate-800 border border-slate-700 rounded-xl text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-400 mb-1">Prix de Vente ({currency}) :</label>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={correctionData.sellPrice}
                    onChange={(e) => setCorrectionData({ ...correctionData, sellPrice: sanitizeDecimalInput(e.target.value) })}
                    className="w-full p-2 bg-slate-800 border border-slate-700 rounded-xl font-extrabold text-indigo-400"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-400 mb-1">Quantité :</label>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={correctionData.stock}
                    onChange={(e) => setCorrectionData({ ...correctionData, stock: sanitizeDecimalInput(e.target.value) })}
                    className="w-full p-2 bg-slate-800 border border-slate-700 rounded-xl font-bold text-white"
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={handleResumeScanning}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs transition"
              >
                Reprendre le Scan 📷
              </button>
              <button
                type="button"
                onClick={handleConfirmAdd}
                className="flex-1 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold rounded-xl text-xs shadow-lg transition"
              >
                Ajouter au Panier / Valider ✅
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
