import React, { useState } from 'react';
import { 
  Store, 
  Sparkles, 
  ShieldCheck, 
  ArrowRight, 
  ArrowLeft, 
  Check, 
  Lock, 
  Key, 
  Eye, 
  EyeOff, 
  Phone, 
  MapPin, 
  Globe2, 
  Building2, 
  DollarSign, 
  Briefcase, 
  CheckCircle2, 
  ShoppingBag,
  Moon,
  Sun,
  AlertCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { db, clearAllDemoData, generateSalt, hashPinWithSalt } from '../db';
import { useToast } from '../context/ToastContext';
import { BUSINESS_TYPES, COUNTRY_OPTIONS, CURRENCY_OPTIONS } from './CreateShopModal';

const MOROCCAN_CITIES = [
  'Casablanca', 'Rabat', 'Marrakech', 'Tanger', 'Fès', 
  'Agadir', 'Oujda', 'Kenitra', 'Tétouan', 'Meknès', 
  'El Jadida', 'Nador', 'Béni Mellal', 'Autre ville'
];

export default function WelcomeOnboardingView({
  settings,
  onUpdateSettings,
  onRefreshData,
  onStartDemo,
  currentLang = 'fr',
  onLangChange,
  theme = 'light',
  onToggleTheme
}) {
  const toast = useToast();

  // Mode de vue : 'welcome' (choix initial) ou 'wizard' (assistant en 3 étapes)
  const [viewMode, setViewMode] = useState('welcome');
  const [step, setStep] = useState(1);

  // Form State
  const [shopName, setShopName] = useState(
    settings?.shopName && settings.shopName !== 'Boutique VenteFacile' ? settings.shopName : ''
  );
  const [businessType, setBusinessType] = useState(settings?.businessType || 'epicerie');
  const [phone, setPhone] = useState(settings?.phone || '');
  const [city, setCity] = useState(settings?.city || 'Casablanca');
  const [customCity, setCustomCity] = useState('');
  const [street, setStreet] = useState(settings?.street || '');
  const [country, setCountry] = useState(settings?.country || 'Maroc');
  const [currency, setCurrency] = useState(settings?.currency || 'DH');
  const [adminPin, setAdminPin] = useState('');
  const [confirmAdminPin, setConfirmAdminPin] = useState('');
  const [showAdminPin, setShowAdminPin] = useState(false);
  const [startClean, setStartClean] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const isRTL = currentLang === 'ar';

  const handleNextStep = () => {
    setError('');
    if (step === 1) {
      if (!shopName.trim()) {
        setError(isRTL ? 'يرجى إدخال اسم متجرك.' : 'Veuillez saisir le nom de votre boutique.');
        return;
      }
      setStep(2);
    } else if (step === 2) {
      const selectedCity = city === 'Autre ville' ? customCity : city;
      if (!selectedCity.trim()) {
        setError(isRTL ? 'يرجى تحديد أو كتابة اسم المدينة.' : 'Veuillez indiquer la ville de votre commerce.');
        return;
      }
      setStep(3);
    }
  };

  const handleFinalSubmit = async (e) => {
    if (e) e.preventDefault();
    setError('');

    // Validation Sécurité PIN
    if (!adminPin.trim()) {
      setError(isRTL ? 'يرجى تعيين رمز PIN للمسؤول لحماية المتجر.' : 'Veuillez définir votre code PIN Gérant personnel.');
      return;
    }
    if (!/^\d{4,8}$/.test(adminPin.trim())) {
      setError(isRTL ? 'يجب أن يتكون رمز PIN من 4 إلى 8 أرقام.' : 'Le code PIN doit comporter entre 4 et 8 chiffres numériques.');
      return;
    }
    if (adminPin.trim() === '1234') {
      setError(
        isRTL 
          ? 'لأسباب أمنية، يرجى اختيار رمز PIN مختلف عن الرمز الافتراضي (1234).' 
          : 'Pour votre sécurité, veuillez choisir un code PIN différent du code d\'usine par défaut (1234).'
      );
      return;
    }
    if (adminPin.trim() !== confirmAdminPin.trim()) {
      setError(isRTL ? 'رمزا PIN غير متطابقين.' : 'Les deux codes PIN saisis ne correspondent pas.');
      return;
    }

    setIsSubmitting(true);

    try {
      if (startClean) {
        await clearAllDemoData();
      }

      // Hachage cryptographique sécurisé SHA-256 avec sel 128-bit
      const adminSalt = generateSalt();
      const adminHash = await hashPinWithSalt(adminPin.trim(), adminSalt);

      const effectiveCity = city === 'Autre ville' ? customCity.trim() : city.trim();
      const addressParts = [street.trim(), effectiveCity, country.trim()].filter(Boolean);
      const fullAddress = addressParts.join(', ');

      let updatedTeam = Array.isArray(settings?.team) ? [...settings.team] : [];
      let patronFound = false;
      updatedTeam = updatedTeam.map(member => {
        if (member.role === 'patron' || member.id === 'usr_patron_1') {
          patronFound = true;
          return {
            ...member,
            pinHash: adminHash,
            pinSalt: adminSalt,
            phone: phone.trim()
          };
        }
        return member;
      });

      if (!patronFound) {
        updatedTeam.unshift({
          id: 'usr_patron_1',
          name: 'Patron',
          role: 'patron',
          pinHash: adminHash,
          pinSalt: adminSalt,
          phone: phone.trim(),
          avatarColor: '#4f46e5',
          createdAt: new Date().toISOString(),
          permissions: {
            canManageCashiers: true,
            canManageProducts: true,
            canManageSuppliers: true,
            canViewProfits: true,
            canCloseCash: true
          }
        });
      }

      const updatedSettings = {
        ...settings,
        shopName: shopName.trim(),
        businessType: businessType,
        phone: phone.trim(),
        city: effectiveCity,
        street: street.trim(),
        country: country.trim(),
        address: fullAddress,
        currency: currency,
        isStoreConfigured: true,
        securityEnabled: true,
        adminPinHash: adminHash,
        adminPinSalt: adminSalt,
        team: updatedTeam
      };

      // Persistence
      sessionStorage.setItem('onboarding_wizard_dismissed', '1');
      await db.settings.update(1, updatedSettings);
      if (onUpdateSettings) await onUpdateSettings(updatedSettings);
      if (onRefreshData) await onRefreshData();

      // Confetti
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.5 }
      });

      toast.success(
        isRTL 
          ? `تم تفعيل متجرك "${shopName.trim()}" بنجاح! مرحباً بك.` 
          : `Félicitations ! Votre boutique "${shopName.trim()}" est active et prête à encaisser.`,
        isRTL ? "تم الإطلاق بنجاح" : "Boutique Prête"
      );
    } catch (err) {
      console.error(err);
      setError(err.message || 'Une erreur est survenue lors de l\'activation.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className={`min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-between selection:bg-indigo-500 selection:text-white ${isRTL ? 'font-arabic' : 'font-sans'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      
      {/* Top Brand Bar */}
      <header className="px-4 sm:px-8 py-4 border-b border-slate-800 bg-slate-950/80 backdrop-blur-md flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/30">
            <Store className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-black text-lg tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 via-purple-300 to-pink-400">
                VenteFacile Pro
              </span>
              <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                🇲🇦 Édition Maroc
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              {isRTL ? 'نظام الكاشير وإدارة المخزون الذكي للأنشطة التجارية' : 'Système de caisse & gestion commerciale tout-en-un'}
            </p>
          </div>
        </div>

        {/* Language & Theme Controls */}
        <div className="flex items-center gap-2">
          {/* Lang Selector */}
          <div className="flex items-center bg-slate-800/80 rounded-xl p-1 border border-slate-700/60">
            <button
              onClick={() => onLangChange && onLangChange('fr')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${currentLang === 'fr' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
            >
              Français 🇫🇷
            </button>
            <button
              onClick={() => onLangChange && onLangChange('ar')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${currentLang === 'ar' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
            >
              العربية 🇲🇦
            </button>
          </div>

          {/* Theme Toggle */}
          <button
            onClick={onToggleTheme}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition border border-slate-700/60"
            title="Basculer le thème"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Main Body */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-8">
        <div className="w-full max-w-4xl mx-auto">
          
          {/* VUE 1 : CHOIX INITIAL IMMERSIF (THE DUAL GATEWAY) */}
          {viewMode === 'welcome' && (
            <div className="space-y-8 animate-in fade-in zoom-in-95 duration-300">
              
              {/* Hero Headline */}
              <div className="text-center space-y-3 max-w-2xl mx-auto">
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-indigo-500/20 to-purple-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-bold shadow-inner">
                  <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
                  <span>{isRTL ? 'إعداد أول مرة سريع في 60 ثانية' : 'Configuration initiale express en 1 minute'}</span>
                </div>
                <h1 className="text-2xl sm:text-4xl font-black tracking-tight text-white leading-tight">
                  {isRTL ? 'مرحباً بك في متجرك الرقمي الجديد 🚀' : 'Bienvenue dans votre nouvelle caisse tactile 🚀'}
                </h1>
                <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                  {isRTL 
                    ? 'اختر كيف تود البدء اليوم : إما إنشاء متجرك الحقيقي بحسابات نظيفة ومستقلة، أو تجربة الميزات بالبضائع التوضيحية.' 
                    : 'Choisissez comment vous souhaitez commencer : activez votre vrai commerce pour démarrer à zéro (0.00 DH), ou testez librement avec des données fictives.'}
                </p>
              </div>

              {/* Dual Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-6 pt-2">
                
                {/* CARD 1 : MON VRAI MAGASIN (RECOMMANDÉ) */}
                <div 
                  onClick={() => setViewMode('wizard')}
                  className="group relative rounded-3xl p-6 sm:p-8 bg-gradient-to-b from-slate-800/90 to-slate-900 border-2 border-indigo-500/60 hover:border-indigo-400 shadow-2xl hover:shadow-indigo-500/20 transition-all duration-300 cursor-pointer flex flex-col justify-between hover:-translate-y-1"
                >
                  <div className="absolute top-4 right-4">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 text-white text-[11px] font-black shadow-md shadow-emerald-500/30 tracking-wide uppercase">
                      <Check className="w-3 h-3" /> {isRTL ? 'موصى به للتجارة' : 'Recommandé'}
                    </span>
                  </div>

                  <div className="space-y-4">
                    <div className="w-14 h-14 rounded-2xl bg-indigo-600/30 border border-indigo-500/40 text-indigo-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Store className="w-7 h-7 text-indigo-400" />
                    </div>
                    <div>
                      <h2 className="text-xl sm:text-2xl font-black text-white group-hover:text-indigo-300 transition">
                        {isRTL ? '🚀 إنشاء وتفعيل متجري الحقيقي' : '🚀 Activer ma Vraie Boutique'}
                      </h2>
                      <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
                        {isRTL 
                          ? 'ابدأ مباشرة بحسابات نظيفة 0.00 درهم، بدون بضائع تجريبية. سيظهر اسمك ورقم هاتفك على التوصيلات والفواتير.' 
                          : 'Démarrez votre comptabilité à zéro (0.00 DH) sans articles fictifs. Vos vraies coordonnées et votre PIN sécurisé seront activés.'}
                      </p>
                    </div>

                    <ul className="space-y-2.5 pt-2 text-xs text-slate-300">
                      <li className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>{isRTL ? 'قاعدة بيانات نظيفة 100% جاهزة لسلعك الحقيقية' : 'Comptabilité 100% propre prête pour vos vrais articles'}</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>{isRTL ? 'توصيلات رسمية باسم محلك ورقم الواتساب الخاص بك' : 'Tickets officiels avec le nom de votre boutique et WhatsApp'}</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>{isRTL ? 'رمز PIN سري للمدير بدلاً من رمز المصنع (1234)' : 'Code PIN secret personnel pour remplacer le code d\'usine (1234)'}</span>
                      </li>
                    </ul>
                  </div>

                  <div className="pt-6">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setViewMode('wizard');
                      }}
                      className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 hover:from-indigo-500 hover:to-purple-500 text-white font-black text-sm shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-2 transition active:scale-95 group-hover:shadow-indigo-500/40"
                    >
                      <span>{isRTL ? 'تهيئة المتجر الآن (دقيقة واحدة)' : 'Configurer mon Magasin (1 min)'}</span>
                      <ArrowRight className="w-4 h-4 rtl:rotate-180" />
                    </button>
                  </div>
                </div>

                {/* CARD 2 : MODE ESSAI / DÉCOUVERTE */}
                <div 
                  onClick={onStartDemo}
                  className="group relative rounded-3xl p-6 sm:p-8 bg-slate-800/50 hover:bg-slate-800/80 border border-slate-700/80 hover:border-slate-600 shadow-xl transition-all duration-300 cursor-pointer flex flex-col justify-between hover:-translate-y-1"
                >
                  <div className="absolute top-4 right-4">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-700 text-slate-300 text-[11px] font-extrabold border border-slate-600">
                      🧪 {isRTL ? 'للتجربة والاكتشاف' : 'Mode Essai'}
                    </span>
                  </div>

                  <div className="space-y-4">
                    <div className="w-14 h-14 rounded-2xl bg-slate-700/50 text-slate-300 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Sparkles className="w-7 h-7 text-amber-400" />
                    </div>
                    <div>
                      <h2 className="text-xl sm:text-2xl font-black text-slate-200 group-hover:text-white transition">
                        {isRTL ? '🌟 استكشاف بضائع تجريبية' : '🌟 Découvrir avec des Exemples'}
                      </h2>
                      <p className="text-xs sm:text-sm text-slate-400 mt-2 leading-relaxed">
                        {isRTL 
                          ? 'جرب الشاشة والبيع وطباعة التوصيلات ببيانات وأسعار افتراضية جاهزة لتفهم كل ميزات البرنامج أولاً.' 
                          : 'Testez la caisse, les tickets et les graphiques avec des produits pré-remplis pour vous familiariser avant de vous lancer.'}
                      </p>
                    </div>

                    <ul className="space-y-2.5 pt-2 text-xs text-slate-400">
                      <li className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-indigo-400 shrink-0" />
                        <span>{isRTL ? 'منتجات جاهزة (هواتف، عطور، قهوة...) لاختبار البيع' : 'Produits prêts à l\'emploi pour tester l\'encaissement'}</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-indigo-400 shrink-0" />
                        <span>{isRTL ? 'لا تلزمك بأي شيء، يمكنك تفريغها والبدء في أي وقت' : 'Rien n\'est définitif, basculez vers votre vrai magasin à tout moment'}</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-indigo-400 shrink-0" />
                        <span>{isRTL ? 'زر تحويل دائم سيبقى ظاهراً في الأعلى' : 'Un bandeau d\'activation restera disponible en haut de l\'écran'}</span>
                      </li>
                    </ul>
                  </div>

                  <div className="pt-6">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (onStartDemo) onStartDemo();
                      }}
                      className="w-full py-3.5 px-6 rounded-2xl bg-slate-700 hover:bg-slate-600 text-slate-200 font-bold text-sm border border-slate-600 flex items-center justify-center gap-2 transition active:scale-95"
                    >
                      <span>{isRTL ? 'الدخول كنسخة تجريبية' : 'Explorer en Mode Démo'}</span>
                      <ArrowRight className="w-4 h-4 rtl:rotate-180" />
                    </button>
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* VUE 2 : WIZARD GUIDÉ EN 3 ÉTAPES ULTRA-VISUELLES */}
          {viewMode === 'wizard' && (
            <div className="bg-slate-800/90 border border-slate-700/80 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-bottom-4 duration-300">
              
              {/* Stepper Progress Bar */}
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <button
                    onClick={() => {
                      if (step === 1) setViewMode('welcome');
                      else setStep(step - 1);
                    }}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-white transition cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
                    <span>{step === 1 ? (isRTL ? 'الرجوع للخيارات' : 'Retour à l\'accueil') : (isRTL ? 'السابق' : 'Étape précédente')}</span>
                  </button>

                  <span className="text-xs font-extrabold uppercase tracking-wider text-indigo-400">
                    {isRTL ? `المرحلة ${step} من 3` : `Étape ${step} sur 3`}
                  </span>
                </div>

                {/* Progress bar line */}
                <div className="w-full h-2 rounded-full bg-slate-700/80 overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-400 transition-all duration-300"
                    style={{ width: `${(step / 3) * 100}%` }}
                  />
                </div>

                {/* Step labels */}
                <div className="grid grid-cols-3 text-center mt-2 text-[11px] font-bold text-slate-400">
                  <span className={step >= 1 ? 'text-indigo-400 font-black' : ''}>
                    1. {isRTL ? 'النشاط والاسم' : 'Métier & Nom'}
                  </span>
                  <span className={step >= 2 ? 'text-indigo-400 font-black' : ''}>
                    2. {isRTL ? 'المدينة والاتصال' : 'Ville & Contact'}
                  </span>
                  <span className={step >= 3 ? 'text-emerald-400 font-black' : ''}>
                    3. {isRTL ? 'الحماية و PIN' : 'Sécurité & PIN'}
                  </span>
                </div>
              </div>

              {/* Error Alert */}
              {error && (
                <div className="mb-5 p-3.5 rounded-2xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-bold flex items-center gap-2 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                  <span>{error}</span>
                </div>
              )}

              {/* ÉTAPE 1 : IDENTITÉ & MÉTIER */}
              {step === 1 && (
                <div className="space-y-5 animate-in fade-in">
                  <div className="space-y-1">
                    <h3 className="text-lg font-black text-white">
                      {isRTL ? '1. ما هو اسم ونشاط متجرك ؟' : '1. Quel est le nom et l\'activité de votre boutique ?'}
                    </h3>
                    <p className="text-xs text-slate-400">
                      {isRTL ? 'سيظهر هذا الاسم مباشرة على شاشتك وعلى ترويسة التوصيلات الورقية ورسائل الواتساب.' : 'Ce nom figurera sur vos tickets de caisse, factures proforma et reçus WhatsApp.'}
                    </p>
                  </div>

                  {/* Shop Name Input */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                      <span>{isRTL ? 'اسم المتجر / المحل' : 'Nom commercial du Magasin'} <strong className="text-rose-400">*</strong></span>
                    </label>
                    <input
                      type="text"
                      autoFocus
                      required
                      placeholder={isRTL ? 'مثال: سوبرماركت البركة، بارفان رويال، فون ستور...' : 'Ex: Supérette Al Baraka, Parfumerie Royale, TechStore Maroc...'}
                      value={shopName}
                      onChange={(e) => setShopName(e.target.value)}
                      className="w-full p-3.5 text-sm bg-slate-900 border border-slate-700 rounded-2xl focus:ring-2 focus:ring-indigo-500 font-black text-white placeholder-slate-500 shadow-inner"
                    />
                  </div>

                  {/* Grid Métiers */}
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                      <Briefcase className="w-3.5 h-3.5 text-indigo-400" />
                      <span>{isRTL ? 'نوع النشاط التجاري (يضبط الوحدات والضرائب تلقائياً)' : 'Secteur d\'activité (adapte les unités et la caisse)'}</span>
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-56 overflow-y-auto custom-scrollbar p-1">
                      {BUSINESS_TYPES.map(b => (
                        <div
                          key={b.id}
                          onClick={() => setBusinessType(b.id)}
                          className={`p-3 rounded-2xl border text-left cursor-pointer transition flex items-start gap-2.5 ${businessType === b.id ? 'bg-indigo-600/30 border-indigo-500 text-white shadow-md' : 'bg-slate-900/60 border-slate-700/60 text-slate-300 hover:bg-slate-900 hover:border-slate-600'}`}
                        >
                          <div className="flex-1">
                            <span className="font-extrabold text-xs block">{b.label}</span>
                            <span className="text-[10px] text-slate-400 block mt-0.5 line-clamp-1">{b.desc}</span>
                          </div>
                          {businessType === b.id && <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0" />}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Action Button */}
                  <div className="pt-3 flex justify-end">
                    <button
                      type="button"
                      onClick={handleNextStep}
                      className="py-3 px-6 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs flex items-center gap-2 transition active:scale-95 shadow-lg shadow-indigo-600/30 cursor-pointer"
                    >
                      <span>{isRTL ? 'المتابعة للمدينة والاتصال' : 'Continuer vers Ville & Contact'}</span>
                      <ArrowRight className="w-4 h-4 rtl:rotate-180" />
                    </button>
                  </div>
                </div>
              )}

              {/* ÉTAPE 2 : VILLE, CONTACT & DEVISE */}
              {step === 2 && (
                <div className="space-y-5 animate-in fade-in">
                  <div className="space-y-1">
                    <h3 className="text-lg font-black text-white">
                      {isRTL ? '2. أين يقع متجرك ورقم الاتصال ؟' : '2. Où est situé votre commerce & Coordonnées ?'}
                    </h3>
                    <p className="text-xs text-slate-400">
                      {isRTL ? 'يُستخدم رقم الهاتف لإرسال التوصيلات عبر الواتساب للزبائن بنقرة واحدة.' : 'Le numéro de téléphone permettra l\'envoi direct des tickets de caisse par WhatsApp.'}
                    </p>
                  </div>

                  {/* Phone / WhatsApp */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-indigo-400" />
                      <span>{isRTL ? 'رقم الهاتف / الواتساب الرسمي للمتجر' : 'Téléphone / WhatsApp officiel'}</span>
                    </label>
                    <input
                      type="tel"
                      placeholder="Ex: +212 6 12 34 56 78"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full p-3 text-sm bg-slate-900 border border-slate-700 rounded-2xl focus:ring-2 focus:ring-indigo-500 font-mono text-white placeholder-slate-500"
                    />
                  </div>

                  {/* Ville Marocaine en 1 Clic */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-indigo-400" />
                      <span>{isRTL ? 'المدينة (اختيار سريع)' : 'Ville au Maroc (clic rapide)'} <strong className="text-rose-400">*</strong></span>
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {MOROCCAN_CITIES.map(c => (
                        <button
                          key={c}
                          type="button"
                          onClick={() => setCity(c)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer border ${city === c ? 'bg-indigo-600 text-white border-indigo-500 shadow' : 'bg-slate-900 text-slate-300 border-slate-700 hover:bg-slate-800'}`}
                        >
                          {c}
                        </button>
                      ))}
                    </div>

                    {city === 'Autre ville' && (
                      <input
                        type="text"
                        autoFocus
                        required
                        placeholder="Saisissez le nom de votre ville..."
                        value={customCity}
                        onChange={(e) => setCustomCity(e.target.value)}
                        className="w-full mt-2 p-2.5 text-xs bg-slate-900 border border-indigo-500 rounded-xl text-white font-bold"
                      />
                    )}
                  </div>

                  {/* Devise */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-300 flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-indigo-400" />
                        <span>{isRTL ? 'الحي / الشارع' : 'Quartier / Adresse (optionnel)'}</span>
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: Boulevard Hassan II, Maarif"
                        value={street}
                        onChange={(e) => setStreet(e.target.value)}
                        className="w-full p-2.5 text-xs bg-slate-900 border border-slate-700 rounded-xl text-white"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-300 flex items-center gap-1">
                        <DollarSign className="w-3 h-3 text-indigo-400" />
                        <span>{isRTL ? 'العملة' : 'Devise'}</span>
                      </label>
                      <select
                        value={currency}
                        onChange={(e) => setCurrency(e.target.value)}
                        className="w-full p-2.5 text-xs bg-slate-900 border border-slate-700 rounded-xl text-white font-bold"
                      >
                        {CURRENCY_OPTIONS.map(c => (
                          <option key={c.code} value={c.code}>{c.label}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="pt-3 flex justify-between">
                    <button
                      type="button"
                      onClick={() => setStep(1)}
                      className="py-3 px-5 rounded-2xl bg-slate-700 hover:bg-slate-600 text-slate-300 font-bold text-xs transition cursor-pointer"
                    >
                      {isRTL ? 'السابق' : 'Retour'}
                    </button>
                    <button
                      type="button"
                      onClick={handleNextStep}
                      className="py-3 px-6 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs flex items-center gap-2 transition active:scale-95 shadow-lg shadow-indigo-600/30 cursor-pointer"
                    >
                      <span>{isRTL ? 'المتابعة للحماية و PIN' : 'Continuer vers Sécurité & PIN'}</span>
                      <ArrowRight className="w-4 h-4 rtl:rotate-180" />
                    </button>
                  </div>
                </div>
              )}

              {/* ÉTAPE 3 : SÉCURITÉ & PIN GÉRANT */}
              {step === 3 && (
                <form onSubmit={handleFinalSubmit} className="space-y-5 animate-in fade-in">
                  <div className="space-y-1">
                    <h3 className="text-lg font-black text-white">
                      {isRTL ? '3. حماية المتجر ورمز PIN السري للمدير 🔐' : '3. Sécurité d\'Accès & Code PIN Gérant 🔐'}
                    </h3>
                    <p className="text-xs text-slate-400">
                      {isRTL 
                        ? 'اختر رمز PIN شخصي (4 إلى 8 أرقام) لحماية الأرباح والإغلاق اليومي للدرج (Z-Report). استبدل رمز المصنع (1234).' 
                        : 'Définissez votre code secret personnel (4 à 8 chiffres). Ce PIN protège la caisse, les bénéfices et la clôture Z.'}
                    </p>
                  </div>

                  {/* PIN Inputs */}
                  <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-700/80 space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* PIN Gérant */}
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                          <span className="flex items-center gap-1.5">
                            <Key className="w-3.5 h-3.5 text-amber-400" />
                            <span>{isRTL ? 'رمز PIN الجديد' : 'Nouveau Code PIN Gérant'} <strong className="text-rose-400">*</strong></span>
                          </span>
                          <button
                            type="button"
                            onClick={() => setShowAdminPin(!showAdminPin)}
                            className="text-[11px] text-indigo-400 hover:underline flex items-center gap-1 cursor-pointer"
                          >
                            {showAdminPin ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                            <span>{showAdminPin ? (isRTL ? 'إخفاء' : 'Masquer') : (isRTL ? 'إظهار' : 'Afficher')}</span>
                          </button>
                        </label>
                        <input
                          type={showAdminPin ? 'text' : 'password'}
                          inputMode="numeric"
                          maxLength={8}
                          required
                          autoFocus
                          placeholder="Ex: 8520"
                          value={adminPin}
                          onChange={(e) => setAdminPin(e.target.value.replace(/\D/g, ''))}
                          className="w-full p-3 text-lg bg-slate-950 border border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 font-mono tracking-widest text-center text-white"
                        />
                      </div>

                      {/* Confirmation PIN */}
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                          <span>{isRTL ? 'تأكيد رمز PIN' : 'Confirmer le Code PIN'} <strong className="text-rose-400">*</strong></span>
                        </label>
                        <input
                          type={showAdminPin ? 'text' : 'password'}
                          inputMode="numeric"
                          maxLength={8}
                          required
                          placeholder="Ex: 8520"
                          value={confirmAdminPin}
                          onChange={(e) => setConfirmAdminPin(e.target.value.replace(/\D/g, ''))}
                          className="w-full p-3 text-lg bg-slate-950 border border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 font-mono tracking-widest text-center text-white"
                        />
                      </div>
                    </div>

                    <p className="text-[11px] text-amber-300/80 bg-amber-500/10 p-2.5 rounded-xl border border-amber-500/20">
                      ⚠️ {isRTL 
                        ? 'ملاحظة مهمة : يمنع استخدام الرمز الافتراضي (1234) لضمان حماية أسرار متجرك.' 
                        : 'Règle de sécurité : Le code d\'usine 1234 est interdit pour protéger vos données commerciales.'}
                    </p>
                  </div>

                  {/* Option Base Propre */}
                  <div className="p-3.5 rounded-2xl bg-indigo-500/10 border border-indigo-500/30">
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={startClean}
                        onChange={(e) => setStartClean(e.target.checked)}
                        className="mt-1 rounded text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                      />
                      <div className="text-xs">
                        <span className="font-extrabold text-indigo-200 block">
                          {isRTL ? '✓ بدء بحسابات نظيفة 100% (تفريغ كل البضائع والزبائن التجريبيين)' : '✓ Démarrer avec une base 100% propre (Recommandé)'}
                        </span>
                        <span className="text-slate-400 text-[11px] block mt-0.5">
                          {isRTL 
                            ? 'يحذف المنتجات الوهمية لتسجل بضائعك الحقيقية من أول يوم وبدون أي خلط.' 
                            : 'Purge tous les articles fictifs pour démarrer votre stock réel et votre caisse à 0.00 DH.'}
                        </span>
                      </div>
                    </label>
                  </div>

                  {/* Submit Button */}
                  <div className="pt-3 flex justify-between items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setStep(2)}
                      className="py-3 px-5 rounded-2xl bg-slate-700 hover:bg-slate-600 text-slate-300 font-bold text-xs transition cursor-pointer"
                    >
                      {isRTL ? 'السابق' : 'Retour'}
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="py-3.5 px-8 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-600 to-emerald-600 hover:from-emerald-400 hover:to-teal-500 text-white font-black text-sm shadow-xl shadow-emerald-600/30 flex items-center gap-2 transition active:scale-95 disabled:opacity-50 cursor-pointer"
                    >
                      <Check className="w-5 h-5" />
                      <span>{isSubmitting ? (isRTL ? 'جاري الإطلاق...' : 'Activation en cours...') : (isRTL ? 'تفعيل متجري وبدء البيع الآن 🚀' : 'Activer mon Magasin & Lancer la Caisse 🚀')}</span>
                    </button>
                  </div>
                </form>
              )}

            </div>
          )}

        </div>
      </main>

      {/* Footer */}
      <footer className="px-4 py-3 border-t border-slate-800 bg-slate-950/60 text-center text-xs text-slate-500">
        <span>VenteFacile Pro • Conçu pour les commerçants indépendants • Données 100% sécurisées en local et Cloud</span>
      </footer>

    </div>
  );
}
