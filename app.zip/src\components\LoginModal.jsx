import React, { useState } from 'react';
import { Lock, QrCode, KeyRound, AlertCircle, X, ShieldCheck, UserCheck, Crown } from 'lucide-react';
import { verifyPin } from '../authSecurity';

export default function LoginModal({ settings, onLoginSuccess, onOpenQRScanner, onClose }) {
  const [selectedRole, setSelectedRole] = useState('caissier'); // 'caissier' | 'admin'
  const [passwordInput, setPasswordInput] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    setErrorMsg('');

    if (selectedRole === 'admin') {
      const isValidAdmin = await verifyPin(
        passwordInput, 
        settings.adminPinHash || settings.adminPasswordHash, 
        settings.adminPinSalt, 
        '1234'
      );
      if (isValidAdmin) {
        onLoginSuccess({ role: 'admin' });
      } else {
        setErrorMsg('❌ Mot de passe Administrateur incorrect (Défaut : 1234)');
      }
    } else {
      // Role Caissier
      const isValidCashier = await verifyPin(
        passwordInput, 
        settings.cashierPinHash || settings.cashierPasswordHash, 
        settings.cashierPinSalt, 
        '0000'
      );
      // Admin PIN can also unlock cashier mode
      const isValidAdmin = await verifyPin(
        passwordInput, 
        settings.adminPinHash || settings.adminPasswordHash, 
        settings.adminPinSalt, 
        '1234'
      );

      if (isValidCashier) {
        onLoginSuccess({ role: 'caissier' });
      } else if (isValidAdmin) {
        onLoginSuccess({ role: 'admin' });
      } else {
        setErrorMsg('❌ Code PIN Caissier incorrect (Défaut : 0000)');
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-md w-full border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto no-scrollbar">
        
        {/* Close Button */}
        {onClose && (
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            title="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Header Icon & Shop Name */}
        <div className="text-center pt-2">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-600 to-purple-600 text-white flex items-center justify-center mx-auto mb-2 shadow-lg shadow-indigo-500/30">
            <Lock className="w-7 h-7" />
          </div>
          <h3 className="font-extrabold text-lg text-slate-900 dark:text-white font-display">
            {settings.shopName || 'Boutique VenteFacile'}
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Sélectionnez votre profil d'accès sécurisé
          </p>
        </div>

        {/* Role Selector Tabs (Caissier vs Admin) */}
        <div className="grid grid-cols-2 gap-2 p-1.5 bg-slate-100 dark:bg-slate-800/80 rounded-2xl">
          <button
            type="button"
            onClick={() => {
              setSelectedRole('caissier');
              setPasswordInput('');
              setErrorMsg('');
            }}
            className={`py-2.5 px-3 rounded-xl font-black text-xs flex items-center justify-center gap-2 transition ${
              selectedRole === 'caissier'
                ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-md ring-2 ring-emerald-500/20'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>💼 Caissier</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setSelectedRole('admin');
              setPasswordInput('');
              setErrorMsg('');
            }}
            className={`py-2.5 px-3 rounded-xl font-black text-xs flex items-center justify-center gap-2 transition ${
              selectedRole === 'admin'
                ? 'bg-white dark:bg-slate-900 text-purple-600 dark:text-purple-400 shadow-md ring-2 ring-purple-500/20'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Crown className="w-4 h-4" />
            <span>👑 Gérant / Admin</span>
          </button>
        </div>

        {/* Role Description Card */}
        <div className={`p-3 rounded-2xl border text-xs ${
          selectedRole === 'admin'
            ? 'bg-purple-50/50 dark:bg-purple-950/30 border-purple-200 dark:border-purple-900 text-purple-800 dark:text-purple-200'
            : 'bg-emerald-50/50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900 text-emerald-800 dark:text-emerald-200'
        }`}>
          {selectedRole === 'admin' ? (
            <p className="leading-relaxed">
              <strong>Accès Administrateur Total :</strong> Visualisation des bénéfices nets, configuration Cloud Supabase, clôture Z, gestion du stock et exports fiscaux.
            </p>
          ) : (
            <p className="leading-relaxed">
              <strong>Accès Vendeur / Caisse :</strong> Encaissement direct, tickets clients, et recherche d'articles. Les marges nettes et paramètres sensibles sont masqués.
            </p>
          )}
        </div>

        {/* QR Code Quick Unlock for Cashiers */}
        {selectedRole === 'caissier' && (
          <>
            <button
              type="button"
              onClick={onOpenQRScanner}
              className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold rounded-2xl text-xs flex items-center justify-center gap-2 shadow-md shadow-emerald-500/20 active:scale-95 transition"
            >
              <QrCode className="w-4 h-4" />
              <span>📷 Scanner le QR Code de Caisse</span>
            </button>

            <div className="relative flex py-1 items-center">
              <div className="flex-grow border-t border-slate-200 dark:border-slate-800"></div>
              <span className="flex-shrink mx-2 text-[10px] font-bold text-slate-400 uppercase">ou taper le code PIN</span>
              <div className="flex-grow border-t border-slate-200 dark:border-slate-800"></div>
            </div>
          </>
        )}

        {/* Password Form */}
        <form onSubmit={handleLogin} className="space-y-3 text-xs pb-1">
          <div>
            <label className="block font-extrabold mb-1 text-slate-700 dark:text-slate-300">
              {selectedRole === 'admin' ? 'Mot de Passe Administrateur :' : 'Code PIN Caisse (4 chiffres) :'}
            </label>
            <div className="relative">
              <KeyRound className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                type="password"
                required
                autoFocus
                placeholder={selectedRole === 'admin' ? 'Ex: 1234...' : 'Ex: 0000...'}
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <span className="text-[10px] text-slate-400 block mt-1">
              {selectedRole === 'admin' ? 'Code usine par défaut : 1234' : 'Code usine par défaut : 0000'}
            </span>
          </div>

          {errorMsg && (
            <div className="p-2.5 bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-300 rounded-xl border border-red-200 font-bold text-[11px] flex items-center gap-2 animate-shake">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <button
            type="submit"
            className={`w-full py-3 text-white font-extrabold rounded-2xl text-xs shadow-md transition flex items-center justify-center gap-2 active:scale-95 ${
              selectedRole === 'admin'
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 shadow-purple-500/20'
                : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 shadow-emerald-500/20'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Se Connecter en tant que {selectedRole === 'admin' ? 'Gérant' : 'Caissier'}</span>
          </button>

          <div className="text-center pt-1">
            <span className="inline-flex items-center gap-1.5 text-[10px] text-slate-400 font-semibold">
              <ShieldCheck className="w-3 h-3 text-emerald-500" />
              <span>Hachage SHA-256 avec Sel Cryptographique</span>
            </span>
          </div>
        </form>

      </div>
    </div>
  );
}
