/**
 * VenteFacile Pro - Hardware Barcode Scanner & Retail Audio Engine
 * Features:
 * - Background keystroke listening with burst-detection (<40ms per char)
 * - Safe input interception: Prevents barcode digits from polluting text inputs
 * - Authentic Web Audio API supermarket beep & buzz feedback (Zero latency)
 * - Global keyboard shortcuts: F12 (Open Drawer), F4 (Custom Item), F2 (TPE Pay)
 */

import { useEffect, useRef } from 'react';

// Shared Web Audio Context for zero-latency POS sounds
let audioCtx = null;

function getAudioContext() {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

/**
 * Plays crisp, authentic supermarket POS sound effect
 * @param {'beep' | 'error' | 'cash' | 'drawer'} type
 */
export function playRetailSound(type = 'beep') {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;

    if (type === 'beep') {
      // Classic high-frequency crisp supermarket scan beep (1750Hz, 60ms)
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(1750, now);

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.07);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.07);
    } else if (type === 'error') {
      // Low dual-tone buzzer for barcode not found / out of stock (250Hz, 160ms)
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(260, now);
      osc.frequency.setValueAtTime(210, now + 0.08);

      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.18);
    } else if (type === 'drawer' || type === 'cash') {
      // Cash register drawer chime / mechanical click
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(987.77, now); // B5
      osc.frequency.setValueAtTime(1318.51, now + 0.06); // E6

      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.25);
    }
  } catch (e) {
    // Audio context not allowed before user gesture
  }
}

/**
 * React Hook for global hardware barcode scanner listening
 */
export function useBarcodeScanner({
  onScan,
  onOpenDrawer,
  onQuickCustomItem,
  onQuickTPE,
  enabled = true
}) {
  const bufferRef = useRef('');
  const lastKeyTimeRef = useRef(0);
  const isBurstRef = useRef(false);

  useEffect(() => {
    if (!enabled) return;

    const handleKeyDown = (e) => {
      // 1. Function Key Shortcuts
      if (e.key === 'F12') {
        e.preventDefault();
        playRetailSound('drawer');
        onOpenDrawer?.();
        return;
      }
      if (e.key === 'F4') {
        e.preventDefault();
        onQuickCustomItem?.();
        return;
      }
      if (e.key === 'F2') {
        e.preventDefault();
        onQuickTPE?.();
        return;
      }

      const now = Date.now();
      const interval = now - lastKeyTimeRef.current;
      lastKeyTimeRef.current = now;

      // Hardware barcode scanners type at < 45ms per character
      if (interval < 50) {
        isBurstRef.current = true;
      } else if (interval > 150) {
        // Reset buffer if delay indicates manual human typing
        bufferRef.current = '';
        isBurstRef.current = false;
      }

      // Check if scanner sent Enter or Tab terminator
      if (e.key === 'Enter' || e.key === 'Tab') {
        const scannedCode = bufferRef.current.trim();
        bufferRef.current = '';

        if (scannedCode.length >= 3 && (isBurstRef.current || scannedCode.length >= 6)) {
          e.preventDefault();
          e.stopPropagation();

          // If focused on an input, clear whatever characters the scanner burst typed in it
          const activeEl = document.activeElement;
          if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA')) {
            if (activeEl.value && activeEl.value.endsWith(scannedCode)) {
              activeEl.value = activeEl.value.slice(0, -scannedCode.length);
            }
          }

          onScan?.(scannedCode);
        }
        isBurstRef.current = false;
        return;
      }

      // Collect single alphanumeric characters
      if (e.key && e.key.length === 1) {
        bufferRef.current += e.key;

        // If burst detected while inside an input, prevent input character pollution
        if (isBurstRef.current && bufferRef.current.length > 3) {
          const activeEl = document.activeElement;
          if (activeEl && ['INPUT', 'TEXTAREA'].includes(activeEl.tagName)) {
            // Keep scanner stream from polluting standard search input
            // e.preventDefault();
          }
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown, true);
    return () => window.removeEventListener('keydown', handleKeyDown, true);
  }, [enabled, onScan, onOpenDrawer, onQuickCustomItem, onQuickTPE]);

  return { playRetailSound };
}
