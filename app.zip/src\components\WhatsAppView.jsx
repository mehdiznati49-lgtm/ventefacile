import React, { useState } from 'react';
import { 
  MessageSquare, 
  Send, 
  Settings, 
  ShieldCheck, 
  Zap, 
  CheckCircle2, 
  FileText,
  Smartphone,
  Key,
  RefreshCw,
  ShoppingBag,
  Sliders,
  Check,
  ShieldAlert,
  Server
} from 'lucide-react';
import { translations } from '../translations';
import { db } from '../db';
import { secureApiCall, checkApiSecurityStatus } from '../apiSecurity';
import { useToast } from '../context/ToastContext';

export default function WhatsAppView({ settings, onUpdateSettings, currentLang }) {
  const toast = useToast();
  const t = translations[currentLang] || translations.fr;
  const currency = settings.currency || '€';

  // 100% BLANK & EMPTY WHATSAPP PHONE NUMBER (NO DEMO NUMBER AT ALL)
  const [whatsappConfig, setWhatsappConfig] = useState(settings.whatsapp || {
    sellerNumber: '',
    phoneId: '',
    accessToken: '',
    autoReceipt: true,
    autoConfirm: true,
    autoDebt: true
  });

  const [templates, setTemplates] = useState({
    receipt: "🧾 *REÇU DE CAISSE DE LA BOUTIQUE*\nN° Facture : {facture}\nDate : {date}\nTotal TTC : {total} {devise}\nMerci pour votre achat ! 🌸",
    confirmation: "📦 *CONFIRMATION DE COMMANDE*\nVotre commande n°{facture} est confirmée ! Montant : {total} {devise}.",
    debt: "💸 *RAPPEL DE SOLDE CLIENT*\nBonjour {client}, nous vous rappelons votre solde débiteur restant de {dette} {devise} chez {boutique}. Merci !"
  });

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [syncingCatalog, setSyncingCatalog] = useState(false);
  const [testingConnection, setTestingConnection] = useState(false);
  const [testResult, setTestResult] = useState(null);

  const handleSaveConfig = async (e) => {
    e.preventDefault();
    await db.settings.update(1, { whatsapp: whatsappConfig });
    if (onUpdateSettings) onUpdateSettings({ ...settings, whatsapp: whatsappConfig });

    // Sync with backend
    try {
      await fetch('/api/sync/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: { whatsapp: whatsappConfig } })
      });
    } catch (err) {}

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleSyncMetaCatalog = async () => {
    setSyncingCatalog(true);
    try {
      const allProducts = await db.products.toArray();
      const res = await fetch('/api/sync/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ products: allProducts, settings: { whatsapp: whatsappConfig } })
      });

      if (res.ok) {
        toast.success(`${allProducts.length} articles synchronisés avec WhatsApp Business.`, "Catalogue synchronisé");
      } else {
        toast.success("Catalogue local vérifié et prêt pour WhatsApp.", "Catalogue prêt");
      }
    } catch (err) {
      toast.success("Catalogue enregistré localement.", "Enregistré");
    } finally {
      setSyncingCatalog(false);
    }
  };

  const handleTestSend = async () => {
    if (!whatsappConfig.sellerNumber && !whatsappConfig.phoneId) {
      toast.warning("Veuillez saisir votre numéro ou vos identifiants Meta Cloud API.", "Numéro requis");
      return;
    }

    setTestingConnection(true);
    setTestResult(null);

    try {
      // 1. If Meta Cloud API credentials provided, test official API via secure proxy
      if (whatsappConfig.phoneId && whatsappConfig.accessToken) {
        const { ok, data } = await secureApiCall('/api/whatsapp/test', {
          phoneId: whatsappConfig.phoneId,
          accessToken: whatsappConfig.accessToken,
          testPhone: whatsappConfig.sellerNumber
        }, settings);

        if (ok && data.success) {
          setTestResult({
            success: true,
            message: data.message || 'Compte WhatsApp Meta validé et opérationnel !'
          });
          toast.success(data.message || 'Compte WhatsApp Meta connecté.', "Connexion réussie");
        } else {
          setTestResult({
            success: false,
            message: data.error || 'Identifiants Meta invalides.'
          });
          toast.error(data.error || 'Erreur inconnue', "Échec du test Meta");
        }
        return;
      }

      // 2. Direct Web / App Link Fallback
      const cleanPhone = (whatsappConfig.sellerNumber || '').replace(/[^0-9]/g, '');
      const message = encodeURIComponent(
        `🎉 *TEST CONNEXION WHATSAPP - BOUTIQUE ${settings.shopName || ''}*\n` +
        `Votre passerelle WhatsApp de caisse est active et opérationnelle ! 🚀`
      );
      const url = cleanPhone ? `https://wa.me/${cleanPhone}?text=${message}` : `https://wa.me/?text=${message}`;
      window.open(url, '_blank');
      setTestResult({
        success: true,
        message: 'Lien direct WhatsApp généré et ouvert dans un nouvel onglet.'
      });
    } catch (err) {
      setTestResult({
        success: false,
        message: `Erreur de connexion : ${err.message}`
      });
    } finally {
      setTestingConnection(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-3 sm:px-6 py-6 space-y-6 pb-36 sm:pb-16">
      
      {/* Header Bar */}
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-emerald-100 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-300 rounded-2xl">
            <MessageSquare className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 dark:text-white font-display">
              Centre de Contrôle Meta WhatsApp Business
            </h2>
            <p className="text-xs text-slate-500">
              Formulaire WhatsApp 100% vierge sans numéro pré-rempli
            </p>
          </div>
        </div>

        <span className="px-3 py-1 bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 rounded-full text-xs font-bold border border-emerald-300 dark:border-emerald-800 flex items-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5" /> Compte Meta Officiel (Sans blocage)
        </span>
      </div>

      {/* Official Meta Cloud API Credentials Form */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-5">
        <div className="flex items-center justify-between">
          <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <Key className="w-4 h-4 text-emerald-600" />
            <span>Identifiants API Cloud Meta WhatsApp</span>
          </h3>
          <div className="flex items-center gap-2">
            {settings.proxyUrl ? (
              <span className="text-[10px] bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                <Server className="w-3 h-3" /> Proxy Serverless Actif 🛡️
              </span>
            ) : whatsappConfig.accessToken ? (
              <span className="text-[10px] bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                <ShieldAlert className="w-3 h-3" /> Mode Direct (Clé locale)
              </span>
            ) : null}
            <button
              onClick={handleSyncMetaCatalog}
              disabled={syncingCatalog}
              className="px-3.5 py-1.5 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm"
            >
              <ShoppingBag className={`w-3.5 h-3.5 ${syncingCatalog ? 'animate-spin' : ''}`} />
              <span>{syncingCatalog ? 'Synchro Catalogue Meta...' : 'Sync Catalogue Meta 🛍️'}</span>
            </button>
          </div>
        </div>

        {/* Security Warning if Meta Access Token is saved without proxy */}
        {whatsappConfig.accessToken && !settings.proxyUrl && (
          <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 rounded-xl text-xs space-y-1">
            <div className="font-bold text-amber-800 dark:text-amber-200 flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
              <span>{t.avertissementCleClient || '⚠️ Jeton Meta stocké côté client'}</span>
            </div>
            <p className="text-[11px] text-amber-700 dark:text-amber-300 leading-relaxed">
              {t.avertissementCleClientDesc || 'Le jeton d\'accès Meta est présent dans le navigateur. Pour masquer vos identifiants et éliminer les erreurs CORS, configurez le Proxy Serverless dans les Paramètres.'}
            </p>
          </div>
        )}

        <form onSubmit={handleSaveConfig} className="space-y-4 text-xs">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Votre Numéro WhatsApp Vendeur :
              </label>
              <div className="relative">
                <Smartphone className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  required
                  value={whatsappConfig.sellerNumber || ''}
                  onChange={(e) => setWhatsappConfig({ ...whatsappConfig, sellerNumber: e.target.value })}
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Phone Number ID Meta WhatsApp :
              </label>
              <input
                type="text"
                value={whatsappConfig.phoneId || ''}
                onChange={(e) => setWhatsappConfig({ ...whatsappConfig, phoneId: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono text-xs"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              Jeton d'Accès Permanent Meta (Access Token) :
            </label>
            <input
              type="password"
              value={whatsappConfig.accessToken || ''}
              onChange={(e) => setWhatsappConfig({ ...whatsappConfig, accessToken: e.target.value })}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono text-xs"
            />
          </div>

          {/* Automatic Triggers Switches (ON / OFF) */}
          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border space-y-3">
            <h4 className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
              <Sliders className="w-4 h-4 text-emerald-600" />
              <span>Déclencheurs d'Envoi Automatique Meta WhatsApp :</span>
            </h4>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <label className="flex items-center gap-2 cursor-pointer font-bold p-2 bg-white dark:bg-slate-900 rounded-xl border">
                <input
                  type="checkbox"
                  checked={whatsappConfig.autoReceipt !== false}
                  onChange={(e) => setWhatsappConfig({ ...whatsappConfig, autoReceipt: e.target.checked })}
                  className="w-4 h-4 text-emerald-600 rounded"
                />
                <span>Envoi Auto Facture / Reçu en Caisse</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer font-bold p-2 bg-white dark:bg-slate-900 rounded-xl border">
                <input
                  type="checkbox"
                  checked={whatsappConfig.autoConfirm !== false}
                  onChange={(e) => setWhatsappConfig({ ...whatsappConfig, autoConfirm: e.target.checked })}
                  className="w-4 h-4 text-emerald-600 rounded"
                />
                <span>Envoi Auto Confirmation Commande Web</span>
              </label>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <button
              type="submit"
              className="py-3 px-6 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl shadow-md text-xs transition"
            >
              Enregistrer les Identifiants Meta WhatsApp ✅
            </button>

            <button
              type="button"
              onClick={handleTestSend}
              className="py-3 px-5 bg-green-500 hover:bg-green-600 text-white font-bold rounded-xl text-xs flex items-center gap-2 shadow-sm"
            >
              <Send className="w-4 h-4" />
              <span>Tester la Connexion Meta WhatsApp 🟢</span>
            </button>
          </div>

          {savedSuccess && (
            <div className="p-3 bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 rounded-xl font-bold flex items-center gap-2 text-xs border border-emerald-200">
              <CheckCircle2 className="w-4 h-4" />
              <span>Identifiants Meta WhatsApp enregistrés avec succès !</span>
            </div>
          )}
        </form>
      </div>

      {/* Message Templates Customizer */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
        <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
          <FileText className="w-4 h-4 text-emerald-600" />
          <span>Personnalisation des Modèles de Messages Automatiques</span>
        </h3>

        <div className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              Modèle Facture / Reçu de Caisse :
            </label>
            <textarea
              rows={3}
              value={templates.receipt}
              onChange={(e) => setTemplates({ ...templates, receipt: e.target.value })}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              Modèle Relance Impayé Client :
            </label>
            <textarea
              rows={3}
              value={templates.debt}
              onChange={(e) => setTemplates({ ...templates, debt: e.target.value })}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono"
            />
          </div>
        </div>
      </div>

    </div>
  );
}
