import React, { useState } from 'react';
import { QrCode, X, Copy, CheckCircle2, ShieldCheck, RefreshCw, Smartphone } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';

export default function QRCodeModal({ settings, onClose, onRegenerateToken }) {
  const [copied, setCopied] = useState(false);

  // Generate payload string encoding Shop Name, Currency, and Access Token
  const qrPayload = JSON.stringify({
    shop: settings.shopName || 'Boutique VenteFacile',
    currency: settings.currency || '€',
    token: settings.qrToken || 'SECRET_TOKEN_' + Date.now(),
    role: 'caissier'
  });

  const accessUrl = `${window.location.origin}${window.location.pathname}?access=${encodeURIComponent(qrPayload)}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(accessUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-sm w-full border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 relative text-center">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-12 h-12 rounded-2xl bg-indigo-100 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-300 flex items-center justify-center mx-auto shadow-sm">
          <QrCode className="w-6 h-6" />
        </div>

        <div>
          <h3 className="font-extrabold text-base text-slate-900 dark:text-white font-display">
            QR Code d'Accès Caissier
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Scannez ce QR Code avec votre smartphone pour ouvrir la caisse directement !
          </p>
        </div>

        {/* Real 2D SVG QR Code Generator (Level M error correction) */}
        <div className="p-4 bg-white rounded-2xl border-2 border-indigo-200 dark:border-indigo-800 flex flex-col items-center justify-center shadow-inner my-2">
          <div className="p-3 bg-white rounded-xl shadow-sm">
            <QRCodeSVG
              value={accessUrl}
              size={180}
              level="M"
              includeMargin={true}
            />
          </div>
          <span className="text-[10px] font-bold text-slate-500 mt-2 uppercase tracking-wider">
            {settings.shopName?.slice(0, 20) || 'ACCÈS CAISSE SÉCURISÉ'}
          </span>
        </div>

        <div className="space-y-2 text-xs">
          <button
            onClick={handleCopyLink}
            className="w-full py-2.5 bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 rounded-xl font-bold flex items-center justify-center gap-1.5"
          >
            {copied ? <CheckCircle2 className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Lien d\'Accès Copié !' : 'Copier le Lien d\'Accès 1-Clic'}</span>
          </button>

          <button
            onClick={onRegenerateToken}
            className="w-full py-2 bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 rounded-xl font-bold text-[11px] flex items-center justify-center gap-1.5"
            title="Changer le QR code pour bloquer l'ancien caissier"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Changer / Bloquer l'Accès du Caissier 🔒</span>
          </button>
        </div>

      </div>
    </div>
  );
}
