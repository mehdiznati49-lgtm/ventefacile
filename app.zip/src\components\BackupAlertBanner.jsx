import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Download, 
  X, 
  CheckCircle2, 
  HardDrive, 
  Clock, 
  AlertTriangle 
} from 'lucide-react';
import { translations } from '../translations';
import { createFullBackup, downloadBackupFile, dismissBackupAlert } from '../backupManager';
import { useToast } from '../context/ToastContext';

export default function BackupAlertBanner({ 
  currentLang = 'fr', 
  onBackupCompleted 
}) {
  const toast = useToast();
  const t = translations[currentLang] || translations.fr;
  const [isExporting, setIsExporting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  const handleBackupNow = async () => {
    setIsExporting(true);
    try {
      const backup = await createFullBackup();
      downloadBackupFile(backup.content, backup.fileName);
      setSuccess(true);
      toast.success(`Sauvegarde téléchargée (${backup.fileName}).`, "Sauvegarde réussie");
      if (onBackupCompleted) onBackupCompleted();
      setTimeout(() => {
        setDismissed(true);
      }, 3000);
    } catch (err) {
      console.error('[BackupBanner] Backup error', err);
      toast.error(err.message, "Erreur de sauvegarde");
    } finally {
      setIsExporting(false);
    }
  };

  const handleDismiss = () => {
    dismissBackupAlert();
    setDismissed(true);
  };

  return (
    <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-white px-4 py-3 shadow-md relative z-20 border-b border-amber-600">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
        
        <div className="flex items-center gap-3 text-sm">
          <div className="w-9 h-9 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center shrink-0 shadow-inner">
            <ShieldAlert className="w-5 h-5 text-white animate-pulse" />
          </div>
          <div>
            <div className="font-extrabold flex items-center gap-1.5 leading-tight">
              <span>{t.alerteSauvegardeTitre || '⚠️ Protection des Données : Sauvegarde Recommandée'}</span>
            </div>
            <p className="text-xs text-amber-100 mt-0.5 leading-snug">
              {t.alerteSauvegardeDesc || 'Votre magasin fonctionne en local. Sauvegardez vos données régulièrement pour éviter toute perte en cas de nettoyage du navigateur.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
          {success ? (
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 text-white rounded-xl text-xs font-bold shadow-sm animate-in fade-in">
              <CheckCircle2 className="w-4 h-4" />
              <span>{t.sauvegardeTelechargee || 'Sauvegarde téléchargée !'}</span>
            </div>
          ) : (
            <button
              onClick={handleBackupNow}
              disabled={isExporting}
              className="px-3.5 py-1.5 bg-white text-amber-900 hover:bg-amber-50 font-extrabold rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition active:scale-95 disabled:opacity-50"
            >
              <Download className={`w-3.5 h-3.5 ${isExporting ? 'animate-bounce' : ''}`} />
              <span>{isExporting ? (t.sauvegardeEnCours || 'Téléchargement...') : (t.sauvegarderMaintenant || 'Sauvegarder Maintenant (JSON)')}</span>
            </button>
          )}

          <button
            onClick={handleDismiss}
            title={t.fermer || 'Ignorer pour cette session'}
            className="p-1.5 text-amber-100 hover:text-white hover:bg-white/10 rounded-lg transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
}
