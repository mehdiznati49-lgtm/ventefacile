/**
 * Client Supabase REST pour VenteFacile Pro
 * Utilise l'API PostgREST standard de Supabase avec fetch native (zéro dépendance externe).
 */

/**
 * 🔑 CONFIGURATION DIRECTE SUPABASE DEPUIS LE CODE SOURCE
 * Les identifiants sont inscrits ici directement pour que les clients 
 * n'aient rien à manipuler dans les paramètres de l'application.
 */
export const SUPABASE_DIRECT_CONFIG = {
  url: '', // ex: 'https://votre-projet.supabase.co'
  anonKey: '', // ex: 'eyJhbGciOiJIUzI1NiIsIn...'
  shopId: 'boutique_principale',
  autoSync: true
};

export const SUPABASE_SQL_SCHEMA = `-- =====================================================
-- SCRIPT D'INITIALISATION POSTGRESQL POUR SUPABASE
-- À copier/coller dans le SQL Editor de votre projet Supabase
-- =====================================================

-- 1. Table des Produits & Stocks
CREATE TABLE IF NOT EXISTS products (
    id BIGINT PRIMARY KEY,
    barcode TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    brand TEXT,
    category TEXT,
    buy_price NUMERIC(10,2) DEFAULT 0,
    sell_price NUMERIC(10,2) NOT NULL,
    vat_rate NUMERIC(5,2) DEFAULT 20,
    stock NUMERIC(10,2) DEFAULT 0,
    min_stock NUMERIC(10,2) DEFAULT 3,
    unit TEXT DEFAULT 'unité',
    image TEXT,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Table des Ventes & Encaissements
CREATE TABLE IF NOT EXISTS sales (
    id BIGINT PRIMARY KEY,
    receipt_no TEXT UNIQUE NOT NULL,
    timestamp TIMESTAMPTZ NOT NULL,
    total_ht NUMERIC(10,2) NOT NULL,
    total_ttc NUMERIC(10,2) NOT NULL,
    payment_method TEXT NOT NULL,
    client_name TEXT,
    client_id BIGINT,
    is_credit BOOLEAN DEFAULT FALSE,
    cashier TEXT DEFAULT 'Caisse 1',
    items JSONB NOT NULL,
    synced_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Table des Clients, Dettes & Points
CREATE TABLE IF NOT EXISTS clients (
    id BIGINT PRIMARY KEY,
    name TEXT NOT NULL,
    phone TEXT,
    debt NUMERIC(10,2) DEFAULT 0,
    credit_limit NUMERIC(10,2) DEFAULT 500,
    fidelity_points INT DEFAULT 0,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Politiques RLS (Row Level Security) - Accès ouvert pour la clé Anon
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anon public access products" ON products;
CREATE POLICY "Anon public access products" ON products FOR ALL TO anon USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Anon public access sales" ON sales;
CREATE POLICY "Anon public access sales" ON sales FOR ALL TO anon USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Anon public access clients" ON clients;
CREATE POLICY "Anon public access clients" ON clients FOR ALL TO anon USING (true) WITH CHECK (true);
`;

/**
 * Nettoie et formate l'URL du projet Supabase
 */
export function cleanSupabaseUrl(url) {
  if (!url) return '';
  let clean = url.trim().replace(/\/+$/, '');
  if (!clean.startsWith('http://') && !clean.startsWith('https://')) {
    clean = 'https://' + clean;
  }
  return clean;
}

/**
 * En-têtes HTTP standards pour Supabase PostgREST
 */
function getHeaders(anonKey, upsert = false) {
  return {
    'apikey': anonKey,
    'Authorization': `Bearer ${anonKey}`,
    'Content-Type': 'application/json',
    'Prefer': upsert ? 'resolution=merge-duplicates,return=representation' : 'return=representation'
  };
}

/**
 * Teste la connexion au projet Supabase
 */
export async function testSupabaseConnection(url, anonKey) {
  if (!url || !anonKey) {
    return { success: false, error: 'URL du projet et clé API anonyme requises.' };
  }

  const endpoint = `${cleanSupabaseUrl(url)}/rest/v1/products?select=id&limit=1`;
  const startTime = Date.now();

  try {
    const res = await fetch(endpoint, {
      method: 'GET',
      headers: getHeaders(anonKey)
    });

    const latency = Date.now() - startTime;

    if (res.ok) {
      return { 
        success: true, 
        latency,
        message: `Connexion PostgreSQL Supabase réussie ! (Latence : ${latency}ms)`
      };
    } else if (res.status === 401 || res.status === 403) {
      return { 
        success: false, 
        error: 'Clé API anonyme (Anon Key) invalide ou expirée.' 
      };
    } else if (res.status === 404) {
      return { 
        success: false, 
        error: 'Table introuvable. Avez-vous exécuté le script SQL dans Supabase ?' 
      };
    } else {
      const text = await res.text();
      return { success: false, error: `Erreur serveur Supabase (${res.status}): ${text}` };
    }
  } catch (err) {
    return { success: false, error: `Impossible de joindre Supabase : ${err.message}` };
  }
}

/**
 * Envoie ou met à jour un produit vers Supabase
 */
export async function pushProductToSupabase(product, config) {
  const { supabaseUrl, supabaseAnonKey } = config || {};
  if (!supabaseUrl || !supabaseAnonKey) return null;

  const endpoint = `${cleanSupabaseUrl(supabaseUrl)}/rest/v1/products`;
  const payload = {
    id: product.id || Date.now(),
    barcode: product.barcode,
    name: product.name,
    brand: product.brand || '',
    category: product.category || 'Général',
    buy_price: parseFloat(product.buyPrice) || 0,
    sell_price: parseFloat(product.sellPrice) || 0,
    vat_rate: parseFloat(product.vatRate) || 20,
    stock: parseFloat(product.stock) || 0,
    min_stock: parseFloat(product.minStock) || 3,
    unit: product.unit || 'unité',
    image: product.image || '',
    updated_at: new Date().toISOString()
  };

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: getHeaders(supabaseAnonKey, true),
      body: JSON.stringify(payload)
    });
    return res.ok;
  } catch (e) {
    console.warn('[Supabase Sync] Échec envoi produit', e);
    return false;
  }
}

/**
 * Envoie une vente vers Supabase
 */
export async function pushSaleToSupabase(sale, config) {
  const { supabaseUrl, supabaseAnonKey } = config || {};
  if (!supabaseUrl || !supabaseAnonKey) return null;

  const endpoint = `${cleanSupabaseUrl(supabaseUrl)}/rest/v1/sales`;
  const payload = {
    id: sale.id || Date.now(),
    receipt_no: sale.receiptNo,
    timestamp: sale.timestamp ? new Date(sale.timestamp).toISOString() : new Date().toISOString(),
    total_ht: parseFloat(sale.totalHT || sale.totalTTC || 0),
    total_ttc: parseFloat(sale.totalTTC || 0),
    payment_method: sale.paymentMethod || 'especes',
    client_name: sale.clientName || 'Client Passant',
    client_id: sale.clientId || null,
    is_credit: Boolean(sale.isCredit),
    cashier: sale.cashier || 'Caisse Principale',
    items: sale.items || [],
    synced_at: new Date().toISOString()
  };

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: getHeaders(supabaseAnonKey, true),
      body: JSON.stringify(payload)
    });
    return res.ok;
  } catch (e) {
    console.warn('[Supabase Sync] Échec envoi vente', e);
    return false;
  }
}

/**
 * Récupère les produits distants depuis Supabase
 */
export async function pullProductsFromSupabase(config) {
  const { supabaseUrl, supabaseAnonKey } = config || {};
  if (!supabaseUrl || !supabaseAnonKey) return [];

  const endpoint = `${cleanSupabaseUrl(supabaseUrl)}/rest/v1/products?select=*`;
  try {
    const res = await fetch(endpoint, {
      method: 'GET',
      headers: getHeaders(supabaseAnonKey)
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.map(row => ({
      id: row.id,
      barcode: row.barcode,
      name: row.name,
      brand: row.brand,
      category: row.category,
      buyPrice: parseFloat(row.buy_price) || 0,
      sellPrice: parseFloat(row.sell_price) || 0,
      vatRate: parseFloat(row.vat_rate) || 20,
      stock: parseFloat(row.stock) || 0,
      minStock: parseFloat(row.min_stock) || 3,
      unit: row.unit || 'unité',
      image: row.image || ''
    }));
  } catch (e) {
    console.warn('[Supabase Sync] Échec récupération produits', e);
    return [];
  }
}

/**
 * Envoie ou met à jour un client vers Supabase
 */
export async function pushClientToSupabase(client, config) {
  const { supabaseUrl, supabaseAnonKey } = config || {};
  if (!supabaseUrl || !supabaseAnonKey) return null;

  const endpoint = `${cleanSupabaseUrl(supabaseUrl)}/rest/v1/clients`;
  const payload = {
    id: client.id || Date.now(),
    name: client.name,
    phone: client.phone || '',
    debt: parseFloat(client.debt) || 0,
    credit_limit: parseFloat(client.creditLimit) || 500,
    fidelity_points: parseInt(client.fidelityPoints, 10) || 0,
    updated_at: new Date().toISOString()
  };

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: getHeaders(supabaseAnonKey, true),
      body: JSON.stringify(payload)
    });
    return res.ok;
  } catch (e) {
    console.warn('[Supabase Sync] Échec envoi client', e);
    return false;
  }
}

/**
 * Récupère les ventes depuis Supabase
 */
export async function pullSalesFromSupabase(config) {
  const { supabaseUrl, supabaseAnonKey } = config || {};
  if (!supabaseUrl || !supabaseAnonKey) return [];

  const endpoint = `${cleanSupabaseUrl(supabaseUrl)}/rest/v1/sales?select=*&order=timestamp.desc&limit=200`;
  try {
    const res = await fetch(endpoint, {
      method: 'GET',
      headers: getHeaders(supabaseAnonKey)
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.map(row => ({
      id: row.id,
      receiptNo: row.receipt_no,
      timestamp: row.timestamp,
      totalHT: parseFloat(row.total_ht) || 0,
      totalTTC: parseFloat(row.total_ttc) || 0,
      paymentMethod: row.payment_method,
      clientName: row.client_name,
      clientId: row.client_id,
      isCredit: Boolean(row.is_credit),
      cashier: row.cashier,
      items: row.items || [],
      synced: true
    }));
  } catch (e) {
    console.warn('[Supabase Sync] Échec récupération ventes', e);
    return [];
  }
}
