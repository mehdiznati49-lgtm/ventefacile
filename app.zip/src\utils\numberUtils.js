/**
 * Fonctions utilitaires robustes pour la gestion des nombres, devises et virgules mobiles.
 * Résout le problème des claviers mobiles/tablettes (Android, iOS) avec virgule (,) ou séparateur arabe (٫).
 * 
 * Exemples :
 * - parseSafeFloat("0,5") => 0.5
 * - parseSafeFloat("150,50") => 150.5
 * - parseSafeFloat(" 1 250,75 ") => 1250.75
 * - parseSafeFloat("١٢٫٥") => 12.5
 * - parseSafeFloat(null) => 0
 */

/**
 * Parse en toute sécurité une chaîne ou un nombre avec support de la virgule et des chiffres arabes.
 * @param {any} val - Valeur à parser
 * @param {number} [fallback=0] - Valeur de repli si invalide ou vide
 * @returns {number} Nombre flottant sécurisé
 */
export function parseSafeFloat(val, fallback = 0) {
  if (val === null || val === undefined) return fallback;
  if (typeof val === 'number') return isNaN(val) ? fallback : val;

  let str = String(val).trim();
  if (str === '') return fallback;

  // Conversion chiffres arabo-indic (٠-٩) vers 0-9
  str = str.replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));

  // Remplacement de la virgule (,) et du séparateur arabe (٫) par un point (.)
  str = str.replace(/[٫,]/g, '.');

  // Suppression des espaces (ex: séparateur de milliers "1 500.50") et caractères parasites sauf - et .
  str = str.replace(/\s+/g, '').replace(/[^0-9.-]/g, '');

  // Gestion des points multiples accidentels ("12.3.4" => "12.34")
  const parts = str.split('.');
  if (parts.length > 2) {
    str = parts[0] + '.' + parts.slice(1).join('');
  }

  const parsed = parseFloat(str);
  return isNaN(parsed) ? fallback : parsed;
}

/**
 * Nettoie une chaîne de saisie utilisateur à la volée (onChange) en remplaçant la virgule par un point.
 * @param {string|any} str 
 * @returns {string}
 */
export function sanitizeDecimalInput(str) {
  if (str === null || str === undefined) return '';
  return String(str).replace(/[٫,]/g, '.');
}

export default parseSafeFloat;
