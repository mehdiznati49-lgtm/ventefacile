/**
 * apiSecurity.js - Secure API Gateway & Key Protection Module
 * Handles safe delegation to Serverless Proxy (Cloudflare Worker / Express Server)
 * and sanitizes sensitive credentials before display or storage.
 */

export const DEFAULT_PROXY_ENDPOINT = ''; // User configurable in settings or server-side

/**
 * Returns security diagnostic for external API keys stored locally
 */
export function checkApiSecurityStatus(settings = {}) {
  const whatsapp = settings.whatsapp || {};
  const website = settings.website || {};
  const issues = [];
  const warnings = [];

  // Check Meta WhatsApp Access Token
  if (whatsapp.accessToken && whatsapp.accessToken.length > 20) {
    if (!settings.proxyUrl) {
      warnings.push({
        module: 'WhatsApp',
        level: 'warning',
        message: 'Jeton d\'accès Meta WhatsApp stocké en clair dans le navigateur.',
        recommendation: 'Déléguez les requêtes à un Proxy Serverless / Cloudflare Worker pour masquer le jeton.'
      });
    }
  }

  // Check WooCommerce Consumer Secret
  if (website.apiSecret && website.apiSecret.length > 10) {
    if (!settings.proxyUrl) {
      warnings.push({
        module: 'WooCommerce',
        level: 'warning',
        message: 'Clé secrète WooCommerce (Consumer Secret) stockée localement.',
        recommendation: 'Activez le Proxy d\'API sécurisé pour éviter l\'exposition F12 et contourner les blocages CORS.'
      });
    }
  }

  const isSecure = warnings.length === 0;

  return {
    isSecure,
    warnings,
    hasProxyConfigured: Boolean(settings.proxyUrl && settings.proxyUrl.trim().length > 0)
  };
}

/**
 * Dispatches an API call either through the configured Serverless Proxy or the local backend server
 */
export async function secureApiCall(route, payload, settings = {}) {
  const proxyUrl = (settings.proxyUrl || '').trim().replace(/\/+$/, '');

  // 1. If Serverless Proxy (Cloudflare Worker / Vercel) is configured, delegate call
  if (proxyUrl) {
    const targetUrl = `${proxyUrl}${route.startsWith('/') ? route : '/' + route}`;
    try {
      const headers = { 'Content-Type': 'application/json' };
      if (settings.proxySecret) {
        headers['X-Proxy-Secret'] = settings.proxySecret;
      }

      const res = await fetch(targetUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      return { ok: res.ok, status: res.status, data, proxied: true };
    } catch (err) {
      console.warn('[SecureAPI] Échec du proxy distant, tentative via serveur local...', err);
    }
  }

  // 2. Fallback to local server proxy endpoint (/api/...)
  try {
    const localUrl = route.startsWith('/') ? route : '/' + route;
    const res = await fetch(localUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const text = await res.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      return {
        ok: false,
        status: res.status,
        data: { success: false, error: "Serveur API local ou Proxy non accessible sur cette instance statique." },
        proxied: false
      };
    }
    return { ok: res.ok, status: res.status, data, proxied: false };
  } catch (err) {
    return {
      ok: false,
      status: 500,
      data: { success: false, error: `Erreur de communication : ${err.message}` },
      proxied: false
    };
  }
}

/**
 * Masks sensitive API keys for safe display in UI (e.g., "EAAB...39fZ")
 */
export function maskApiKey(key) {
  if (!key || typeof key !== 'string') return '';
  if (key.length <= 8) return '********';
  return `${key.slice(0, 4)}••••••••${key.slice(-4)}`;
}
