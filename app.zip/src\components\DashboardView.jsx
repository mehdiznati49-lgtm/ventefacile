import React, { useState, useEffect } from 'react';
import { 
  DollarSign, 
  TrendingUp, 
  ShoppingBag, 
  CreditCard, 
  PieChart as PieIcon, 
  AlertTriangle, 
  Trophy, 
  Send, 
  Receipt, 
  ArrowUpRight, 
  ArrowDownRight,
  Sparkles,
  ShieldAlert,
  Percent,
  ShieldCheck,
  Lock,
  CheckCircle2,
  Download,
  FileText,
  RefreshCw,
  Eye,
  Hash,
  Search,
  Printer,
  X,
  FileSpreadsheet,
  Activity,
  Layers,
  Undo2,
  Coins,
  Truck,
  Trash2,
  Users
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';
import { translations, formatWithParens } from '../translations';
import { db, loadCompleteDemoDataset, clearAllDemoData } from '../db';
import { 
  verifyAuditChain, 
  generateZReportData, 
  exportAuditLogFEC, 
  buildSaleCanonicalString,
  computeSaleSeal,
  GENESIS_HASH 
} from '../auditChain';
import { triggerPrintWithLayout } from '../thermalPrinter';
import { useToast } from '../context/ToastContext';
import { 
  getLocalDateString, 
  getLocalDateCompact, 
  getLocalMonth, 
  getLocalYear, 
  isSameLocalDay, 
  isSameLocalMonth 
} from '../utils/dateUtils';

export default function DashboardView({ 
  sales, 
  products, 
  clients, 
  settings, 
  currentLang,
  onRefreshData,
  isAdmin = true,
  userRole = 'admin',
  onOpenCreateShop,
  onOpenTeamManagement
}) {
  const toast = useToast();
  const t = translations[currentLang] || translations.fr;
  const currency = settings.currency || '€';
  const isStoreConfigured = Boolean(settings?.isStoreConfigured);

  // Sub-navigation: 'stats' | 'audit'
  const [activeSection, setActiveSection] = useState('stats');

  // Cryptographic Audit & Fiscal States
  const [auditResult, setAuditResult] = useState(null);
  const [isCheckingAudit, setIsCheckingAudit] = useState(false);
  const [zReport, setZReport] = useState(null);
  const [showZModal, setShowZModal] = useState(false);
  const [auditSearch, setAuditSearch] = useState('');
  const [inspectedSale, setInspectedSale] = useState(null);

  // Refund & Return Modal State
  const [refundModalSale, setRefundModalSale] = useState(null);
  const [refundQuantities, setRefundQuantities] = useState({});
  const [refundMethod, setRefundMethod] = useState('especes');
  const [refundReason, setRefundReason] = useState('Retour Marchandise');

  // Cash Drawer & Float Management State
  const [openingFloat, setOpeningFloat] = useState(100);
  const [countedCash, setCountedCash] = useState('');
  const [cashMovements, setCashMovements] = useState([]);
  const [suppliersList, setSuppliersList] = useState([]);
  const [clientDebtPayments, setClientDebtPayments] = useState([]);

  // Monthly Accounting Report State
  const [selectedAccMonth, setSelectedAccMonth] = useState(getLocalMonth());
  const [selectedAccYear, setSelectedAccYear] = useState(getLocalYear());

  // Run integrity verification and load cash movements when sales change
  useEffect(() => {
    if (sales && sales.length > 0) {
      verifyAuditChain(sales).then(res => setAuditResult(res));
    } else {
      setAuditResult({
        isIntact: true,
        totalChecked: 0,
        chainHead: GENESIS_HASH,
        brokenAtReceipt: null
      });
    }

    if (db.cashMovements) {
      db.cashMovements.toArray().then(res => setCashMovements(res || []));
    }

    if (db.suppliers) {
      db.suppliers.toArray().then(sups => setSuppliersList(sups || []));
    }

    if (db.payments) {
      db.payments.toArray().then(pmts => setClientDebtPayments(pmts || []));
    }
  }, [sales]);

  const handleRunIntegrityCheck = async () => {
    setIsCheckingAudit(true);
    try {
      const res = await verifyAuditChain(sales);
      setAuditResult(res);
    } catch (e) {
      console.error('[DashboardView] Erreur vérification intégrité:', e);
    } finally {
      setTimeout(() => setIsCheckingAudit(false), 400);
    }
  };

  const handleGenerateZReport = async () => {
    const todaySales = sales.filter(s => isSameLocalDay(s.timestamp));
    const reportData = await generateZReportData(todaySales.length > 0 ? todaySales : sales);
    
    // Attach float and cash drawer info to report
    const todayCash = todaySales
      .filter(s => s.paymentMethod === 'especes')
      .reduce((sum, s) => sum + (Number(s.totalTTC) || 0), 0);

    const todayClientCash = (clientDebtPayments || [])
      .filter(p => isSameLocalDay(p.timestamp) && (p.paymentMethod || 'especes').toLowerCase() === 'especes')
      .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
    
    const todayExp = (cashMovements || [])
      .filter(m => isSameLocalDay(m.timestamp))
      .reduce((sum, m) => sum + (Number(m.amount) || 0), 0);

    const floatNum = Number(openingFloat || 0);
    const theoreticalCash = Math.max(0, floatNum + todayCash + todayClientCash - todayExp);
    const countedNum = countedCash !== '' ? parseFloat(countedCash) : null;
    const variance = countedNum !== null ? Math.round((countedNum - theoreticalCash) * 100) / 100 : null;

    setZReport({
      ...reportData,
      openingFloat: floatNum,
      clientDebtCash: todayClientCash,
      cashExpenses: todayExp,
      countedCash: countedNum,
      cashVariance: variance
    });
    setShowZModal(true);
  };

  const handleConfirmRefund = async () => {
    if (!refundModalSale) return;

    const returnedItems = [];
    let refundTotal = 0;
    let refundSubtotalHT = 0;
    let refundTotalVAT = 0;

    for (const item of (refundModalSale.items || [])) {
      const itemKey = item.productId || item.id || item.cartKey || item.name;
      const q = parseFloat(refundQuantities[itemKey]) || 0;
      if (q > 0) {
        const itemUnitPrice = Number(item.sellPrice || 0) * (1 - (Number(item.discountPercent) || 0) / 100);
        const itemLineTotal = itemUnitPrice * q;
        const vatFactor = 1 + ((Number(item.vatRate) || 20) / 100);
        const itemHT = itemLineTotal / vatFactor;
        const itemVAT = itemLineTotal - itemHT;

        refundTotal += itemLineTotal;
        refundSubtotalHT += itemHT;
        refundTotalVAT += itemVAT;

        returnedItems.push({
          ...item,
          quantity: q,
          refundedPrice: itemUnitPrice
        });

        // Re-increment stock in db.products
        if (item.productId) {
          const prod = await db.products.get(item.productId);
          if (prod) {
            await db.products.update(item.productId, {
              stock: (prod.stock || 0) + q
            });
          }
        }
      }
    }

    if (returnedItems.length === 0 || refundTotal <= 0) {
      toast.warning("Veuillez sélectionner au moins un article à rembourser.", "Quantité requise");
      return;
    }

    // Reduce client debt if the sale was on credit
    if (refundModalSale.clientId && refundModalSale.isCredit) {
      const client = await db.clients.get(refundModalSale.clientId);
      if (client) {
        const newDebt = Math.max(0, (client.debt || 0) - refundTotal);
        await db.clients.update(client.id, { debt: Math.round(newDebt * 100) / 100 });
      }
    }

    const lastSale = await db.sales.orderBy('id').last();
    const count = await db.sales.count();
    const sequenceNumber = (lastSale && typeof lastSale.sequenceNumber === 'number') 
      ? lastSale.sequenceNumber + 1 
      : count + 1;

    const refundReceiptNo = `AVOIR-${getLocalDateCompact()}-${String(sequenceNumber).padStart(4, '0')}`;
    const previousHash = lastSale?.currentHash || GENESIS_HASH;

    const refundSaleData = {
      receiptNo: refundReceiptNo,
      originalReceiptNo: refundModalSale.receiptNo,
      timestamp: new Date().toISOString(),
      items: returnedItems,
      subtotalHT: -Math.round(refundSubtotalHT * 100) / 100,
      totalVAT: -Math.round(refundTotalVAT * 100) / 100,
      totalTTC: -Math.round(refundTotal * 100) / 100,
      paymentMethod: refundMethod,
      clientName: refundModalSale.clientName || 'Client Passant',
      clientId: refundModalSale.clientId,
      type: 'refund',
      refundReason: refundReason,
      cashier: refundModalSale.cashier || 'Admin'
    };

    const seal = await computeSaleSeal(previousHash, refundSaleData, sequenceNumber);

    await db.sales.add({
      ...refundSaleData,
      sequenceNumber,
      previousHash: seal.previousHash,
      currentHash: seal.currentHash,
      sealShort: seal.sealShort,
      sealedAt: seal.sealedAt
    });

    setRefundModalSale(null);
    setRefundQuantities({});
    if (onRefreshData) onRefreshData();
    toast.success(`Avoir de ${refundTotal.toFixed(2)} ${currency} validé (${refundReceiptNo}). Stock réintégré.`, "Remboursement effectué");
  };

  const handleExportAuditCSV = () => {
    exportAuditLogFEC(sales, currency);
  };

  const handleResetDemoDebts = async () => {
    const ok = await toast.confirm({
      title: "Réinitialiser les soldes",
      message: "Remettre à zéro les dettes et points de fidélité des clients de test ?",
      confirmText: "Réinitialiser",
      variant: "danger"
    });
    if (!ok) return;

    const allClients = await db.clients.toArray();
    for (const c of allClients) {
      await db.clients.update(c.id, { debt: 0, points: 0 });
    }
    if (onRefreshData) await onRefreshData();
    toast.success("Soldes et points réinitialisés avec succès.");
  };

  const handleLoadStoreDemo = async () => {
    const ok = await toast.confirm({
      title: "Charger la boutique exemple",
      message: "Injecter un catalogue complet, des ventes récentes et des clients pour explorer le tableau de bord ?",
      confirmText: "Charger les exemples",
      variant: "primary"
    });
    if (!ok) return;

    try {
      await loadCompleteDemoDataset();
      if (onRefreshData) await onRefreshData();
      if (db.suppliers) {
        const sups = await db.suppliers.toArray();
        setSuppliersList(sups || []);
      }
      if (db.cashMovements) {
        const cm = await db.cashMovements.toArray();
        setCashMovements(cm || []);
      }
      toast.success("Boutique exemple chargée avec succès.");
    } catch (err) {
      console.error(err);
      toast.error(err.message, "Erreur de chargement");
    }
  };

  const handleResetStoreToZero = async () => {
    const ok = await toast.confirm({
      title: "Remettre la boutique à zéro",
      message: "Toutes les données d'exemples (produits, ventes, clients, fournisseurs) seront supprimées pour démarrer avec une boutique vierge.",
      confirmText: "Effacer les données",
      variant: "danger"
    });
    if (!ok) return;

    try {
      await clearAllDemoData();
      if (onRefreshData) await onRefreshData();
      setSuppliersList([]);
      setCashMovements([]);
      toast.success("Boutique réinitialisée. Base de données 100% vierge.");
    } catch (err) {
      console.error(err);
      toast.error(err.message, "Erreur de réinitialisation");
    }
  };

  // 1. Calculate Revenue (TTC & HT), Buy Cost, Gross Margin, Expenses & Real Net Profit
  const realSales = (sales || []).filter(s => !s?.receiptNo?.startsWith('PAY-'));
  const totalRevenue = realSales.reduce((sum, s) => sum + (Number(s?.totalTTC) || 0), 0);
  
  // Chiffre d'Affaires HT réel (base comptable réelle, hors TVA collectée pour l'État)
  const totalRevenueHT = realSales.reduce((sum, s) => {
    const ht = (typeof s?.subtotalHT === 'number' && s.subtotalHT !== 0) 
      ? Number(s.subtotalHT) 
      : (Number(s?.totalTTC) || 0);
    return sum + ht;
  }, 0);

  // Indexation des produits pour fallback sur buyPrice si manquant dans les articles vendus
  const productMap = (products || []).reduce((acc, p) => {
    if (p && p.id) acc[p.id] = p;
    return acc;
  }, {});

  // Coût d'Achat des Marchandises Vendues (CAMV)
  const totalBuyCost = realSales.reduce((sum, s) => {
    const saleCost = (s?.items || []).reduce((itemSum, item) => {
      const prodId = item?.productId || item?.id;
      const unitBuyPrice = Number(item?.buyPrice ?? productMap[prodId]?.buyPrice ?? 0);
      const qty = Number(item?.quantity) || 1;
      return itemSum + (unitBuyPrice * qty);
    }, 0);
    return sum + saleCost;
  }, 0);

  // Marge Brute Commerciale = CA HT - Coût d'Achat
  const grossMargin = totalRevenueHT - totalBuyCost;
  const grossMarginPercentage = totalRevenueHT > 0 
    ? ((grossMargin / totalRevenueHT) * 100).toFixed(1) 
    : '0.0';

  // Dépenses d'exploitation réelles (sorties de caisse, charges enregistrées)
  const totalExpenses = (cashMovements || []).reduce((sum, m) => sum + (Number(m?.amount) || 0), 0);

  // Bénéfice Net Réel = Marge Brute HT - Dépenses d'exploitation
  const netProfit = grossMargin - totalExpenses;
  const marginPercentage = grossMarginPercentage;
  const netMarginPercentage = totalRevenueHT > 0 
    ? ((netProfit / totalRevenueHT) * 100).toFixed(1) 
    : '0.0';

  // 2. VAT Fiscal Calculations
  const totalVATCollected = realSales.reduce((sum, s) => sum + (Number(s?.totalVAT) || 0), 0);
  const totalHTAmount = totalRevenueHT;

  // 3. Payment Method Distribution
  const paymentCounts = realSales.reduce((acc, s) => {
    const method = s?.paymentMethod || 'especes';
    acc[method] = (acc[method] || 0) + (Number(s?.totalTTC) || 0);
    return acc;
  }, { especes: 0, carte: 0, virement: 0, credit: 0 });

  const pieData = [
    { name: t.especes, value: paymentCounts.especes, color: '#10b981' },
    { name: t.carte, value: paymentCounts.carte, color: '#3b82f6' },
    { name: t.virement, value: paymentCounts.virement, color: '#8b5cf6' },
    { name: t.creditClient, value: paymentCounts.credit, color: '#f59e0b' }
  ].filter(d => d.value > 0);

  // 4. Product Sales Performance (Top vs Flop)
  const productSalesMap = {};
  (sales || []).forEach(s => {
    (s?.items || []).forEach(item => {
      const id = item?.name;
      if (id) {
        productSalesMap[id] = (productSalesMap[id] || 0) + (Number(item?.quantity) || 1);
      }
    });
  });

  const sortedProductsBySales = [...(products || [])].map(p => ({
    ...p,
    totalQuantitySold: productSalesMap[p.name] || 0
  })).sort((a, b) => b.totalQuantitySold - a.totalQuantitySold);

  const topProducts = sortedProductsBySales.slice(0, 4);
  const slowProducts = sortedProductsBySales.filter(p => p.totalQuantitySold === 0).slice(0, 4);

  // 5. Debtors / Unpaid accounts (Clients & Fournisseurs)
  const debtors = (clients || []).filter(c => Number(c.debt) > 0);
  const totalClientDebt = debtors.reduce((sum, c) => sum + (Number(c.debt) || 0), 0);
  const suppliersWithDebt = (suppliersList || []).filter(s => Number(s.debt) > 0);
  const totalSupplierDebt = suppliersWithDebt.reduce((sum, s) => sum + (Number(s.debt) || 0), 0);

  // Send WhatsApp Debt Reminder
  const handleSendDebtReminder = (client) => {
    const phone = client.phone ? client.phone.replace(/\s+/g, '') : '';
    const message = `Bonjour ${client.name},\n` +
      `Nous vous contactons concernant votre solde débiteur de *${Number(client.debt).toFixed(2)} ${currency}* dans notre boutique ${settings.shopName || ''}.\n` +
      `Merci de bien vouloir passer effectuer le règlement dès que possible.\n` +
      `Bonne journée ! 🌸`;

    const encoded = encodeURIComponent(message);
    const url = phone ? `https://wa.me/${phone}?text=${encoded}` : `https://wa.me/?text=${encoded}`;
    window.open(url, '_blank');
  };

  // 6. Cash Drawer & Float calculations
  const todayDateStr = getLocalDateString();
  const todayCashSales = (sales || [])
    .filter(s => isSameLocalDay(s.timestamp) && s.paymentMethod === 'especes')
    .reduce((sum, s) => sum + (Number(s.totalTTC) || 0), 0);

  const todayClientDebtCash = (clientDebtPayments || [])
    .filter(p => isSameLocalDay(p.timestamp) && (p.paymentMethod || 'especes').toLowerCase() === 'especes')
    .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);

  const todayCashExpenses = (cashMovements || [])
    .filter(m => isSameLocalDay(m.timestamp))
    .reduce((sum, m) => sum + (Number(m.amount) || 0), 0);

  const theoreticalCashInDrawer = Math.max(0, Number(openingFloat || 0) + todayCashSales + todayClientDebtCash - todayCashExpenses);
  const countedCashNum = countedCash !== '' ? parseFloat(countedCash) : null;
  const cashVariance = countedCashNum !== null ? Math.round((countedCashNum - theoreticalCashInDrawer) * 100) / 100 : null;

  // Monthly Accounting calculations
  const monthlySales = (realSales || []).filter(s => isSameLocalMonth(s.timestamp, selectedAccYear, selectedAccMonth));
  const monthlyExpensesList = (cashMovements || []).filter(m => isSameLocalMonth(m.timestamp, selectedAccYear, selectedAccMonth));

  const monthlyTTC = monthlySales.reduce((sum, s) => sum + (Number(s.totalTTC) || 0), 0);
  const monthlyHT = monthlySales.reduce((sum, s) => sum + (Number(s.subtotalHT) || 0), 0);
  const monthlyTVA = monthlySales.reduce((sum, s) => sum + (Number(s.totalVAT) || 0), 0);
  const monthlySavings = monthlySales.reduce((sum, s) => sum + (Number(s.totalSavings) || 0), 0);
  const monthlyTotalExpenses = monthlyExpensesList.reduce((sum, m) => sum + (Number(m.amount) || 0), 0);

  const vatBreakdown = {
    '20%': { ht: 0, tva: 0, ttc: 0 },
    '10%': { ht: 0, tva: 0, ttc: 0 },
    '5.5%': { ht: 0, tva: 0, ttc: 0 },
    '2.1%': { ht: 0, tva: 0, ttc: 0 },
    '0%': { ht: 0, tva: 0, ttc: 0 }
  };

  monthlySales.forEach(s => {
    (s.items || []).forEach(item => {
      const rate = (item.vatRate || 20).toString() + '%';
      const itemDisc = (item.discountPercent || 0) / 100;
      const globalDisc = (s.globalDiscount || 0) / 100;
      const itemTTC = (Number(item.sellPrice) || 0) * (1 - itemDisc) * (1 - globalDisc) * (Number(item.quantity) || 1);
      const vatDivisor = 1 + ((Number(item.vatRate) || 20) / 100);
      const itemHT = itemTTC / vatDivisor;
      const itemVat = itemTTC - itemHT;

      const targetKey = vatBreakdown[rate] ? rate : '20%';
      vatBreakdown[targetKey].ht += itemHT;
      vatBreakdown[targetKey].tva += itemVat;
      vatBreakdown[targetKey].ttc += itemTTC;
    });
  });

  const monthlyPayments = monthlySales.reduce((acc, s) => {
    const m = s.paymentMethod || 'especes';
    acc[m] = (acc[m] || 0) + (Number(s.totalTTC) || 0);
    return acc;
  }, { especes: 0, carte: 0, virement: 0, credit: 0 });

  const handleExportAccountingCSV = () => {
    const rows = [
      ['RAPPORT MENSUEL COMPTABLE - ' + (settings.shopName || 'VENTE FACILE')],
      ['Periode', `${selectedAccMonth}/${selectedAccYear}`],
      ['Date export', new Date().toLocaleString()],
      [],
      ['INDICATEURS GLOBAUX', 'MONTANT (' + currency + ')'],
      ['Chiffre d Affaires TTC', monthlyTTC.toFixed(2)],
      ['Chiffre d Affaires HT', monthlyHT.toFixed(2)],
      ['Total TVA Collectee', monthlyTVA.toFixed(2)],
      ['Total Remises Accordees', monthlySavings.toFixed(2)],
      ['Total Depenses et Sorties Especes', monthlyTotalExpenses.toFixed(2)],
      [],
      ['VENTILATION TVA', 'BASE HT', 'MONTANT TVA', 'TOTAL TTC'],
      ['Taux 20.0%', vatBreakdown['20%'].ht.toFixed(2), vatBreakdown['20%'].tva.toFixed(2), vatBreakdown['20%'].ttc.toFixed(2)],
      ['Taux 10.0%', vatBreakdown['10%'].ht.toFixed(2), vatBreakdown['10%'].tva.toFixed(2), vatBreakdown['10%'].ttc.toFixed(2)],
      ['Taux 5.5%', vatBreakdown['5.5%'].ht.toFixed(2), vatBreakdown['5.5%'].tva.toFixed(2), vatBreakdown['5.5%'].ttc.toFixed(2)],
      ['Taux 2.1%', vatBreakdown['2.1%'].ht.toFixed(2), vatBreakdown['2.1%'].tva.toFixed(2), vatBreakdown['2.1%'].ttc.toFixed(2)],
      ['Exonere 0%', vatBreakdown['0%'].ht.toFixed(2), vatBreakdown['0%'].tva.toFixed(2), vatBreakdown['0%'].ttc.toFixed(2)],
      [],
      ['ENCAISSEMENTS PAR MODE', 'MONTANT (' + currency + ')'],
      ['Especes', monthlyPayments.especes.toFixed(2)],
      ['Carte Bancaire', monthlyPayments.carte.toFixed(2)],
      ['Virement Bancaire', monthlyPayments.virement.toFixed(2)],
      ['Credit Client', monthlyPayments.credit.toFixed(2)]
    ];

    const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + rows.map(e => e.map(cell => `"${cell}"`).join(";")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Rapport_Comptable_${selectedAccYear}_${selectedAccMonth}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filtered sales for Audit Table
  const filteredAuditSales = (sales || []).filter(s => {
    if (!auditSearch.trim()) return true;
    const q = auditSearch.toLowerCase();
    return (
      (s.receiptNo && s.receiptNo.toLowerCase().includes(q)) ||
      (s.clientName && s.clientName.toLowerCase().includes(q)) ||
      (s.sealShort && s.sealShort.toLowerCase().includes(q)) ||
      (s.currentHash && s.currentHash.toLowerCase().includes(q)) ||
      (s.paymentMethod && s.paymentMethod.toLowerCase().includes(q))
    );
  }).sort((a, b) => (b.sequenceNumber || 0) - (a.sequenceNumber || 0));

  if (!isAdmin) {
    return (
      <div className="max-w-md mx-auto my-16 p-8 bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-slate-200 dark:border-slate-800 text-center animate-in fade-in">
        <div className="w-16 h-16 bg-amber-100 dark:bg-amber-950/50 text-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4 text-3xl">
          🔒
        </div>
        <h3 className="text-xl font-bold mb-2">Accès Réservé au Gérant</h3>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">
          Le Tableau de bord financier, le chiffre d'affaires, les marges nettes et les totaux d'audit fiscal sont protégés et inaccessibles au profil Caissier.
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 space-y-6 pb-36 sm:pb-16">
      
      {/* Top Header & Dual Section Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white font-display flex items-center gap-2">
            <span>{t.dashboard}</span>
            <span className="text-[11px] font-mono font-bold bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 px-2.5 py-0.5 rounded-full">
              PRO
            </span>
          </h2>
          <p className="text-xs text-slate-500">
            {t.dashboardSubtitle}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Subtab Pills */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700">
            <button
              onClick={() => setActiveSection('stats')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                activeSection === 'stats'
                  ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              <span>{t.bilanFinancier}</span>
            </button>

            <button
              onClick={() => setActiveSection('accounting')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                activeSection === 'accounting'
                  ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <FileSpreadsheet className="w-4 h-4 text-blue-500" />
              <span>{t.rapportComptable}</span>
              <span className="text-[9px] bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 font-mono px-1.5 py-0.5 rounded-md font-bold">
                {t.mensuel}
              </span>
            </button>

            <button
              onClick={() => setActiveSection('audit')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                activeSection === 'audit'
                  ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>{t.journalAudit}</span>
              <span className="text-[9px] bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-mono px-1.5 py-0.5 rounded-md font-bold">
                NF525
              </span>
            </button>
          </div>

          {/* Contextual Demo Button - ONLY shown BEFORE store creation and ONLY to Admin */}
          {!isStoreConfigured && isAdmin && (
            (sales?.length > 0 || products?.length > 0) ? (
              <button
                onClick={handleResetStoreToZero}
                className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-red-50 text-slate-600 hover:text-red-600 dark:bg-slate-800 dark:hover:bg-red-950/40 dark:text-slate-300 font-extrabold text-xs flex items-center gap-1.5 transition border border-slate-200 dark:border-slate-700 active:scale-95 shadow-sm"
                title="Supprimer les exemples et remettre toute la boutique à zéro"
              >
                <Trash2 className="w-3.5 h-3.5 text-red-500" />
                <span className="hidden sm:inline">🧹 Supprimer les exemples</span>
                <span className="sm:hidden">🧹 Vider</span>
              </button>
            ) : (
              <button
                onClick={handleLoadStoreDemo}
                className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:opacity-95 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-sm transition active:scale-95"
                title="Charger une boutique de démonstration complète"
              >
                <Sparkles className="w-4 h-4 text-yellow-200" />
                <span>🌟 Charger Boutique Exemple</span>
              </button>
            )
          )}

          {/* Team Management Trigger */}
          {onOpenTeamManagement && isAdmin && (
            <button
              onClick={onOpenTeamManagement}
              className="px-3 py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 font-extrabold text-xs flex items-center gap-1.5 transition border border-indigo-200 dark:border-indigo-800 active:scale-95 shadow-sm"
              title="Gérer l'équipe, les caissiers et les gérants"
            >
              <Users className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
              <span>👥 Équipe</span>
            </button>
          )}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SECTION 1: FINANCIAL STATEMENTS & MARGINS ('stats')                       */}
      {/* ========================================================================= */}
      {activeSection === 'stats' && (
        <div className="space-y-6">

          {/* Onboarding Banner - ONLY displayed BEFORE store is configured */}
          {!isStoreConfigured && (
            <div className="bg-gradient-to-r from-indigo-900 via-purple-900 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-indigo-700/40 relative overflow-hidden space-y-4">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
                <div className="space-y-1.5 max-w-xl">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 font-extrabold text-xs mb-1 border border-amber-400/30">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Mode Découverte & Configuration Initiale</span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-black">
                    Bienvenue dans VenteFacile Pro !
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-300">
                    Vous pouvez tester l'application avec des données d'exemple, ou bien <strong>activer votre vraie boutique</strong> dès maintenant. Une fois votre boutique créée, tous les boutons de test seront automatiquement masqués sur tous les écrans.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-3 shrink-0">
                  <button
                    onClick={onOpenCreateShop}
                    className="py-3 px-5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-black rounded-2xl text-xs shadow-lg shadow-emerald-500/25 flex items-center gap-2 transition active:scale-95"
                  >
                    <span>🚀 Créer ma Boutique Réelle</span>
                  </button>
                  <button
                    onClick={handleLoadStoreDemo}
                    className="py-3 px-4 bg-white/10 hover:bg-white/20 text-white font-extrabold rounded-2xl text-xs border border-white/20 flex items-center gap-1.5 transition active:scale-95"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    <span>🌟 Découvrir avec la Démo</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* KPI Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            
            {/* Card 1: Net Profit */}
            <div className="bg-gradient-to-br from-emerald-500 to-teal-700 text-white rounded-3xl p-5 shadow-lg shadow-emerald-500/20 relative overflow-hidden">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-100">{t.beneficeNet}</span>
                <div className="p-2 bg-white/20 rounded-xl backdrop-blur-sm">
                  <TrendingUp className="w-5 h-5 text-white" />
                </div>
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold mb-1">
                {netProfit.toFixed(2)} <span className="text-base font-semibold">{currency}</span>
              </div>
              <div className="flex flex-col gap-0.5 text-xs text-emerald-100 font-semibold">
                <div className="flex items-center gap-1">
                  <Percent className="w-3.5 h-3.5" />
                  <span>{t.margeBruteLabel} : {grossMargin.toFixed(2)} {currency} ({grossMarginPercentage}%)</span>
                </div>
                {totalExpenses > 0 && (
                  <span className="text-[11px] text-emerald-200/90 font-medium">
                    Dépenses déduites : -{totalExpenses.toFixed(2)} {currency}
                  </span>
                )}
              </div>
            </div>

            {/* Card 2: Total Revenue */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">{t.chiffreAffaires}</span>
                <div className="p-2 bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400 rounded-xl">
                  <DollarSign className="w-5 h-5" />
                </div>
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mb-1">
                {totalRevenue.toFixed(2)} <span className="text-base font-semibold text-slate-500">{currency}</span>
              </div>
              <div className="text-xs text-slate-500 font-medium flex items-center justify-between">
                <span>HT : {totalRevenueHT.toFixed(2)} {currency}</span>
                {totalVATCollected > 0 && (
                  <span className="text-[10px] text-indigo-600 dark:text-indigo-400 font-bold">
                    TVA : {totalVATCollected.toFixed(2)} {currency}
                  </span>
                )}
              </div>
            </div>

            {/* Card 3: Total Buy Cost */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">{t.coutAchat}</span>
                <div className="p-2 bg-purple-50 text-purple-600 dark:bg-purple-950 dark:text-purple-400 rounded-xl">
                  <ShoppingBag className="w-5 h-5" />
                </div>
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mb-1">
                {totalBuyCost.toFixed(2)} <span className="text-base font-semibold text-slate-500">{currency}</span>
              </div>
              <span className="text-xs text-slate-500 font-medium">{t.coutAchatTotalDesc}</span>
            </div>

            {/* Card 4: Client Debt Total */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">{t.totalCreances}</span>
                <div className="p-2 bg-amber-50 text-amber-600 dark:bg-amber-950 dark:text-amber-400 rounded-xl">
                  <ShieldAlert className="w-5 h-5" />
                </div>
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-amber-600 dark:text-amber-400 mb-1">
                {totalClientDebt.toFixed(2)} <span className="text-base font-semibold text-slate-500">{currency}</span>
              </div>
              <span className="text-xs text-slate-500 font-medium">{debtors.length} {t.clientsEnDette}</span>
            </div>

            {/* Card 5: Supplier Debt Total */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400">Dettes Fournisseurs</span>
                <div className="p-2 bg-rose-50 text-rose-600 dark:bg-rose-950 dark:text-rose-400 rounded-xl">
                  <Truck className="w-5 h-5" />
                </div>
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-rose-600 dark:text-rose-400 mb-1">
                {totalSupplierDebt.toFixed(2)} <span className="text-base font-semibold text-slate-500">{currency}</span>
              </div>
              <span className="text-xs text-slate-500 font-medium">{suppliersWithDebt.length} grossiste(s) à régler</span>
            </div>

          </div>

          {/* Cash Drawer & Float Control (Tiroir-Caisse) */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <div className="flex items-center gap-2">
                <Coins className="w-5 h-5 text-amber-500 shrink-0" />
                <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                  {t.controleCaisseTitre}
                </h3>
              </div>
              <span className="text-xs font-bold text-slate-500">
                {t.aujourdhui} ({new Date().toLocaleDateString(currentLang === 'ar' ? 'ar-SA' : 'fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' })})
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 text-xs">
              {/* Box 1: Opening Float */}
              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700">
                <label className="text-slate-500 font-bold block mb-1">
                  {t.fondInitial} :
                </label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    step="1"
                    value={openingFloat}
                    onChange={(e) => setOpeningFloat(parseFloat(e.target.value) || 0)}
                    className="w-full font-extrabold text-base bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-xl p-1 text-slate-900 dark:text-white"
                  />
                  <span className="font-bold text-slate-500">{currency}</span>
                </div>
                <span className="text-[10px] text-slate-400 block mt-1">
                  {t.monnaieOuverture}
                </span>
              </div>

              {/* Box 2: Cash Sales Today */}
              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700">
                <span className="text-slate-500 font-bold block mb-1">
                  {t.ventesEspeces} :
                </span>
                <div className="text-base font-extrabold text-emerald-600 dark:text-emerald-400 py-1">
                  +{todayCashSales.toFixed(2)} {currency}
                </div>
                <span className="text-[10px] text-slate-400 block mt-1">
                  {t.encaisseesCeJour}
                </span>
              </div>

              {/* Box 3: Client Debt Repayments Today */}
              <div className="p-3 bg-emerald-50/50 dark:bg-emerald-950/30 rounded-2xl border border-emerald-200 dark:border-emerald-800">
                <span className="text-emerald-700 dark:text-emerald-300 font-bold block mb-1">
                  🤝 Règl. Dettes :
                </span>
                <div className="text-base font-extrabold text-emerald-600 dark:text-emerald-400 py-1">
                  +{todayClientDebtCash.toFixed(2)} {currency}
                </div>
                <span className="text-[10px] text-emerald-600 dark:text-emerald-400 block mt-1">
                  Versements clients
                </span>
              </div>

              {/* Box 3: Expenses Today */}
              <div className="p-3 bg-rose-50/50 dark:bg-rose-950/30 rounded-2xl border border-rose-200 dark:border-rose-900">
                <span className="text-rose-700 dark:text-rose-300 font-bold block mb-1">
                  {t.sortiesDepenses} :
                </span>
                <div className="text-base font-extrabold text-rose-600 dark:text-rose-400 py-1">
                  -{todayCashExpenses.toFixed(2)} {currency}
                </div>
                <span className="text-[10px] text-rose-500 dark:text-rose-400 block mt-1">
                  {t.fournituresFrais}
                </span>
              </div>

              {/* Box 4: Theoretical Drawer Total */}
              <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 rounded-2xl border border-indigo-200 dark:border-indigo-800">
                <span className="text-indigo-700 dark:text-indigo-300 font-bold block mb-1">
                  {t.theoriqueCaisse} :
                </span>
                <div className="text-base font-extrabold text-indigo-700 dark:text-indigo-300 py-1">
                  {theoreticalCashInDrawer.toFixed(2)} {currency}
                </div>
                <span className="text-[10px] text-indigo-600 dark:text-indigo-400 block mt-1">
                  {t.calculFondVentesDepenses}
                </span>
              </div>

              {/* Box 5: Physical Count & Variance */}
              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700">
                <label className="text-slate-500 font-bold block mb-1">
                  {t.comptageReel} :
                </label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    step="0.5"
                    placeholder={t.placeholderCompte}
                    value={countedCash}
                    onChange={(e) => setCountedCash(e.target.value)}
                    className="w-full font-extrabold text-base bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-xl p-1 text-slate-900 dark:text-white"
                  />
                  <span className="font-bold text-slate-500">{currency}</span>
                </div>
                {countedCash !== '' && (
                  <div className="mt-1">
                    {cashVariance === 0 ? (
                      <span className="text-[11px] font-extrabold text-emerald-600">
                        {`✅ ${t.caisseParfaite}`}
                      </span>
                    ) : cashVariance > 0 ? (
                      <span className="text-[11px] font-extrabold text-emerald-600">
                        {`🟢 ${t.excedent} : +${cashVariance.toFixed(2)} ${currency}`}
                      </span>
                    ) : (
                      <span className="text-[11px] font-extrabold text-red-600">
                        {`🔴 ${t.manquant} : ${cashVariance.toFixed(2)} ${currency}`}
                      </span>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Middle Section: Payment Methods & Top/Flop Products */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left: Payment Method Distribution */}
            <div className="lg:col-span-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
              <div className="flex items-center gap-2 mb-4">
                <CreditCard className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                  {t.modesPaiement}
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
                {/* Pie Chart */}
                <div className="h-44 w-full flex items-center justify-center">
                  {pieData.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={pieData}
                          cx="50%"
                          cy="50%"
                          innerRadius={45}
                          outerRadius={70}
                          paddingAngle={4}
                          dataKey="value"
                        >
                          {pieData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => `${parseFloat(value).toFixed(2)} ${currency}`} />
                      </PieChart>
                    </ResponsiveContainer>
                  ) : (
                    <p className="text-xs text-slate-400">{t.aucunVenteEnregistree}</p>
                  )}
                </div>

                {/* Payment Method Legends */}
                <div className="space-y-2">
                  {pieData.map(item => (
                    <div key={item.name} className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 text-xs">
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                        <span className="font-semibold text-slate-700 dark:text-slate-300">{item.name}</span>
                      </div>
                      <span className="font-bold text-slate-900 dark:text-white">
                        {item.value.toFixed(2)} {currency}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right: Top Selling vs Slow Moving Products */}
            <div className="lg:col-span-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
              
              {/* Top Products */}
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Trophy className="w-5 h-5 text-amber-500" />
                  <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">{t.topProduits}</h3>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {topProducts.map(p => (
                    <div key={p.id} className="p-2.5 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/50 text-xs">
                      <span className="font-bold text-slate-800 dark:text-slate-100 block truncate">{p.name}</span>
                      <div className="flex justify-between items-center mt-1 text-[11px] text-emerald-700 dark:text-emerald-400">
                        <span>{t.vendus} : {p.totalQuantitySold}</span>
                        <span className="font-extrabold">{Number(p.sellPrice || 0).toFixed(2)} {currency}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Slow Products */}
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="w-4 h-4 text-red-500" />
                  <h3 className="font-extrabold text-xs text-slate-700 dark:text-slate-300">{t.invendus}</h3>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {slowProducts.length > 0 ? (
                    slowProducts.map(p => (
                      <div key={p.id} className="p-2 rounded-xl bg-red-50/50 dark:bg-red-950/20 border border-red-100 dark:border-red-900/40 text-[11px]">
                        <span className="font-semibold text-slate-700 dark:text-slate-300 block truncate">{p.name}</span>
                        <span className="text-red-600 dark:text-red-400 font-bold block mt-0.5">{t.zeroVente} ({t.enStock}: {p.stock})</span>
                      </div>
                    ))
                  ) : (
                    <p className="text-xs text-slate-400 col-span-2">{t.tousProduitsVentes}</p>
                  )}
                </div>
              </div>

            </div>

          </div>

          {/* Bottom Section: Debts & Unpaid Accounts List */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-amber-500" />
                <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                  {t.impayesDettes}
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-amber-600 bg-amber-50 dark:bg-amber-950 px-2.5 py-1 rounded-xl">
                  {t.totalDettes} : {totalClientDebt.toFixed(2)} {currency}
                </span>
                {debtors.length > 0 && (
                  <button
                    onClick={handleResetDemoDebts}
                    className="text-xs font-bold text-slate-600 dark:text-slate-300 hover:text-red-600 bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-xl border border-slate-300 dark:border-slate-700 transition flex items-center gap-1"
                    title={t.reinitialiserDettesDemo}
                  >
                    <span>🧹 {t.reinitialiserDettesDemo}</span>
                  </button>
                )}
              </div>
            </div>

            {debtors.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-6">{t.aucunImpaye}</p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {debtors.map(client => (
                  <div key={client.id} className="p-3.5 rounded-2xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900 flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-xs text-slate-900 dark:text-white">{client.name}</h4>
                      <span className="text-[11px] text-slate-500 block">{client.phone}</span>
                      <span className="text-xs font-extrabold text-amber-600 dark:text-amber-400 block mt-1">
                        {t.dette} : {Number(client.debt || 0).toFixed(2)} {currency} {client.maxDebt ? `/ Max : ${client.maxDebt}${currency}` : ''}
                      </span>
                    </div>
                    <button
                      onClick={() => handleSendDebtReminder(client)}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-sm transition"
                      title={t.relancer}
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{t.relancer}</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SECTION 2: IMMUTABLE FISCAL AUDIT LOG (NF525 CERTIFICATION) ('audit')     */}
      {/* ========================================================================= */}
      {activeSection === 'audit' && (
        <div className="space-y-6 animate-in fade-in-50 duration-200">
          
          {/* Integrity Status Banner */}
          <div className={`rounded-3xl p-5 border shadow-sm transition-all ${
            auditResult?.isIntact !== false
              ? 'bg-gradient-to-br from-emerald-950/40 via-slate-900 to-slate-900 border-emerald-500/30 text-emerald-50'
              : 'bg-gradient-to-br from-red-950/50 via-slate-900 to-slate-900 border-red-500/40 text-red-50'
          }`}>
            <div className="flex flex-wrap items-center justify-between gap-4">
              
              <div className="flex items-start gap-3.5">
                <div className={`p-3 rounded-2xl flex items-center justify-center ${
                  auditResult?.isIntact !== false
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : 'bg-red-500/20 text-red-400 border border-red-500/30'
                }`}>
                  <ShieldCheck className="w-7 h-7" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-extrabold text-base sm:text-lg text-white">
                      {auditResult?.isIntact !== false ? t.chaineIntacte : t.chaineRompu}
                    </h3>
                    <span className="text-[10px] font-mono font-extrabold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-full">
                      SHA-256
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5 max-w-2xl">
                    {auditResult?.isIntact !== false
                      ? `${auditResult?.totalChecked || 0} ${t.ticketsChainesSeq}`
                      : auditResult?.reason}
                  </p>
                  <div className="flex flex-wrap items-center gap-2 mt-2 font-mono text-[11px] text-slate-400">
                    <span>{t.teteDeChaine} :</span>
                    <span className="text-emerald-400 bg-slate-800/80 px-2 py-0.5 rounded-md border border-slate-700 truncate max-w-[280px]">
                      {auditResult?.chainHead ? `${auditResult.chainHead.slice(0, 18)}...${auditResult.chainHead.slice(-6)}` : GENESIS_HASH.slice(0, 16) + '...'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Quick Action Controls */}
              <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto">
                <button
                  onClick={handleRunIntegrityCheck}
                  disabled={isCheckingAudit}
                  className="flex-1 sm:flex-initial px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition disabled:opacity-50"
                  title={t.verifierIntegrite}
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isCheckingAudit ? 'animate-spin' : ''}`} />
                  <span>{t.verifierIntegrite}</span>
                </button>

                <button
                  onClick={handleGenerateZReport}
                  className="flex-1 sm:flex-initial px-3.5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition"
                  title={t.clotureZ}
                >
                  <Receipt className="w-3.5 h-3.5" />
                  <span>{t.clotureZ}</span>
                </button>

                <button
                  onClick={handleExportAuditCSV}
                  className="flex-1 sm:flex-initial px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 border border-slate-700 shadow-sm transition"
                  title={t.exportFEC}
                >
                  <Download className="w-3.5 h-3.5 text-slate-300" />
                  <span>{t.exportFEC}</span>
                </button>
              </div>

            </div>
          </div>

          {/* Audit Metrics Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">{t.totalTicketsScelles}</span>
                <div className="p-2 bg-emerald-50 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400 rounded-xl">
                  <Hash className="w-5 h-5" />
                </div>
              </div>
              <div className="text-2xl font-extrabold text-slate-900 dark:text-white mb-1">
                {sales.length}
              </div>
              <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">{t.sequenceContinue}</span>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">{t.caScelleTTC}</span>
                <div className="p-2 bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400 rounded-xl">
                  <DollarSign className="w-5 h-5" />
                </div>
              </div>
              <div className="text-2xl font-extrabold text-slate-900 dark:text-white mb-1">
                {totalRevenue.toFixed(2)} <span className="text-sm font-semibold text-slate-500">{currency}</span>
              </div>
              <span className="text-xs text-slate-500 font-medium">{t.totalCertifieInalterable}</span>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">{t.tvaScellee}</span>
                <div className="p-2 bg-purple-50 text-purple-600 dark:bg-purple-950 dark:text-purple-400 rounded-xl">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
              </div>
              <div className="text-2xl font-extrabold text-purple-600 dark:text-purple-400 mb-1">
                {totalVATCollected.toFixed(2)} <span className="text-sm font-semibold text-slate-500">{currency}</span>
              </div>
              <span className="text-xs text-slate-500 font-medium">{t.montantHT} : {totalHTAmount.toFixed(2)} {currency}</span>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">{t.conformiteFiscale}</span>
                <div className="p-2 bg-emerald-50 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400 rounded-xl">
                  <Lock className="w-5 h-5" />
                </div>
              </div>
              <div className="text-xl font-extrabold text-emerald-600 dark:text-emerald-400 mb-1 flex items-center gap-1.5">
                <CheckCircle2 className="w-5 h-5" />
                <span>{t.securise100}</span>
              </div>
              <span className="text-xs text-slate-500 font-medium">{t.legislationAntiFraude}</span>
            </div>

          </div>

          {/* Sealed Sales Log Table */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
            
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                  <span>{t.registreChronoVentes}</span>
                  <span className="text-xs font-mono font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 px-2 py-0.5 rounded-lg">
                    {filteredAuditSales.length} {t.entrees}
                  </span>
                </h3>
                <p className="text-xs text-slate-500">
                  {t.blockchainDesc}
                </p>
              </div>

              {/* Search input */}
              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder={t.rechercheTicketPlaceholder}
                  value={auditSearch}
                  onChange={(e) => setAuditSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
                <thead className="bg-slate-50 dark:bg-slate-800/80 text-[11px] uppercase font-bold text-slate-500 dark:text-slate-400 border-y border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="py-3 px-3">Seq</th>
                    <th className="py-3 px-3">{t.ticketNumero}</th>
                    <th className="py-3 px-3">Date (UTC)</th>
                    <th className="py-3 px-3">Client</th>
                    <th className="py-3 px-3">Mode</th>
                    <th className="py-3 px-3 text-right">TTC</th>
                    <th className="py-3 px-3 text-center">{t.sceauCrypto}</th>
                    <th className="py-3 px-3 text-center">{t.precedentHash}</th>
                    <th className="py-3 px-3 text-center">Contrôle</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
                  {filteredAuditSales.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-8 text-center text-slate-400 font-sans">
                        Aucune transaction ne correspond à la recherche.
                      </td>
                    </tr>
                  ) : (
                    filteredAuditSales.map((sale, idx) => (
                      <tr key={sale.id || idx} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                        <td className="py-3 px-3 font-bold text-slate-900 dark:text-slate-100">
                          #{sale.sequenceNumber || (sales.length - idx)}
                        </td>
                        <td className="py-3 px-3 font-bold text-indigo-600 dark:text-indigo-400">
                          {sale.receiptNo}
                        </td>
                        <td className="py-3 px-3 text-[11px] text-slate-500 font-sans">
                          {new Date(sale.timestamp).toLocaleString()}
                        </td>
                        <td className="py-3 px-3 font-sans truncate max-w-[120px]">
                          {sale.clientName || 'Client Passant'}
                        </td>
                        <td className="py-3 px-3 font-sans capitalize">
                          {sale.paymentMethod || 'especes'}
                        </td>
                        <td className="py-3 px-3 text-right font-bold text-slate-900 dark:text-white">
                          {(sale.totalTTC || 0).toFixed(2)} {currency}
                        </td>
                        <td className="py-3 px-3 text-center">
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                            {sale.sealShort || (sale.currentHash ? sale.currentHash.slice(0, 8).toUpperCase() : 'LEGACY')}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-center text-[10px] text-slate-400">
                          {sale.previousHash ? `${sale.previousHash.slice(0, 8)}...` : GENESIS_HASH.slice(0, 8) + '...'}
                        </td>
                        <td className="py-3 px-3 text-center font-sans space-x-1">
                          <button
                            onClick={() => setInspectedSale(sale)}
                            className="p-1 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                            title="Inspecter la signature"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          {sale.totalTTC > 0 && sale.type !== 'refund' && (
                            <button
                              onClick={() => {
                                setRefundModalSale(sale);
                                const initialQ = {};
                                (sale.items || []).forEach(item => {
                                  const key = item.productId || item.id || item.cartKey || item.name;
                                  initialQ[key] = item.quantity || 1;
                                });
                                setRefundQuantities(initialQ);
                                setRefundMethod(sale.paymentMethod || 'especes');
                              }}
                              className="p-1 text-amber-500 hover:text-amber-700 dark:hover:text-amber-300 rounded-lg hover:bg-amber-50 dark:hover:bg-amber-950 transition"
                              title="Effectuer un Retour / Remboursement (Avoir)"
                            >
                              <Undo2 className="w-4 h-4" />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* SECTION 3: MONTHLY ACCOUNTING & TAX REPORT ('accounting')                 */}
      {/* ========================================================================= */}
      {activeSection === 'accounting' && (
        <div id="dashboard-accounting-report" className="space-y-6">
          {/* Top Controls: Month & Year Selector + Export Buttons */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-100 text-blue-600 dark:bg-blue-950 dark:text-blue-300 rounded-2xl">
                <FileSpreadsheet className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                  {t.rapportMensuelTitre}
                </h3>
                <p className="text-xs text-slate-500">
                  {t.rapportMensuelDesc}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 no-print">
              {/* Month Picker */}
              <select
                value={selectedAccMonth}
                onChange={(e) => setSelectedAccMonth(e.target.value)}
                className="p-2.5 bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-xs"
              >
                <option value="01">{t.mois01} (01)</option>
                <option value="02">{t.mois02} (02)</option>
                <option value="03">{t.mois03} (03)</option>
                <option value="04">{t.mois04} (04)</option>
                <option value="05">{t.mois05} (05)</option>
                <option value="06">{t.mois06} (06)</option>
                <option value="07">{t.mois07} (07)</option>
                <option value="08">{t.mois08} (08)</option>
                <option value="09">{t.mois09} (09)</option>
                <option value="10">{t.mois10} (10)</option>
                <option value="11">{t.mois11} (11)</option>
                <option value="12">{t.mois12} (12)</option>
              </select>

              {/* Year Picker */}
              <select
                value={selectedAccYear}
                onChange={(e) => setSelectedAccYear(e.target.value)}
                className="p-2.5 bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-xs"
              >
                <option value="2025">2025</option>
                <option value="2026">2026</option>
                <option value="2027">2027</option>
              </select>

              <button
                onClick={handleExportAccountingCSV}
                className="py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center gap-2 shadow-sm transition"
              >
                <Download className="w-4 h-4" />
                <span>{t.exporterCSV}</span>
              </button>

              <button
                onClick={() => triggerPrintWithLayout('a4')}
                className="py-2.5 px-4 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs flex items-center gap-2 transition"
              >
                <Printer className="w-4 h-4" />
                <span>{t.imprimerA4}</span>
              </button>
            </div>
          </div>

          {/* Monthly KPI Overview Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">{t.caTotalTTC}</span>
              <div className="text-2xl font-extrabold text-indigo-600 dark:text-indigo-400 mt-2">
                {monthlyTTC.toFixed(2)} <span className="text-sm font-semibold">{currency}</span>
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">{monthlySales.length} {t.ticketsEmis}</span>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">{t.chiffreAffairesHT}</span>
              <div className="text-2xl font-extrabold text-slate-900 dark:text-white mt-2">
                {monthlyHT.toFixed(2)} <span className="text-sm font-semibold">{currency}</span>
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">{t.baseImpositionNette}</span>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">{t.tvaCollectee}</span>
              <div className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400 mt-2">
                {monthlyTVA.toFixed(2)} <span className="text-sm font-semibold">{currency}</span>
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">{t.aDeclarerTresor}</span>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">{t.sortiesCaisseFrais}</span>
              <div className="text-2xl font-extrabold text-rose-600 dark:text-rose-400 mt-2">
                {monthlyTotalExpenses.toFixed(2)} <span className="text-sm font-semibold">{currency}</span>
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">{monthlyExpensesList.length} {t.depensesTracees}</span>
            </div>
          </div>

          {/* Tables Grid: VAT Breakdown & Payments Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left: VAT Breakdown Table */}
            <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
              <h4 className="font-extrabold text-sm text-slate-900 dark:text-white mb-3 flex items-center gap-2">
                <Percent className="w-4 h-4 text-indigo-600" />
                <span>{t.ventilationTVATitre}</span>
              </h4>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold text-slate-400 uppercase">
                      <th className="py-2.5">{t.tauxTVA}</th>
                      <th className="py-2.5 text-right">{t.baseHT}</th>
                      <th className="py-2.5 text-right">{t.montantTVA}</th>
                      <th className="py-2.5 text-right">{t.totalTTC}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {Object.entries(vatBreakdown).map(([rateKey, data]) => (
                      <tr key={rateKey} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                        <td className="py-2.5 font-bold text-slate-800 dark:text-slate-200">
                          {rateKey === '20%' && `${t.tauxNormal} (20.0%)`}
                          {rateKey === '10%' && `${t.tauxIntermediaire} (10.0%)`}
                          {rateKey === '5.5%' && `${t.tauxReduit} (5.5%)`}
                          {rateKey === '2.1%' && `${t.tauxSuperReduit} (2.1%)`}
                          {rateKey === '0%' && `${t.exonere} (0.0%)`}
                        </td>
                        <td className="py-2.5 text-right font-medium">{data.ht.toFixed(2)} {currency}</td>
                        <td className="py-2.5 text-right font-bold text-emerald-600">{data.tva.toFixed(2)} {currency}</td>
                        <td className="py-2.5 text-right font-extrabold text-slate-900 dark:text-white">{data.ttc.toFixed(2)} {currency}</td>
                      </tr>
                    ))}
                    <tr className="border-t-2 border-slate-300 dark:border-slate-700 font-extrabold bg-slate-50 dark:bg-slate-800/60">
                      <td className="py-3 text-slate-900 dark:text-white">{t.totalMensuel} :</td>
                      <td className="py-3 text-right">{monthlyHT.toFixed(2)} {currency}</td>
                      <td className="py-3 text-right text-emerald-600">{monthlyTVA.toFixed(2)} {currency}</td>
                      <td className="py-3 text-right text-indigo-600">{monthlyTTC.toFixed(2)} {currency}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Right: Payment Method Breakdown & Expenses */}
            <div className="lg:col-span-5 space-y-6">
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
                <h4 className="font-extrabold text-sm text-slate-900 dark:text-white mb-3 flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-blue-600" />
                  <span>{t.encaissementsParMode}</span>
                </h4>

                <div className="space-y-2 text-xs">
                  <div className="flex justify-between items-center p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                    <span className="font-bold text-slate-700 dark:text-slate-300">💵 {t.especes}</span>
                    <span className="font-extrabold text-slate-900 dark:text-white">{monthlyPayments.especes.toFixed(2)} {currency}</span>
                  </div>
                  <div className="flex justify-between items-center p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                    <span className="font-bold text-slate-700 dark:text-slate-300">💳 {t.carte}</span>
                    <span className="font-extrabold text-slate-900 dark:text-white">{monthlyPayments.carte.toFixed(2)} {currency}</span>
                  </div>
                  <div className="flex justify-between items-center p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                    <span className="font-bold text-slate-700 dark:text-slate-300">🏦 {t.virement}</span>
                    <span className="font-extrabold text-slate-900 dark:text-white">{monthlyPayments.virement.toFixed(2)} {currency}</span>
                  </div>
                  <div className="flex justify-between items-center p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                    <span className="font-bold text-slate-700 dark:text-slate-300">🤝 {t.creditClient}</span>
                    <span className="font-extrabold text-amber-600">{monthlyPayments.credit.toFixed(2)} {currency}</span>
                  </div>
                </div>
              </div>

              {/* Monthly Cash Expenses List */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
                <h4 className="font-extrabold text-sm text-slate-900 dark:text-white mb-2 flex items-center gap-2">
                  <Coins className="w-4 h-4 text-rose-600" />
                  <span>{t.depensesDuMois} ({monthlyExpensesList.length})</span>
                </h4>

                <div className="max-h-48 overflow-y-auto space-y-1.5 text-xs">
                  {monthlyExpensesList.length === 0 ? (
                    <p className="text-slate-400 text-center py-4">{t.aucuneDepenseMois}</p>
                  ) : (
                    monthlyExpensesList.map((exp, idx) => (
                      <div key={idx} className="p-2 rounded-xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-100 dark:border-rose-900 flex justify-between items-center">
                        <div>
                          <span className="font-bold text-slate-800 dark:text-slate-200 block">{exp.reason}</span>
                          <span className="text-[10px] text-slate-400">{new Date(exp.timestamp).toLocaleDateString('fr-FR')} • {exp.cashier}</span>
                        </div>
                        <span className="font-extrabold text-rose-600">-{Number(exp.amount).toFixed(2)} {currency}</span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: CRYPTOGRAPHIC PROOF INSPECTOR                                      */}
      {/* ========================================================================= */}
      {inspectedSale && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-lg w-full border border-slate-200 dark:border-slate-800 shadow-2xl animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between mb-4 border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                  Preuve Cryptographique Inaltérable
                </h3>
              </div>
              <button
                onClick={() => setInspectedSale(null)}
                className="p-1 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs">
              <div>
                <span className="text-slate-500 font-bold block mb-1">Ticket & Séquence :</span>
                <div className="p-2 bg-slate-50 dark:bg-slate-800/80 rounded-xl font-mono text-slate-800 dark:text-slate-200 flex justify-between">
                  <span>{inspectedSale.receiptNo}</span>
                  <span className="font-bold text-indigo-600">Index #{inspectedSale.sequenceNumber || 1}</span>
                </div>
              </div>

              <div>
                <span className="text-slate-500 font-bold block mb-1">Empreinte Actuelle SHA-256 (Current Hash) :</span>
                <div className="p-2.5 bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 rounded-xl font-mono text-[11px] text-emerald-800 dark:text-emerald-300 break-all select-all">
                  {inspectedSale.currentHash || 'Non scellé (historique)'}
                </div>
              </div>

              <div>
                <span className="text-slate-500 font-bold block mb-1">Chaînage Antérieur (Previous Hash) :</span>
                <div className="p-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl font-mono text-[11px] text-slate-600 dark:text-slate-400 break-all select-all">
                  {inspectedSale.previousHash || GENESIS_HASH}
                </div>
              </div>

              <div>
                <span className="text-slate-500 font-bold block mb-1">Payload Canonique Signé :</span>
                <div className="p-2.5 bg-slate-100 dark:bg-slate-800/50 rounded-xl font-mono text-[10px] text-slate-500 break-all max-h-24 overflow-y-auto">
                  {buildSaleCanonicalString(inspectedSale)}
                </div>
              </div>

              <div className="pt-2 flex justify-between items-center text-emerald-700 dark:text-emerald-400 font-bold">
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Conformité Norme NF525 Vérifiée</span>
                </span>
                <button
                  onClick={() => setInspectedSale(null)}
                  className="px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl font-bold hover:bg-slate-300"
                >
                  Fermer
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: SEALED DAILY Z-REPORT (CLÔTURE DE CAISSE OFFICIELLE)               */}
      {/* ========================================================================= */}
      {showZModal && zReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-md w-full border border-slate-200 dark:border-slate-800 shadow-2xl animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between mb-4 border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-indigo-600" />
                <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                  {t.clotureCaisseZModalTitre}
                </h3>
              </div>
              <button
                onClick={() => setShowZModal(false)}
                className="p-1 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Thermal/Receipt Style Box */}
            <div id="z-report-print" className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 text-xs font-mono space-y-2 mb-4">
              <div className="text-center font-bold text-sm text-slate-900 dark:text-white">
                {settings.shopName || 'Boutique VenteFacile'}
              </div>
              <div className="text-center text-[11px] text-slate-500">
                CLÔTURE OFFICIELLE TYPE Z
              </div>
              <div className="border-t border-dashed border-slate-300 dark:border-slate-600 my-2"></div>
              
              <div className="flex justify-between">
                <span className="text-slate-500">N° Clôture :</span>
                <span className="font-bold text-slate-900 dark:text-white">{zReport.zNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Date & Heure :</span>
                <span>{new Date(zReport.closedAt).toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Nb de Tickets :</span>
                <span className="font-bold">{zReport.ticketsCount}</span>
              </div>

              <div className="border-t border-dashed border-slate-300 dark:border-slate-600 my-2"></div>

              <div className="space-y-1">
                <div className="flex justify-between">
                  <span>Ventes Espèces :</span>
                  <span>{(zReport.payments.especes || 0).toFixed(2)} {currency}</span>
                </div>
                {zReport.clientDebtCash > 0 && (
                  <div className="flex justify-between text-emerald-600 dark:text-emerald-400 font-bold">
                    <span>Dettes Clients (Espèces) :</span>
                    <span>+{zReport.clientDebtCash.toFixed(2)} {currency}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Carte Bancaire :</span>
                  <span>{(zReport.payments.carte || 0).toFixed(2)} {currency}</span>
                </div>
                <div className="flex justify-between">
                  <span>Virement :</span>
                  <span>{(zReport.payments.virement || 0).toFixed(2)} {currency}</span>
                </div>
                <div className="flex justify-between">
                  <span>Crédit Client :</span>
                  <span>{(zReport.payments.credit || 0).toFixed(2)} {currency}</span>
                </div>
              </div>

              {typeof zReport.openingFloat === 'number' && (
                <>
                  <div className="border-t border-dashed border-slate-300 dark:border-slate-600 my-2"></div>
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Fond de caisse :</span>
                      <span>{zReport.openingFloat.toFixed(2)} {currency}</span>
                    </div>
                    {zReport.cashExpenses > 0 && (
                      <div className="flex justify-between text-rose-600">
                        <span className="text-slate-500">Sorties de caisse :</span>
                        <span>-{zReport.cashExpenses.toFixed(2)} {currency}</span>
                      </div>
                    )}
                    <div className="flex justify-between font-bold">
                      <span className="text-slate-500">Espèces théoriques :</span>
                      <span>{(zReport.openingFloat + (zReport.payments.especes || 0) + (zReport.clientDebtCash || 0) - (zReport.cashExpenses || 0)).toFixed(2)} {currency}</span>
                    </div>
                    {zReport.countedCash !== null && (
                      <>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Espèces comptées :</span>
                          <span>{zReport.countedCash.toFixed(2)} {currency}</span>
                        </div>
                        <div className="flex justify-between font-bold">
                          <span>Écart de caisse :</span>
                          <span className={zReport.cashVariance === 0 ? 'text-emerald-600' : zReport.cashVariance > 0 ? 'text-emerald-600' : 'text-red-600'}>
                            {zReport.cashVariance > 0 ? `+${zReport.cashVariance.toFixed(2)}` : zReport.cashVariance.toFixed(2)} {currency}
                          </span>
                        </div>
                      </>
                    )}
                  </div>
                </>
              )}

              <div className="border-t border-dashed border-slate-300 dark:border-slate-600 my-2"></div>

              <div className="flex justify-between">
                <span className="text-slate-500">Total Hors Taxes (HT) :</span>
                <span>{Number(zReport.totalHT || 0).toFixed(2)} {currency}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Total TVA :</span>
                <span>{Number(zReport.totalVAT || 0).toFixed(2)} {currency}</span>
              </div>
              <div className="flex justify-between font-extrabold text-sm text-indigo-600 dark:text-indigo-400">
                <span>TOTAL TTC :</span>
                <span>{Number(zReport.totalTTC || 0).toFixed(2)} {currency}</span>
              </div>

              <div className="border-t border-dashed border-slate-300 dark:border-slate-600 my-2"></div>

              <div className="text-[10px] text-slate-500 text-center">
                <div>🔐 SIGNATURE NUMÉRIQUE DU Z :</div>
                <div className="font-bold text-slate-800 dark:text-slate-200 break-all select-all">
                  {zReport.zSignatureShort} ({zReport.zSignature.slice(0, 16)}...)
                </div>
              </div>
            </div>

            <div className="flex gap-2 no-print">
              <button
                onClick={() => triggerPrintWithLayout('80mm')}
                className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md shadow-indigo-500/20"
              >
                <Printer className="w-4 h-4" />
                <span>{t.imprimerTicketZ}</span>
              </button>
              <button
                onClick={() => setShowZModal(false)}
                className="px-4 py-3 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold rounded-xl text-xs hover:bg-slate-300"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: RETURN & REFUND MANAGEMENT (RETOURS / AVOIRS / RESTOCKAGE)        */}
      {/* ========================================================================= */}
      {refundModalSale && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-sm p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-lg w-full border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto no-scrollbar">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400">
                <Undo2 className="w-5 h-5" />
                <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                  {t.retoursAvoirsTitre}
                </h3>
              </div>
              <button
                onClick={() => setRefundModalSale(null)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Sale Reference */}
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 text-xs space-y-1">
              <div className="flex justify-between font-bold">
                <span className="text-slate-500">Ticket d'origine :</span>
                <span className="text-indigo-600 dark:text-indigo-400">{refundModalSale.receiptNo}</span>
              </div>
              <div className="flex justify-between text-slate-600 dark:text-slate-400">
                <span>Client :</span>
                <span>{refundModalSale.clientName || 'Client Passant'}</span>
              </div>
              <div className="flex justify-between text-slate-600 dark:text-slate-400">
                <span>Mode de paiement initial :</span>
                <span className="capitalize">{refundModalSale.paymentMethod || 'especes'}</span>
              </div>
            </div>

            {/* Select Articles to Return */}
            <div>
              <label className="block text-xs font-extrabold text-slate-900 dark:text-white mb-2">
                Sélectionnez les articles et quantités à retourner (Stock réintégré automatiquement) :
              </label>
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {(refundModalSale.items || []).map((item, idx) => {
                  const itemKey = item.productId || item.id || item.cartKey || item.name;
                  const currentQty = refundQuantities[itemKey] || 0;
                  const maxQty = item.quantity || 1;
                  const unitPrice = item.sellPrice * (1 - (item.discountPercent || 0) / 100);

                  return (
                    <div
                      key={idx}
                      className="flex items-center justify-between p-2.5 bg-slate-50 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700 text-xs"
                    >
                      <div className="flex-1 min-w-0 pr-2">
                        <span className="font-bold text-slate-800 dark:text-slate-200 block truncate">
                          {item.name} {formatWithParens(item.variant)}
                        </span>
                        <span className="text-[11px] text-slate-500">
                          Vendu : x{maxQty} • Prix : {unitPrice.toFixed(2)} {currency}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-slate-500 font-bold text-[11px]">Rembourser :</span>
                        <input
                          type="number"
                          min="0"
                          max={maxQty}
                          step={item.isWeight ? '0.1' : '1'}
                          value={currentQty}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value) || 0;
                            setRefundQuantities({
                              ...refundQuantities,
                              [itemKey]: Math.min(maxQty, Math.max(0, val))
                            });
                          }}
                          className="w-16 p-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-lg text-center font-bold text-slate-900 dark:text-white"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Refund Method & Reason */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  Mode de restitution :
                </label>
                <select
                  value={refundMethod}
                  onChange={(e) => setRefundMethod(e.target.value)}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-semibold text-slate-800 dark:text-slate-200"
                >
                  <option value="especes">💵 Espèces (Sortie de caisse)</option>
                  <option value="carte">💳 Carte Bancaire</option>
                  <option value="credit">📝 Avoir / Déduction Dette</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  Motif du retour :
                </label>
                <select
                  value={refundReason}
                  onChange={(e) => setRefundReason(e.target.value)}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-semibold text-slate-800 dark:text-slate-200"
                >
                  <option value="Retour Marchandise">Retour / Échange</option>
                  <option value="Produit Défectueux">Produit Défectueux</option>
                  <option value="Erreur de Saisie Caisse">Erreur de Caisse</option>
                  <option value="Annulation Client">Annulation Client</option>
                </select>
              </div>
            </div>

            {/* Estimated Total Refund */}
            {(() => {
              const totalEst = (refundModalSale.items || []).reduce((sum, item) => {
                const itemKey = item.productId || item.id || item.cartKey || item.name;
                const q = refundQuantities[itemKey] || 0;
                const unitPrice = item.sellPrice * (1 - (item.discountPercent || 0) / 100);
                return sum + (unitPrice * q);
              }, 0);

              return (
                <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-2xl border border-amber-200 dark:border-amber-800 flex justify-between items-center text-xs">
                  <span className="font-bold text-amber-800 dark:text-amber-300">
                    Montant total à restituer :
                  </span>
                  <span className="text-lg font-extrabold text-amber-700 dark:text-amber-400">
                    {totalEst.toFixed(2)} {currency}
                  </span>
                </div>
              );
            })()}

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={handleConfirmRefund}
                className="flex-1 py-3 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md shadow-amber-600/20 active:scale-98 transition"
              >
                <Undo2 className="w-4 h-4" />
                <span>Confirmer l'Avoir & Restocker ✅</span>
              </button>
              <button
                type="button"
                onClick={() => setRefundModalSale(null)}
                className="px-4 py-3 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold rounded-xl text-xs hover:bg-slate-300 transition"
              >
                Annuler
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
