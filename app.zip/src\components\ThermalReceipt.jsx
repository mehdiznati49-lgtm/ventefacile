import React from 'react';
import { QRCodeSVG } from 'qrcode.react';

/**
 * ThermalReceipt component - Designed strictly for POS thermal receipt printers (80mm & 58mm).
 * Renders high-contrast monochrome layout with clean dashed separators,
 * compact item tables, tax breakdown, and verifiable cryptographic NF525 QR code.
 */
export default function ThermalReceipt({
  sale,
  settings = {},
  currentLang = 'fr'
}) {
  if (!sale) return null;

  const currency = settings.currency || '€';
  const widthMode = settings.printerWidth || '80mm'; // '80mm' or '58mm'
  const shopName = settings.shopName || 'Boutique VenteFacile';
  const phone = settings.phone || '';
  const email = settings.email || '';
  const address = settings.address || '';
  const receiptNo = sale.receiptNo || 'TICK-0001';
  const timestamp = sale.timestamp ? new Date(sale.timestamp) : new Date();
  const dateFormatted = timestamp.toLocaleDateString('fr-FR');
  const timeFormatted = timestamp.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

  // Calculation details
  const totalTTC = Number(sale.totalTTC || 0);
  const totalHT = Number(sale.totalHT || (totalTTC / 1.2));
  const totalTVA = Number(sale.totalTVA || (totalTTC - totalHT));
  const paymentMethod = (sale.paymentMethod || 'especes').toUpperCase();
  const amountReceived = Number(sale.amountReceived || totalTTC);
  const changeReturned = Number(sale.changeReturned || 0);
  const clientName = sale.clientName && sale.clientName !== 'Client Passant' ? sale.clientName : null;
  const cashier = sale.cashier || 'Caisse 1';

  // NF525 Cryptographic Seal info
  const seal = sale.seal || sale.sealShort || 'NF525-VALIDE';
  const sealShort = sale.sealShort || (seal.length > 16 ? `${seal.slice(0, 8)}...${seal.slice(-8)}` : seal);
  const seqNum = sale.sequenceNumber || 1;

  // Verification Payload for QR Code (Standard NF525 format)
  const qrVerificationPayload = JSON.stringify({
    magasin: shopName,
    ticket: receiptNo,
    seq: seqNum,
    date: timestamp.toISOString(),
    totalTTC: totalTTC.toFixed(2),
    tva: totalTVA.toFixed(2),
    sceau: seal
  });

  return (
    <div 
      id="thermal-receipt" 
      className={`thermal-receipt font-mono text-black bg-white ${widthMode === '58mm' ? 'thermal-58mm' : 'thermal-80mm'}`}
    >
      {/* 1. Header: Store info */}
      <div className="receipt-header text-center">
        <h2 className="receipt-title font-bold text-sm tracking-wider uppercase m-0 leading-tight">
          {shopName}
        </h2>
        {address && <div className="text-[10px] leading-tight mt-0.5">{address}</div>}
        {phone && <div className="text-[10px] leading-tight">Tél: {phone}</div>}
        {email && <div className="text-[10px] leading-tight">Email: {email}</div>}
        {sale.type === 'exchange' ? (
          <div className="mt-1 px-2 py-0.5 border border-black font-extrabold text-[11px] uppercase tracking-wider inline-block">
            👗 TICKET D'ÉCHANGE
          </div>
        ) : (sale.type === 'refund' || totalTTC < 0) ? (
          <div className="mt-1 px-2 py-0.5 border border-black font-extrabold text-[11px] uppercase tracking-wider inline-block">
            🏷️ TICKET D'AVOIR / RETOUR
          </div>
        ) : null}
      </div>

      <div className="receipt-divider my-1.5 border-b border-dashed border-black"></div>

      {/* Meta: Receipt No, Date, Time, Cashier, Client */}
      <div className="receipt-meta text-[10px] leading-tight space-y-0.5">
        <div className="flex justify-between font-bold">
          <span>{sale.type === 'exchange' ? 'ÉCHANGE:' : (sale.type === 'refund' || totalTTC < 0 ? 'AVOIR:' : 'TICKET:')} #{receiptNo}</span>
          <span>{dateFormatted} {timeFormatted}</span>
        </div>
        {sale.originalReceiptNo && (
          <div className="flex justify-between text-slate-700">
            <span>Ticket d'origine :</span>
            <span className="font-bold">#{sale.originalReceiptNo}</span>
          </div>
        )}
        {sale.refundReason && (
          <div className="flex justify-between text-slate-700">
            <span>Motif :</span>
            <span className="font-bold">{sale.refundReason}</span>
          </div>
        )}
        <div className="flex justify-between text-slate-700">
          <span>Caisse: {cashier}</span>
          {clientName && <span>Client: {clientName}</span>}
        </div>
      </div>

      <div className="receipt-divider my-1.5 border-b border-dashed border-black"></div>

      {/* 2. Compact Items Table */}
      <div className="receipt-items-container">
        <table className="receipt-table w-full text-[10px] border-collapse">
          <thead>
            <tr className="border-b border-dashed border-black font-bold">
              <th className="text-left py-1 w-7/12">ARTICLE</th>
              <th className="text-center py-1 w-2/12">QTÉ</th>
              <th className="text-right py-1 w-3/12">TOTAL</th>
            </tr>
          </thead>
          <tbody>
            {(sale.items || []).map((item, index) => {
              const itemTotal = item.total !== undefined 
                ? Number(item.total) 
                : (Number(item.sellPrice || 0) * Number(item.quantity || 1));
              return (
                <tr key={index} className="align-top border-b border-dotted border-gray-300">
                  <td className="text-left py-1 pr-1">
                    <div className="font-bold leading-tight">{item.name}</div>
                    {item.variant && <div className="text-[9px] text-gray-600">({item.variant})</div>}
                    <div className="text-[9px] text-gray-500">
                      PU: {Number(item.sellPrice || 0).toFixed(2)} {currency}
                    </div>
                  </td>
                  <td className="text-center py-1 font-bold">
                    {item.quantity}
                  </td>
                  <td className="text-right py-1 font-bold">
                    {itemTotal > 0 ? `+${itemTotal.toFixed(2)}` : itemTotal.toFixed(2)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="receipt-divider my-1.5 border-b border-dashed border-black"></div>

      {/* 3. Totals & Tax Breakdown */}
      <div className="receipt-totals text-[10px] space-y-0.5">
        {sale.totalSavings > 0 && (
          <div className="flex justify-between font-bold text-gray-700">
            <span>REMISE ACCORDÉE:</span>
            <span>-{Number(sale.totalSavings || 0).toFixed(2)} {currency}</span>
          </div>
        )}
        {sale.fidelityDiscount > 0 && (
          <div className="flex justify-between font-bold text-gray-700">
            <span>DÉDUCTION FIDÉLITÉ ({sale.redeemedPoints} pts):</span>
            <span>-{Number(sale.fidelityDiscount).toFixed(2)} {currency}</span>
          </div>
        )}
        <div className="flex justify-between">
          <span>TOTAL HT:</span>
          <span>{totalHT.toFixed(2)} {currency}</span>
        </div>
        <div className="flex justify-between">
          <span>TVA COLLECTÉE:</span>
          <span>{totalTVA.toFixed(2)} {currency}</span>
        </div>
        <div className="flex justify-between text-xs font-black pt-1 border-t border-dashed border-black">
          <span>TOTAL TTC:</span>
          <span className="text-sm font-extrabold">{totalTTC.toFixed(2)} {currency}</span>
        </div>
      </div>

      <div className="receipt-divider my-1.5 border-b border-dashed border-black"></div>

      {/* Payment Information */}
      <div className="receipt-payment text-[10px] space-y-0.5">
        <div className="flex justify-between">
          <span>MODE RÈGLEMENT:</span>
          <span className="font-bold">{paymentMethod}</span>
        </div>
        {paymentMethod === 'ESPECES' && (
          <>
            <div className="flex justify-between">
              <span>MONTANT REÇU:</span>
              <span>{amountReceived.toFixed(2)} {currency}</span>
            </div>
            <div className="flex justify-between font-bold">
              <span>MONNAIE RENDUE:</span>
              <span>{changeReturned.toFixed(2)} {currency}</span>
            </div>
          </>
        )}
      </div>

      {/* Loyalty Points Account Summary */}
      {(sale.clientRemainingPoints !== undefined || (sale.pointsEarned && sale.pointsEarned > 0) || (sale.redeemedPoints && sale.redeemedPoints > 0)) && (
        <>
          <div className="receipt-divider my-1.5 border-b border-dashed border-black"></div>
          <div className="receipt-fidelity text-[10px] space-y-0.5">
            <div className="font-bold flex justify-between">
              <span>PROGRAMME FIDÉLITÉ CLIENT :</span>
            </div>
            {sale.pointsEarned > 0 && (
              <div className="flex justify-between text-gray-700">
                <span>• Points acquis cette vente :</span>
                <span className="font-bold">+{sale.pointsEarned} pts</span>
              </div>
            )}
            {sale.redeemedPoints > 0 && (
              <div className="flex justify-between text-gray-700">
                <span>• Points déduits en remise :</span>
                <span className="font-bold">-{sale.redeemedPoints} pts</span>
              </div>
            )}
            {sale.clientRemainingPoints !== undefined && (
              <div className="flex justify-between font-bold">
                <span>• Nouveau solde points :</span>
                <span>{sale.clientRemainingPoints} pts</span>
              </div>
            )}
          </div>
        </>
      )}

      <div className="receipt-divider my-1.5 border-b border-dashed border-black"></div>

      {/* 4. Footer & Verification NF525 QR Code */}
      <div className="receipt-footer text-center space-y-1">
        <div className="text-[10px] font-bold">
          Merci de votre visite ! À très bientôt.
        </div>

        {/* NF525 Cryptographic QR Code Verification */}
        <div className="qr-container flex flex-col items-center justify-center my-1.5">
          <div className="p-1 bg-white inline-block">
            <QRCodeSVG
              value={qrVerificationPayload}
              size={widthMode === '58mm' ? 80 : 100}
              level="M"
              includeMargin={false}
            />
          </div>
          <div className="text-[8px] font-mono leading-tight mt-1">
            <div className="font-bold">🔐 CONFORME NF525 / FISCAL</div>
            <div>Index: #{seqNum} | Sceau: {sealShort}</div>
          </div>
        </div>

        <div className="text-[8px] text-gray-500">
          Système certifié VenteFacile POS
        </div>
      </div>
    </div>
  );
}
