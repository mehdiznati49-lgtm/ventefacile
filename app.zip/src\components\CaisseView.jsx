import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Minus, 
  Trash2, 
  ShoppingBag, 
  CreditCard, 
  Banknote, 
  ArrowRightLeft, 
  UserCheck, 
  Printer, 
  Send, 
  Sparkles, 
  PauseCircle, 
  PlayCircle, 
  Scale, 
  AlertTriangle, 
  Search, 
  CheckCircle,
  Clock,
  Zap,
  Tag,
  Gift,
  ShieldCheck,
  Lock,
  Coins,
  FileText,
  Check,
  Eye,
  Calculator,
  X
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { QRCodeSVG } from 'qrcode.react';
import { translations } from '../translations';
import { db } from '../db';
import { parseSafeFloat, sanitizeDecimalInput } from '../utils/numberUtils';
import { getLocalDateCompact } from '../utils/dateUtils';
import { computeSaleSeal, GENESIS_HASH } from '../auditChain';
import { syncManager } from '../syncManager';
import ThermalReceipt from './ThermalReceipt';
import RefundModal from './RefundModal';
import { triggerOpenCashDrawer, printReceiptThermal, triggerPrintWithLayout } from '../thermalPrinter';
import { useToast } from '../context/ToastContext';
import { searchProducts } from '../utils/searchEngine';
import { useBarcodeScanner, playRetailSound } from '../hooks/useBarcodeScanner';

export default function CaisseView({ 
  products, 
  sales = [],
  clients, 
  settings, 
  currentLang, 
  onOpenScanner,
  onRefreshData,
  currentCashier: propCurrentCashier,
  onOpenSwitchCashier,
  onOpenTeamManagement,
  searchQuery = '',
  scannedProductToAdd = null,
  onScannedProductAdded = null
}) {
  const toast = useToast();
  const t = translations[currentLang] || translations.fr;
  const currency = settings.currency || '€';

  // Resolved active cashier details
  const currentCashierName = typeof propCurrentCashier === 'object'
    ? (propCurrentCashier?.name || 'Patron')
    : (propCurrentCashier || 'Patron');
  const currentCashierRole = typeof propCurrentCashier === 'object'
    ? (propCurrentCashier?.role || 'patron')
    : 'patron';
  const currentCashierAvatar = typeof propCurrentCashier === 'object'
    ? (propCurrentCashier?.avatarColor || '#4f46e5')
    : '#4f46e5';

  // Cart state
  const [cart, setCart] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('Tous');
  const [selectedClient, setSelectedClient] = useState(null);
  const [currentCashier, setCurrentCashier] = useState(currentCashierName);
  const [globalDiscount, setGlobalDiscount] = useState(0); // in %
  const [redeemPoints, setRedeemPoints] = useState(0); // loyalty points to redeem for discount

  // Fast Checkout & Payment Modals
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('especes'); // especes, carte, virement, credit
  const [amountReceived, setAmountReceived] = useState('');
  const [cardAuthRef, setCardAuthRef] = useState('');
  
  // Persistent Parked / Held Carts State
  const [showHeldCartsModal, setShowHeldCartsModal] = useState(false);
  const [heldCarts, setHeldCarts] = useState(() => {
    try {
      const saved = localStorage.getItem('vf_held_carts');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  // Sync held carts to localStorage so they survive page reloads and browser restart
  useEffect(() => {
    try {
      localStorage.setItem('vf_held_carts', JSON.stringify(heldCarts));
    } catch (e) {
      console.warn('[VenteFacile] Erreur sauvegarde paniers en attente', e);
    }
  }, [heldCarts]);

  // Cash Expense / Withdrawal Modal State
  const [showExpenseModal, setShowExpenseModal] = useState(false);
  const [expenseAmount, setExpenseAmount] = useState('');
  const [expenseReason, setExpenseReason] = useState('Fournitures / Frais');

  // Custom / Free Item ("Article Divers / Vente Libre") State
  const [showCustomItemModal, setShowCustomItemModal] = useState(false);
  const [customItemData, setCustomItemData] = useState({
    name: '',
    price: '',
    buyPrice: '',
    vatRate: '20',
    quantity: '1'
  });

  // Quotes / Proforma Modal State
  const [showQuoteModal, setShowQuoteModal] = useState(false);
  const [activeQuote, setActiveQuote] = useState(null);
  const [showQuotesListModal, setShowQuotesListModal] = useState(false);
  const [savedQuotes, setSavedQuotes] = useState([]);
  
  // Cash Closing (Ticket Z / Ticket X) State
  const [showCashClosingModal, setShowCashClosingModal] = useState(false);
  
  // Weight & Variant Modals
  const [weightModalProduct, setWeightModalProduct] = useState(null);
  const [weightInput, setWeightInput] = useState(''); // in Kg or grams
  const [variantModalProduct, setVariantModalProduct] = useState(null);

  // Completed Receipt Modal
  const [completedSale, setCompletedSale] = useState(null);
  const [showReceiptModal, setShowReceiptModal] = useState(false);

  // Return & Refund Modal State
  const [showRefundModal, setShowRefundModal] = useState(false);

  // Filter categories
  const categories = ['Tous', ...new Set(products.map(p => p.category).filter(Boolean))];

  // Optimized Multi-Token Fuzzy Search with Arabic & Accent normalization
  const filteredProducts = React.useMemo(() => {
    return searchProducts(products, searchQuery, {
      category: selectedCategory,
      enableFuzzy: true
    });
  }, [products, searchQuery, selectedCategory]);

  // Feedback sonore et haptique pour lecteur de code-barres (douchette USB / Bluetooth)
  const playScanSound = (isSuccess = true) => {
    playRetailSound(isSuccess ? 'beep' : 'error');
    if (navigator.vibrate) {
      navigator.vibrate(isSuccess ? 80 : [100, 60, 100]);
    }
  };

  // Hardware USB / Bluetooth Barcode Scanner Listener & POS Shortcuts (F12, F4, F2)
  useBarcodeScanner({
    onScan: (scannedCode) => {
      const matched = products.find(p => p.barcode === scannedCode || p.barcode?.endsWith(scannedCode));
      if (matched) {
        playRetailSound('beep');
        handleAddToCart(matched).then((added) => {
          if (added) {
            toast.success(`« ${matched.name} » ajouté au panier !`, 'Code-barres Scanné');
          }
        });
      } else {
        playRetailSound('error');
        toast.error(
          `Code-barres inconnu : « ${scannedCode} ». Cet article n'existe pas dans le catalogue.`,
          'Article Non Trouvé'
        );
      }
    },
    onOpenDrawer: () => {
      triggerOpenCashDrawer('Raccourci Clavier F12', currentCashier?.name || 'Caissier');
      toast.info('Tiroir-caisse déclenché (F12)', 'Tiroir Ouvert');
    },
    onQuickCustomItem: () => {
      setShowCustomItemModal(true);
    },
    onQuickTPE: () => {
      setPaymentMethod('carte');
      toast.info('Mode Carte Bancaire / TPE activé (F2)', 'Paiement TPE');
    }
  });

  // Add product to cart logic with Out-of-Stock Protection & Alert
  const handleAddToCart = async (product, selectedVariant = null, weightAmount = null) => {
    if (!product) return false;

    // 1. Check stock level & warning / blocking
    const currentStock = Number(product.stock !== undefined ? product.stock : 9999);
    
    // Calculate total quantity of this product already in cart
    const qtyAlreadyInCart = cart
      .filter(item => (item.productId || item.id) === product.id)
      .reduce((sum, item) => sum + (Number(item.quantity) || 0), 0);

    const qtyRequested = weightAmount ? parseSafeFloat(weightAmount, 1) : 1;
    const projectedTotalQty = qtyAlreadyInCart + qtyRequested;

    // A. Out-of-Stock Protection (stock <= 0)
    if (currentStock <= 0) {
      playScanSound(false);

      if (settings?.strictStockControl) {
        toast.error(
          `Ajout impossible : L'article « ${product.name} » est en RUPTURE TOTALE de stock (Stock : ${currentStock}).`,
          'Rupture de Stock'
        );
        return false;
      }

      const confirmAdd = await toast.confirm({
        title: "⚠️ Article en Rupture de Stock",
        message: `L'article « ${product.name} » est actuellement en RUPTURE DE STOCK (Stock théorique : ${currentStock} ${product.unit || 'unité(s)'}).\n\nVoulez-vous quand même l'ajouter au panier (vente sur arrivage non encore réceptionné) ?`,
        confirmText: "Ajouter quand même",
        cancelText: "Ne pas ajouter",
        variant: "warning"
      });

      if (!confirmAdd) {
        return false;
      }
    } else if (projectedTotalQty > currentStock) {
      toast.warning(
        `Attention : La quantité totale (${projectedTotalQty}) dépasse le stock restant (${currentStock} ${product.unit || 'unités'}).`,
        'Stock Faible'
      );
    }

    if (product.isWeight && weightAmount === null) {
      setWeightModalProduct(product);
      setWeightInput('');
      return true;
    }

    if (product.variants && product.variants.length > 0 && !selectedVariant) {
      setVariantModalProduct(product);
      return true;
    }

    const itemKey = `${product.id}-${selectedVariant || 'default'}-${weightAmount || 'std'}`;
    const existingIndex = cart.findIndex(item => item.cartKey === itemKey);

    const qtyToAdd = weightAmount ? parseSafeFloat(weightAmount, 1) : 1;
    const finalPrice = product.sellPrice;

    if (existingIndex > -1) {
      const updatedCart = [...cart];
      updatedCart[existingIndex].quantity += qtyToAdd;
      setCart(updatedCart);
    } else {
      setCart([
        ...cart,
        {
          cartKey: itemKey,
          productId: product.id,
          name: product.name,
          variant: selectedVariant,
          sellPrice: finalPrice,
          buyPrice: product.buyPrice,
          vatRate: product.vatRate || 20,
          quantity: qtyToAdd,
          isWeight: product.isWeight,
          unit: product.unit || 'unité',
          image: product.image
        }
      ]);
    }
    return true;
  };

  // Weight Modal Submit
  const handleConfirmWeight = async (e) => {
    e.preventDefault();
    const weightVal = parseSafeFloat(weightInput, 0);
    if (weightVal && weightVal > 0 && weightModalProduct) {
      const added = await handleAddToCart(weightModalProduct, null, weightVal);
      if (added) {
        setWeightModalProduct(null);
        setWeightInput('');
      }
    }
  };

  // Custom / Free Item ("Article Divers / Vente Libre") Submit
  const handleConfirmCustomItem = (e) => {
    e.preventDefault();
    const finalPrice = parseSafeFloat(customItemData.price, 0);
    if (!finalPrice || finalPrice <= 0) {
      toast.error("Veuillez saisir un prix de vente valide supérieur à 0.", "Prix invalide");
      return;
    }

    const finalQty = Math.max(0.01, parseSafeFloat(customItemData.quantity, 1));
    const itemName = customItemData.name.trim() || 'Article Divers';
    const vatRate = parseSafeFloat(customItemData.vatRate, 20);
    const buyPrice = parseSafeFloat(customItemData.buyPrice, 0);

    const customKey = `custom-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    const customItem = {
      cartKey: customKey,
      productId: null, // Vente libre sans déstockage
      name: itemName,
      sellPrice: finalPrice,
      buyPrice: buyPrice,
      vatRate: vatRate,
      quantity: finalQty,
      isWeight: false,
      unit: 'unité',
      isCustom: true
    };

    setCart([...cart, customItem]);
    toast.success(`« ${itemName} » (${finalPrice.toFixed(2)} ${currency}) ajouté au panier !`, "Vente Libre");
    setCustomItemData({
      name: '',
      price: '',
      buyPrice: '',
      vatRate: '20',
      quantity: '1'
    });
    setShowCustomItemModal(false);
  };

  // Auto-add product scanned from camera modal
  useEffect(() => {
    if (scannedProductToAdd) {
      handleAddToCart(scannedProductToAdd).then((added) => {
        if (onScannedProductAdded) {
          onScannedProductAdded();
        }
        if (added) {
          toast.success(
            `« ${scannedProductToAdd.name} » ajouté au panier !`,
            'Scan Caméra Validé'
          );
        }
      });
    }
  }, [scannedProductToAdd]);

  // Cart Calculations with Discounts & Fidelity Program
  const grossTotal = cart.reduce((sum, item) => {
    const itemDisc = (item.discountPercent || 0) / 100;
    const discountedUnitPrice = item.sellPrice * (1 - itemDisc);
    return sum + (discountedUnitPrice * item.quantity);
  }, 0);

  const globalFactor = 1 - (globalDiscount / 100);
  const totalAfterGlobalDiscount = Math.max(0, grossTotal * globalFactor);

  // Fidelity / Loyalty Program Variables
  const fidelityEnabled = settings.fidelityEnabled !== false;
  const fidelityRatio = Number(settings.fidelityRatio) || 1;
  const fidelityRedeemValue = Number(settings.fidelityRedeemValue) || 0.05;
  const clientPoints = Number(selectedClient?.points || 0);
  const pointsValue = clientPoints * fidelityRedeemValue;

  const maxRedeemablePoints = selectedClient && fidelityEnabled && clientPoints > 0
    ? Math.min(clientPoints, Math.floor(totalAfterGlobalDiscount / fidelityRedeemValue))
    : 0;

  const effectiveRedeemedPoints = Math.min(redeemPoints, maxRedeemablePoints);
  const fidelityDiscountAmount = Math.round(effectiveRedeemedPoints * fidelityRedeemValue * 100) / 100;

  const totalTTC = Math.max(0, Math.round((totalAfterGlobalDiscount - fidelityDiscountAmount) * 100) / 100);

  const subtotalHT = cart.reduce((sum, item) => {
    const itemDisc = (item.discountPercent || 0) / 100;
    const discountedUnitPrice = item.sellPrice * (1 - itemDisc) * globalFactor;
    const itemTotal = discountedUnitPrice * item.quantity;
    const vatFactor = 1 + ((item.vatRate || 20) / 100);
    return sum + (itemTotal / vatFactor);
  }, 0);

  const totalVAT = Math.max(0, totalTTC - (subtotalHT * (totalAfterGlobalDiscount > 0 ? (totalTTC / totalAfterGlobalDiscount) : 1)));

  // Full price without discount to compute total savings
  const originalFullTotal = cart.reduce((sum, item) => sum + (item.sellPrice * item.quantity), 0);
  const totalSavings = Math.max(0, originalFullTotal - totalTTC);

  // Points earned on current sale
  const pointsEarnedOnSale = fidelityEnabled ? Math.floor(totalTTC * fidelityRatio) : 0;

  // Change Return Calculation
  const receivedNum = parseSafeFloat(amountReceived, 0);
  const changeToReturn = Math.max(0, receivedNum - totalTTC);

  // Hold Cart Logic (Park / Resume)
  const handleHoldCart = () => {
    if (cart.length === 0) {
      toast.warning("Votre panier est vide. Aucun article à mettre en pause.", "Panier vide");
      return;
    }
    const defaultLabel = selectedClient 
      ? selectedClient.name 
      : `Client #${heldCarts.length + 1}`;

    const newHeldCart = {
      id: Date.now(),
      label: defaultLabel,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      createdAt: new Date().toISOString(),
      items: cart,
      selectedClient: selectedClient,
      globalDiscount: globalDiscount,
      total: totalTTC
    };

    setHeldCarts([newHeldCart, ...heldCarts]);
    setCart([]);
    setSelectedClient(null);
    setGlobalDiscount(0);
    toast.success(`Panier "${defaultLabel}" (${cart.length} articles) mis en attente.`, "⏸️ Panier en pause");
  };

  const handleRestoreHeldCart = (heldCart) => {
    if (cart.length > 0) {
      const ok = window.confirm("Votre panier actuel contient déjà des articles. Voulez-vous le remplacer par ce panier en attente ?");
      if (!ok) return;
    }

    setCart(heldCart.items || []);
    setSelectedClient(heldCart.selectedClient || null);
    setGlobalDiscount(heldCart.globalDiscount || 0);
    setHeldCarts(heldCarts.filter(c => c.id !== heldCart.id));
    setShowHeldCartsModal(false);
    toast.info(`Panier "${heldCart.label || 'en attente'}" rechargé en caisse.`, "▶️ Panier repris");
  };

  const handleDeleteHeldCart = (cartId) => {
    setHeldCarts(heldCarts.filter(c => c.id !== cartId));
    toast.info("Panier en attente supprimé.");
  };

  // Record Cash Drawer Expense / Withdrawal
  const handleRecordExpense = async (e) => {
    e.preventDefault();
    const amt = parseSafeFloat(expenseAmount, 0);
    if (!amt || amt <= 0) {
      toast.warning("Veuillez saisir un montant supérieur à 0.", "Montant invalide");
      return;
    }

    const movement = {
      timestamp: new Date().toISOString(),
      amount: amt,
      reason: expenseReason || 'Sortie de Caisse',
      cashier: currentCashierName || 'Patron'
    };

    if (db.cashMovements) {
      await db.cashMovements.add(movement);
    }

    toast.success(`Sortie de caisse de ${amt.toFixed(2)} ${currency} enregistrée.`);
    setExpenseAmount('');
    setShowExpenseModal(false);
    if (onRefreshData) onRefreshData();
  };

  // Generate Proforma Quote from Cart
  const handleCreateQuote = async () => {
    if (cart.length === 0) {
      handleOpenQuotesList();
      return;
    }

    const todayStr = getLocalDateCompact();
    const randSuffix = Math.floor(1000 + Math.random() * 9000);
    const quoteNo = `DEV-${todayStr}-${randSuffix}`;

    const quoteRecord = {
      quoteNo,
      timestamp: new Date().toISOString(),
      validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      clientId: selectedClient ? selectedClient.id : null,
      clientName: selectedClient ? selectedClient.name : 'Client Particulier',
      clientPhone: selectedClient ? selectedClient.phone : '',
      items: [...cart],
      subtotalHT: Math.round(subtotalHT * 100) / 100,
      totalVAT: Math.round(totalVAT * 100) / 100,
      totalTTC: Math.round(totalTTC * 100) / 100,
      globalDiscount,
      totalSavings: Math.round(totalSavings * 100) / 100,
      cashier: currentCashierName || 'Patron',
      status: 'en_attente'
    };

    if (db.quotes) {
      const id = await db.quotes.add(quoteRecord);
      quoteRecord.id = id;
    }

    setActiveQuote(quoteRecord);
    setShowQuoteModal(true);
  };

  // View Saved Quotes List
  const handleOpenQuotesList = async () => {
    if (db.quotes) {
      const list = await db.quotes.reverse().toArray();
      setSavedQuotes(list);
    }
    setShowQuotesListModal(true);
  };

  // Convert Quote to Active Sale Cart
  const handleConvertQuoteToSale = async (quote) => {
    setCart(quote.items || []);
    if (quote.clientId && clients) {
      const c = clients.find(cl => cl.id === quote.clientId);
      if (c) setSelectedClient(c);
    }
    if (quote.globalDiscount) {
      setGlobalDiscount(quote.globalDiscount);
    }
    if (db.quotes && quote.id) {
      await db.quotes.update(quote.id, { status: 'converti' });
    }
    setShowQuotesListModal(false);
    setShowQuoteModal(false);
    toast.success(`Devis ${quote.quoteNo} chargé dans le panier.`, "Devis importé");
  };

  // Complete Sale Execution
  const handleCompleteSale = async () => {
    // 1. Strict validation: empty cart
    if (cart.length === 0) {
      toast.warning('Le panier est vide. Veuillez ajouter au moins un produit avant d\'encaisser.', 'Panier vide');
      return;
    }

    // 2. Strict validation: positive sale total
    if (totalTTC <= 0) {
      toast.error('Le montant total de la vente doit être strictement supérieur à 0.', 'Montant invalide');
      return;
    }

    // 3. Strict validation: cash amount given by customer
    const receivedNum = parseSafeFloat(amountReceived, NaN);
    if (paymentMethod === 'especes') {
      if (isNaN(receivedNum) || receivedNum < totalTTC) {
        toast.error(`Montant reçu insuffisant (${isNaN(receivedNum) ? '0.00' : receivedNum.toFixed(2)} ${currency} sur ${totalTTC.toFixed(2)} ${currency} dus).`, 'Règlement Espèces');
        return;
      }
    }

    // 4. Strict validation: credit payment rules
    if (paymentMethod === 'credit') {
      if (!selectedClient) {
        toast.error("Veuillez sélectionner un client pour enregistrer une vente à crédit.", "Client obligatoire");
        return;
      }
      const newDebt = (selectedClient.debt || 0) + totalTTC;
      if (selectedClient.maxDebt && newDebt > selectedClient.maxDebt) {
        toast.error(`Blocage de crédit : Ce client dépasserait son plafond maximal (${selectedClient.maxDebt} ${currency}). Solde actuel : ${selectedClient.debt || 0} ${currency}.`, 'Plafond dépassé');
        return;
      }
    }

    // Compute sequential numbering without holes and link to predecessor hash
    const lastSale = await db.sales.orderBy('id').last();
    const count = await db.sales.count();
    const sequenceNumber = (lastSale && typeof lastSale.sequenceNumber === 'number') 
      ? lastSale.sequenceNumber + 1 
      : count + 1;

    const todayStr = getLocalDateCompact();
    const receiptNo = `FAC-${todayStr}-${String(sequenceNumber).padStart(4, '0')}`;
    const timestamp = new Date().toISOString();
    const previousHash = lastSale?.currentHash || GENESIS_HASH;

    const preliminaryData = {
      receiptNo,
      timestamp,
      items: cart,
      subtotalHT: Math.round(subtotalHT * 100) / 100,
      totalVAT: Math.round(totalVAT * 100) / 100,
      totalTTC: Math.round(totalTTC * 100) / 100,
      paymentMethod
    };

    // Seal sale cryptographically (NF525 compliant hash-chaining)
    const sealInfo = await computeSaleSeal(previousHash, preliminaryData, sequenceNumber);

    const saleRecord = {
      ...preliminaryData,
      sequenceNumber,
      previousHash: sealInfo.previousHash,
      currentHash: sealInfo.currentHash,
      sealShort: sealInfo.sealShort,
      sealedAt: sealInfo.sealedAt,
      amountReceived: paymentMethod === 'especes' ? receivedNum : preliminaryData.totalTTC,
      changeReturned: paymentMethod === 'especes' ? Math.round(changeToReturn * 100) / 100 : 0,
      clientId: selectedClient ? selectedClient.id : null,
      clientName: selectedClient ? selectedClient.name : 'Client Passant',
      clientPhone: selectedClient ? selectedClient.phone : '',
      isCredit: paymentMethod === 'credit',
      cashier: currentCashierName || 'Patron',
      globalDiscount: globalDiscount,
      totalSavings: Math.round(totalSavings * 100) / 100,
      redeemedPoints: effectiveRedeemedPoints,
      fidelityDiscount: fidelityDiscountAmount,
      pointsEarned: pointsEarnedOnSale,
      clientPreviousPoints: clientPoints,
      clientRemainingPoints: selectedClient ? (Math.max(0, clientPoints - effectiveRedeemedPoints) + pointsEarnedOnSale) : 0,
      cardAuthRef: paymentMethod === 'carte' && cardAuthRef ? cardAuthRef : undefined,
      synced: false
    };

    // Exécution atomique sécurisée via transaction ACID Dexie
    try {
      await db.transaction('rw', [db.sales, db.products, db.clients], async () => {
        // 1. Enregistrement du ticket certifié dans IndexedDB
        const newSaleId = await db.sales.add(saleRecord);
        saleRecord.id = newSaleId;

        // 2. Décrémentation atomique des stocks des articles vendus
        for (const item of cart) {
          const prodId = item.productId || item.id;
          if (prodId) {
            const prod = await db.products.get(prodId);
            if (prod) {
              const newStock = Math.max(0, (Number(prod.stock) || 0) - Number(item.quantity));
              await db.products.update(prodId, { 
                stock: newStock,
                synced: false,
                updatedAt: new Date().toISOString()
              });
            }
          }
        }

        // 3. Mise à jour atomique de la dette / points de fidélité du client
        if (selectedClient && selectedClient.id) {
          const clientRecord = await db.clients.get(selectedClient.id);
          if (clientRecord) {
            let updatedDebt = Number(clientRecord.debt || 0);
            if (paymentMethod === 'credit') {
              updatedDebt += totalTTC;
            }

            let currentPoints = Number(clientRecord.points || 0);
            let updatedPoints = currentPoints;
            if (fidelityEnabled) {
              updatedPoints = Math.max(0, currentPoints - effectiveRedeemedPoints) + pointsEarnedOnSale;
            }

            await db.clients.update(selectedClient.id, {
              debt: Math.round(updatedDebt * 100) / 100,
              points: updatedPoints
            });
          }
        }
      });
    } catch (err) {
      console.error('[CaisseView] Échec de la transaction ACID (Rollback automatique Dexie) :', err);
      toast.error(
        `Erreur lors de l'encaissement (Transaction annulée, aucune donnée corrompue) : ${err.message}`,
        'Intégrité ACID'
      );
      return;
    }

    // Push changes to Supabase cloud in background if connected
    syncManager.syncNow().catch(err => console.warn('[CloudSync] Sync report:', err));

    // 4. Trigger celebration confetti
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 }
    });

    // 5. Close payment modal, set receipt modal
    setShowPaymentModal(false);
    setCompletedSale(saleRecord);
    setShowReceiptModal(true);
    setCart([]);
    setGlobalDiscount(0);
    setRedeemPoints(0);
    setAmountReceived('');
    setCardAuthRef('');
    setSelectedClient(null);

    toast.success(`Vente ${receiptNo} enregistrée avec succès (${totalTTC.toFixed(2)} ${currency}) !`, 'Encaissement Validé');

    if (onRefreshData) onRefreshData();
  };

  // WhatsApp Send helper
  const handleSendWhatsAppReceipt = (sale) => {
    if (!sale) return;
    const phone = sale.clientPhone ? sale.clientPhone.replace(/\s+/g, '') : '';
    const message = `🧾 *REÇU DE CAISSE - ${settings.shopName || 'Boutique'}*\n` +
      `N° Facture: ${sale.receiptNo}\n` +
      `Date: ${new Date(sale.timestamp).toLocaleString()}\n` +
      (sale.sealShort ? `🔐 Sceau NF525: ${sale.sealShort} (Index #${sale.sequenceNumber || 1})\n` : '') +
      `\n*ARTICLES:*\n` +
      sale.items.map(i => `• ${i.name} ${i.variant ? `(${i.variant})` : ''} x${i.quantity} = ${(i.sellPrice * i.quantity).toFixed(2)} ${currency}`).join('\n') +
      `\n\n` +
      `*Sous-Total HT:* ${Number(sale.subtotalHT ?? (sale.totalTTC / 1.2) ?? 0).toFixed(2)} ${currency}\n` +
      `*TVA:* ${Number(sale.totalVAT ?? (sale.totalTTC - (sale.subtotalHT || (sale.totalTTC / 1.2))) ?? 0).toFixed(2)} ${currency}\n` +
      (sale.fidelityDiscount > 0 ? `🎁 *Remise Fidélité:* -${Number(sale.fidelityDiscount).toFixed(2)} ${currency} (${sale.redeemedPoints} pts)\n` : '') +
      `*TOTAL TTC:* ${Number(sale.totalTTC || 0).toFixed(2)} ${currency}\n` +
      `*Mode de Règlement:* ${(sale.paymentMethod || 'Espèces').toUpperCase()}\n` +
      (sale.clientRemainingPoints !== undefined ? `⭐ *Solde Fidélité:* ${sale.clientRemainingPoints} pts\n\n` : '\n') +
      `Merci pour votre confiance ! 🌸`;

    const encoded = encodeURIComponent(message);
    const url = phone ? `https://wa.me/${phone}?text=${encoded}` : `https://wa.me/?text=${encoded}`;
    window.open(url, '_blank');
  };

  return (
    <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 py-4 pb-36 sm:pb-16">
      
      {/* Top Quick Action Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4 bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        
        {/* Category Filters Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-500/30'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Cashier Selector & Scanner Bar */}
        <div className="flex items-center gap-2 ml-auto">
          {/* Quick Cashier Selector & Shift Switch Button */}
          {onOpenSwitchCashier ? (
            <button
              type="button"
              onClick={onOpenSwitchCashier}
              className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 hover:bg-indigo-50 dark:bg-slate-800 dark:hover:bg-indigo-950/60 rounded-xl text-xs border border-slate-200 dark:border-slate-700 transition active:scale-95 shadow-xs"
              title="Changer de caissier actif pour ce poste de vente"
            >
              <div
                className="w-5 h-5 rounded-lg flex items-center justify-center text-white text-[10px] font-black"
                style={{ backgroundColor: currentCashierAvatar }}
              >
                {currentCashierName.slice(0, 2).toUpperCase()}
              </div>
              <span className="text-slate-500 font-bold text-[11px] hidden sm:inline">Vendeur:</span>
              <span className="font-extrabold text-slate-800 dark:text-slate-200 text-xs">
                {currentCashierName}
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 font-bold text-slate-600 dark:text-slate-300">
                {currentCashierRole === 'patron' ? '👑' : currentCashierRole === 'gerant' ? '🎖️' : '💼'}
              </span>
              <ArrowRightLeft className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
            </button>
          ) : (
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs border border-slate-200 dark:border-slate-700">
              <span className="text-slate-500 font-bold text-[11px] hidden sm:inline">👤 Vendeur:</span>
              <span className="font-extrabold text-slate-800 dark:text-slate-200 text-xs">
                {currentCashierName}
              </span>
            </div>
          )}

          {/* Cash Drawer Expense Button */}
          <button
            onClick={() => setShowExpenseModal(true)}
            className="px-2.5 sm:px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 rounded-xl text-xs font-bold border border-rose-200 dark:border-rose-900 flex items-center gap-1 transition active:scale-95"
            title="Enregistrer une sortie d'espèces (dépense, fournitures, coursier)"
          >
            <Coins className="w-3.5 h-3.5 text-rose-600" />
            <span className="hidden sm:inline">Sortie Caisse</span>
          </button>

          {/* Quick Cash Drawer Kick (RJ11 / F12) */}
          <button
            onClick={() => {
              triggerOpenCashDrawer('Ouverture Rapide Caisse', currentCashierName || 'Caissier');
              playRetailSound('drawer');
              toast.info('Tiroir-caisse déclenché (RJ11)', 'Tiroir Ouvert');
            }}
            className="px-2.5 sm:px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 rounded-xl text-xs font-bold border border-emerald-200 dark:border-emerald-900 flex items-center gap-1 transition active:scale-95"
            title="Ouvrir le tiroir-caisse manuellement (Raccourci clavier: F12)"
          >
            <Banknote className="w-3.5 h-3.5 text-emerald-600" />
            <span>Tiroir (F12)</span>
          </button>

          {/* Returns & Avoirs Button */}
          <button
            onClick={() => setShowRefundModal(true)}
            className="px-2.5 sm:px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 rounded-xl text-xs font-bold border border-amber-200 dark:border-amber-900 flex items-center gap-1 transition active:scale-95"
            title="Retourner un article, réintégrer en stock et générer un avoir"
          >
            <ArrowRightLeft className="w-3.5 h-3.5 text-amber-600" />
            <span className="hidden sm:inline">Retours & Avoirs</span>
          </button>

          {/* Quotes / Proforma Generator Button */}
          <button
            onClick={handleCreateQuote}
            className="px-2.5 sm:px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 flex items-center gap-1 transition active:scale-95"
            title="Générer un Devis / Facture Proforma ou consulter l'historique"
          >
            <FileText className="w-3.5 h-3.5 text-indigo-600" />
            <span className="hidden sm:inline">{cart.length > 0 ? 'Créer Devis' : 'Devis'}</span>
          </button>

          {/* Official Cash Closing (Ticket Z & Ticket X) Button */}
          <button
            onClick={() => setShowCashClosingModal(true)}
            className="px-2.5 sm:px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 rounded-xl text-xs font-bold border border-indigo-200 dark:border-indigo-900 flex items-center gap-1 transition active:scale-95"
            title="Consulter le Ticket X ou effectuer la Clôture Journalière (Ticket Z)"
          >
            <Calculator className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
            <span className="hidden sm:inline">Clôture (Z/X)</span>
          </button>

          {/* Quick Custom Item / Vente Libre Button */}
          <button
            onClick={() => setShowCustomItemModal(true)}
            className="px-3 sm:px-3.5 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-extrabold shadow-md shadow-emerald-500/20 transition flex items-center gap-1.5 active:scale-95"
            title="Vente rapide sans code-barres (pain, recharge, dépannage, article divers) - Raccourci F4"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-200" />
            <span>⚡ Vente Libre</span>
          </button>

          <button
            onClick={onOpenScanner}
            className="px-3.5 py-1.5 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-500/20 hover:opacity-95 transition flex items-center gap-1.5 active:scale-95"
          >
            <Zap className="w-4 h-4 text-yellow-300 animate-pulse" />
            <span>📷 {t.scanner}</span>
          </button>
          
          {/* Held Carts / Parked Orders Button */}
          <button
            onClick={() => setShowHeldCartsModal(true)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold border flex items-center gap-1.5 transition active:scale-95 ${
              heldCarts.length > 0
                ? 'bg-amber-500 hover:bg-amber-600 text-white border-amber-600 shadow-md shadow-amber-500/25'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-200 dark:border-slate-700'
            }`}
            title="Consulter et reprendre les paniers mis en attente"
          >
            <Clock className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Paniers en pause</span>
            {heldCarts.length > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-white text-amber-700 text-[10px] font-black">
                {heldCarts.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Main Grid & Cart 2-Column POS Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Product Selection Grid (7 Columns on LG) */}
        <div className="lg:col-span-7 space-y-4">
          {searchQuery && (
            <div className="flex items-center justify-between px-3.5 py-2 bg-indigo-50/80 dark:bg-indigo-950/40 border border-indigo-200/70 dark:border-indigo-800/60 rounded-2xl text-xs text-indigo-700 dark:text-indigo-300">
              <div className="flex items-center gap-2 truncate">
                <Search className="w-4 h-4 text-indigo-500 shrink-0" />
                <span className="truncate">
                  Recherche : <strong className="font-bold">"{searchQuery}"</strong>
                </span>
              </div>
              <span className="text-[11px] font-extrabold px-2 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 shrink-0">
                {filteredProducts.length} article{filteredProducts.length > 1 ? 's' : ''}
              </span>
            </div>
          )}

          {filteredProducts.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 sm:p-12 text-center shadow-sm">
              <div className="w-14 h-14 bg-indigo-50 dark:bg-slate-800 text-indigo-500 rounded-2xl flex items-center justify-center mx-auto mb-3">
                <Search className="w-7 h-7 opacity-70" />
              </div>
              <h3 className="text-base font-bold text-slate-800 dark:text-slate-100 mb-1">
                Aucun produit trouvé
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mb-4">
                {searchQuery
                  ? `Aucun article ne correspond à votre recherche « ${searchQuery} »${selectedCategory !== 'Tous' ? ` dans la catégorie « ${selectedCategory} »` : ''}.`
                  : `Aucun produit disponible dans la catégorie « ${selectedCategory} ».`}
              </p>
              <button
                type="button"
                onClick={() => {
                  setCustomItemData({
                    name: searchQuery ? searchQuery.trim() : 'Article Divers',
                    price: '',
                    buyPrice: '',
                    vatRate: '20',
                    quantity: '1'
                  });
                  setShowCustomItemModal(true);
                }}
                className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:opacity-95 text-white font-extrabold rounded-xl text-xs shadow-md shadow-emerald-500/20 inline-flex items-center gap-1.5 transition active:scale-95"
              >
                <Sparkles className="w-4 h-4" />
                <span>Ajouter en Vente Libre Immédiate</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4">
              {filteredProducts.map((product) => {
                const isOutOfStock = Number(product.stock !== undefined ? product.stock : 9999) <= 0;
                const isLowStock = !isOutOfStock && product.stock <= (product.minStock || 3);

                return (
                  <div
                    key={product.id}
                    onClick={() => handleAddToCart(product)}
                    className={`group bg-white dark:bg-slate-900 border rounded-2xl p-3 shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer flex flex-col justify-between relative overflow-hidden active:scale-98 ${
                      isOutOfStock
                        ? 'border-rose-300 dark:border-rose-900/60 bg-rose-50/15 dark:bg-rose-950/10 hover:border-rose-500'
                        : 'border-slate-200/80 dark:border-slate-800/80 hover:border-indigo-500 dark:hover:border-indigo-500'
                    }`}
                  >
                    {/* Product Badge Stock Alert */}
                    {isOutOfStock ? (
                      <span className="absolute top-2 right-2 z-10 px-2 py-0.5 text-[10px] font-black rounded-md bg-rose-600 text-white shadow-md flex items-center gap-1">
                        ⚠️ Rupture ({product.stock ?? 0})
                      </span>
                    ) : isLowStock ? (
                      <span className="absolute top-2 right-2 z-10 px-1.5 py-0.5 text-[10px] font-extrabold rounded-md bg-amber-500 text-white shadow-sm">
                        Stock : {product.stock}
                      </span>
                    ) : null}

                    {/* Product Image */}
                    <div className="aspect-square w-full rounded-xl bg-slate-100 dark:bg-slate-800 overflow-hidden mb-2 relative">
                      {product.image ? (
                        <>
                          <img 
                            src={product.image} 
                            alt={product.name} 
                            onError={(e) => {
                              e.currentTarget.style.display = 'none';
                              const fallback = e.currentTarget.parentElement.querySelector('.image-fallback');
                              if (fallback) fallback.classList.remove('hidden');
                            }}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                          <div className="image-fallback hidden w-full h-full flex flex-col items-center justify-center bg-indigo-50 dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 font-extrabold text-lg">
                            <ShoppingBag className="w-6 h-6 mb-1 opacity-70" />
                            <span>{product.name.slice(0, 2).toUpperCase()}</span>
                          </div>
                        </>
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center bg-indigo-50 dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 font-extrabold text-lg">
                          <ShoppingBag className="w-6 h-6 mb-1 opacity-70" />
                          <span>{product.name.slice(0, 2).toUpperCase()}</span>
                        </div>
                      )}
                      {product.isWeight && (
                        <span className="absolute bottom-1 left-1 px-1.5 py-0.5 bg-slate-900/80 text-white rounded text-[10px] font-bold flex items-center gap-1">
                          <Scale className="w-3 h-3 text-emerald-400" /> Au Kg
                        </span>
                      )}
                    </div>

                    {/* Product Info */}
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 block truncate">
                        {product.brand || product.category}
                      </span>
                      <h3 className="font-semibold text-xs sm:text-sm text-slate-800 dark:text-slate-100 line-clamp-1 group-hover:text-indigo-600 transition-colors">
                        {product.name}
                      </h3>

                      <div className="flex items-center justify-between mt-2 pt-1 border-t border-slate-100 dark:border-slate-800">
                        <span className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white">
                          {product.sellPrice.toFixed(2)} <span className="text-xs font-semibold text-slate-500">{currency}</span>
                        </span>
                        <button 
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleAddToCart(product);
                          }}
                          aria-label={`Ajouter ${product.name} au panier`}
                          className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors ${
                            isOutOfStock
                              ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 group-hover:bg-rose-600 group-hover:text-white'
                              : 'bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-300 group-hover:bg-indigo-600 group-hover:text-white'
                          }`}
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
        )}
      </div>

        {/* Right Column: POS Cart Panel (5 Columns on LG) */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-4 sm:p-5 shadow-lg sticky top-20">
          
          {/* Cart Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 mb-3">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-indigo-100 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-300">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-bold text-base text-slate-900 dark:text-white">{t.panier}</h2>
                <span className="text-xs text-slate-500">{cart.length} articles sélectionnés</span>
              </div>
            </div>
            {cart.length > 0 && (
              <div className="flex items-center gap-1">
                <button
                  onClick={handleHoldCart}
                  className="px-2.5 py-1 text-amber-700 bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/50 dark:text-amber-300 border border-amber-200 dark:border-amber-800/80 rounded-xl text-xs font-bold flex items-center gap-1 transition active:scale-95"
                  title="Mettre en pause ce panier pour servir un autre client"
                >
                  <PauseCircle className="w-3.5 h-3.5" />
                  <span>En pause</span>
                </button>
                <button
                  onClick={() => setCart([])}
                  className="p-1.5 text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-xl text-xs font-semibold transition"
                  title={t.viderPanier}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

          {/* Client Selection Bar */}
          <div className="mb-3">
            <select
              value={selectedClient ? selectedClient.id : ''}
              onChange={(e) => {
                const found = clients.find(c => c.id === parseInt(e.target.value));
                setSelectedClient(found || null);
                setRedeemPoints(0);
              }}
              className="w-full text-xs font-medium bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="">👤 Client Passant (Anonyme)</option>
              {clients.map(c => (
                <option key={c.id} value={c.id}>
                  👤 {c.name} {c.points ? `(${c.points} pts)` : ''} {c.debt > 0 ? `(Dette : ${c.debt} ${currency})` : ''}
                </option>
              ))}
            </select>
          </div>

          {/* Loyalty / Fidelity Balance Banner in Cart */}
          {selectedClient && fidelityEnabled && (
            <div className="mb-3 p-2.5 bg-gradient-to-r from-amber-50 to-indigo-50 dark:from-slate-800 dark:to-indigo-950/40 rounded-xl border border-amber-200 dark:border-indigo-900/60 text-xs">
              <div className="flex items-center justify-between mb-1">
                <span className="font-extrabold text-amber-900 dark:text-amber-200 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>Fidélité :</span>
                </span>
                <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400">
                  {clientPoints} pts ({pointsValue.toFixed(2)} {currency})
                </span>
              </div>

              {clientPoints > 0 && maxRedeemablePoints > 0 ? (
                <div className="flex items-center justify-between gap-2 pt-1 border-t border-amber-200/60 dark:border-indigo-900/40">
                  <span className="text-[11px] text-slate-600 dark:text-slate-300">
                    {effectiveRedeemedPoints > 0 ? `${effectiveRedeemedPoints} pts déduits` : `Points convertibles`}
                  </span>
                  {effectiveRedeemedPoints > 0 ? (
                    <button
                      type="button"
                      onClick={() => setRedeemPoints(0)}
                      className="px-2 py-0.5 bg-rose-100 hover:bg-rose-200 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 rounded-lg text-[10px] font-bold transition"
                    >
                      Annuler remise
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setRedeemPoints(maxRedeemablePoints)}
                      className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-[10px] font-extrabold shadow-sm active:scale-95 transition"
                    >
                      Convertir {maxRedeemablePoints} pts (-{(maxRedeemablePoints * fidelityRedeemValue).toFixed(2)} {currency})
                    </button>
                  )}
                </div>
              ) : (
                <div className="text-[10px] text-slate-500 dark:text-slate-400 pt-0.5">
                  +{pointsEarnedOnSale} pts seront crédités sur cette vente
                </div>
              )}
            </div>
          )}

          {/* Cart Item List */}
          <div className="max-h-[280px] overflow-y-auto space-y-2 pr-1 mb-4">
            {cart.length === 0 ? (
              <div className="text-center py-10 px-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700">
                <ShoppingBag className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-600 mb-2" />
                <p className="text-xs text-slate-500 dark:text-slate-400">{t.panierVide}</p>
              </div>
            ) : (
              cart.map((item, idx) => (
                <div 
                  key={item.cartKey} 
                  className="flex items-center justify-between p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800 gap-2"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <h4 className="font-bold text-xs text-slate-800 dark:text-slate-100 truncate">
                        {item.name}
                      </h4>
                      {item.isCustom && (
                        <span className="text-[9px] font-extrabold text-emerald-700 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-950/80 px-1.5 py-0.2 rounded-md shrink-0 border border-emerald-300 dark:border-emerald-800">
                          Vente Libre
                        </span>
                      )}
                    </div>
                    {item.variant && (
                      <span className="text-[10px] font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950 px-1.5 py-0.5 rounded">
                        {item.variant}
                      </span>
                    )}
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      {item.sellPrice.toFixed(2)} {currency} {item.isWeight ? `/ ${item.unit}` : ''}
                    </div>
                  </div>

                  {/* Quantity and Discount adjustment buttons */}
                  <div className="flex items-center gap-1.5">
                    {/* Item Discount Toggle Button */}
                    <button
                      onClick={() => {
                        const updated = [...cart];
                        const current = updated[idx].discountPercent || 0;
                        const next = current === 0 ? 5 : current === 5 ? 10 : current === 10 ? 20 : 0;
                        updated[idx].discountPercent = next;
                        setCart(updated);
                      }}
                      className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold transition ${
                        item.discountPercent 
                          ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border border-amber-300 dark:border-amber-700' 
                          : 'bg-slate-200/80 dark:bg-slate-700 text-slate-500 hover:text-amber-600'
                      }`}
                      title="Cliquer pour appliquer une remise (0%, 5%, 10%, 20%)"
                    >
                      {item.discountPercent ? `-${item.discountPercent}%` : '%'}
                    </button>

                    <button
                      onClick={() => {
                        const updated = [...cart];
                        if (updated[idx].quantity > (item.isWeight ? 0.1 : 1)) {
                          updated[idx].quantity -= (item.isWeight ? 0.1 : 1);
                          setCart(updated);
                        } else {
                          setCart(cart.filter((_, i) => i !== idx));
                        }
                      }}
                      className="w-6 h-6 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center text-xs hover:bg-slate-300 transition"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    
                    <span className="font-extrabold text-xs text-slate-900 dark:text-white px-1">
                      {item.isWeight ? item.quantity.toFixed(2) : item.quantity}
                    </span>

                    <button
                      onClick={() => {
                        const updated = [...cart];
                        updated[idx].quantity += (item.isWeight ? 0.1 : 1);
                        setCart(updated);
                      }}
                      className="w-6 h-6 rounded-md bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 flex items-center justify-center text-xs hover:bg-indigo-200 transition"
                    >
                      <Plus className="w-3 h-3" />
                    </button>

                    <span className="font-bold text-xs text-slate-900 dark:text-white min-w-[55px] text-right ml-1">
                      {(item.sellPrice * (1 - (item.discountPercent || 0) / 100) * item.quantity).toFixed(2)} {currency}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Global Discount Selector */}
          {cart.length > 0 && (
            <div className="flex items-center justify-between p-2 rounded-xl bg-slate-100 dark:bg-slate-800/80 mb-3 text-xs border border-slate-200 dark:border-slate-700">
              <span className="font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1">
                <Tag className="w-3.5 h-3.5 text-indigo-500" />
                <span>Remise panier :</span>
              </span>
              <div className="flex items-center gap-1">
                {[0, 5, 10, 15, 20].map(disc => (
                  <button
                    key={disc}
                    onClick={() => setGlobalDiscount(disc)}
                    className={`px-2 py-0.5 rounded-lg text-[10px] font-extrabold transition ${
                      globalDiscount === disc
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : 'bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'
                    }`}
                  >
                    {disc === 0 ? '0%' : `-${disc}%`}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Totals & Tax Summary Breakdown */}
          <div className="space-y-1.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 mb-4 text-xs">
            {totalSavings > 0 && (
              <div className="flex justify-between text-emerald-600 dark:text-emerald-400 font-bold bg-emerald-50 dark:bg-emerald-950/60 p-1.5 rounded-lg">
                <span>🎁 Économie accordée :</span>
                <span>-{totalSavings.toFixed(2)} {currency}</span>
              </div>
            )}
            {fidelityDiscountAmount > 0 && (
              <div className="flex justify-between text-indigo-600 dark:text-indigo-400 font-bold bg-indigo-50 dark:bg-indigo-950/60 p-1.5 rounded-lg">
                <span>⭐ Déduction Fidélité ({effectiveRedeemedPoints} pts) :</span>
                <span>-{fidelityDiscountAmount.toFixed(2)} {currency}</span>
              </div>
            )}
            <div className="flex justify-between text-slate-600 dark:text-slate-400">
              <span>{t.totalHT}</span>
              <span>{subtotalHT.toFixed(2)} {currency}</span>
            </div>
            {settings.modules?.vat && (
              <div className="flex justify-between text-slate-600 dark:text-slate-400">
                <span>{t.tva} (Calculée)</span>
                <span>{totalVAT.toFixed(2)} {currency}</span>
              </div>
            )}
            <div className="flex justify-between items-baseline pt-2 border-t border-slate-200 dark:border-slate-700 font-extrabold text-sm sm:text-base text-slate-900 dark:text-white">
              <span>{t.totalTTC}</span>
              <span className="text-xl text-indigo-600 dark:text-indigo-400">
                {totalTTC.toFixed(2)} {currency}
              </span>
            </div>
          </div>

          {/* Speed Checkout Actions */}
          <div className="grid grid-cols-2 gap-2 mb-2">
            <button
              disabled={cart.length === 0}
              onClick={() => {
                setPaymentMethod('especes');
                setAmountReceived(totalTTC.toString());
                setShowPaymentModal(true);
              }}
              className="py-2.5 px-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1 shadow-sm transition active:scale-95"
            >
              <Banknote className="w-4 h-4" />
              <span>Espèces Exactes ⚡</span>
            </button>
            <button
              disabled={cart.length === 0}
              onClick={() => {
                setPaymentMethod('carte');
                setAmountReceived(totalTTC.toString());
                setShowPaymentModal(true);
              }}
              className="py-2.5 px-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1 shadow-sm transition active:scale-95"
            >
              <CreditCard className="w-4 h-4" />
              <span>Carte Bancaire 💳</span>
            </button>
          </div>

          {/* Hold Cart Footer Action Button */}
          {cart.length > 0 && (
            <button
              type="button"
              onClick={handleHoldCart}
              className="w-full py-2 px-3 bg-amber-50 hover:bg-amber-100 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300 border border-amber-200 dark:border-amber-800/80 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition active:scale-95 mb-2 shadow-xs"
              title="Mettre en pause ce panier pour servir un autre client"
            >
              <PauseCircle className="w-4 h-4 text-amber-600" />
              <span>⏸️ Mettre ce Panier en Attente (Pause)</span>
            </button>
          )}

          <button
            disabled={cart.length === 0}
            onClick={() => setShowPaymentModal(true)}
            className="w-full py-3.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 disabled:opacity-50 text-white font-extrabold rounded-2xl text-sm shadow-md shadow-indigo-500/25 flex items-center justify-center gap-2 transition active:scale-98"
          >
            <span>{t.encaisser}</span>
            <span className="px-2 py-0.5 bg-white/20 rounded-lg text-xs">
              {totalTTC.toFixed(2)} {currency}
            </span>
          </button>

        </div>

      </div>

      {/* Weight Modal */}
      {weightModalProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-sm w-full border border-slate-200 dark:border-slate-800 shadow-2xl animate-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-emerald-100 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-300 rounded-2xl">
                <Scale className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                  {weightModalProduct.name}
                </h3>
                <span className="text-xs text-slate-500">
                  Prix : {weightModalProduct.sellPrice.toFixed(2)} {currency} / {weightModalProduct.unit || 'kg'}
                </span>
              </div>
            </div>

            <form onSubmit={handleConfirmWeight} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Saisir le Poids (en {weightModalProduct.unit || 'kg'}) :
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  autoFocus
                  required
                  placeholder="ex: 0.250 pour 250g ou 1.5 pour 1.5kg"
                  value={weightInput}
                  onChange={(e) => setWeightInput(sanitizeDecimalInput(e.target.value))}
                  className="w-full text-lg font-bold p-3 bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {parseSafeFloat(weightInput, 0) > 0 && (
                <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl border border-emerald-200 dark:border-emerald-800 text-xs font-bold text-emerald-700 dark:text-emerald-300 flex justify-between">
                  <span>Calcul Total :</span>
                  <span>{(weightModalProduct.sellPrice * parseSafeFloat(weightInput, 0)).toFixed(2)} {currency}</span>
                </div>
              )}

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setWeightModalProduct(null)}
                  className="flex-1 py-2.5 text-xs font-semibold rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 text-xs font-bold rounded-xl bg-emerald-600 text-white shadow-md shadow-emerald-500/20 hover:bg-emerald-700"
                >
                  Ajouter au Panier
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Variant Selector Modal */}
      {variantModalProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-sm w-full border border-slate-200 dark:border-slate-800 shadow-2xl">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white mb-2">
              Choisir la Variante ({variantModalProduct.name})
            </h3>
            <p className="text-xs text-slate-500 mb-4">Sélectionnez la taille, contenance ou couleur :</p>
            <div className="grid grid-cols-2 gap-2 mb-4">
              {variantModalProduct.variants.map((v) => (
                <button
                  key={v}
                  onClick={async () => {
                    const added = await handleAddToCart(variantModalProduct, v);
                    if (added) {
                      setVariantModalProduct(null);
                    }
                  }}
                  className="p-3 text-xs font-bold rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 hover:bg-indigo-600 hover:text-white transition"
                >
                  {v}
                </button>
              ))}
            </div>
            <button
              onClick={() => setVariantModalProduct(null)}
              className="w-full py-2 text-xs font-semibold text-slate-500 hover:text-slate-800"
            >
              Annuler
            </button>
          </div>
        </div>
      )}

      {/* Payment Selection Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-md w-full border border-slate-200 dark:border-slate-800 shadow-2xl animate-in zoom-in-95 duration-150">
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white mb-3">
              Mode de Règlement ({totalTTC.toFixed(2)} {currency})
            </h3>

            {/* Loyalty Points Conversion in Payment Modal */}
            {selectedClient && fidelityEnabled && clientPoints > 0 && maxRedeemablePoints > 0 && (
              <div className="mb-4 p-3 bg-gradient-to-r from-amber-50 to-indigo-50 dark:from-slate-800 dark:to-indigo-950/40 rounded-2xl border border-amber-200 dark:border-indigo-900/60 text-xs">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-amber-500" />
                      <span>Points Fidélité : {clientPoints} pts ({pointsValue.toFixed(2)} {currency})</span>
                    </span>
                    <span className="text-[10px] text-slate-500 block mt-0.5">
                      {effectiveRedeemedPoints > 0 
                        ? `Remise de -${fidelityDiscountAmount.toFixed(2)} ${currency} appliquée` 
                        : `Possibilité de déduire jusqu'à ${(maxRedeemablePoints * fidelityRedeemValue).toFixed(2)} ${currency}`}
                    </span>
                  </div>

                  {effectiveRedeemedPoints > 0 ? (
                    <button
                      type="button"
                      onClick={() => setRedeemPoints(0)}
                      className="px-2.5 py-1.5 bg-rose-100 hover:bg-rose-200 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 rounded-xl text-[11px] font-bold"
                    >
                      Retirer
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setRedeemPoints(maxRedeemablePoints)}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-[11px] font-extrabold shadow-sm active:scale-95"
                    >
                      Déduire {maxRedeemablePoints} pts
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Payment Method Selector Grid */}
            <div className="grid grid-cols-2 gap-2.5 mb-5">
              <button
                onClick={() => setPaymentMethod('especes')}
                className={`p-3 rounded-2xl border text-xs font-bold flex flex-col items-center gap-1.5 transition ${
                  paymentMethod === 'especes'
                    ? 'border-emerald-500 bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 ring-2 ring-emerald-500'
                    : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50'
                }`}
              >
                <Banknote className="w-5 h-5 text-emerald-600" />
                <span>{t.especes}</span>
              </button>
              
              <button
                onClick={() => setPaymentMethod('carte')}
                className={`p-3 rounded-2xl border text-xs font-bold flex flex-col items-center gap-1.5 transition ${
                  paymentMethod === 'carte'
                    ? 'border-blue-500 bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 ring-2 ring-blue-500'
                    : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50'
                }`}
              >
                <CreditCard className="w-5 h-5 text-blue-600" />
                <span>{t.carte}</span>
              </button>

              <button
                onClick={() => setPaymentMethod('virement')}
                className={`p-3 rounded-2xl border text-xs font-bold flex flex-col items-center gap-1.5 transition ${
                  paymentMethod === 'virement'
                    ? 'border-purple-500 bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 ring-2 ring-purple-500'
                    : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50'
                }`}
              >
                <ArrowRightLeft className="w-5 h-5 text-purple-600" />
                <span>{t.virement}</span>
              </button>

              <button
                onClick={() => setPaymentMethod('credit')}
                className={`p-3 rounded-2xl border text-xs font-bold flex flex-col items-center gap-1.5 transition ${
                  paymentMethod === 'credit'
                    ? 'border-amber-500 bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 ring-2 ring-amber-500'
                    : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50'
                }`}
              >
                <UserCheck className="w-5 h-5 text-amber-600" />
                <span>{t.creditClient}</span>
              </button>
            </div>

            {/* Cash change return input */}
            {paymentMethod === 'especes' && (
              <div className="space-y-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-2xl mb-4 border border-slate-200 dark:border-slate-700">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Montant donné par le client : <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    inputMode="decimal"
                    placeholder={`ex: ${Math.ceil(totalTTC)}`}
                    value={amountReceived}
                    onChange={(e) => setAmountReceived(sanitizeDecimalInput(e.target.value))}
                    className={`w-full p-2.5 text-base font-bold bg-white dark:bg-slate-900 border rounded-xl transition ${
                      amountReceived !== '' && parseSafeFloat(amountReceived, 0) < totalTTC
                        ? 'border-rose-500 ring-2 ring-rose-200 dark:ring-rose-950 bg-rose-50/20'
                        : 'border-slate-300 dark:border-slate-600'
                    }`}
                  />
                  {amountReceived !== '' && parseSafeFloat(amountReceived, 0) < totalTTC && (
                    <p className="text-[11px] text-rose-500 font-bold mt-1 flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                      <span>Montant insuffisant (reste {(totalTTC - parseSafeFloat(amountReceived, 0)).toFixed(2)} {currency})</span>
                    </p>
                  )}
                </div>
                <div className="flex justify-between items-center text-xs font-extrabold text-emerald-700 dark:text-emerald-400">
                  <span>{t.monnaieARendre} :</span>
                  <span className="text-base">{changeToReturn.toFixed(2)} {currency}</span>
                </div>
              </div>
            )}

            {/* Assisted TPE Card Payment Panel */}
            {paymentMethod === 'carte' && (
              <div className="space-y-3 p-3.5 bg-blue-50/80 dark:bg-blue-950/40 rounded-2xl mb-4 border border-blue-200 dark:border-blue-800 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-blue-900 dark:text-blue-200 flex items-center gap-1.5">
                    <CreditCard className="w-4 h-4 text-blue-600" />
                    <span>Terminal de Paiement (TPE) :</span>
                  </span>
                  <span className="px-2 py-0.5 rounded-lg bg-blue-200 dark:bg-blue-900 text-blue-900 dark:text-blue-200 font-extrabold text-[11px]">
                    {totalTTC.toFixed(2)} {currency}
                  </span>
                </div>
                <p className="text-[11px] text-blue-800 dark:text-blue-300">
                  Insérez ou présentez la carte sans contact du client sur votre lecteur TPE.
                </p>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Réf / N° d'autorisation TPE (Optionnel) :
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: TPE-9823 ou 4 derniers chiffres CB"
                    value={cardAuthRef}
                    onChange={(e) => setCardAuthRef(e.target.value)}
                    className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-mono"
                  />
                </div>
              </div>
            )}

            {/* Assisted Instant Mobile Transfer with dynamic QR Code */}
            {paymentMethod === 'virement' && (
              <div className="space-y-3 p-3.5 bg-purple-50/80 dark:bg-purple-950/40 rounded-2xl mb-4 border border-purple-200 dark:border-purple-800 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-purple-900 dark:text-purple-200 flex items-center gap-1.5">
                    <ArrowRightLeft className="w-4 h-4 text-purple-600" />
                    <span>Paiement Mobile / Virement Instantané</span>
                  </span>
                  <span className="px-2 py-0.5 rounded-lg bg-purple-200 dark:bg-purple-900 text-purple-900 dark:text-purple-200 font-extrabold text-[11px]">
                    {totalTTC.toFixed(2)} {currency}
                  </span>
                </div>

                {settings?.bankRib || settings?.instantPayNumber ? (
                  <div className="flex flex-col sm:flex-row items-center gap-3 bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-purple-200 dark:border-purple-900/60">
                    <div className="p-1.5 bg-white rounded-lg shadow-sm shrink-0">
                      <QRCodeSVG 
                        value={`PAY;;AMOUNT:${totalTTC.toFixed(2)};;CUR:${currency};;RIB:${settings.bankRib || ''};;TEL:${settings.instantPayNumber || ''};;REF:${Date.now()}`}
                        size={76}
                        level="M"
                      />
                    </div>
                    <div className="text-[11px] space-y-0.5 min-w-0">
                      <span className="font-bold text-slate-800 dark:text-slate-200 block">
                        Faites scanner ce QR Code par le client :
                      </span>
                      {settings?.instantPayNumber && (
                        <div className="text-slate-600 dark:text-slate-400">
                          📱 Mobile Pay : <strong className="text-purple-700 dark:text-purple-300 font-mono">{settings.instantPayNumber}</strong>
                        </div>
                      )}
                      {settings?.bankRib && (
                        <div className="text-slate-600 dark:text-slate-400 truncate">
                          🏦 RIB : <strong className="text-purple-700 dark:text-purple-300 font-mono text-[10px]">{settings.bankRib}</strong>
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <p className="text-[11px] text-purple-800 dark:text-purple-300">
                    💡 Astuce : Renseignez votre RIB ou numéro Mobile Pay dans les <em>Paramètres</em> pour afficher ici un QR Code de paiement instantané scannable par le client.
                  </p>
                )}
              </div>
            )}

            {/* Credit payment warning & selector */}
            {paymentMethod === 'credit' && (
              <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-2xl border border-amber-200 dark:border-amber-800 text-xs text-amber-800 dark:text-amber-300 mb-4">
                <div className="flex items-start gap-2 mb-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
                  <div>
                    <span className="font-bold">Avertissement Crédit Client :</span> Le montant sera ajouté à la dette du client.
                  </div>
                </div>

                {!selectedClient ? (
                  <div className="mt-2 pt-2 border-t border-amber-200 dark:border-amber-800">
                    <label className="block text-[11px] font-bold text-amber-900 dark:text-amber-200 mb-1">
                      Sélectionnez un client : <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value=""
                      onChange={(e) => {
                        const found = clients.find(c => c.id === parseInt(e.target.value));
                        setSelectedClient(found || null);
                      }}
                      className="w-full text-xs font-semibold p-2 rounded-xl border border-amber-300 dark:border-amber-700 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-amber-500"
                    >
                      <option value="">Sélectionner le client débiteur...</option>
                      {clients.map(c => (
                        <option key={c.id} value={c.id}>
                          👤 {c.name} {c.debt > 0 ? `(Dette actuelle: ${c.debt} ${currency})` : ''}
                        </option>
                      ))}
                    </select>
                  </div>
                ) : (
                  <div className="text-xs font-bold text-amber-900 dark:text-amber-200 bg-amber-100/60 dark:bg-amber-900/40 p-2 rounded-xl mt-1">
                    Client : 👤 {selectedClient.name} • Dette actuelle : {selectedClient.debt || 0} {currency}
                  </div>
                )}
              </div>
            )}

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setShowPaymentModal(false)}
                className="flex-1 py-3 text-xs font-semibold rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200"
              >
                Annuler
              </button>
              <button
                onClick={handleCompleteSale}
                className="flex-1 py-3 text-xs font-extrabold rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-500/20 hover:opacity-95"
              >
                Valider la Vente ✅
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Completed Sale Receipt Modal */}
      {showReceiptModal && completedSale && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-md w-full border border-slate-200 dark:border-slate-800 shadow-2xl animate-in zoom-in-95 duration-150">
            <div className="text-center mb-4">
              <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-300 flex items-center justify-center mx-auto mb-2">
                <CheckCircle className="w-7 h-7" />
              </div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                Vente Validée !
              </h3>
              <p className="text-xs text-slate-500">N° Facture : {completedSale.receiptNo}</p>
            </div>

            {/* Cryptographic Digital Seal Badge (NF525) */}
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800 text-xs mb-3 flex items-center justify-between">
              <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-300">
                <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <div>
                  <div className="font-bold flex items-center gap-1.5">
                    <span>Scellement Numérique NF525</span>
                    <span className="text-[9px] bg-emerald-600 text-white px-1.5 py-0.2 rounded font-bold">SHA-256</span>
                  </div>
                  <div className="font-mono text-[10px] text-emerald-700 dark:text-emerald-300">
                    Sceau: <span className="font-bold">{completedSale.sealShort || 'VALIDE'}</span> • Index #{completedSale.sequenceNumber || 1}
                  </div>
                </div>
              </div>
              <span className="text-[10px] bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700 px-2 py-0.5 rounded-full font-bold">
                ✓ Intègre
              </span>
            </div>

            {/* Receipt Summary Box */}
            <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 text-xs space-y-1.5 mb-5 max-h-48 overflow-y-auto">
              {completedSale.cashier && (
                <div className="flex justify-between text-slate-500 pb-1 border-b border-slate-200 dark:border-slate-700">
                  <span>Vendeur :</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">👤 {completedSale.cashier}</span>
                </div>
              )}
              {completedSale.totalSavings > 0 && (
                <div className="flex justify-between text-emerald-600 dark:text-emerald-400 font-bold">
                  <span>Remise accordée :</span>
                  <span>-{completedSale.totalSavings.toFixed(2)} {currency}</span>
                </div>
              )}
              {completedSale.items.map((i, idx) => (
                <div key={idx} className="flex justify-between text-slate-700 dark:text-slate-300">
                  <span>{i.name} {i.variant ? `(${i.variant})` : ''} x{i.quantity}</span>
                  <span className="font-bold">{(i.sellPrice * i.quantity).toFixed(2)} {currency}</span>
                </div>
              ))}
              <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex justify-between font-extrabold text-sm text-slate-900 dark:text-white">
                <span>Total Payé :</span>
                <span className="text-indigo-600">{completedSale.totalTTC.toFixed(2)} {currency}</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2 no-print">
              <button
                onClick={() => handleSendWhatsAppReceipt(completedSale)}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md shadow-emerald-500/20"
              >
                <Send className="w-4 h-4" />
                <span>{t.envoyerWhatsApp}</span>
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => triggerPrintWithLayout('80mm')}
                  className="py-2.5 px-3 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-sm"
                >
                  <Printer className="w-4 h-4 text-emerald-400" />
                  <span>Imprimer 80mm</span>
                </button>
                <button
                  onClick={() => triggerPrintWithLayout('58mm')}
                  className="py-2.5 px-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 border border-slate-300 dark:border-slate-700"
                >
                  <Printer className="w-4 h-4 text-indigo-500" />
                  <span>Imprimer 58mm</span>
                </button>
              </div>

              <button
                onClick={() => setShowReceiptModal(false)}
                className="w-full py-2 text-xs text-slate-500 font-semibold hover:text-slate-800"
              >
                Fermer et Nouvelle Vente
              </button>
            </div>

            {/* Dedicated Thermal Receipt Container (Calibrated for 80mm & 58mm POS thermal printers) */}
            <ThermalReceipt
              sale={completedSale}
              settings={settings}
              currentLang={currentLang}
            />
          </div>
        </div>
      )}

      {/* Cash Expense / Withdrawal Modal */}
      {showExpenseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-sm w-full border border-slate-200 dark:border-slate-800 shadow-2xl animate-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-rose-100 text-rose-600 dark:bg-rose-950 dark:text-rose-300 rounded-2xl">
                <Coins className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">
                  Sortie d'Espèces du Tiroir
                </h3>
                <p className="text-[11px] text-slate-500">
                  Déduit du fond de caisse et tracé pour la clôture
                </p>
              </div>
            </div>

            <form onSubmit={handleRecordExpense} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Montant retiré ({currency}) :
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  required
                  autoFocus
                  placeholder="ex: 20.00"
                  value={expenseAmount}
                  onChange={(e) => setExpenseAmount(sanitizeDecimalInput(e.target.value))}
                  className="w-full text-lg font-bold p-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-rose-500 text-rose-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Motif de la dépense :
                </label>
                <select
                  value={expenseReason}
                  onChange={(e) => setExpenseReason(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-semibold"
                >
                  <option value="Fournitures / Frais magasin">Fournitures / Frais magasin</option>
                  <option value="Achat sacs & emballages">Achat sacs & emballages</option>
                  <option value="Avance sur salaire">Avance sur salaire</option>
                  <option value="Remboursement direct client">Remboursement direct client</option>
                  <option value="Frais livraison / Coursier">Frais livraison / Coursier</option>
                  <option value="Autre sortie exceptionnelle">Autre sortie exceptionnelle</option>
                </select>
              </div>

              <div className="p-2.5 bg-rose-50 dark:bg-rose-950/40 rounded-xl border border-rose-200 dark:border-rose-900 text-[11px] text-rose-800 dark:text-rose-300 font-medium">
                👤 Enregistré sous le caissier : <b>{currentCashier || 'Patron'}</b>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowExpenseModal(false)}
                  className="flex-1 py-2.5 text-xs font-semibold rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 text-xs font-extrabold rounded-xl bg-rose-600 hover:bg-rose-700 text-white shadow-md shadow-rose-500/20"
                >
                  Valider Sortie ✅
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Custom / Free Item ("Article Divers / Vente Libre") Modal */}
      {showCustomItemModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 max-w-md w-full border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 bg-gradient-to-br from-emerald-500 to-teal-600 text-white rounded-2xl shadow-md shadow-emerald-500/20">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                    Vente Libre / Article Divers
                  </h3>
                  <p className="text-xs text-slate-500">Ajout direct sans code-barres pour la caisse (F4)</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowCustomItemModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Preset Buttons for Retail/Grocery */}
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                ⚡ Raccourcis Fréquents :
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { name: 'Pain rond / Khobz', price: '1.20', vat: '0' },
                  { name: 'Œuf (Unité)', price: '1.50', vat: '0' },
                  { name: 'Menthe / Naanaa', price: '1.00', vat: '0' },
                  { name: 'Recharge 10 DH', price: '10.00', vat: '20' },
                  { name: 'Sac / Emballage', price: '0.50', vat: '20' },
                  { name: 'Article Divers', price: '', vat: '20' }
                ].map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setCustomItemData({
                        ...customItemData,
                        name: preset.name,
                        price: preset.price || customItemData.price,
                        vatRate: preset.vat
                      });
                    }}
                    className="p-2 rounded-xl text-left bg-slate-50 dark:bg-slate-800/80 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 border border-slate-200 dark:border-slate-700 hover:border-emerald-300 dark:hover:border-emerald-700 transition group"
                  >
                    <span className="font-extrabold text-[11px] text-slate-800 dark:text-slate-200 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 block truncate">
                      {preset.name}
                    </span>
                    <span className="text-[10px] text-slate-400 font-semibold">
                      {preset.price ? `${preset.price} ${currency}` : 'Prix libre'}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <form onSubmit={handleConfirmCustomItem} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Nom / Libellé de l'Article : <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="ex: Pain, Fruits en vrac, Petit dépannage..."
                  value={customItemData.name}
                  onChange={(e) => setCustomItemData({ ...customItemData, name: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Prix de Vente ({currency}) : <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    inputMode="decimal"
                    autoFocus
                    required
                    placeholder="ex: 12.50"
                    value={customItemData.price}
                    onChange={(e) => setCustomItemData({ ...customItemData, price: sanitizeDecimalInput(e.target.value) })}
                    className="w-full p-2.5 bg-white dark:bg-slate-800 border border-emerald-300 dark:border-emerald-700 rounded-xl font-black text-lg text-emerald-600 dark:text-emerald-400 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Quantité :
                  </label>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={customItemData.quantity}
                    onChange={(e) => setCustomItemData({ ...customItemData, quantity: sanitizeDecimalInput(e.target.value) })}
                    placeholder="1"
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Taux de TVA :
                  </label>
                  <select
                    value={customItemData.vatRate}
                    onChange={(e) => setCustomItemData({ ...customItemData, vatRate: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold"
                  >
                    <option value="0">0% (Alimentaire de base / Exonéré)</option>
                    <option value="5.5">5.5% (Taux Réduit)</option>
                    <option value="10">10% (Restauration / Services)</option>
                    <option value="20">20% (Taux Normal Standard)</option>
                  </select>
                </div>

                {isAdmin && (
                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Prix d'Achat ({currency}) <span className="text-slate-400 font-normal text-[10px]">(Optionnel)</span> :
                    </label>
                    <input
                      type="text"
                      inputMode="decimal"
                      placeholder="0.00"
                      value={customItemData.buyPrice}
                      onChange={(e) => setCustomItemData({ ...customItemData, buyPrice: sanitizeDecimalInput(e.target.value) })}
                      className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
                    />
                  </div>
                )}
              </div>

              <div className="flex gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowCustomItemModal(false)}
                  className="flex-1 py-2.5 text-xs font-bold rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 transition"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 text-xs font-extrabold rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-lg shadow-emerald-500/20 transition"
                >
                  Ajouter au Panier 🛒
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* Quote / Proforma A4 Modal */}
      {showQuoteModal && activeQuote && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-2xl w-full border border-slate-200 dark:border-slate-800 shadow-2xl my-8 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <FileText className="w-6 h-6 text-indigo-600" />
                <div>
                  <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                    Devis & Facture Proforma
                  </h3>
                  <span className="text-xs text-slate-500 font-mono">N° {activeQuote.quoteNo}</span>
                </div>
              </div>
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-extrabold ${
                activeQuote.status === 'converti' 
                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' 
                  : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
              }`}>
                {activeQuote.status === 'converti' ? '✓ Converti en Vente' : '⏳ En attente'}
              </span>
            </div>

            {/* Printable A4 Container */}
            <div id="quote-printable-area" className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 text-xs space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">{settings.shopName || 'Boutique VenteFacile'}</h4>
                  {settings.phone && <p className="text-slate-500">Tél : {settings.phone}</p>}
                  {settings.address && <p className="text-slate-500">{settings.address}</p>}
                </div>
                <div className="text-right">
                  <span className="text-[10px] uppercase font-bold text-indigo-600 dark:text-indigo-400">Date d'émission</span>
                  <p className="font-bold">{new Date(activeQuote.timestamp).toLocaleDateString('fr-FR')}</p>
                  <p className="text-[10px] text-slate-500">Validité : 30 jours</p>
                </div>
              </div>

              <div className="p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                <span className="text-[10px] font-bold text-slate-400 uppercase block">Destinataire / Client :</span>
                <p className="font-extrabold text-slate-900 dark:text-white text-xs">{activeQuote.clientName}</p>
                {activeQuote.clientPhone && <p className="text-slate-500 text-[11px]">Tél : {activeQuote.clientPhone}</p>}
              </div>

              {/* Items Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-700 text-slate-400 text-[10px] uppercase font-bold">
                      <th className="py-1">Désignation</th>
                      <th className="py-1 text-center">Qté</th>
                      <th className="py-1 text-right">P.U. TTC</th>
                      <th className="py-1 text-right">Total TTC</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {activeQuote.items.map((item, idx) => (
                      <tr key={idx}>
                        <td className="py-1.5 font-medium text-slate-800 dark:text-slate-200">
                          {item.name} {item.variant ? `(${item.variant})` : ''}
                        </td>
                        <td className="py-1.5 text-center font-bold">{item.quantity}</td>
                        <td className="py-1.5 text-right">{item.sellPrice.toFixed(2)} {currency}</td>
                        <td className="py-1.5 text-right font-bold">
                          {(item.sellPrice * item.quantity).toFixed(2)} {currency}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Financial Summary */}
              <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex justify-end">
                <div className="w-56 space-y-1 text-xs">
                  <div className="flex justify-between text-slate-500">
                    <span>Sous-Total HT :</span>
                    <span>{activeQuote.subtotalHT.toFixed(2)} {currency}</span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>TVA :</span>
                    <span>{activeQuote.totalVAT.toFixed(2)} {currency}</span>
                  </div>
                  <div className="flex justify-between font-extrabold text-sm text-indigo-600 dark:text-indigo-400 pt-1 border-t border-slate-200 dark:border-slate-700">
                    <span>NET À PAYER :</span>
                    <span>{activeQuote.totalTTC.toFixed(2)} {currency}</span>
                  </div>
                </div>
              </div>

              {/* Signature Box */}
              <div className="pt-3 border-t border-dashed border-slate-200 dark:border-slate-700 flex justify-between items-end text-[10px] text-slate-400">
                <div>Mention manuscrite "Bon pour accord" :</div>
                <div className="h-10 w-36 border-b border-slate-300 dark:border-slate-600 text-center">Date & Signature</div>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex flex-wrap gap-2 pt-4 no-print">
              <button
                onClick={() => handleConvertQuoteToSale(activeQuote)}
                className="flex-1 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-500/20"
              >
                <Check className="w-4 h-4" />
                <span>Convertir en Vente Immédiate</span>
              </button>

              <button
                onClick={() => triggerPrintWithLayout('a4')}
                className="py-2.5 px-4 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>Imprimer Devis A4</span>
              </button>

              <button
                onClick={() => setShowQuoteModal(false)}
                className="py-2.5 px-4 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold rounded-xl text-xs"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Saved Quotes List Modal */}
      {showQuotesListModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-xl w-full border border-slate-200 dark:border-slate-800 shadow-2xl animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3 mb-4">
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-600" />
                <span>Devis & Proformas Enregistrés ({savedQuotes.length})</span>
              </h3>
              <button
                onClick={() => setShowQuotesListModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold text-lg"
              >
                ✕
              </button>
            </div>

            <div className="max-h-80 overflow-y-auto space-y-2 pr-1">
              {savedQuotes.length === 0 ? (
                <div className="text-center py-8 text-slate-400 text-xs">
                  Aucun devis enregistré pour l'instant. Créez-en un depuis le panier !
                </div>
              ) : (
                savedQuotes.map((q) => (
                  <div
                    key={q.id || q.quoteNo}
                    className="p-3 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3 text-xs"
                  >
                    <div>
                      <div className="font-mono font-extrabold text-indigo-600 dark:text-indigo-400">
                        {q.quoteNo}
                      </div>
                      <div className="font-bold text-slate-800 dark:text-slate-100">
                        👤 {q.clientName || 'Client Particulier'}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {new Date(q.timestamp).toLocaleDateString('fr-FR')} • {q.items?.length || 0} articles
                      </div>
                    </div>

                    <div className="text-right flex flex-col items-end gap-1">
                      <span className="font-extrabold text-sm text-slate-900 dark:text-white">
                        {q.totalTTC.toFixed(2)} {currency}
                      </span>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => {
                            setActiveQuote(q);
                            setShowQuoteModal(true);
                          }}
                          className="px-2 py-1 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-[11px] font-bold flex items-center gap-1"
                        >
                          <Eye className="w-3 h-3" /> Voir
                        </button>
                        <button
                          onClick={() => handleConvertQuoteToSale(q)}
                          className="px-2.5 py-1 bg-emerald-600 text-white rounded-lg text-[11px] font-bold shadow-sm flex items-center gap-1"
                        >
                          <Check className="w-3 h-3" /> Charger
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 text-right">
              <button
                onClick={() => setShowQuotesListModal(false)}
                className="px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Return & Refund Modal (NF525 Certified Avoirs & Variant Exchanges) */}
      <RefundModal
        isOpen={showRefundModal}
        onClose={() => setShowRefundModal(false)}
        settings={settings}
        currentLang={currentLang}
        onRefreshData={onRefreshData}
        cashierName={currentCashier}
        products={products}
      />

      {/* Official Cash Closing Modal (Ticket Z & Ticket X) */}
      <CashClosingModal
        isOpen={showCashClosingModal}
        onClose={() => setShowCashClosingModal(false)}
        sales={sales || []}
        settings={settings}
        currentLang={currentLang}
        currentCashier={currentCashier}
        onClosingCompleted={() => {
          if (onRefreshData) onRefreshData();
        }}
      />

      {/* Held / Parked Carts Modal */}
      {showHeldCartsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-3 sm:p-4 animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            <div className="p-4 sm:p-5 bg-gradient-to-r from-amber-500 to-amber-600 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-white/20">
                  <PauseCircle className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base">Paniers en Pause ({heldCarts.length})</h3>
                  <p className="text-[11px] text-amber-100">
                    Reprenez la vente d'un client parti chercher un article en rayon
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowHeldCartsModal(false)}
                className="p-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto space-y-3 flex-1 custom-scrollbar">
              {heldCarts.length === 0 ? (
                <div className="text-center py-10 px-4 text-slate-500">
                  <div className="w-14 h-14 mx-auto mb-3 bg-amber-50 dark:bg-amber-950/40 text-amber-600 rounded-2xl flex items-center justify-center">
                    <Clock className="w-7 h-7" />
                  </div>
                  <h4 className="font-bold text-sm text-slate-800 dark:text-slate-200 mb-1">
                    Aucun panier en attente
                  </h4>
                  <p className="text-xs max-w-xs mx-auto">
                    Pour mettre une vente en pause, cliquez sur <strong>« ⏸️ En pause »</strong> lorsque des articles sont dans le panier.
                  </p>
                </div>
              ) : (
                heldCarts.map((hc, idx) => (
                  <div
                    key={hc.id}
                    className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/80 shadow-xs space-y-2.5 hover:border-amber-400 transition"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded-lg bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 font-extrabold text-xs">
                            #{idx + 1} • {hc.label}
                          </span>
                          <span className="text-[11px] text-slate-400 font-mono">
                            🕒 {hc.timestamp}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-1">
                          {hc.items.length} article(s) • Total : <strong className="text-slate-900 dark:text-white font-mono">{hc.total.toFixed(2)} {currency}</strong>
                        </p>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          onClick={() => handleRestoreHeldCart(hc)}
                          className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-extrabold shadow-sm flex items-center gap-1 transition active:scale-95"
                          title="Charger ce panier en caisse"
                        >
                          <PlayCircle className="w-3.5 h-3.5" />
                          <span>Reprendre</span>
                        </button>
                        <button
                          onClick={() => handleDeleteHeldCart(hc.id)}
                          className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition"
                          title="Supprimer définitivement ce panier"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Items miniature preview */}
                    <div className="text-[11px] bg-white dark:bg-slate-900 p-2 rounded-xl border border-slate-200/60 dark:border-slate-800 text-slate-600 dark:text-slate-400 flex flex-wrap gap-1.5">
                      {hc.items.map((it, i) => (
                        <span key={i} className="inline-block px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 rounded font-medium">
                          {it.quantity}x {it.name}
                        </span>
                      ))}
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 flex justify-between items-center text-xs">
              <span className="text-slate-500">
                {heldCarts.length} vente(s) en pause sauvegardée(s)
              </span>
              <button
                onClick={() => setShowHeldCartsModal(false)}
                className="px-4 py-1.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
