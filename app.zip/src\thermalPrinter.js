/**
 * VenteFacile Pro - Direct Universal Thermal ESC/POS Engine
 * Supports:
 * 1. Web Serial / Web USB direct silent hardware printing (PC Windows, Mac)
 * 2. Web Bluetooth BLE direct wireless printing (PC, Mac, Android)
 * 3. Network Wi-Fi / IP LAN raw socket printing (Port 9100 / iPad, iPhone, Android, PC)
 * 4. Android RawBT Intent direct printing for pocket 58mm/80mm Bluetooth printers
 * 5. Automated Cash Drawer opening pulse (ESC p 0 25 250) + Audit log
 * 6. Automated Paper Cutter pulse (GS V B 0)
 * 7. High-precision browser thermal print fallback (80mm & 58mm)
 */

export const ESC_COMMANDS = {
  INIT: new Uint8Array([0x1B, 0x40]), // ESC @ - Initialize printer
  ALIGN_LEFT: new Uint8Array([0x1B, 0x61, 0x00]), // ESC a 0
  ALIGN_CENTER: new Uint8Array([0x1B, 0x61, 0x01]), // ESC a 1
  ALIGN_RIGHT: new Uint8Array([0x1B, 0x61, 0x02]), // ESC a 2
  BOLD_ON: new Uint8Array([0x1B, 0x45, 0x01]), // ESC E 1
  BOLD_OFF: new Uint8Array([0x1B, 0x45, 0x00]), // ESC E 0
  FEED_LINES: (n = 3) => new Uint8Array([0x1B, 0x64, n]), // ESC d n
  CUT_PAPER: new Uint8Array([0x1D, 0x56, 0x42, 0x00]), // GS V B 0 - Full paper cut
  OPEN_DRAWER: new Uint8Array([0x1B, 0x70, 0x00, 0x19, 0xFA]) // ESC p 0 25 250 - Kick cash drawer RJ11
};

// Global active hardware connection references
let activeSerialPort = null;
let activeBluetoothCharacteristic = null;
let connectedDeviceName = '';

/**
 * Checks supported hardware APIs in current browser / OS
 */
export function getHardwareCapabilities() {
  const isSerial = typeof navigator !== 'undefined' && 'serial' in navigator;
  const isBluetooth = typeof navigator !== 'undefined' && 'bluetooth' in navigator;
  const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent || '');
  const isIOS = typeof navigator !== 'undefined' && /iPhone|iPad|iPod/i.test(navigator.userAgent || '');

  return {
    webSerial: isSerial,
    webBluetooth: isBluetooth,
    rawBTAndroid: isAndroid,
    networkIP: true,
    isMobile: isAndroid || isIOS,
    isIOS
  };
}

export function isDirectPrintingSupported() {
  return typeof navigator !== 'undefined' && ('serial' in navigator || 'bluetooth' in navigator);
}

export function isBluetoothSupported() {
  return typeof navigator !== 'undefined' && 'bluetooth' in navigator;
}

/**
 * Connect to USB / Serial Thermal Printer silently (PC Windows, Mac)
 */
export async function connectDirectThermalPrinter() {
  if (!('serial' in navigator)) {
    throw new Error("L'API Web Serial n'est pas supportée par votre navigateur (utiliser Chrome ou Edge).");
  }

  try {
    const port = await navigator.serial.requestPort();
    await port.open({ baudRate: 9600 });
    activeSerialPort = port;
    connectedDeviceName = 'Imprimante USB Direct';
    return { success: true, message: "Imprimante thermique connectée avec succès en direct USB !" };
  } catch (err) {
    if (err.name === 'NotFoundError') {
      return { success: false, message: "Aucun port d'imprimante sélectionné." };
    }
    throw err;
  }
}

/**
 * Connect to Bluetooth Thermal Printer (PC, Mac, Android Chrome)
 */
export async function connectBluetoothThermalPrinter() {
  if (!('bluetooth' in navigator)) {
    throw new Error("L'API Web Bluetooth n'est pas disponible sur ce navigateur. Assurez-vous d'utiliser Chrome/Edge sous HTTPS.");
  }

  try {
    // Search for common thermal printer BLE services
    const device = await navigator.bluetooth.requestDevice({
      filters: [
        { services: ['000018f0-0000-1000-8000-00805f9b34fb'] },
        { services: ['49535343-fe7d-4ae5-8fa9-9fafd205e455'] },
        { services: ['e7810a71-73ae-499d-8c15-faa9aef0c3f1'] },
        { namePrefix: 'MPT' },
        { namePrefix: 'POS' },
        { namePrefix: 'Printer' },
        { namePrefix: 'RP' },
        { namePrefix: 'Blue' },
        { namePrefix: 'XP' }
      ],
      optionalServices: [
        '000018f0-0000-1000-8000-00805f9b34fb',
        '49535343-fe7d-4ae5-8fa9-9fafd205e455',
        'e7810a71-73ae-499d-8c15-faa9aef0c3f1',
        '0000af30-0000-1000-8000-00805f9b34fb'
      ]
    });

    const server = await device.gatt.connect();
    connectedDeviceName = device.name || 'Imprimante Bluetooth';

    // Locate writable characteristic
    let targetChar = null;
    const services = await server.getPrimaryServices();
    for (const service of services) {
      const characteristics = await service.getCharacteristics();
      for (const char of characteristics) {
        if (char.properties.write || char.properties.writeWithoutResponse) {
          targetChar = char;
          break;
        }
      }
      if (targetChar) break;
    }

    if (!targetChar) {
      throw new Error("Aucune caractéristique d'écriture trouvée sur cette imprimante Bluetooth.");
    }

    activeBluetoothCharacteristic = targetChar;
    return { success: true, message: `Connecté à l'imprimante Bluetooth : ${connectedDeviceName}` };
  } catch (err) {
    if (err.name === 'NotFoundError') {
      return { success: false, message: "Aucun appareil Bluetooth sélectionné." };
    }
    throw err;
  }
}

/**
 * Send raw byte payload to active hardware printer (USB or Bluetooth)
 */
export async function sendRawBytesToPrinter(byteArray) {
  // 1. USB Web Serial
  if (activeSerialPort && activeSerialPort.writable) {
    try {
      const writer = activeSerialPort.writable.getWriter();
      await writer.write(byteArray);
      writer.releaseLock();
      return true;
    } catch (err) {
      console.warn('[Thermal USB] Write error:', err);
    }
  }

  // 2. Bluetooth BLE Characteristic (Chunked writes for BLE MTU limits)
  if (activeBluetoothCharacteristic) {
    try {
      const CHUNK_SIZE = 100;
      for (let i = 0; i < byteArray.length; i += CHUNK_SIZE) {
        const chunk = byteArray.slice(i, i + CHUNK_SIZE);
        if (activeBluetoothCharacteristic.writeValueWithoutResponse) {
          await activeBluetoothCharacteristic.writeValueWithoutResponse(chunk);
        } else {
          await activeBluetoothCharacteristic.writeValue(chunk);
        }
      }
      return true;
    } catch (err) {
      console.warn('[Thermal Bluetooth] Write error:', err);
    }
  }

  return false;
}

/**
 * Print via Android RawBT Application protocol
 */
export function printViaRawBT(base64Payload) {
  if (typeof window === 'undefined') return false;
  try {
    const rawBtUrl = `rawbt:data:application/octet-stream;base64,${base64Payload}`;
    window.location.href = rawBtUrl;
    return true;
  } catch (e) {
    console.warn('[RawBT] Launch failed:', e);
    return false;
  }
}

/**
 * Print via Network IP / LAN Socket (Port 9100)
 */
export async function printViaNetworkIP(ip, port = 9100, byteArray) {
  if (!ip) return false;
  try {
    // Send to local print proxy or IP printer directly
    const url = `http://${ip}:${port}`;
    const res = await fetch(url, {
      method: 'POST',
      mode: 'no-cors',
      body: byteArray
    });
    return true;
  } catch (err) {
    console.warn('[Thermal IP] Network print error:', err);
    return false;
  }
}

/**
 * Records a cash drawer opening event for audit trail
 */
export function logDrawerOpening(reason = 'Encaissement Vente', user = 'Caissier') {
  try {
    const history = JSON.parse(localStorage.getItem('vf_drawer_audit_log') || '[]');
    history.unshift({
      id: Date.now(),
      timestamp: new Date().toISOString(),
      reason,
      user
    });
    // Keep last 100 entries
    localStorage.setItem('vf_drawer_audit_log', JSON.stringify(history.slice(0, 100)));
  } catch (e) {}
}

/**
 * Pulse Cash Drawer Kick (Open Drawer instantly via RJ11 pulse)
 */
export async function triggerOpenCashDrawer(reason = 'Encaissement Espèces', user = 'Caissier') {
  logDrawerOpening(reason, user);

  // Send hardware pulse if connected
  if (activeSerialPort || activeBluetoothCharacteristic) {
    const sent = await sendRawBytesToPrinter(ESC_COMMANDS.OPEN_DRAWER);
    if (sent) return true;
  }

  // Audio simulated mechanical drawer sound
  try {
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(987, audioCtx.currentTime);
    osc.frequency.setValueAtTime(1318, audioCtx.currentTime + 0.05);
    gain.gain.setValueAtTime(0.18, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.2);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + 0.2);
  } catch (e) {}

  return true;
}

/**
 * Converts array of Uint8Array chunks into a single concatenated Uint8Array
 */
function concatByteArrays(arrays) {
  const totalLength = arrays.reduce((acc, curr) => acc + curr.length, 0);
  const result = new Uint8Array(totalLength);
  let offset = 0;
  for (const arr of arrays) {
    result.set(arr, offset);
    offset += arr.length;
  }
  return result;
}

/**
 * Converts Uint8Array to Base64
 */
function uint8ToBase64(uint8) {
  let binary = '';
  const len = uint8.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(uint8[i]);
  }
  return window.btoa(binary);
}

/**
 * Triggers Universal Thermal Print (Hardware USB, Bluetooth, IP, RawBT, or High-Res Browser Print)
 */
export async function printReceiptThermal(sale, settings = {}, width = '80mm') {
  // If drawer kick is enabled in settings, open it
  if (settings.openDrawerOnSale) {
    await triggerOpenCashDrawer('Vente Finalisée', settings.cashierName || 'Caisse');
  }

  const encoder = new TextEncoder();
  let binaryChunks = [];

  // 1. Build ESC/POS Byte Chunks
  if (typeof sale === 'string') {
    // Raw formatted text string
    binaryChunks = [
      ESC_COMMANDS.INIT,
      ESC_COMMANDS.ALIGN_LEFT,
      ESC_COMMANDS.BOLD_OFF,
      encoder.encode(sale + '\n\n'),
      ESC_COMMANDS.FEED_LINES(3),
      ESC_COMMANDS.CUT_PAPER
    ];
  } else if (sale && (sale.supplierName || sale.isSupplierPayment)) {
    // Supplier Payment
    const formattedPaymentText = `
========================================
     BON DE RÈGLEMENT FOURNISSEUR
========================================
Boutique : ${settings.shopName || 'VENTEFACILE PRO'}
Date : ${sale.date ? new Date(sale.date).toLocaleString() : new Date().toLocaleString()}
Réf : PAY-SUP-${sale.id || 'N/A'}

FOURNISSEUR : ${sale.supplierName || 'Grossiste'}
Mode : ${(sale.paymentMethod || 'especes').toUpperCase()}
${sale.checkNumber ? `N° Chèque/Traite : ${sale.checkNumber}` : ''}
${sale.dueDate ? `Échéance : ${sale.dueDate}` : ''}
----------------------------------------
MONTANT VERSÉ : ${Number(sale.amount || 0).toFixed(2)} ${settings.currency || 'DH'}
${sale.deductedFromCashDrawer ? '(*) Déduit du tiroir-caisse de la boutique' : ''}
----------------------------------------
Notes : ${sale.notes || 'Règlement de dette grossiste'}

Signature Livreur / Fournisseur :



========================================
`.trim();

    return printReceiptThermal(formattedPaymentText, settings, width);
  } else {
    // Retail Sale
    binaryChunks = [
      ESC_COMMANDS.INIT,
      ESC_COMMANDS.ALIGN_CENTER,
      ESC_COMMANDS.BOLD_ON,
      encoder.encode(`${settings.shopName || 'VENTEFACILE'}\n`),
      ESC_COMMANDS.BOLD_OFF,
      encoder.encode(`${settings.address || ''}\n${settings.phone || ''}\n`),
      encoder.encode('--------------------------------\n'),
      ESC_COMMANDS.ALIGN_LEFT,
      encoder.encode(`Ticket: ${sale?.receiptNo || 'TICK'}\nDate: ${new Date().toLocaleString()}\n`),
      encoder.encode('--------------------------------\n')
    ];

    (sale?.items || []).forEach(item => {
      const line = `${(item.name || '').slice(0, 18).padEnd(18)} x${item.quantity}  ${(Number(item.sellPrice || 0) * Number(item.quantity || 1)).toFixed(2)}\n`;
      binaryChunks.push(encoder.encode(line));
    });

    binaryChunks.push(
      encoder.encode('--------------------------------\n'),
      ESC_COMMANDS.ALIGN_RIGHT,
      ESC_COMMANDS.BOLD_ON,
      encoder.encode(`TOTAL TTC: ${Number(sale?.totalTTC || 0).toFixed(2)} ${settings.currency || 'DH'}\n`),
      ESC_COMMANDS.BOLD_OFF,
      ESC_COMMANDS.ALIGN_CENTER,
      encoder.encode(`\nMode: ${(sale?.paymentMethod || 'especes').toUpperCase()}\n`),
      encoder.encode(`Sceau NF525: ${(sale?.sealShort || '').slice(0, 16)}\n\nMerci de votre visite !\n`),
      ESC_COMMANDS.FEED_LINES(3),
      ESC_COMMANDS.CUT_PAPER
    );
  }

  const fullPayload = concatByteArrays(binaryChunks);

  // 2. DISPATCH METHOD: Direct USB or Bluetooth
  if (isHardwareConnected()) {
    const sent = await sendRawBytesToPrinter(fullPayload);
    if (sent) return true;
  }

  // 3. DISPATCH METHOD: Network Wi-Fi / IP if configured in settings
  if (settings.printerNetworkIP) {
    const sentIP = await printViaNetworkIP(settings.printerNetworkIP, settings.printerNetworkPort || 9100, fullPayload);
    if (sentIP) return true;
  }

  // 4. DISPATCH METHOD: Android RawBT Intent if enabled
  if (settings.useRawBTAndroid && /Android/i.test(navigator.userAgent || '')) {
    const base64Data = uint8ToBase64(fullPayload);
    printViaRawBT(base64Data);
    return true;
  }

  // 5. DISPATCH METHOD: High-Precision Calibrated Browser Print Fallback
  if (typeof sale === 'string') {
    if (typeof document !== 'undefined') {
      let textEl = document.getElementById('thermal-receipt-text');
      if (!textEl) {
        textEl = document.createElement('pre');
        textEl.id = 'thermal-receipt-text';
        document.body.appendChild(textEl);
      }
      textEl.textContent = sale;
      textEl.style.display = 'block';

      triggerPrintWithLayout(width === '58mm' ? '58mm' : '80mm');

      setTimeout(() => {
        if (textEl) {
          textEl.style.display = 'none';
          textEl.textContent = '';
        }
      }, 2000);
      return true;
    }
  }

  triggerPrintWithLayout(width === '58mm' ? '58mm' : '80mm');
  return true;
}

/**
 * Triggers browser print with target page dimensions: '80mm', '58mm', 'a4', or 'auto'.
 */
export function triggerPrintWithLayout(mode = 'auto') {
  if (typeof document === 'undefined') return;

  let styleEl = document.getElementById('dynamic-print-page-style');
  if (!styleEl) {
    styleEl = document.createElement('style');
    styleEl.id = 'dynamic-print-page-style';
    document.head.appendChild(styleEl);
  }

  document.body.classList.remove('print-thermal', 'print-58mm', 'print-80mm', 'print-a4');

  if (mode === '80mm') {
    styleEl.textContent = '@media print { @page { size: 80mm auto !important; margin: 0 !important; } }';
    document.body.classList.add('print-thermal', 'print-80mm');
  } else if (mode === '58mm') {
    styleEl.textContent = '@media print { @page { size: 58mm auto !important; margin: 0 !important; } }';
    document.body.classList.add('print-thermal', 'print-58mm');
  } else if (mode === 'a4') {
    styleEl.textContent = '@media print { @page { size: A4 portrait !important; margin: 10mm !important; } }';
    document.body.classList.add('print-a4');
  } else {
    styleEl.textContent = '@media print { @page { size: auto !important; margin: 5mm !important; } }';
  }

  window.print();

  setTimeout(() => {
    document.body.classList.remove('print-thermal', 'print-58mm', 'print-80mm', 'print-a4');
    if (styleEl) {
      styleEl.textContent = '';
    }
  }, 1000);
}

/**
 * Check if a direct hardware printer is actively connected
 */
export function isHardwareConnected() {
  return Boolean(
    (activeSerialPort && activeSerialPort.writable) ||
    activeBluetoothCharacteristic
  );
}

export function getConnectedDeviceName() {
  if (activeSerialPort) return 'Câble USB (Direct Serial)';
  if (activeBluetoothCharacteristic) return connectedDeviceName || 'Sans Fil (Bluetooth BLE)';
  return 'Aucun appareil matériel direct';
}

/**
 * Diagnostic printer & cash drawer test
 */
export async function printDiagnosticTestTicket(shopName = 'VenteFacile') {
  const encoder = new TextEncoder();
  const testChunks = [
    ESC_COMMANDS.INIT,
    ESC_COMMANDS.ALIGN_CENTER,
    ESC_COMMANDS.BOLD_ON,
    encoder.encode(`*** TEST MATERIEL REUSSI ***\n${shopName}\n`),
    ESC_COMMANDS.BOLD_OFF,
    encoder.encode(`Date: ${new Date().toLocaleString()}\n`),
    encoder.encode('Liaison Matérielle : OK\n'),
    encoder.encode('Impulsion Tiroir-Caisse RJ11 : OK\n'),
    encoder.encode('Coupe Papier Automatique : OK\n'),
    ESC_COMMANDS.FEED_LINES(2),
    ESC_COMMANDS.CUT_PAPER,
    ESC_COMMANDS.OPEN_DRAWER
  ];

  if (isHardwareConnected()) {
    try {
      const fullTest = concatByteArrays(testChunks);
      await sendRawBytesToPrinter(fullTest);
      return { direct: true, message: `Ticket de test imprimé et tiroir-caisse déclenché en direct via ${getConnectedDeviceName()} !` };
    } catch (err) {
      console.warn('[Thermal] Direct test failed:', err);
    }
  }

  // Fallback: trigger drawer kick simulation
  await triggerOpenCashDrawer('Test Diagnostic', 'Admin');
  return { 
    direct: false, 
    message: "Signal de test émis avec succès (Impulsion tiroir activée). Connectez une imprimante USB ou Bluetooth pour l'impression silencieuse instantanée." 
  };
}
