// Authentication & Access Control Security Module
// Provides salted cryptographic hashing, PIN verification, role sanitization, and auto-lock management

/**
 * Generate a cryptographically secure random hexadecimal salt
 * @param {number} length Number of random bytes (default 16 bytes = 32 hex chars)
 * @returns {string} Hexadecimal salt string
 */
export function generateSalt(length = 16) {
  try {
    const array = new Uint8Array(length);
    if (typeof window !== 'undefined' && window.crypto && window.crypto.getRandomValues) {
      window.crypto.getRandomValues(array);
    } else {
      for (let i = 0; i < length; i++) {
        array[i] = Math.floor(Math.random() * 256);
      }
    }
    return Array.from(array).map(b => b.toString(16).padStart(2, '0')).join('');
  } catch (e) {
    console.error('[authSecurity] Erreur génération sel', e);
    return Math.random().toString(36).substring(2) + Date.now().toString(36);
  }
}

/**
 * Cryptographic SHA-256 hashing with Salt
 * Formule: SHA-256(salt + ":" + pin)
 * @param {string} pin Cleartext PIN or password
 * @param {string} salt Cryptographic salt
 * @returns {Promise<string>} Hexadecimal SHA-256 digest
 */
export async function hashPinWithSalt(pin, salt) {
  if (!pin) return '';
  const combined = `${salt || ''}:${pin}`;
  try {
    const encoder = new TextEncoder();
    const data = encoder.encode(combined);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  } catch (e) {
    console.error('[authSecurity] Erreur hachage avec sel', e);
    // Simple fallback hash if crypto.subtle fails
    let hash = 0;
    for (let i = 0; i < combined.length; i++) {
      hash = (hash << 5) - hash + combined.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash).toString(16);
  }
}

/**
 * Legacy SHA-256 without salt (for backwards compatibility migration)
 */
export async function hashPinUnsalted(pin) {
  if (!pin) return '';
  try {
    const encoder = new TextEncoder();
    const data = encoder.encode(pin);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  } catch (e) {
    return pin;
  }
}

/**
 * Verify a user-provided PIN against stored hashes
 * Supports salted SHA-256, legacy unsalted SHA-256, and initial defaults
 * @param {string} inputPin The PIN entered by the user
 * @param {string} storedHash The stored hash
 * @param {string} storedSalt The stored salt (if available)
 * @param {string} defaultPin Fallback default PIN ('1234' for admin, '0000' for cashier)
 * @returns {Promise<boolean>} True if valid
 */
export async function verifyPin(inputPin, storedHash, storedSalt, defaultPin = null) {
  if (!inputPin) return false;

  // 1. Salted Hash Verification (Most secure)
  if (storedHash && storedSalt) {
    const computed = await hashPinWithSalt(inputPin, storedSalt);
    if (computed === storedHash) {
      return true;
    }
  }

  // 2. Legacy Unsalted Hash Verification
  if (storedHash && !storedSalt) {
    const legacyComputed = await hashPinUnsalted(inputPin);
    if (legacyComputed === storedHash) {
      return true;
    }
  }

  // 3. Fallback Default PIN Verification (if no custom hash is set yet)
  if (defaultPin && (!storedHash || storedHash === '')) {
    if (inputPin === defaultPin) {
      return true;
    }
  }

  // Also allow checking against the default pin if storedHash matches default's unsalted/salted hash
  if (defaultPin) {
    const defaultLegacy = await hashPinUnsalted(defaultPin);
    if (storedHash === defaultLegacy && inputPin === defaultPin) {
      return true;
    }
  }

  return false;
}

/**
 * Migrate settings to salted PINs and completely remove cleartext passwords
 * @param {object} settings 
 * @returns {Promise<object>} Cleaned settings with salted hashes and NO cleartext PINs
 */
export async function migrateSettingsToSaltedPins(settings) {
  if (!settings) return settings;
  const copy = { ...settings };
  let modified = false;

  // Admin PIN migration
  if (copy.adminPassword) {
    const salt = generateSalt();
    copy.adminPinSalt = salt;
    copy.adminPinHash = await hashPinWithSalt(copy.adminPassword, salt);
    delete copy.adminPassword; // PURGE CLEARTEXT
    modified = true;
  } else if (!copy.adminPinHash) {
    // Initialize default admin PIN ('1234') with salt
    const salt = generateSalt();
    copy.adminPinSalt = salt;
    copy.adminPinHash = await hashPinWithSalt('1234', salt);
    modified = true;
  }

  // Cashier PIN migration
  if (copy.cashierPassword) {
    const salt = generateSalt();
    copy.cashierPinSalt = salt;
    copy.cashierPinHash = await hashPinWithSalt(copy.cashierPassword, salt);
    delete copy.cashierPassword; // PURGE CLEARTEXT
    modified = true;
  } else if (!copy.cashierPinHash) {
    // Initialize default cashier PIN ('0000') with salt
    const salt = generateSalt();
    copy.cashierPinSalt = salt;
    copy.cashierPinHash = await hashPinWithSalt('0000', salt);
    modified = true;
  }

  // Clean any remaining legacy cleartext properties
  if (copy.adminPassword) delete copy.adminPassword;
  if (copy.cashierPassword) delete copy.cashierPassword;

  // Team PINs migration: purge cleartext pin and compute pinHash + pinSalt
  if (Array.isArray(copy.team) && copy.team.length > 0) {
    copy.team = await Promise.all(copy.team.map(async (member) => {
      const mCopy = { ...member };
      if (mCopy.pin && !mCopy.pinHash) {
        const salt = mCopy.pinSalt || generateSalt();
        mCopy.pinSalt = salt;
        mCopy.pinHash = await hashPinWithSalt(mCopy.pin, salt);
        delete mCopy.pin; // PURGE CLEARTEXT PIN
        modified = true;
      } else if (!mCopy.pinHash) {
        const defaultPin = mCopy.role === 'patron' ? '1234' : '0000';
        const salt = generateSalt();
        mCopy.pinSalt = salt;
        mCopy.pinHash = await hashPinWithSalt(defaultPin, salt);
        delete mCopy.pin;
        modified = true;
      } else if (mCopy.pin) {
        delete mCopy.pin; // PURGE CLEARTEXT
        modified = true;
      }
      return mCopy;
    }));
  }

  return { cleanedSettings: copy, hasChanged: modified };
}

/**
 * Hash a new member PIN with unique cryptographic salt
 * @param {string} pin 
 * @returns {Promise<{pinHash: string, pinSalt: string}>}
 */
export async function hashMemberPin(pin) {
  const salt = generateSalt(16);
  const pinHash = await hashPinWithSalt(pin, salt);
  return { pinHash, pinSalt: salt };
}

/**
 * Verify a member PIN against their salted hash
 * @param {string} inputPin 
 * @param {object} member 
 * @returns {Promise<boolean>}
 */
export async function verifyMemberPin(inputPin, member) {
  if (!inputPin || !member) return false;
  if (member.pinHash && member.pinSalt) {
    return verifyPin(inputPin, member.pinHash, member.pinSalt);
  }
  if (member.pin) {
    return inputPin === member.pin;
  }
  const defaultPin = member.role === 'patron' ? '1234' : '0000';
  return inputPin === defaultPin;
}

/**
 * Purge sensitive margin and supplier purchase prices from products when role is Cashier
 * Completely removes `buyPrice` from memory/state, preventing extraction via devtools
 * @param {Array} products 
 * @param {boolean} isAdmin 
 * @returns {Array} Sanitized products array
 */
export function sanitizeProductsForRole(products, isAdmin) {
  if (!products || !Array.isArray(products)) return [];
  if (isAdmin) return products;

  return products.map(p => {
    // Deep clone product without buyPrice
    const { buyPrice, supplierCost, ...safeProduct } = p;
    return safeProduct;
  });
}

/**
 * Purge sensitive fiscal totals, audit seals, and net margins when role is Cashier
 * @param {object} statsData 
 * @param {boolean} isAdmin 
 * @returns {object} Sanitized financial stats
 */
export function sanitizeStatsForRole(statsData, isAdmin) {
  if (isAdmin) return statsData;

  // Completely blank out sensitive margin and fiscal audit metrics for cashiers
  return {
    isRestricted: true,
    message: "Accès Réservé au Gérant"
  };
}
