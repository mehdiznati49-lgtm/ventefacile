/**
 * Date utilities ensuring strict adherence to the local timezone.
 * 
 * ⚠️ CRITICAL NOTICE (Fix for Tâche 19):
 * JavaScript's native new Date().toISOString().slice(0, 10) converts dates to UTC (GMT+0).
 * In timezones ahead of UTC (such as GMT+1 Morocco, GMT+1/+2 France, etc.),
 * executing a Z-Closing (Clôture Z) or filtering daily sales between 00:00 and 01:00/02:00
 * produces a 1-day lag, corrupting the cash journal and daily closing reports.
 * 
 * These helper functions extract year, month, and day strictly using local getters
 * or local ISO-standard format ('en-CA' is YYYY-MM-DD), ensuring 100% accounting fidelity.
 */

/**
 * Returns YYYY-MM-DD for a given date in LOCAL timezone.
 * @param {Date|string|number} [dateInput=new Date()]
 * @returns {string} e.g. "2026-10-03"
 */
export function getLocalDateString(dateInput = new Date()) {
  if (!dateInput) return '';
  const d = dateInput instanceof Date ? dateInput : new Date(dateInput);
  if (isNaN(d.getTime())) return '';
  
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Returns YYYYMMDD for a given date in LOCAL timezone.
 * Ideal for receipt numbering prefixes (e.g., FAC-20261003-0001, AVOIR-..., ECH-...).
 * @param {Date|string|number} [dateInput=new Date()]
 * @returns {string} e.g. "20261003"
 */
export function getLocalDateCompact(dateInput = new Date()) {
  if (!dateInput) return '';
  const d = dateInput instanceof Date ? dateInput : new Date(dateInput);
  if (isNaN(d.getTime())) return '';
  
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}${month}${day}`;
}

/**
 * Checks if a given timestamp or date belongs to the same local calendar day as targetDate.
 * @param {Date|string|number} dateToCheck
 * @param {Date|string|number} [targetDate=new Date()]
 * @returns {boolean}
 */
export function isSameLocalDay(dateToCheck, targetDate = new Date()) {
  if (!dateToCheck) return false;
  const strA = getLocalDateString(dateToCheck);
  const strB = getLocalDateString(targetDate);
  return Boolean(strA && strB && strA === strB);
}

/**
 * Checks if a given timestamp belongs to the given year and month in local timezone.
 * @param {Date|string|number} dateToCheck
 * @param {string|number} year e.g. 2026 or "2026"
 * @param {string|number} month e.g. 10 or "10"
 * @returns {boolean}
 */
export function isSameLocalMonth(dateToCheck, year, month) {
  if (!dateToCheck) return false;
  const d = dateToCheck instanceof Date ? dateToCheck : new Date(dateToCheck);
  if (isNaN(d.getTime())) return false;

  const y = String(d.getFullYear());
  const m = String(d.getMonth() + 1).padStart(2, '0');
  return y === String(year) && m === String(month).padStart(2, '0');
}

/**
 * Returns two-digit month string "01"-"12" in local timezone.
 * @param {Date|string|number} [dateInput=new Date()]
 * @returns {string}
 */
export function getLocalMonth(dateInput = new Date()) {
  const d = dateInput instanceof Date ? dateInput : new Date(dateInput);
  if (isNaN(d.getTime())) return '01';
  return String(d.getMonth() + 1).padStart(2, '0');
}

/**
 * Returns four-digit year string in local timezone.
 * @param {Date|string|number} [dateInput=new Date()]
 * @returns {string}
 */
export function getLocalYear(dateInput = new Date()) {
  const d = dateInput instanceof Date ? dateInput : new Date(dateInput);
  if (isNaN(d.getTime())) return String(new Date().getFullYear());
  return String(d.getFullYear());
}
