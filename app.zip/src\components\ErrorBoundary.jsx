import React from 'react';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';

export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('[VenteFacile ErrorBoundary]', error, errorInfo);
  }

  handleReload = () => {
    // Purge caches and hard reload
    if ('caches' in window) {
      caches.keys().then((keys) => keys.forEach((k) => caches.delete(k)));
    }
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-slate-800 border border-slate-700 rounded-3xl p-6 shadow-2xl text-center space-y-4">
            <div className="w-16 h-16 bg-red-500/20 text-red-400 rounded-2xl flex items-center justify-center mx-auto text-3xl">
              <AlertTriangle className="w-8 h-8" />
            </div>
            <h2 className="text-xl font-black">Affichage interrompu</h2>
            <p className="text-xs text-slate-400">
              Une mise à jour ou un élément temporaire a causé un problème d'affichage. Vos données locales sont en totale sécurité dans Dexie.
            </p>
            {this.state.error && (
              <pre className="p-3 bg-slate-950 rounded-xl text-[11px] text-red-300 font-mono overflow-x-auto text-start max-h-28">
                {this.state.error.message || String(this.state.error)}
              </pre>
            )}
            <div className="flex gap-2 justify-center pt-2">
              <button
                onClick={this.handleReload}
                className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition active:scale-95"
              >
                <RefreshCw className="w-4 h-4" />
                Actualiser la page
              </button>
              <button
                onClick={() => {
                  this.setState({ hasError: false });
                  window.location.href = window.location.pathname;
                }}
                className="px-4 py-2.5 bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs rounded-xl flex items-center gap-2 transition"
              >
                <Home className="w-4 h-4" />
                Retour Caisse
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
