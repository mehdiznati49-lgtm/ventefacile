import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import { ToastProvider } from './context/ToastContext'
import { ErrorBoundary } from './components/ErrorBoundary'

// Register Service Worker for PWA Offline-First
if ('serviceWorker' in navigator && window.location.protocol.startsWith('http')) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js')
      .then((reg) => {
        console.log('[VenteFacile PWA] Service Worker actif :', reg.scope);

        // Check if there is already an update waiting
        if (reg.waiting) {
          window.dispatchEvent(new CustomEvent('ventefacile:update-ready', { detail: reg }));
        }

        // Detect new update found
        reg.addEventListener('updatefound', () => {
          const newWorker = reg.installing;
          if (newWorker) {
            newWorker.addEventListener('statechange', () => {
              if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                console.log('[VenteFacile PWA] Nouvelle version installée en arrière-plan.');
                window.dispatchEvent(new CustomEvent('ventefacile:update-ready', { detail: reg }));
              }
            });
          }
        });

        // Periodic check for updates every 15 minutes
        setInterval(() => {
          reg.update().catch(() => {});
        }, 15 * 60 * 1000);
      })
      .catch((err) => {
        console.warn('[VenteFacile PWA] Erreur enregistrement Service Worker :', err);
      });
  });
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ErrorBoundary>
      <ToastProvider>
        <App />
      </ToastProvider>
    </ErrorBoundary>
  </React.StrictMode>,
)
