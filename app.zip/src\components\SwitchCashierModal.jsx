import React, { useState } from 'react';
import { Users, X, Check, Lock, ShieldCheck, UserCheck } from 'lucide-react';
import { translations } from '../translations';
import { verifyPin } from '../authSecurity';

export default function SwitchCashierModal({
  isOpen,
  onClose,
  team = [],
  currentCashier,
  onSelectCashier,
  currentLang = 'fr'
}) {
  if (!isOpen) return null;

  const t = translations[currentLang] || translations.fr;
  const [selectedMember, setSelectedMember] = useState(null);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');

  const roleLabels = {
    patron: { label: '👑 Patron', color: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 border-indigo-300' },
    gerant: { label: '🎖️ Gérant', color: 'bg-teal-100 text-teal-700 dark:bg-teal-950 dark:text-teal-300 border-teal-300' },
    caissier: { label: '💼 Caissier', color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border-emerald-300' }
  };

  const handleMemberClick = (member) => {
    setSelectedMember(member);
    setPinInput('');
    setPinError('');
  };

  const handleValidatePin = async (e) => {
    e.preventDefault();
    if (!selectedMember) return;
    setPinError('');

    let isValid = false;

    // 1. Vérification hachage salé SHA-256
    if (selectedMember.pinHash && selectedMember.pinSalt) {
      isValid = await verifyPin(pinInput, selectedMember.pinHash, selectedMember.pinSalt);
    } else if (selectedMember.pin) {
      // 2. Rétrocompatibilité transitoire
      isValid = pinInput === selectedMember.pin;
    } else {
      // 3. Codes par défaut (1234 Patron, 0000 Caissier)
      const fallbackDefault = selectedMember.role === 'patron' ? '1234' : '0000';
      isValid = pinInput === fallbackDefault;
    }

    if (!isValid) {
      setPinError('❌ Code PIN incorrect. Veuillez réessayer.');
      return;
    }

    onSelectCashier(selectedMember);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-indigo-600 via-indigo-700 to-purple-700 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center text-white font-bold">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black">
                {currentLang === 'ar' ? 'تبديل الكاشير / البائع' : 'Changer de Caissier en Caisse'}
              </h3>
              <p className="text-xs text-indigo-100">
                {currentLang === 'ar' ? 'اختر البائع الذي يستلم الوردية الآن' : 'Sélectionnez le vendeur qui prend le service'}
              </p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {!selectedMember ? (
            <div className="space-y-2">
              <p className="text-xs text-slate-500 font-semibold mb-2">
                Membres de l'équipe enregistrés :
              </p>
              <div className="grid grid-cols-1 gap-2 max-h-72 overflow-y-auto pr-1">
                {team.map((member) => {
                  const isCurrent = currentCashier?.id === member.id || currentCashier?.name === member.name;
                  const roleBadge = roleLabels[member.role] || roleLabels.caissier;

                  return (
                    <button
                      key={member.id}
                      onClick={() => handleMemberClick(member)}
                      className={`w-full p-3.5 rounded-2xl border text-left flex items-center justify-between transition active:scale-98 ${
                        isCurrent
                          ? 'border-indigo-500 bg-indigo-50/80 dark:bg-indigo-950/40 shadow-sm'
                          : 'border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-slate-700 bg-white dark:bg-slate-800/50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-black text-sm shadow-sm"
                          style={{ backgroundColor: member.avatarColor || '#4f46e5' }}
                        >
                          {member.name?.slice(0, 2)?.toUpperCase() || 'US'}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-extrabold text-sm text-slate-900 dark:text-white">
                              {member.name}
                            </span>
                            {isCurrent && (
                              <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-300 dark:border-emerald-800">
                                🟢 En service
                              </span>
                            )}
                          </div>
                          <span className={`inline-block mt-0.5 text-[10px] font-bold px-2 py-0.5 rounded-full border ${roleBadge.color}`}>
                            {roleBadge.label}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 text-xs text-slate-400">
                        {member.pin ? <Lock className="w-3.5 h-3.5" /> : <UserCheck className="w-3.5 h-3.5 text-emerald-500" />}
                        <span className="font-bold text-[11px]">{isCurrent ? 'Actif' : 'Prendre'}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          ) : (
            /* PIN Verification Form */
            <form onSubmit={handleValidatePin} className="space-y-4 animate-in fade-in">
              <div className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-black text-sm"
                  style={{ backgroundColor: selectedMember.avatarColor || '#4f46e5' }}
                >
                  {selectedMember.name?.slice(0, 2)?.toUpperCase()}
                </div>
                <div>
                  <h4 className="font-black text-sm text-slate-900 dark:text-white">
                    {selectedMember.name}
                  </h4>
                  <span className="text-[10px] font-bold text-slate-400">
                    Saisie du code secret requise
                  </span>
                </div>
              </div>

              {pinError && (
                <div className="p-2.5 rounded-xl bg-red-50 dark:bg-red-950/50 text-red-600 dark:text-red-400 text-xs font-bold border border-red-200 dark:border-red-800">
                  {pinError}
                </div>
              )}

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Code PIN personnel (4 chiffres) :</span>
                </label>
                <input
                  type="password"
                  maxLength="8"
                  autoFocus
                  placeholder="••••"
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  className="w-full text-center tracking-widest text-lg font-black p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl focus:ring-2 focus:ring-indigo-500 font-mono"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setSelectedMember(null)}
                  className="flex-1 py-2.5 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 transition"
                >
                  {t.annuler}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs shadow-md shadow-indigo-600/25 transition active:scale-95 flex items-center justify-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>Valider la Relève</span>
                </button>
              </div>
            </form>
          )}
        </div>

      </div>
    </div>
  );
}
