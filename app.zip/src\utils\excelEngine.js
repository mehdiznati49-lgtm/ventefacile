/**
 * VenteFacile Pro - Enterprise Excel Engine
 * Handles:
 * - Professional stylized .xlsx exports (Catalogue, Ventes, Z de caisse)
 * - Intelligent auto-mapping import from .xlsx and .csv
 * - 1-click Downloadable blank template with French & Arabic headers
 * - Validation & dry-run reporting before saving to database
 */

import * as XLSX from 'xlsx';
import { parseSafeFloat } from './numberUtils.js';
import { getLocalDateString } from './dateUtils.js';

// Standard known column synonyms across French, Arabic, English
const COLUMN_MAPPINGS = {
  name: [
    'nom', 'nom produit', 'designation', 'désignation', 'name', 'product name',
    'article', 'libelle', 'libellé', 'item', 'الاسم', 'اسم المنتج', 'المادة'
  ],
  barcode: [
    'code', 'code-barres', 'code barres', 'barcode', 'ean', 'ean13', 'upc',
    'sku', 'ref', 'référence', 'reference', 'الباركود', 'رمز المنتج', 'كود'
  ],
  buyPrice: [
    'prix achat', 'prix d\'achat', 'achat', 'cout', 'coût', 'buy price', 'cost',
    'prix achat (€)', 'prix achat (dh)', 'سعر الشراء', 'شراء'
  ],
  sellPrice: [
    'prix vente', 'prix de vente', 'vente', 'sell price', 'price', 'prix',
    'prix vente (€)', 'prix vente (dh)', 'tarif', 'سعر البيع', 'بيع', 'الثمن'
  ],
  stock: [
    'stock', 'quantite', 'quantité', 'qty', 'quantity', 'inventaire',
    'stock actuel', 'المخزون', 'الكمية', 'العدد'
  ],
  category: [
    'categorie', 'catégorie', 'category', 'famille', 'rayon', 'groupe',
    'التصنيف', 'القسم', 'الفئة'
  ],
  brand: [
    'marque', 'brand', 'fabricant', 'constructeur', 'الماركة', 'العلامة التجارية'
  ],
  vatRate: [
    'tva', 'tva (%)', 'tax', 'taux tva', 'vat', 'ضريبة', 'نسبة الضريبة'
  ],
  unit: [
    'unite', 'unité', 'unit', 'uom', 'unite mesure', 'الوحدة'
  ],
  minStock: [
    'stock min', 'stock minimum', 'min stock', 'seuil', 'الحد الأدنى للمخزون'
  ],
  expiryDate: [
    'date peremption', 'date péremption', 'peremption', 'expiry date', 'expiry',
    'dluo', 'تاريخ الصلاحية', 'انتهاء الصلاحية'
  ]
};

/**
 * Detects internal field name from a raw header string
 */
function matchHeaderToField(header) {
  if (!header) return null;
  const cleanHeader = String(header).toLowerCase().trim().replace(/[_\-]/g, ' ');

  for (const [field, synonyms] of Object.entries(COLUMN_MAPPINGS)) {
    for (const syn of synonyms) {
      if (cleanHeader === syn || cleanHeader.includes(syn)) {
        return field;
      }
    }
  }
  return null;
}

/**
 * Downloads a sample blank Excel template with dummy data and notes
 */
export function downloadExcelTemplate(currency = 'DH') {
  const sampleData = [
    {
      'Code-Barres': '6111234567890',
      'Nom Produit': 'Huile d\'Olive Vierge Extra 1L',
      'Catégorie': 'Épicerie',
      'Marque': 'Oued Souss',
      [`Prix Achat (${currency})`]: 65.00,
      [`Prix Vente (${currency})`]: 85.00,
      'Stock': 50,
      'Unité': 'bouteille',
      'TVA (%)': 0,
      'Stock Minimum': 10,
      'Date Péremption': '2026-12-31'
    },
    {
      'Code-Barres': '6111234567891',
      'Nom Produit': 'Café Moulu Premium 250g',
      'Catégorie': 'Boissons Chaudes',
      'Marque': 'Samar',
      [`Prix Achat (${currency})`]: 22.00,
      [`Prix Vente (${currency})`]: 30.00,
      'Stock': 120,
      'Unité': 'paquet',
      'TVA (%)': 20,
      'Stock Minimum': 15,
      'Date Péremption': '2027-06-30'
    },
    {
      'Code-Barres': '6111234567892',
      'Nom Produit': 'Eau Minérale Naturelle 1.5L',
      'Catégorie': 'Boissons',
      'Marque': 'Ain Atlas',
      [`Prix Achat (${currency})`]: 4.50,
      [`Prix Vente (${currency})`]: 6.00,
      'Stock': 200,
      'Unité': 'bouteille',
      'TVA (%)': 20,
      'Stock Minimum': 24,
      'Date Péremption': '2027-01-01'
    }
  ];

  const worksheet = XLSX.utils.json_to_sheet(sampleData);
  // Auto column widths
  worksheet['!cols'] = [
    { wch: 18 }, // Barcode
    { wch: 35 }, // Name
    { wch: 20 }, // Category
    { wch: 18 }, // Brand
    { wch: 16 }, // Buy Price
    { wch: 16 }, // Sell Price
    { wch: 12 }, // Stock
    { wch: 12 }, // Unit
    { wch: 10 }, // TVA
    { wch: 14 }, // Min stock
    { wch: 16 }  // Expiry
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Modèle Import VenteFacile');
  XLSX.writeFile(workbook, `Modele_Catalogue_VenteFacile_${currency}.xlsx`);
}

/**
 * Parses and validates an uploaded Excel file before importing
 * @param {File} file - Uploaded File object
 * @returns {Promise<Object>} { validRows, errorRows, detectedColumns, summary }
 */
export async function parseAndValidateExcel(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const rawRows = XLSX.utils.sheet_to_json(worksheet, { defval: '' });

        if (!rawRows || rawRows.length === 0) {
          resolve({
            success: false,
            message: "Le fichier Excel est vide ou ne contient aucune ligne de données."
          });
          return;
        }

        // Map columns from first row
        const sampleRow = rawRows[0];
        const headerMap = {};
        for (const rawHeader of Object.keys(sampleRow)) {
          const matched = matchHeaderToField(rawHeader);
          if (matched) {
            headerMap[rawHeader] = matched;
          }
        }

        const validRows = [];
        const errorRows = [];
        const seenBarcodes = new Set();

        rawRows.forEach((row, index) => {
          const rowNumber = index + 2; // +1 for 0-index, +1 for header
          const item = {};

          for (const [rawHeader, val] of Object.entries(row)) {
            const field = headerMap[rawHeader];
            if (field) {
              item[field] = val;
            }
          }

          const name = String(item.name || '').trim();
          let barcode = String(item.barcode || '').trim();

          // If no barcode provided, generate clean fallback
          if (!barcode) {
            barcode = `AUTO-${Date.now().toString().slice(-6)}${index}`;
          }

          // Validation
          if (!name) {
            errorRows.push({
              rowNumber,
              reason: "Nom du produit manquant",
              data: row
            });
            return;
          }

          if (seenBarcodes.has(barcode)) {
            errorRows.push({
              rowNumber,
              reason: `Code-barres en double dans le fichier : « ${barcode} »`,
              data: row
            });
            return;
          }
          seenBarcodes.add(barcode);

          const buyPrice = parseSafeFloat(item.buyPrice, 0);
          const sellPrice = parseSafeFloat(item.sellPrice, buyPrice > 0 ? buyPrice * 1.3 : 10);
          const stock = parseSafeFloat(item.stock, 0);
          const vatRate = parseSafeFloat(item.vatRate, 20);
          const minStock = parseSafeFloat(item.minStock, 3);

          validRows.push({
            barcode,
            name,
            category: String(item.category || 'Général').trim(),
            brand: String(item.brand || '').trim(),
            buyPrice,
            sellPrice,
            stock,
            minStock,
            vatRate,
            unit: String(item.unit || 'unité').trim(),
            expiryDate: String(item.expiryDate || '').trim(),
            isArchived: false,
            synced: false
          });
        });

        resolve({
          success: true,
          totalRows: rawRows.length,
          validRows,
          errorRows,
          detectedColumns: Object.values(headerMap)
        });
      } catch (err) {
        reject(err);
      }
    };

    reader.onerror = (err) => reject(err);
    reader.readAsArrayBuffer(file);
  });
}

/**
 * Professional Stylized Export for Products
 */
export function exportProductsXLSX(products = [], currency = 'DH') {
  const exportData = products.map((p, idx) => ({
    'N°': idx + 1,
    'Code-Barres': p.barcode || '',
    'Nom Produit': p.name || '',
    'Catégorie': p.category || 'Général',
    'Marque': p.brand || '',
    [`Prix Achat (${currency})`]: Number(p.buyPrice || 0).toFixed(2),
    [`Prix Vente (${currency})`]: Number(p.sellPrice || 0).toFixed(2),
    [`Marge Unitaire (${currency})`]: (Number(p.sellPrice || 0) - Number(p.buyPrice || 0)).toFixed(2),
    'TVA (%)': p.vatRate !== undefined ? `${p.vatRate}%` : '20%',
    'Stock Actuel': p.stock || 0,
    'Unité': p.unit || 'unité',
    [`Valeur Stock Vente (${currency})`]: (Number(p.sellPrice || 0) * Number(p.stock || 0)).toFixed(2),
    'Date Péremption': p.expiryDate || 'N/A'
  }));

  const ws = XLSX.utils.json_to_sheet(exportData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Catalogue Produits');
  XLSX.writeFile(wb, `VenteFacile_Catalogue_${getLocalDateString()}.xlsx`);
}

/**
 * Professional Stylized Export for Sales History
 */
export function exportSalesXLSX(sales = [], currency = 'DH') {
  const exportData = sales.map((s, idx) => ({
    'N° Ticket': s.receiptNo || `VTE-${idx + 1}`,
    'Date & Heure': s.date ? new Date(s.date).toLocaleString() : '',
    'Caissier': s.cashierName || 'Principal',
    'Mode Paiement': (s.paymentMethod || 'especes').toUpperCase(),
    'Nb Articles': (s.items || []).length,
    [`Total HT (${currency})`]: Number(s.subtotalHT || s.totalHT || 0).toFixed(2),
    [`Total TVA (${currency})`]: Number(s.totalVAT || s.totalTva || 0).toFixed(2),
    [`Total TTC (${currency})`]: Number(s.totalTTC || 0).toFixed(2),
    [`Marge / Bénéfice (${currency})`]: Number(s.profit || 0).toFixed(2),
    'Statut': s.status || 'complété'
  }));

  const ws = XLSX.utils.json_to_sheet(exportData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Journal des Ventes');
  XLSX.writeFile(wb, `VenteFacile_Journal_Ventes_${getLocalDateString()}.xlsx`);
}
