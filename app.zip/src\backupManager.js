import { db } from './db';
import { getLocalDateString } from './utils/dateUtils';

const BACKUP_META_KEY = 'ventefacile_last_backup_meta';
const BACKUP_DISMISSED_KEY = 'ventefacile_backup_alert_dismissed';

/**
 * Creates a complete snapshot of all tables in IndexedDB and settings
 * Generates an encrypted/checksummed, timestamped JSON object
 */
export async function createFullBackup(password = null) {
  const products = await db.products.toArray();
  const sales = await db.sales.toArray();
  const clients = await db.clients.toArray();
  const payments = await db.payments.toArray();
  const cashMovements = db.cashMovements ? await db.cashMovements.toArray() : [];
  const quotes = db.quotes ? await db.quotes.toArray() : [];
  const suppliers = db.suppliers ? await db.suppliers.toArray() : [];
  const supplierInvoices = db.supplierInvoices ? await db.supplierInvoices.toArray() : [];
  const supplierPayments = db.supplierPayments ? await db.supplierPayments.toArray() : [];
  const cashClosings = db.cashClosings ? await db.cashClosings.toArray() : [];
  const settings = (await db.settings.get(1)) || {};

  const payload = {
    app: 'VenteFacile Pro',
    version: 5,
    createdAt: new Date().toISOString(),
    stats: {
      productsCount: products.length,
      salesCount: sales.length,
      clientsCount: clients.length,
      paymentsCount: payments.length,
      cashMovementsCount: cashMovements.length,
      quotesCount: quotes.length,
      suppliersCount: suppliers.length,
      supplierInvoicesCount: supplierInvoices.length,
      supplierPaymentsCount: supplierPayments.length,
      cashClosingsCount: cashClosings.length
    },
    data: {
      products,
      sales,
      clients,
      payments,
      cashMovements,
      quotes,
      suppliers,
      supplierInvoices,
      supplierPayments,
      cashClosings,
      settings
    }
  };

  const rawJson = JSON.stringify(payload, null, 2);

  // Optional lightweight AES-GCM encryption if user specified a password
  let finalContent = rawJson;
  let isEncrypted = false;

  if (password && password.trim().length > 0) {
    try {
      finalContent = await encryptBackupData(rawJson, password.trim());
      isEncrypted = true;
    } catch (e) {
      console.warn('[BackupManager] Encryption fallback to plain JSON', e);
      finalContent = rawJson;
    }
  }

  // Update backup metadata in localStorage
  const meta = {
    lastBackupDate: new Date().toISOString(),
    stats: payload.stats,
    isEncrypted
  };
  localStorage.setItem(BACKUP_META_KEY, JSON.stringify(meta));
  sessionStorage.removeItem(BACKUP_DISMISSED_KEY);

  // Format file name ventefacile_backup_YYYY-MM-DD.json
  const dateStr = getLocalDateString();
  const timeStr = new Date().toTimeString().slice(0, 5).replace(':', 'h');
  const fileName = `ventefacile_backup_${dateStr}_${timeStr}${isEncrypted ? '.enc' : ''}.json`;

  return {
    content: finalContent,
    fileName,
    stats: payload.stats,
    isEncrypted,
    dateStr
  };
}

/**
 * Downloads a generated backup directly to the client filesystem
 */
export function downloadBackupFile(content, fileName) {
  const blob = new Blob([content], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Reads, verifies, decrypts if necessary, and imports a backup file
 * @param {string} fileContent Raw string from file reader
 * @param {string|null} password Optional decryption password
 * @returns {Promise<{success: boolean, stats: object, message?: string, needsPassword?: boolean}>}
 */
export async function restoreBackup(fileContent, password = null) {
  let parsed;

  // Check if encrypted
  try {
    const rawParsed = JSON.parse(fileContent);
    if (rawParsed.encrypted && rawParsed.iv && rawParsed.cipherText) {
      if (!password) {
        return { success: false, needsPassword: true, error: 'Ce fichier est chiffré. Veuillez saisir le mot de passe.' };
      }
      const decryptedJson = await decryptBackupData(rawParsed, password);
      parsed = JSON.parse(decryptedJson);
    } else {
      parsed = rawParsed;
    }
  } catch (err) {
    return { success: false, error: 'Fichier invalide ou mot de passe incorrect : ' + err.message };
  }

  // Normalize legacy vs new format
  const data = parsed.data || parsed;
  const products = data.products || [];
  const sales = data.sales || [];
  const clients = data.clients || [];
  const payments = data.payments || [];
  const cashMovements = data.cashMovements || [];
  const quotes = data.quotes || [];
  const suppliers = data.suppliers || [];
  const supplierInvoices = data.supplierInvoices || [];
  const supplierPayments = data.supplierPayments || [];
  const cashClosings = data.cashClosings || [];
  const settings = data.settings || null;

  // Atomic database restoration across all tables
  const tables = [
    db.products, 
    db.sales, 
    db.clients, 
    db.payments, 
    db.cashMovements, 
    db.quotes, 
    db.suppliers,
    db.supplierInvoices,
    db.supplierPayments,
    db.cashClosings,
    db.settings
  ].filter(Boolean);

  await db.transaction('rw', tables, async () => {
    if (products.length > 0 || parsed.data) {
      await db.products.clear();
      if (products.length > 0) await db.products.bulkAdd(products);
    }
    if (sales.length > 0 || parsed.data) {
      await db.sales.clear();
      if (sales.length > 0) await db.sales.bulkAdd(sales);
    }
    if (clients.length > 0 || parsed.data) {
      await db.clients.clear();
      if (clients.length > 0) await db.clients.bulkAdd(clients);
    }
    if (payments.length > 0 || parsed.data) {
      await db.payments.clear();
      if (payments.length > 0) await db.payments.bulkAdd(payments);
    }
    if (db.cashMovements && (cashMovements.length > 0 || parsed.data)) {
      await db.cashMovements.clear();
      if (cashMovements.length > 0) await db.cashMovements.bulkAdd(cashMovements);
    }
    if (db.quotes && (quotes.length > 0 || parsed.data)) {
      await db.quotes.clear();
      if (quotes.length > 0) await db.quotes.bulkAdd(quotes);
    }
    if (db.suppliers && (suppliers.length > 0 || parsed.data)) {
      await db.suppliers.clear();
      if (suppliers.length > 0) await db.suppliers.bulkAdd(suppliers);
    }
    if (db.supplierInvoices && (supplierInvoices.length > 0 || parsed.data)) {
      await db.supplierInvoices.clear();
      if (supplierInvoices.length > 0) await db.supplierInvoices.bulkAdd(supplierInvoices);
    }
    if (db.supplierPayments && (supplierPayments.length > 0 || parsed.data)) {
      await db.supplierPayments.clear();
      if (supplierPayments.length > 0) await db.supplierPayments.bulkAdd(supplierPayments);
    }
    if (db.cashClosings && (cashClosings.length > 0 || parsed.data)) {
      await db.cashClosings.clear();
      if (cashClosings.length > 0) await db.cashClosings.bulkAdd(cashClosings);
    }
    if (settings) {
      await db.settings.put({ ...settings, id: 1 });
    }
  });

  // Update backup meta
  const stats = {
    productsCount: products.length,
    salesCount: sales.length,
    clientsCount: clients.length,
    paymentsCount: payments.length,
    cashMovementsCount: cashMovements.length,
    quotesCount: quotes.length,
    suppliersCount: suppliers.length,
    supplierInvoicesCount: supplierInvoices.length,
    supplierPaymentsCount: supplierPayments.length,
    cashClosingsCount: cashClosings.length
  };
  localStorage.setItem(BACKUP_META_KEY, JSON.stringify({
    lastBackupDate: new Date().toISOString(),
    stats,
    restored: true
  }));

  return {
    success: true,
    stats,
    settings
  };
}

/**
 * Returns metadata about the last backup
 */
export function getLastBackupMeta() {
  try {
    const raw = localStorage.getItem(BACKUP_META_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
}

/**
 * Evaluates whether a preventive backup banner/alert should be shown
 * Rule:
 * 1. Has sales (> 0)
 * 2. No backup in the last 24 hours OR never backed up
 * 3. User hasn't dismissed the alert during current session
 */
export async function shouldShowBackupAlert() {
  try {
    const dismissed = sessionStorage.getItem(BACKUP_DISMISSED_KEY);
    if (dismissed === 'true') return false;

    const salesCount = await db.sales.count();
    if (salesCount === 0) return false;

    const meta = getLastBackupMeta();
    if (!meta || !meta.lastBackupDate) {
      return true; // Never backed up with active sales!
    }

    const lastDate = new Date(meta.lastBackupDate).getTime();
    const now = Date.now();
    const diffHours = (now - lastDate) / (1000 * 60 * 60);

    return diffHours >= 24; // Older than 24 hours
  } catch (e) {
    return false;
  }
}

/**
 * Dismisses backup alert for the current session
 */
export function dismissBackupAlert() {
  sessionStorage.setItem(BACKUP_DISMISSED_KEY, 'true');
}

// ----------------- Lightweight Crypto Utilities (Web Crypto API) -----------------
async function getKey(password, salt) {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveKey']
  );
  return crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt,
      iterations: 100000,
      hash: 'SHA-256'
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

async function encryptBackupData(plainText, password) {
  const enc = new TextEncoder();
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await getKey(password, salt);

  const cipherBuffer = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    key,
    enc.encode(plainText)
  );

  return JSON.stringify({
    encrypted: true,
    version: 1,
    salt: Array.from(salt),
    iv: Array.from(iv),
    cipherText: Array.from(new Uint8Array(cipherBuffer))
  });
}

async function decryptBackupData(encryptedObj, password) {
  const salt = new Uint8Array(encryptedObj.salt);
  const iv = new Uint8Array(encryptedObj.iv);
  const cipherBytes = new Uint8Array(encryptedObj.cipherText);
  const key = await getKey(password, salt);

  const decryptedBuffer = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv },
    key,
    cipherBytes
  );

  const dec = new TextDecoder();
  return dec.decode(decryptedBuffer);
}
